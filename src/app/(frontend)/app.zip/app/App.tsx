import { UnifiedCommunicationPlatform } from './components/UnifiedCommunicationPlatform';

export default function App() {
  return <UnifiedCommunicationPlatform />;
}
