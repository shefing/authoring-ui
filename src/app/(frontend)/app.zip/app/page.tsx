'use client'

import App from './App'
import './index.css'

export default function Page() {
  return <App />
}
