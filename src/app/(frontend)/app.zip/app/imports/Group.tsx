import svgPaths from "./svg-so1l6otz5z";

function Group() {
  return (
    <div className="absolute contents inset-0" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 175 38">
        <g id="Group">
          <path d={svgPaths.p155ba800} fill="url(#paint0_linear_57_435)" id="Vector" />
          <g id="Clip path group">
            <mask height="38" id="mask0_57_435" maskUnits="userSpaceOnUse" style={{ maskType: "luminance" }} width="175" x="0" y="0">
              <g id="SVGID_00000071548168473768805350000001817490848782264244_">
                <path d={svgPaths.p155ba800} fill="var(--fill-0, white)" id="Vector_2" />
              </g>
            </mask>
            <g mask="url(#mask0_57_435)">
              <path d={svgPaths.p10c8c200} fill="url(#paint1_linear_57_435)" id="Vector_3" />
            </g>
          </g>
        </g>
        <defs>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_57_435" x1="40.2247" x2="143.293" y1="75.0006" y2="-31.0361">
            <stop offset="0.025" stopColor="#4C4EAC" />
            <stop offset="0.0741" stopColor="#544DB0" />
            <stop offset="0.1482" stopColor="#684ABC" />
            <stop offset="0.2202" stopColor="#8346CA" />
            <stop offset="0.2535" stopColor="#9041CD" />
            <stop offset="0.3149" stopColor="#B233D6" />
            <stop offset="0.3403" stopColor="#C22DDA" />
            <stop offset="0.4131" stopColor="#E813A9" />
            <stop offset="0.4561" stopColor="#F4248F" />
            <stop offset="0.4883" stopColor="#FF3378" />
            <stop offset="0.5469" stopColor="#FF685B" />
            <stop offset="0.6003" stopColor="#FF7856" />
            <stop offset="0.6558" stopColor="#FE8750" />
            <stop offset="0.8884" stopColor="#FCC13A" />
            <stop offset="1" stopColor="#FBD831" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint1_linear_57_435" x1="20.0949" x2="207.515" y1="61.1742" y2="-67.0138">
            <stop offset="0.025" stopColor="#4C4EAC" />
            <stop offset="0.0741" stopColor="#544DB0" />
            <stop offset="0.1482" stopColor="#684ABC" />
            <stop offset="0.2202" stopColor="#8346CA" />
            <stop offset="0.2535" stopColor="#9041CD" />
            <stop offset="0.3149" stopColor="#B233D6" />
            <stop offset="0.3403" stopColor="#C22DDA" />
            <stop offset="0.4131" stopColor="#E813A9" />
            <stop offset="0.4561" stopColor="#F4248F" />
            <stop offset="0.4883" stopColor="#FF3378" />
            <stop offset="0.5469" stopColor="#FF685B" />
            <stop offset="0.6003" stopColor="#FF7856" />
            <stop offset="0.6558" stopColor="#FE8750" />
            <stop offset="0.8884" stopColor="#FCC13A" />
            <stop offset="1" stopColor="#FBD831" />
          </linearGradient>
        </defs>
      </svg>
    </div>
  );
}

function Group1() {
  return (
    <div className="absolute contents inset-0" data-name="Group">
      <Group />
    </div>
  );
}

export default function Group2() {
  return (
    <div className="relative size-full" data-name="Group">
      <Group1 />
    </div>
  );
}