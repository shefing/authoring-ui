import svgPaths from "./svg-um79usum5d";

function Icon() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d="M2.66667 8H13.3333" id="Vector" stroke="var(--stroke-0, #CAD5E2)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M2.66667 12H13.3333" id="Vector_2" stroke="var(--stroke-0, #CAD5E2)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M2.66667 4H13.3333" id="Vector_3" stroke="var(--stroke-0, #CAD5E2)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Button() {
  return (
    <div className="relative rounded-[8px] shrink-0 size-[32px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <Icon />
      </div>
    </div>
  );
}

function Icon1() {
  return (
    <div className="h-[33.108px] relative shrink-0 w-[150px]" data-name="Icon">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid overflow-clip relative rounded-[inherit] size-full">
        <p className="absolute font-['Inter:Bold',sans-serif] font-bold inset-[-2.04%_24.16%_14.45%_4.5%] leading-[normal] not-italic text-[24.324px] text-black text-nowrap">Riverbed</p>
      </div>
    </div>
  );
}

function RiverbedLogo() {
  return (
    <div className="h-[33.094px] relative shrink-0 w-[128px]" data-name="RiverbedLogo">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center relative size-full">
        <Icon1 />
      </div>
    </div>
  );
}

function Text() {
  return (
    <div className="absolute content-stretch flex h-[16px] items-start left-0 top-0 w-[25.547px]" data-name="Text">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[normal] not-italic relative shrink-0 text-[#e2e8f0] text-[13px] text-center text-nowrap tracking-[-0.0762px]">App</p>
    </div>
  );
}

function Text1() {
  return (
    <div className="absolute content-stretch flex h-[16px] items-start left-[25.55px] top-0 w-[60.094px]" data-name="Text">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[normal] not-italic relative shrink-0 text-[#cad5e2] text-[13px] text-center text-nowrap tracking-[-0.0762px]">{` : Aternity`}</p>
    </div>
  );
}

function AppFilterDropdown() {
  return (
    <div className="h-[16px] relative shrink-0 w-[85.641px]" data-name="AppFilterDropdown">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Text />
        <Text1 />
      </div>
    </div>
  );
}

function AppFilterDropdown1() {
  return (
    <div className="h-[4px] relative w-[5px]" data-name="AppFilterDropdown">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid size-full" />
    </div>
  );
}

function SlotClone() {
  return (
    <div className="absolute bg-[#3d3864] content-stretch flex gap-[10px] h-[32px] items-center justify-center left-0 p-px rounded-[4px] top-0 w-[122.641px]" data-name="SlotClone">
      <div aria-hidden="true" className="absolute border border-[rgba(255,255,255,0.2)] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <AppFilterDropdown />
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none rotate-[180deg]">
          <AppFilterDropdown1 />
        </div>
      </div>
    </div>
  );
}

function Text2() {
  return (
    <div className="absolute content-stretch flex h-[16px] items-start left-0 top-0 w-[43.063px]" data-name="Text">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[normal] not-italic relative shrink-0 text-[#e2e8f0] text-[13px] text-center text-nowrap tracking-[-0.0762px]">Tenant</p>
    </div>
  );
}

function Text3() {
  return (
    <div className="absolute content-stretch flex h-[16px] items-start left-[43.06px] top-0 w-[78.766px]" data-name="Text">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[normal] not-italic relative shrink-0 text-[#cad5e2] text-[13px] text-center text-nowrap tracking-[-0.0762px]">{` : Production`}</p>
    </div>
  );
}

function TenantFilterDropdown() {
  return (
    <div className="h-[16px] relative shrink-0 w-[121.828px]" data-name="TenantFilterDropdown">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Text2 />
        <Text3 />
      </div>
    </div>
  );
}

function TenantFilterDropdown1() {
  return (
    <div className="h-[4px] relative w-[5px]" data-name="TenantFilterDropdown">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid size-full" />
    </div>
  );
}

function SlotClone1() {
  return (
    <div className="absolute bg-[#3d3864] content-stretch flex gap-[10px] h-[32px] items-center justify-center left-[134.64px] p-px rounded-[4px] top-0 w-[158.828px]" data-name="SlotClone">
      <div aria-hidden="true" className="absolute border border-[rgba(255,255,255,0.2)] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <TenantFilterDropdown />
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none rotate-[180deg]">
          <TenantFilterDropdown1 />
        </div>
      </div>
    </div>
  );
}

function Icon2() {
  return (
    <div className="absolute left-[12px] size-[16px] top-[7px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p12824f00} id="Vector" stroke="var(--stroke-0, #E2E8F0)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Badge() {
  return (
    <div className="absolute bg-[#4e4fa9] h-[16px] left-[100.8px] rounded-[8px] top-[7px] w-[19.766px]" data-name="Badge">
      <div className="content-stretch flex items-center justify-center overflow-clip px-[7px] py-[3px] relative rounded-[inherit] size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[12px] text-center text-nowrap text-white">1</p>
      </div>
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function Icon3() {
  return (
    <div className="absolute left-[136.56px] size-[16px] top-[7px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d="M4 6L8 10L12 6" id="Vector" stroke="var(--stroke-0, #E2E8F0)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Button1() {
  return (
    <div className="absolute bg-[#3d3864] border border-[rgba(255,255,255,0.2)] border-solid h-[32px] left-[305.47px] rounded-[8px] top-0 w-[166.563px]" data-name="Button">
      <Icon2 />
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-[64.5px] not-italic text-[#e2e8f0] text-[14px] text-center text-nowrap top-[5px] tracking-[-0.1504px] translate-x-[-50%]">Filters</p>
      <Badge />
      <Icon3 />
    </div>
  );
}

function MainFilters() {
  return (
    <div className="basis-0 grow h-[32px] min-h-px min-w-px relative shrink-0" data-name="MainFilters">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <SlotClone />
        <SlotClone1 />
        <Button1 />
      </div>
    </div>
  );
}

function Container() {
  return (
    <div className="h-[32px] relative shrink-0 w-[676.031px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[12px] items-center relative size-full">
        <Button />
        <RiverbedLogo />
        <MainFilters />
      </div>
    </div>
  );
}

function Input() {
  return (
    <div className="absolute bg-white h-[32px] left-0 rounded-[8px] top-0 w-[320px]" data-name="Input">
      <div className="content-stretch flex items-center overflow-clip pl-[36px] pr-[40px] py-[4px] relative rounded-[inherit] size-full">
        <p className="font-['Inter:Regular',sans-serif] font-normal leading-[normal] not-italic relative shrink-0 text-[#6c757d] text-[14px] text-nowrap tracking-[-0.1504px]">Search devices, users, dashboards... (Ctrl+K)</p>
      </div>
      <div aria-hidden="true" className="absolute border border-[#e9ecef] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function Icon4() {
  return (
    <div className="absolute left-[12px] size-[16px] top-[8px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d="M14 14L11.1066 11.1067" id="Vector" stroke="var(--stroke-0, #6C757D)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p107a080} id="Vector_2" stroke="var(--stroke-0, #6C757D)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function SlotClone2() {
  return (
    <div className="absolute h-[32px] left-[119.61px] top-0 w-[320px]" data-name="SlotClone">
      <Input />
      <Icon4 />
    </div>
  );
}

function Icon5() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g clipPath="url(#clip0_31_2374)" id="Icon">
          <path d={svgPaths.p3cec7170} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M13.3333 2V4.66667" id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M14.6667 3.33333H12" id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M2.66667 11.3333V12.6667" id="Vector_4" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M3.33333 12H2" id="Vector_5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
        <defs>
          <clipPath id="clip0_31_2374">
            <rect fill="white" height="16" width="16" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Button2() {
  return (
    <div className="absolute bg-[rgba(255,255,255,0.1)] content-stretch flex items-center justify-center left-[447.61px] p-px rounded-[8px] size-[32px] top-0" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[rgba(255,255,255,0.3)] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <Icon5 />
    </div>
  );
}

function Container1() {
  return (
    <div className="basis-0 grow h-[32px] min-h-px min-w-px relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <SlotClone2 />
        <Button2 />
      </div>
    </div>
  );
}

function Button3() {
  return (
    <div className="bg-[#ff6900] h-[28px] relative rounded-[8px] shadow-[0px_1px_3px_0px_rgba(0,0,0,0.1),0px_1px_2px_-1px_rgba(0,0,0,0.1)] shrink-0 w-[93.391px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center px-[12px] py-[4px] relative size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[12px] text-center text-nowrap text-white">{`What's New`}</p>
      </div>
    </div>
  );
}

function Icon6() {
  return (
    <div className="absolute left-[9px] size-[12px] top-[5px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
        <g id="Icon">
          <path d="M6 10H6.005" id="Vector" stroke="var(--stroke-0, #00D492)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p31254580} id="Vector_2" stroke="var(--stroke-0, #00D492)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p32674500} id="Vector_3" stroke="var(--stroke-0, #00D492)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p26a3d980} id="Vector_4" stroke="var(--stroke-0, #00D492)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
      </svg>
    </div>
  );
}

function Badge1() {
  return (
    <div className="bg-[rgba(0,188,125,0.1)] h-[22px] relative rounded-[8px] shrink-0 w-[99.125px]" data-name="Badge">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid overflow-clip relative rounded-[inherit] size-full">
        <Icon6 />
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[16px] left-[27px] not-italic text-[#00d492] text-[12px] text-nowrap top-[3px]">Connected</p>
      </div>
      <div aria-hidden="true" className="absolute border border-[rgba(0,188,125,0.5)] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function Icon7() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p7ad6800} id="Vector" stroke="var(--stroke-0, #51A2FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M5.33333 14H10.6667" id="Vector_2" stroke="var(--stroke-0, #51A2FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M8 11.3333V14" id="Vector_3" stroke="var(--stroke-0, #51A2FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Text4() {
  return (
    <div className="absolute content-stretch flex h-[17px] items-start left-0 top-px w-[35.609px]" data-name="Text">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[20px] not-italic relative shrink-0 text-[#8ec5ff] text-[14px] text-nowrap tracking-[-0.1504px]">1,247</p>
    </div>
  );
}

function Text5() {
  return (
    <div className="absolute content-stretch flex h-[17px] items-start left-[39.61px] top-px w-[49.625px]" data-name="Text">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[20px] not-italic relative shrink-0 text-[#cad5e2] text-[14px] text-nowrap tracking-[-0.1504px]">devices</p>
    </div>
  );
}

function Container2() {
  return (
    <div className="basis-0 grow h-[20px] min-h-px min-w-px relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Text4 />
        <Text5 />
      </div>
    </div>
  );
}

function Container3() {
  return (
    <div className="basis-0 bg-[rgba(255,255,255,0.05)] grow h-[34px] min-h-px min-w-px relative rounded-[8px] shrink-0" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[rgba(255,255,255,0.1)] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <div className="flex flex-row items-center size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] items-center px-[13px] py-px relative size-full">
          <Icon7 />
          <Container2 />
        </div>
      </div>
    </div>
  );
}

function Icon8() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.pd3d3f00} id="Vector" stroke="var(--stroke-0, #FFB900)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M8 6V8.66667" id="Vector_2" stroke="var(--stroke-0, #FFB900)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M8 11.3333H8.00667" id="Vector_3" stroke="var(--stroke-0, #FFB900)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Text6() {
  return (
    <div className="absolute content-stretch flex h-[17px] items-start left-0 top-px w-[17.313px]" data-name="Text">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[20px] not-italic relative shrink-0 text-[#ffd230] text-[14px] text-nowrap tracking-[-0.1504px]">23</p>
    </div>
  );
}

function Text7() {
  return (
    <div className="absolute content-stretch flex h-[17px] items-start left-[21.31px] top-px w-[36.109px]" data-name="Text">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[20px] not-italic relative shrink-0 text-[#cad5e2] text-[14px] text-nowrap tracking-[-0.1504px]">alerts</p>
    </div>
  );
}

function Container4() {
  return (
    <div className="basis-0 grow h-[20px] min-h-px min-w-px relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Text6 />
        <Text7 />
      </div>
    </div>
  );
}

function Container5() {
  return (
    <div className="bg-[rgba(255,255,255,0.05)] h-[34px] relative rounded-[8px] shrink-0 w-[107.422px]" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[rgba(255,255,255,0.1)] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] items-center px-[13px] py-px relative size-full">
        <Icon8 />
        <Container4 />
      </div>
    </div>
  );
}

function Container6() {
  return (
    <div className="basis-0 grow h-[34px] min-h-px min-w-px relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[16px] items-center relative size-full">
        <Container3 />
        <Container5 />
      </div>
    </div>
  );
}

function Badge2() {
  return (
    <div className="basis-0 bg-white grow h-[22px] min-h-px min-w-px relative rounded-[8px] shrink-0" data-name="Badge">
      <div className="flex flex-row items-center justify-center overflow-clip rounded-[inherit] size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center px-[9px] py-[3px] relative size-full">
          <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#314158] text-[12px] text-center text-nowrap">Administrator</p>
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[#cad5e2] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function Icon9() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d="M4 6L8 10L12 6" id="Vector" stroke="var(--stroke-0, #45556C)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function UserSwitcher() {
  return (
    <div className="absolute content-stretch flex gap-[8px] h-[22px] items-center left-[56px] top-[13px] w-[120.563px]" data-name="UserSwitcher">
      <Badge2 />
      <Icon9 />
    </div>
  );
}

function Text8() {
  return (
    <div className="basis-0 bg-[#4e4fa9] grow h-[32px] min-h-px min-w-px relative rounded-[3.35544e+07px] shrink-0" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[20px] not-italic relative shrink-0 text-[14px] text-center text-nowrap text-white tracking-[-0.1504px]">JD</p>
      </div>
    </div>
  );
}

function PrimitiveSpan() {
  return (
    <div className="absolute content-stretch flex items-start left-[8px] overflow-clip rounded-[3.35544e+07px] size-[32px] top-[8px]" data-name="Primitive.span">
      <Text8 />
    </div>
  );
}

function Button4() {
  return (
    <div className="h-[48px] relative rounded-[8px] shrink-0 w-[184.563px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <UserSwitcher />
        <PrimitiveSpan />
      </div>
    </div>
  );
}

function Icon10() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g clipPath="url(#clip0_31_2421)" id="Icon">
          <path d={svgPaths.p39ee6532} id="Vector" stroke="var(--stroke-0, #CAD5E2)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p17940e00} id="Vector_2" stroke="var(--stroke-0, #CAD5E2)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M8 11.3333H8.00667" id="Vector_3" stroke="var(--stroke-0, #CAD5E2)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
        <defs>
          <clipPath id="clip0_31_2421">
            <rect fill="white" height="16" width="16" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Button5() {
  return (
    <div className="relative rounded-[8px] shrink-0 size-[32px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <Icon10 />
      </div>
    </div>
  );
}

function Container7() {
  return (
    <div className="h-[48px] relative shrink-0 w-[735.734px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[16px] items-center relative size-full">
        <Button3 />
        <Badge1 />
        <Container6 />
        <Button4 />
        <Button5 />
      </div>
    </div>
  );
}

function Header() {
  return (
    <div className="bg-[#323157] h-[57px] relative shrink-0 w-[2059px]" data-name="Header">
      <div aria-hidden="true" className="absolute border-[#4a4570] border-[0px_0px_1px] border-solid inset-0 pointer-events-none" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-between pb-px pt-0 px-[24px] relative size-full">
        <Container />
        <Container1 />
        <Container7 />
      </div>
    </div>
  );
}

function Icon11() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p203476e0} id="Vector" stroke="var(--stroke-0, #6C757D)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M12.6667 8H3.33333" id="Vector_2" stroke="var(--stroke-0, #6C757D)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Toolbar() {
  return (
    <div className="h-[16px] relative shrink-0 w-[28.391px]" data-name="Toolbar">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#6c757d] text-[12px] text-center text-nowrap">Back</p>
      </div>
    </div>
  );
}

function Button6() {
  return (
    <div className="h-[28px] relative rounded-[8px] shrink-0 w-[68.391px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[4px] items-center justify-center relative size-full">
        <Icon11 />
        <Toolbar />
      </div>
    </div>
  );
}

function Container8() {
  return (
    <div className="bg-[rgba(0,0,0,0.15)] h-[16px] relative shrink-0 w-px" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid size-full" />
    </div>
  );
}

function Icon12() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p3a151200} id="Vector" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p1811de30} id="Vector_2" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Button7() {
  return (
    <div className="relative rounded-[8px] shrink-0 size-[32px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <Icon12 />
      </div>
    </div>
  );
}

function Icon13() {
  return (
    <div className="relative shrink-0 size-[12px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
        <g id="Icon">
          <path d="M4.5 9L7.5 6L4.5 3" id="Vector" stroke="var(--stroke-0, #6C757D)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
      </svg>
    </div>
  );
}

function Button8() {
  return (
    <div className="h-[24px] relative rounded-[8px] shrink-0 w-[62.344px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center px-[8px] py-0 relative size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[20px] not-italic relative shrink-0 text-[#6c757d] text-[14px] text-center text-nowrap tracking-[-0.1504px]">Agents</p>
      </div>
    </div>
  );
}

function Button9() {
  return (
    <div className="basis-0 grow h-[24px] min-h-px min-w-px relative rounded-[8px] shrink-0" data-name="Button">
      <div className="flex flex-row items-center justify-center size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center px-[8px] py-0 relative size-full">
          <p className="font-['Inter:Medium',sans-serif] font-medium leading-[20px] not-italic relative shrink-0 text-[#6c757d] text-[14px] text-center text-nowrap tracking-[-0.1504px]">Unified Agent</p>
        </div>
      </div>
    </div>
  );
}

function Button10() {
  return (
    <div className="h-[24px] relative rounded-[8px] shrink-0 w-[59.5px]" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[rgba(108,117,125,0.3)] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center px-[9px] py-px relative size-full">
        <p className="font-['Inter:Medium_Italic',sans-serif] font-medium italic leading-[20px] relative shrink-0 text-[14px] text-[rgba(108,117,125,0.6)] text-center text-nowrap tracking-[-0.1504px]">Select</p>
      </div>
    </div>
  );
}

function Container9() {
  return (
    <div className="basis-0 grow h-[32px] min-h-px min-w-px relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center relative size-full">
        <Button7 />
        <Icon13 />
        <Button8 />
        <Icon13 />
        <Button9 />
        <Icon13 />
        <Button10 />
      </div>
    </div>
  );
}

function Container10() {
  return (
    <div className="h-[32px] relative shrink-0 w-[381.219px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] items-center relative size-full">
        <Button6 />
        <Container8 />
        <Container9 />
      </div>
    </div>
  );
}

function Icon14() {
  return (
    <div className="absolute left-[11px] size-[16px] top-[8px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d="M4 2L13.3333 8L4 14V2Z" id="Vector" stroke="var(--stroke-0, #F50505)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Button11() {
  return (
    <div className="basis-0 bg-white grow h-[32px] min-h-px min-w-px relative rounded-[8px] shrink-0" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[#fb2c36] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Icon14 />
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-[99px] not-italic text-[#f50505] text-[14px] text-center text-nowrap top-[6px] tracking-[-0.1504px] translate-x-[-50%]">Actions Simulator</p>
      </div>
    </div>
  );
}

function Icon15() {
  return (
    <div className="absolute left-[11px] size-[16px] top-[8px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g clipPath="url(#clip0_31_2385)" id="Icon">
          <path d={svgPaths.p2d09d900} id="Vector" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
        <defs>
          <clipPath id="clip0_31_2385">
            <rect fill="white" height="16" width="16" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Button12() {
  return (
    <div className="bg-[#f8f9fa] h-[32px] opacity-50 relative rounded-[8px] shrink-0 w-[159.406px]" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.15)] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Icon15 />
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-[95.5px] not-italic text-[#0a0a0a] text-[14px] text-center text-nowrap top-[6px] tracking-[-0.1504px] translate-x-[-50%]">Running Actions</p>
      </div>
    </div>
  );
}

function Icon16() {
  return (
    <div className="absolute left-[11px] size-[16px] top-[8px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p2d13300} fill="var(--fill-0, #4E4FA9)" id="Vector" stroke="var(--stroke-0, #4E4FA9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Button13() {
  return (
    <div className="bg-[#f8f9fa] h-[32px] relative rounded-[8px] shrink-0 w-[113.266px]" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[#4e4fa9] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Icon16 />
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-[72px] not-italic text-[#4e4fa9] text-[14px] text-center text-nowrap top-[6px] tracking-[-0.1504px] translate-x-[-50%]">Favorited</p>
      </div>
    </div>
  );
}

function Icon17() {
  return (
    <div className="absolute left-[11px] size-[16px] top-[8px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p19987d80} id="Vector" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M14 2V5.33333H10.6667" id="Vector_2" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p2a3e9c80} id="Vector_3" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M5.33333 10.6667H2V14" id="Vector_4" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Button14() {
  return (
    <div className="bg-[#f8f9fa] h-[32px] relative rounded-[8px] shrink-0 w-[102.984px]" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.15)] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Icon17 />
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-[66.5px] not-italic text-[#0a0a0a] text-[14px] text-center text-nowrap top-[6px] tracking-[-0.1504px] translate-x-[-50%]">Refresh</p>
      </div>
    </div>
  );
}

function Icon18() {
  return (
    <div className="absolute left-[11px] size-[16px] top-[8px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p154e6c80} id="Vector" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p22879fc0} id="Vector_2" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Button15() {
  return (
    <div className="bg-[#f8f9fa] h-[32px] relative rounded-[8px] shrink-0 w-[95.344px]" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.15)] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Icon18 />
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-[63px] not-italic text-[#0a0a0a] text-[14px] text-center text-nowrap top-[6px] tracking-[-0.1504px] translate-x-[-50%]">Export</p>
      </div>
    </div>
  );
}

function PrimitiveDiv() {
  return (
    <div className="bg-[rgba(0,0,0,0.15)] h-0 relative shrink-0 w-px" data-name="Primitive.div">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid size-full" />
    </div>
  );
}

function Icon19() {
  return (
    <div className="absolute left-[10px] size-[16px] top-[8px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d="M3.33333 8H12.6667" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M8 3.33333V12.6667" id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Button16() {
  return (
    <div className="bg-[#4e4fa9] h-[32px] relative rounded-[8px] shrink-0 w-[109.406px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Icon19 />
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-[70.5px] not-italic text-[14px] text-center text-nowrap text-white top-[6px] tracking-[-0.1504px] translate-x-[-50%]">Add New</p>
      </div>
    </div>
  );
}

function Icon20() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p36e45a00} id="Vector" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p1a14b300} id="Vector_2" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p2295f880} id="Vector_3" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Button17() {
  return (
    <div className="bg-[#f8f9fa] h-[32px] relative rounded-[8px] shrink-0 w-[38px]" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.15)] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center p-px relative size-full">
        <Icon20 />
      </div>
    </div>
  );
}

function Container11() {
  return (
    <div className="h-[32px] relative shrink-0 w-[843.781px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] items-center relative size-full">
        <Button11 />
        <Button12 />
        <Button13 />
        <Button14 />
        <Button15 />
        <PrimitiveDiv />
        <Button16 />
        <Button17 />
      </div>
    </div>
  );
}

function Container12() {
  return (
    <div className="h-[32px] relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between pl-[30px] pr-0 py-0 relative size-full">
          <Container10 />
          <Container11 />
        </div>
      </div>
    </div>
  );
}

function Toolbar1() {
  return (
    <div className="bg-white h-[57px] relative shrink-0 w-[2059px]" data-name="Toolbar">
      <div aria-hidden="true" className="absolute border-[0px_0px_1px] border-[rgba(0,0,0,0.15)] border-solid inset-0 pointer-events-none" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pb-px pt-[12px] px-[24px] relative size-full">
        <Container12 />
      </div>
    </div>
  );
}

function Heading() {
  return (
    <div className="h-[20px] relative shrink-0 w-[179.859px]" data-name="Heading 3">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-0 not-italic text-[#0a0a0a] text-[14px] text-nowrap top-0 tracking-[-0.1504px]">Unified Agent Management</p>
      </div>
    </div>
  );
}

function Icon21() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p7138080} id="Vector" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M8 14.6667V12.6667" id="Vector_2" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Button18() {
  return (
    <div className="bg-white relative rounded-[8px] shadow-[0px_1px_3px_0px_rgba(0,0,0,0.1),0px_1px_2px_-1px_rgba(0,0,0,0.1)] shrink-0 size-[24px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <Icon21 />
      </div>
    </div>
  );
}

function Icon22() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p1cfa1bc0} id="Vector" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p2cfdb900} id="Vector_2" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p17f25d40} id="Vector_3" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p15fb5e00} id="Vector_4" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Button19() {
  return (
    <div className="basis-0 grow h-[24px] min-h-px min-w-px relative rounded-[8px] shrink-0" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <Icon22 />
      </div>
    </div>
  );
}

function Container13() {
  return (
    <div className="bg-[#e9ecef] h-[28px] relative rounded-[8px] shrink-0 w-[54px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[2px] items-center px-[2px] py-0 relative size-full">
        <Button18 />
        <Button19 />
      </div>
    </div>
  );
}

function Container14() {
  return (
    <div className="content-stretch flex h-[28px] items-center justify-between relative shrink-0 w-full" data-name="Container">
      <Heading />
      <Container13 />
    </div>
  );
}

function Container15() {
  return (
    <div className="h-[57px] relative shrink-0 w-[513.5px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[0px_0px_1px] border-[rgba(0,0,0,0.15)] border-solid inset-0 pointer-events-none" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pb-px pt-[16px] px-[16px] relative size-full">
        <Container14 />
      </div>
    </div>
  );
}

function Input1() {
  return (
    <div className="absolute bg-[#f1f3f4] h-[32px] left-0 rounded-[8px] top-0 w-[481.5px]" data-name="Input">
      <div className="content-stretch flex items-center overflow-clip pl-[36px] pr-[12px] py-[4px] relative rounded-[inherit] size-full">
        <p className="font-['Inter:Regular',sans-serif] font-normal leading-[normal] not-italic relative shrink-0 text-[#6c757d] text-[14px] text-nowrap tracking-[-0.1504px]">{`Search packages & modules...`}</p>
      </div>
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function Icon23() {
  return (
    <div className="absolute left-[12px] size-[14px] top-[9px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="Icon">
          <path d="M12.25 12.25L9.71833 9.71834" id="Vector" stroke="var(--stroke-0, #6C757D)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
          <path d={svgPaths.p8cdb700} id="Vector_2" stroke="var(--stroke-0, #6C757D)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
        </g>
      </svg>
    </div>
  );
}

function Container16() {
  return (
    <div className="h-[32px] relative shrink-0 w-full" data-name="Container">
      <Input1 />
      <Icon23 />
    </div>
  );
}

function Button20() {
  return (
    <div className="bg-[#4e4fa9] h-[24px] relative rounded-[8px] shrink-0 w-[30.734px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center px-[8px] py-0 relative size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[12px] text-center text-nowrap text-white">All</p>
      </div>
    </div>
  );
}

function Button21() {
  return (
    <div className="bg-[#f8f9fa] h-[24px] relative rounded-[8px] shrink-0 w-[96.813px]" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.15)] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center px-[9px] py-px relative size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#0a0a0a] text-[12px] text-center text-nowrap">Unified Agent</p>
      </div>
    </div>
  );
}

function Icon24() {
  return (
    <div className="absolute left-[11px] size-[16px] top-[4px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p2bb95e00} id="Vector" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M8 14.6667V8" id="Vector_2" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p14df0fc0} id="Vector_3" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M5 2.84667L11 6.28" id="Vector_4" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Button22() {
  return (
    <div className="bg-[#f8f9fa] h-[24px] relative rounded-[8px] shrink-0 w-[103.359px]" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.15)] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Icon24 />
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[16px] left-[65px] not-italic text-[#0a0a0a] text-[12px] text-center text-nowrap top-[4px] translate-x-[-50%]">Packages</p>
      </div>
    </div>
  );
}

function Icon25() {
  return (
    <div className="absolute left-[11px] size-[16px] top-[4px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g clipPath="url(#clip0_31_2447)" id="Icon">
          <path d={svgPaths.p15f82200} id="Vector" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p375323f0} id="Vector_2" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M4 4H4.00667" id="Vector_3" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M4 12H4.00667" id="Vector_4" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
        <defs>
          <clipPath id="clip0_31_2447">
            <rect fill="white" height="16" width="16" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Button23() {
  return (
    <div className="bg-[#f8f9fa] h-[24px] relative rounded-[8px] shrink-0 w-[97.156px]" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.15)] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Icon25 />
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[16px] left-[62px] not-italic text-[#0a0a0a] text-[12px] text-center text-nowrap top-[4px] translate-x-[-50%]">Modules</p>
      </div>
    </div>
  );
}

function Container17() {
  return (
    <div className="content-stretch flex gap-[4px] h-[24px] items-center relative shrink-0 w-full" data-name="Container">
      <Button20 />
      <Button21 />
      <Button22 />
      <Button23 />
    </div>
  );
}

function Container18() {
  return (
    <div className="h-[101px] relative shrink-0 w-[513.5px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[0px_0px_1px] border-[rgba(0,0,0,0.15)] border-solid inset-0 pointer-events-none" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[12px] items-start pb-px pt-[16px] px-[16px] relative size-full">
        <Container16 />
        <Container17 />
      </div>
    </div>
  );
}

function Icon26() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="Icon">
          <path d="M3.5 5.25L7 8.75L10.5 5.25" id="Vector" stroke="var(--stroke-0, #6C757D)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
        </g>
      </svg>
    </div>
  );
}

function Icon27() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="Icon">
          <path d={svgPaths.p55f200} id="Vector" stroke="var(--stroke-0, #6C757D)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
          <path d={svgPaths.p4c1f200} id="Vector_2" stroke="var(--stroke-0, #6C757D)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
        </g>
      </svg>
    </div>
  );
}

function Text9() {
  return (
    <div className="h-[20px] relative shrink-0 w-[87.875px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#0a0a0a] text-[14px] text-nowrap top-0 tracking-[-0.1504px]">Unified Agent</p>
      </div>
    </div>
  );
}

function Container19() {
  return (
    <div className="absolute content-stretch flex gap-[8px] h-[32px] items-center left-0 pl-[8px] pr-0 py-0 rounded-[4px] top-0 w-[481.5px]" data-name="Container">
      <Icon26 />
      <Icon27 />
      <Text9 />
    </div>
  );
}

function Icon28() {
  return (
    <div className="absolute left-[8px] size-[14px] top-[9px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="Icon">
          <path d={svgPaths.p2fc48000} id="Vector" stroke="var(--stroke-0, #4E4FA9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
          <path d={svgPaths.p4c1f200} id="Vector_2" stroke="var(--stroke-0, #4E4FA9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
        </g>
      </svg>
    </div>
  );
}

function Container20() {
  return (
    <div className="absolute bg-[rgba(78,79,169,0.15)] h-[32px] left-[24px] rounded-[4px] top-[34px] w-[457.5px]" data-name="Container">
      <Icon28 />
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[30px] not-italic text-[#4e4fa9] text-[14px] text-nowrap top-[6px] tracking-[-0.1504px]">Overview</p>
    </div>
  );
}

function Container21() {
  return (
    <div className="h-[66px] relative shrink-0 w-full" data-name="Container">
      <Container19 />
      <Container20 />
    </div>
  );
}

function Icon29() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="Icon">
          <path d="M3.5 5.25L7 8.75L10.5 5.25" id="Vector" stroke="var(--stroke-0, #6C757D)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
        </g>
      </svg>
    </div>
  );
}

function Icon30() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="Icon">
          <path d={svgPaths.p375e0800} id="Vector" stroke="var(--stroke-0, #6C757D)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
          <path d="M7 12.8333V7" id="Vector_2" stroke="var(--stroke-0, #6C757D)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
          <path d={svgPaths.p21a6a770} id="Vector_3" stroke="var(--stroke-0, #6C757D)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
          <path d="M4.375 2.49083L9.625 5.49499" id="Vector_4" stroke="var(--stroke-0, #6C757D)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
        </g>
      </svg>
    </div>
  );
}

function Text10() {
  return (
    <div className="basis-0 grow h-[20px] min-h-px min-w-px relative shrink-0" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#0a0a0a] text-[14px] text-nowrap top-0 tracking-[-0.1504px]">Packages</p>
      </div>
    </div>
  );
}

function Container22() {
  return (
    <div className="h-[20px] relative shrink-0 w-[105.969px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] items-center relative size-full">
        <Icon29 />
        <Icon30 />
        <Text10 />
      </div>
    </div>
  );
}

function Icon31() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d="M3.33333 8H12.6667" id="Vector" stroke="var(--stroke-0, #4E4FA9)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.6" strokeWidth="1.33333" />
          <path d="M8 3.33333V12.6667" id="Vector_2" stroke="var(--stroke-0, #4E4FA9)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.6" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Button24() {
  return (
    <div className="relative rounded-[8px] shrink-0 size-[20px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <Icon31 />
      </div>
    </div>
  );
}

function Container23() {
  return (
    <div className="absolute content-stretch flex h-[32px] items-center justify-between left-0 px-[8px] py-0 rounded-[4px] top-0 w-[481.5px]" data-name="Container">
      <Container22 />
      <Button24 />
    </div>
  );
}

function Icon32() {
  return (
    <div className="relative shrink-0 size-[12px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
        <g id="Icon">
          <path d="M4.5 9L7.5 6L4.5 3" id="Vector" stroke="var(--stroke-0, #6C757D)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.6" />
        </g>
      </svg>
    </div>
  );
}

function Icon33() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p2bb95e00} id="Vector" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M8 14.6667V8" id="Vector_2" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p14df0fc0} id="Vector_3" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M5 2.84666L11 6.27999" id="Vector_4" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Text11() {
  return (
    <div className="basis-0 grow h-[20px] min-h-px min-w-px relative shrink-0" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid overflow-clip relative rounded-[inherit] size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#0a0a0a] text-[14px] text-nowrap top-0 tracking-[-0.1504px]">Aternity Package</p>
      </div>
    </div>
  );
}

function Container24() {
  return (
    <div className="bg-[rgba(0,201,80,0.7)] relative rounded-[3.35544e+07px] shrink-0 size-[6px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid size-full" />
    </div>
  );
}

function Container25() {
  return (
    <div className="absolute content-stretch flex gap-[8px] h-[20px] items-center left-[8px] top-[6px] w-[167.156px]" data-name="Container">
      <Icon32 />
      <Icon33 />
      <Text11 />
      <Container24 />
    </div>
  );
}

function Text12() {
  return (
    <div className="absolute h-[15.703px] left-[28px] top-[28px] w-[54.563px]" data-name="Text">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[15.714px] left-0 not-italic text-[11px] text-[rgba(0,166,62,0.8)] top-0 tracking-[0.0645px] w-[55px]">5 modules</p>
    </div>
  );
}

function Container26() {
  return (
    <div className="h-[49.703px] relative rounded-[4px] shrink-0 w-full" data-name="Container">
      <Container25 />
      <Text12 />
    </div>
  );
}

function Icon34() {
  return (
    <div className="relative shrink-0 size-[12px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
        <g id="Icon">
          <path d="M4.5 9L7.5 6L4.5 3" id="Vector" stroke="var(--stroke-0, #6C757D)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.6" />
        </g>
      </svg>
    </div>
  );
}

function Icon35() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p2bb95e00} id="Vector" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M8 14.6667V8" id="Vector_2" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p14df0fc0} id="Vector_3" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M5 2.84666L11 6.27999" id="Vector_4" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Text13() {
  return (
    <div className="basis-0 grow h-[20px] min-h-px min-w-px relative shrink-0" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid overflow-clip relative rounded-[inherit] size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#0a0a0a] text-[14px] text-nowrap top-0 tracking-[-0.1504px]">NPM Package</p>
      </div>
    </div>
  );
}

function Container27() {
  return (
    <div className="bg-[rgba(0,201,80,0.7)] relative rounded-[3.35544e+07px] shrink-0 size-[6px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid size-full" />
    </div>
  );
}

function Container28() {
  return (
    <div className="absolute content-stretch flex gap-[8px] h-[20px] items-center left-[8px] top-[6px] w-[147.641px]" data-name="Container">
      <Icon34 />
      <Icon35 />
      <Text13 />
      <Container27 />
    </div>
  );
}

function Text14() {
  return (
    <div className="absolute h-[15.703px] left-[28px] top-[28px] w-[54.656px]" data-name="Text">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[15.714px] left-0 not-italic text-[11px] text-[rgba(0,166,62,0.8)] top-0 tracking-[0.0645px] w-[55px]">3 modules</p>
    </div>
  );
}

function Container29() {
  return (
    <div className="h-[49.703px] relative rounded-[4px] shrink-0 w-full" data-name="Container">
      <Container28 />
      <Text14 />
    </div>
  );
}

function Icon36() {
  return (
    <div className="relative shrink-0 size-[12px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
        <g id="Icon">
          <path d="M4.5 9L7.5 6L4.5 3" id="Vector" stroke="var(--stroke-0, #6C757D)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.6" />
        </g>
      </svg>
    </div>
  );
}

function Icon37() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p1f2074f0} id="Vector" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M8 14.6667V8" id="Vector_2" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p14df0fc0} id="Vector_3" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M5 2.84668L11 6.28001" id="Vector_4" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Text15() {
  return (
    <div className="basis-0 grow h-[20px] min-h-px min-w-px relative shrink-0" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid overflow-clip relative rounded-[inherit] size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#0a0a0a] text-[14px] text-nowrap top-0 tracking-[-0.1504px]">Communications Package</p>
      </div>
    </div>
  );
}

function Container30() {
  return (
    <div className="bg-[rgba(108,117,125,0.3)] relative rounded-[3.35544e+07px] shrink-0 size-[6px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid size-full" />
    </div>
  );
}

function Container31() {
  return (
    <div className="content-stretch flex gap-[8px] h-[20px] items-center relative shrink-0 w-full" data-name="Container">
      <Icon36 />
      <Icon37 />
      <Text15 />
      <Container30 />
    </div>
  );
}

function Container32() {
  return (
    <div className="h-[32px] relative rounded-[4px] shrink-0 w-full" data-name="Container">
      <div className="size-full">
        <div className="content-stretch flex flex-col items-start pb-0 pl-[8px] pr-[224.703px] pt-[6px] relative size-full">
          <Container31 />
        </div>
      </div>
    </div>
  );
}

function Icon38() {
  return (
    <div className="relative shrink-0 size-[12px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
        <g id="Icon">
          <path d="M4.5 9L7.5 6L4.5 3" id="Vector" stroke="var(--stroke-0, #6C757D)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.6" />
        </g>
      </svg>
    </div>
  );
}

function Icon39() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p1f2074f0} id="Vector" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M8 14.6667V8" id="Vector_2" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p14df0fc0} id="Vector_3" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M5 2.84668L11 6.28001" id="Vector_4" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Text16() {
  return (
    <div className="basis-0 grow h-[20px] min-h-px min-w-px relative shrink-0" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid overflow-clip relative rounded-[inherit] size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#0a0a0a] text-[14px] text-nowrap top-0 tracking-[-0.1504px]">SteelHead Package</p>
      </div>
    </div>
  );
}

function Container33() {
  return (
    <div className="bg-[rgba(0,201,80,0.7)] relative rounded-[3.35544e+07px] shrink-0 size-[6px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid size-full" />
    </div>
  );
}

function Container34() {
  return (
    <div className="absolute content-stretch flex gap-[8px] h-[20px] items-center left-[8px] top-[6px] w-[183.375px]" data-name="Container">
      <Icon38 />
      <Icon39 />
      <Text16 />
      <Container33 />
    </div>
  );
}

function Text17() {
  return (
    <div className="absolute h-[15.703px] left-[28px] top-[28px] w-[52.859px]" data-name="Text">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[15.714px] left-0 not-italic text-[11px] text-[rgba(0,166,62,0.8)] top-0 tracking-[0.0645px] w-[53px]">1 modules</p>
    </div>
  );
}

function Container35() {
  return (
    <div className="h-[49.703px] relative rounded-[4px] shrink-0 w-full" data-name="Container">
      <Container34 />
      <Text17 />
    </div>
  );
}

function Container36() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[2px] h-[187.109px] items-start left-[24px] top-[34px] w-[457.5px]" data-name="Container">
      <Container26 />
      <Container29 />
      <Container32 />
      <Container35 />
    </div>
  );
}

function Container37() {
  return (
    <div className="h-[221.109px] relative shrink-0 w-full" data-name="Container">
      <Container23 />
      <Container36 />
    </div>
  );
}

function Icon40() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="Icon">
          <path d="M3.5 5.25L7 8.75L10.5 5.25" id="Vector" stroke="var(--stroke-0, #6C757D)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
        </g>
      </svg>
    </div>
  );
}

function Icon41() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="Icon">
          <path d={svgPaths.p28fd4e80} id="Vector" stroke="var(--stroke-0, #6C757D)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
          <path d="M7 12.8333V7" id="Vector_2" stroke="var(--stroke-0, #6C757D)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
          <path d={svgPaths.p21a6a770} id="Vector_3" stroke="var(--stroke-0, #6C757D)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
          <path d="M4.375 2.49084L9.625 5.49501" id="Vector_4" stroke="var(--stroke-0, #6C757D)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
        </g>
      </svg>
    </div>
  );
}

function Text18() {
  return (
    <div className="h-[20px] relative shrink-0 w-[55.094px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#0a0a0a] text-[14px] text-nowrap top-0 tracking-[-0.1504px]">Modules</p>
      </div>
    </div>
  );
}

function Container38() {
  return (
    <div className="absolute content-stretch flex gap-[8px] h-[32px] items-center left-0 pl-[8px] pr-0 py-0 rounded-[4px] top-0 w-[481.5px]" data-name="Container">
      <Icon40 />
      <Icon41 />
      <Text18 />
    </div>
  );
}

function Icon42() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="Icon">
          <path d="M5.25 10.5L8.75 7L5.25 3.5" id="Vector" stroke="var(--stroke-0, #6C757D)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
        </g>
      </svg>
    </div>
  );
}

function Icon43() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="Icon">
          <path d={svgPaths.p3bfbad00} id="Vector" stroke="var(--stroke-0, #6C757D)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
          <path d="M4.66667 12.25H9.33333" id="Vector_2" stroke="var(--stroke-0, #6C757D)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
          <path d="M7 9.91667V12.25" id="Vector_3" stroke="var(--stroke-0, #6C757D)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
        </g>
      </svg>
    </div>
  );
}

function Text19() {
  return (
    <div className="h-[20px] relative shrink-0 w-[50.594px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#0a0a0a] text-[14px] text-nowrap top-0 tracking-[-0.1504px]">Aternity</p>
      </div>
    </div>
  );
}

function Container39() {
  return (
    <div className="h-[32px] relative rounded-[4px] shrink-0 w-full" data-name="Container">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[8px] items-center pl-[8px] pr-0 py-0 relative size-full">
          <Icon42 />
          <Icon43 />
          <Text19 />
        </div>
      </div>
    </div>
  );
}

function Icon44() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="Icon">
          <path d="M5.25 10.5L8.75 7L5.25 3.5" id="Vector" stroke="var(--stroke-0, #6C757D)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
        </g>
      </svg>
    </div>
  );
}

function Icon45() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g clipPath="url(#clip0_31_2269)" id="Icon">
          <path d={svgPaths.p23c52300} id="Vector" stroke="var(--stroke-0, #6C757D)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
          <path d={svgPaths.p2505ef80} id="Vector_2" stroke="var(--stroke-0, #6C757D)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
          <path d="M3.5 3.5H3.50583" id="Vector_3" stroke="var(--stroke-0, #6C757D)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
          <path d="M3.5 10.5H3.50583" id="Vector_4" stroke="var(--stroke-0, #6C757D)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
        </g>
        <defs>
          <clipPath id="clip0_31_2269">
            <rect fill="white" height="14" width="14" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Text20() {
  return (
    <div className="h-[20px] relative shrink-0 w-[31.078px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#0a0a0a] text-[14px] text-nowrap top-0 tracking-[-0.1504px]">NPM</p>
      </div>
    </div>
  );
}

function Container40() {
  return (
    <div className="h-[32px] relative rounded-[4px] shrink-0 w-full" data-name="Container">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[8px] items-center pl-[8px] pr-0 py-0 relative size-full">
          <Icon44 />
          <Icon45 />
          <Text20 />
        </div>
      </div>
    </div>
  );
}

function Icon46() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="Icon">
          <path d="M5.25 10.5L8.75 7L5.25 3.5" id="Vector" stroke="var(--stroke-0, #6C757D)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
        </g>
      </svg>
    </div>
  );
}

function Icon47() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="Icon">
          <path d={svgPaths.p28fd4e80} id="Vector" stroke="var(--stroke-0, #6C757D)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
          <path d="M7 12.8333V7" id="Vector_2" stroke="var(--stroke-0, #6C757D)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
          <path d={svgPaths.p21a6a770} id="Vector_3" stroke="var(--stroke-0, #6C757D)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
          <path d="M4.375 2.49084L9.625 5.49501" id="Vector_4" stroke="var(--stroke-0, #6C757D)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
        </g>
      </svg>
    </div>
  );
}

function Text21() {
  return (
    <div className="h-[20px] relative shrink-0 w-[36.703px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#0a0a0a] text-[14px] text-nowrap top-0 tracking-[-0.1504px]">Other</p>
      </div>
    </div>
  );
}

function Container41() {
  return (
    <div className="h-[32px] relative rounded-[4px] shrink-0 w-full" data-name="Container">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[8px] items-center pl-[8px] pr-0 py-0 relative size-full">
          <Icon46 />
          <Icon47 />
          <Text21 />
        </div>
      </div>
    </div>
  );
}

function Container42() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[2px] h-[100px] items-start left-[16px] top-[34px] w-[465.5px]" data-name="Container">
      <Container39 />
      <Container40 />
      <Container41 />
    </div>
  );
}

function Container43() {
  return (
    <div className="h-[134px] relative shrink-0 w-full" data-name="Container">
      <Container38 />
      <Container42 />
    </div>
  );
}

function UnifiedAgentView() {
  return (
    <div className="content-stretch flex flex-col gap-[12px] h-[445.109px] items-start relative shrink-0 w-full" data-name="UnifiedAgentView">
      <Container21 />
      <Container37 />
      <Container43 />
    </div>
  );
}

function PrimitiveDiv1() {
  return (
    <div className="basis-0 grow min-h-px min-w-px relative shrink-0 w-[513.5px]" data-name="Primitive.div">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start overflow-clip pb-0 pt-[16px] px-[16px] relative rounded-[inherit] size-full">
        <UnifiedAgentView />
      </div>
    </div>
  );
}

function UnifiedAgentView1() {
  return (
    <div className="absolute bg-white h-[1154px] left-0 top-0 w-[514.5px]" data-name="UnifiedAgentView">
      <div className="content-stretch flex flex-col items-start overflow-clip pl-0 pr-px py-0 relative rounded-[inherit] size-full">
        <Container15 />
        <Container18 />
        <PrimitiveDiv1 />
      </div>
      <div aria-hidden="true" className="absolute border-[0px_1px_0px_0px] border-[rgba(0,0,0,0.15)] border-solid inset-0 pointer-events-none" />
    </div>
  );
}

function Badge3() {
  return (
    <div className="absolute h-[22px] left-[228.33px] rounded-[8px] top-[3px] w-[33.969px]" data-name="Badge">
      <div className="content-stretch flex items-center justify-center overflow-clip px-[9px] py-[3px] relative rounded-[inherit] size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#0a0a0a] text-[12px] text-nowrap">V3</p>
      </div>
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.15)] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function Icon48() {
  return (
    <div className="absolute left-[270.3px] size-[16px] top-[6px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d="M4 6L8 10L12 6" id="Vector" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function SlotClone3() {
  return (
    <div className="h-[28px] relative shrink-0 w-full" data-name="SlotClone">
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[28px] left-0 not-italic text-[#0a0a0a] text-[20px] text-nowrap top-0 tracking-[-0.4492px]">Unified Agent Overview</p>
      <Badge3 />
      <Icon48 />
    </div>
  );
}

function Paragraph() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#6c757d] text-[14px] text-nowrap top-0 tracking-[-0.1504px]">Unified Agent Installation Summary - Click any metric to view filtered devices</p>
    </div>
  );
}

function Container44() {
  return (
    <div className="h-[52px] relative shrink-0 w-[496.188px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[4px] items-start relative size-full">
        <SlotClone3 />
        <Paragraph />
      </div>
    </div>
  );
}

function Icon49() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d="M8 10V2" id="Vector" stroke="var(--stroke-0, #F54900)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p23ad1400} id="Vector_2" stroke="var(--stroke-0, #F54900)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p19411800} id="Vector_3" stroke="var(--stroke-0, #F54900)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Text22() {
  return (
    <div className="basis-0 grow h-[20px] min-h-px min-w-px relative shrink-0" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-0 not-italic text-[#0a0a0a] text-[14px] text-nowrap top-0 tracking-[-0.1504px]">Unified Agent Installation</p>
      </div>
    </div>
  );
}

function Button25() {
  return (
    <div className="bg-[#f9fafb] h-[28px] relative rounded-[8px] shrink-0 w-[105.188px]" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.15)] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center px-[13px] py-px relative size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#212121] text-[12px] text-center text-nowrap">Get Packages</p>
      </div>
    </div>
  );
}

function Container45() {
  return (
    <div className="basis-0 bg-[#ececec] grow h-[46px] min-h-px min-w-px relative rounded-[10px] shrink-0" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.15)] border-solid inset-0 pointer-events-none rounded-[10px]" />
      <div className="flex flex-row items-center size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] items-center px-[13px] py-px relative size-full">
          <Icon49 />
          <Text22 />
          <Button25 />
        </div>
      </div>
    </div>
  );
}

function Icon50() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p2bb95e00} id="Vector" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M8 14.6667V8" id="Vector_2" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p176da400} id="Vector_3" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M5 2.84667L11 6.28" id="Vector_4" stroke="var(--stroke-0, #155DFC)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Text23() {
  return (
    <div className="h-[20px] relative shrink-0 w-[49.406px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-0 not-italic text-[#0a0a0a] text-[14px] text-nowrap top-0 tracking-[-0.1504px]">Version</p>
      </div>
    </div>
  );
}

function Button26() {
  return (
    <div className="basis-0 bg-[#f8f9fa] grow h-[28px] min-h-px min-w-px relative rounded-[8px] shrink-0" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.15)] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <div className="flex flex-row items-center justify-center size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center px-[13px] py-px relative size-full">
          <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#0a0a0a] text-[12px] text-center text-nowrap">Manage</p>
        </div>
      </div>
    </div>
  );
}

function Container46() {
  return (
    <div className="bg-[#ececec] h-[46px] relative rounded-[10px] shrink-0 w-[187.188px]" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.15)] border-solid inset-0 pointer-events-none rounded-[10px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] items-center px-[13px] py-px relative size-full">
        <Icon50 />
        <Text23 />
        <Button26 />
      </div>
    </div>
  );
}

function Container47() {
  return (
    <div className="h-[46px] relative shrink-0 w-[536.406px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[12px] items-center relative size-full">
        <Container45 />
        <Container46 />
      </div>
    </div>
  );
}

function Container48() {
  return (
    <div className="content-stretch flex h-[52px] items-start justify-between relative shrink-0 w-full" data-name="Container">
      <Container44 />
      <Container47 />
    </div>
  );
}

function Icon51() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p8db9670} id="Vector" stroke="var(--stroke-0, #4E4FA9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M6.66667 17.5H13.3333" id="Vector_2" stroke="var(--stroke-0, #4E4FA9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M10 14.1667V17.5" id="Vector_3" stroke="var(--stroke-0, #4E4FA9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
      </svg>
    </div>
  );
}

function Container49() {
  return (
    <div className="bg-[rgba(78,79,169,0.1)] relative rounded-[3.35544e+07px] shrink-0 size-[40px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <Icon51 />
      </div>
    </div>
  );
}

function Paragraph1() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[43px] not-italic text-[#6c757d] text-[14px] text-center text-nowrap top-0 tracking-[-0.1504px] translate-x-[-50%]">Total Devices</p>
    </div>
  );
}

function Paragraph2() {
  return (
    <div className="content-stretch flex h-[36px] items-start relative shrink-0 w-full" data-name="Paragraph">
      <p className="basis-0 font-['Inter:Semi_Bold',sans-serif] font-semibold grow leading-[36px] min-h-px min-w-px not-italic relative shrink-0 text-[#4e4fa9] text-[30px] text-center tracking-[0.3955px]">18</p>
    </div>
  );
}

function Icon52() {
  return (
    <div className="relative shrink-0 size-[12px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
        <g id="Icon">
          <path d="M8 3.5H11V6.5" id="Vector" stroke="var(--stroke-0, #00A63E)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p3a7e7417} id="Vector_2" stroke="var(--stroke-0, #00A63E)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
      </svg>
    </div>
  );
}

function Text24() {
  return (
    <div className="h-[16px] relative shrink-0 w-[31.484px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[#00a63e] text-[12px] text-center text-nowrap">+12%</p>
      </div>
    </div>
  );
}

function Paragraph3() {
  return (
    <div className="content-stretch flex gap-[4px] h-[16px] items-center justify-center relative shrink-0 w-full" data-name="Paragraph">
      <Icon52 />
      <Text24 />
    </div>
  );
}

function Container50() {
  return (
    <div className="h-[84px] relative shrink-0 w-[86.359px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[4px] items-start relative size-full">
        <Paragraph1 />
        <Paragraph2 />
        <Paragraph3 />
      </div>
    </div>
  );
}

function UnifiedAgentViewV() {
  return (
    <div className="h-[132px] relative shrink-0 w-[86.359px]" data-name="UnifiedAgentViewV3">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[8px] items-center justify-center relative size-full">
        <Container49 />
        <Container50 />
      </div>
    </div>
  );
}

function Card() {
  return (
    <div className="absolute bg-white content-stretch flex flex-col h-[230px] items-start left-0 pb-px pl-[137.75px] pr-px pt-[31px] rounded-[14px] top-0 w-[361.875px]" data-name="Card">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.15)] border-solid inset-0 pointer-events-none rounded-[14px]" />
      <UnifiedAgentViewV />
    </div>
  );
}

function Icon53() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g clipPath="url(#clip0_31_2436)" id="Icon">
          <path d={svgPaths.p14d24500} id="Vector" stroke="var(--stroke-0, #F54900)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M10 6.66667V10" id="Vector_2" stroke="var(--stroke-0, #F54900)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M10 13.3333H10.0083" id="Vector_3" stroke="var(--stroke-0, #F54900)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
        <defs>
          <clipPath id="clip0_31_2436">
            <rect fill="white" height="20" width="20" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Container51() {
  return (
    <div className="bg-[rgba(255,105,0,0.1)] relative rounded-[3.35544e+07px] shrink-0 size-[40px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <Icon53 />
      </div>
    </div>
  );
}

function Paragraph4() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[54.05px] not-italic text-[#6c757d] text-[14px] text-center text-nowrap top-0 tracking-[-0.1504px] translate-x-[-50%]">Issues</p>
    </div>
  );
}

function Paragraph5() {
  return (
    <div className="content-stretch flex h-[36px] items-start relative shrink-0 w-full" data-name="Paragraph">
      <p className="basis-0 font-['Inter:Semi_Bold',sans-serif] font-semibold grow leading-[36px] min-h-px min-w-px not-italic relative shrink-0 text-[#f54900] text-[30px] text-center tracking-[0.3955px]">3</p>
    </div>
  );
}

function Paragraph6() {
  return (
    <div className="content-stretch flex h-[16px] items-start relative shrink-0 w-full" data-name="Paragraph">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[#6c757d] text-[12px] text-center text-nowrap">Devices with errors</p>
    </div>
  );
}

function Container52() {
  return (
    <div className="h-[84px] relative shrink-0 w-[108.969px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[4px] items-start relative size-full">
        <Paragraph4 />
        <Paragraph5 />
        <Paragraph6 />
      </div>
    </div>
  );
}

function UnifiedAgentViewV1() {
  return (
    <div className="h-[132px] relative shrink-0 w-[108.969px]" data-name="UnifiedAgentViewV3">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[8px] items-center justify-center relative size-full">
        <Container51 />
        <Container52 />
      </div>
    </div>
  );
}

function Card1() {
  return (
    <div className="absolute bg-white content-stretch flex flex-col h-[230px] items-start left-[377.88px] pb-px pl-[126.453px] pr-px pt-[31px] rounded-[14px] top-0 w-[361.875px]" data-name="Card">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.15)] border-solid inset-0 pointer-events-none rounded-[14px]" />
      <UnifiedAgentViewV1 />
    </div>
  );
}

function Icon54() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p2fedb580} id="Vector" stroke="var(--stroke-0, #4E4FA9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M10 18.3333V10" id="Vector_2" stroke="var(--stroke-0, #4E4FA9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d={svgPaths.p2bed4500} id="Vector_3" stroke="var(--stroke-0, #4E4FA9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M6.25 3.55834L13.75 7.85" id="Vector_4" stroke="var(--stroke-0, #4E4FA9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
      </svg>
    </div>
  );
}

function Container53() {
  return (
    <div className="bg-[rgba(78,79,169,0.1)] relative rounded-[3.35544e+07px] shrink-0 size-[40px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <Icon54 />
      </div>
    </div>
  );
}

function Paragraph7() {
  return (
    <div className="h-[20px] relative shrink-0 w-[129.609px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-0 not-italic text-[#6c757d] text-[14px] text-nowrap top-0 tracking-[-0.1504px]">Module Distribution</p>
      </div>
    </div>
  );
}

function Text25() {
  return (
    <div className="basis-0 grow min-h-px min-w-px relative shrink-0 w-[13.734px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[32px] left-0 not-italic text-[#0a0a0a] text-[24px] text-nowrap top-0 tracking-[0.0703px]">7</p>
      </div>
    </div>
  );
}

function Text26() {
  return (
    <div className="h-[16px] relative shrink-0 w-[85.359px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[#6c757d] text-[12px] text-nowrap">active modules</p>
      </div>
    </div>
  );
}

function Paragraph8() {
  return (
    <div className="h-[48px] relative shrink-0 w-[85.359px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-center relative size-full">
        <Text25 />
        <Text26 />
      </div>
    </div>
  );
}

function Container54() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[8px] h-[162px] items-center left-0 pb-[30px] pt-[8px] px-0 top-0 w-[129.609px]" data-name="Container">
      <Container53 />
      <Paragraph7 />
      <Paragraph8 />
    </div>
  );
}

function Group() {
  return (
    <div className="absolute bottom-1/2 left-[68.29%] right-[3.13%] top-[14.39%]" data-name="Group">
      <div className="absolute inset-[-1.24%_-1.09%_-0.88%_-1.54%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 47 59">
          <g id="Group">
            <path d={svgPaths.p1b750180} fill="var(--fill-0, #3B82F6)" fillOpacity="0.9" id="Vector" stroke="var(--stroke-0, white)" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group1() {
  return (
    <div className="absolute inset-[3.12%_20.77%_71.99%_41.17%]" data-name="Group">
      <div className="absolute inset-[-1.26%_-1.15%_-1.76%_-0.96%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 63 42">
          <g id="Group">
            <path d={svgPaths.p267f6100} fill="var(--fill-0, #3B82F6)" fillOpacity="0.75" id="Vector" stroke="var(--stroke-0, white)" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group2() {
  return (
    <div className="absolute inset-[4.3%_56.26%_63.08%_8.5%]" data-name="Group">
      <div className="absolute inset-[-1.15%_-1.06%_-1.29%_-1.2%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 58 54">
          <g id="Group">
            <path d={svgPaths.p38a31300} fill="var(--fill-0, #3B82F6)" fillOpacity="0.45" id="Vector" stroke="var(--stroke-0, white)" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group3() {
  return (
    <div className="absolute inset-[29.66%_75.34%_31.15%_3.12%]" data-name="Group">
      <div className="absolute inset-[-1.06%_-1.94%_-1.05%_-1.45%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 36 65">
          <g id="Group">
            <path d={svgPaths.p356a6c00} fill="var(--fill-0, #3B82F6)" fillOpacity="0.3" id="Vector" stroke="var(--stroke-0, white)" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group4() {
  return (
    <div className="absolute inset-[62.2%_57.21%_4.69%_7.77%]" data-name="Group">
      <div className="absolute inset-[-1.26%_-1.09%_-1.15%_-1.19%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 58 55">
          <g id="Group">
            <path d={svgPaths.pd751710} fill="var(--fill-0, #3B82F6)" fillOpacity="0.15" id="Vector" stroke="var(--stroke-0, white)" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group5() {
  return (
    <div className="absolute inset-[72.59%_22.07%_3.13%_39.57%]" data-name="Group">
      <div className="absolute inset-[-1.8%_-1.14%_-1.29%_-0.98%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 63 41">
          <g id="Group">
            <path d={svgPaths.p2ef1cec0} id="Vector" stroke="var(--stroke-0, white)" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group6() {
  return (
    <div className="absolute inset-[50.98%_3.15%_13.35%_67.54%]" data-name="Group">
      <div className="absolute inset-[-0.91%_-1.1%_-1.23%_-1.5%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 49 59">
          <g id="Group">
            <path d={svgPaths.p470f6c0} id="Vector" stroke="var(--stroke-0, white)" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group7() {
  return (
    <div className="absolute contents inset-[3.12%_3.13%_3.13%_3.12%]" data-name="Group">
      <Group />
      <Group1 />
      <Group2 />
      <Group3 />
      <Group4 />
      <Group5 />
      <Group6 />
    </div>
  );
}

function Group8() {
  return (
    <div className="absolute contents inset-[3.12%_3.13%_3.13%_3.12%]" data-name="Group">
      <Group7 />
    </div>
  );
}

function Icon55() {
  return (
    <div className="absolute left-0 overflow-clip size-[160px] top-0" data-name="Icon">
      <Group8 />
    </div>
  );
}

function Container55() {
  return (
    <div className="absolute left-[161.61px] size-[160px] top-0" data-name="Container">
      <Icon55 />
    </div>
  );
}

function Container56() {
  return (
    <div className="bg-[rgba(59,130,246,0.9)] relative rounded-[3.35544e+07px] shrink-0 size-[12px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid size-full" />
    </div>
  );
}

function Text27() {
  return (
    <div className="basis-0 grow h-[20px] min-h-px min-w-px relative shrink-0" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid overflow-clip relative rounded-[inherit] size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#6c757d] text-[14px] text-nowrap top-0 tracking-[-0.1504px]">Aternity Module</p>
      </div>
    </div>
  );
}

function Text28() {
  return (
    <div className="h-[20px] relative shrink-0 w-[15.5px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-0 not-italic text-[#0a0a0a] text-[14px] text-nowrap top-0 tracking-[-0.1504px]">10</p>
      </div>
    </div>
  );
}

function Container57() {
  return (
    <div className="h-[20px] relative shrink-0 w-[251.5px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[12px] items-center relative size-full">
        <Container56 />
        <Text27 />
        <Text28 />
      </div>
    </div>
  );
}

function Container58() {
  return (
    <div className="bg-[rgba(59,130,246,0.75)] relative rounded-[3.35544e+07px] shrink-0 size-[12px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid size-full" />
    </div>
  );
}

function Text29() {
  return (
    <div className="basis-0 grow h-[20px] min-h-px min-w-px relative shrink-0" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid overflow-clip relative rounded-[inherit] size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#6c757d] text-[14px] text-nowrap top-0 tracking-[-0.1504px]">Aternity Sentiment</p>
      </div>
    </div>
  );
}

function Text30() {
  return (
    <div className="h-[20px] relative shrink-0 w-[15.5px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-0 not-italic text-[#0a0a0a] text-[14px] text-nowrap top-0 tracking-[-0.1504px]">10</p>
      </div>
    </div>
  );
}

function Container59() {
  return (
    <div className="h-[20px] relative shrink-0 w-[251.5px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[12px] items-center relative size-full">
        <Container58 />
        <Text29 />
        <Text30 />
      </div>
    </div>
  );
}

function Container60() {
  return (
    <div className="bg-[rgba(59,130,246,0.6)] relative rounded-[3.35544e+07px] shrink-0 size-[12px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid size-full" />
    </div>
  );
}

function Text31() {
  return (
    <div className="basis-0 grow h-[20px] min-h-px min-w-px relative shrink-0" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid overflow-clip relative rounded-[inherit] size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#6c757d] text-[14px] text-nowrap top-0 tracking-[-0.1504px]">NPM Core for Windows</p>
      </div>
    </div>
  );
}

function Text32() {
  return (
    <div className="h-[20px] relative shrink-0 w-[15.5px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-0 not-italic text-[#0a0a0a] text-[14px] text-nowrap top-0 tracking-[-0.1504px]">10</p>
      </div>
    </div>
  );
}

function Container61() {
  return (
    <div className="h-[20px] relative shrink-0 w-[251.5px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[12px] items-center relative size-full">
        <Container60 />
        <Text31 />
        <Text32 />
      </div>
    </div>
  );
}

function Container62() {
  return (
    <div className="bg-[rgba(59,130,246,0.45)] relative rounded-[3.35544e+07px] shrink-0 size-[12px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid size-full" />
    </div>
  );
}

function Text33() {
  return (
    <div className="basis-0 grow h-[20px] min-h-px min-w-px relative shrink-0" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid overflow-clip relative rounded-[inherit] size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#6c757d] text-[14px] text-nowrap top-0 tracking-[-0.1504px]">NPM Core for Linux</p>
      </div>
    </div>
  );
}

function Text34() {
  return (
    <div className="h-[20px] relative shrink-0 w-[15.5px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-0 not-italic text-[#0a0a0a] text-[14px] text-nowrap top-0 tracking-[-0.1504px]">10</p>
      </div>
    </div>
  );
}

function Container63() {
  return (
    <div className="h-[20px] relative shrink-0 w-[251.5px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[12px] items-center relative size-full">
        <Container62 />
        <Text33 />
        <Text34 />
      </div>
    </div>
  );
}

function Container64() {
  return (
    <div className="bg-[rgba(59,130,246,0.3)] relative rounded-[3.35544e+07px] shrink-0 size-[12px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid size-full" />
    </div>
  );
}

function Text35() {
  return (
    <div className="basis-0 grow h-[20px] min-h-px min-w-px relative shrink-0" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid overflow-clip relative rounded-[inherit] size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#6c757d] text-[14px] text-nowrap top-0 tracking-[-0.1504px]">Aternity Recorder</p>
      </div>
    </div>
  );
}

function Text36() {
  return (
    <div className="h-[20px] relative shrink-0 w-[15.5px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-0 not-italic text-[#0a0a0a] text-[14px] text-nowrap top-0 tracking-[-0.1504px]">10</p>
      </div>
    </div>
  );
}

function Container65() {
  return (
    <div className="h-[20px] relative shrink-0 w-[251.5px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[12px] items-center relative size-full">
        <Container64 />
        <Text35 />
        <Text36 />
      </div>
    </div>
  );
}

function Container66() {
  return (
    <div className="bg-[rgba(59,130,246,0.15)] relative rounded-[3.35544e+07px] shrink-0 size-[12px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid size-full" />
    </div>
  );
}

function Text37() {
  return (
    <div className="basis-0 grow h-[20px] min-h-px min-w-px relative shrink-0" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid overflow-clip relative rounded-[inherit] size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#6c757d] text-[14px] text-nowrap top-0 tracking-[-0.1504px]">SteelHead Mobile</p>
      </div>
    </div>
  );
}

function Text38() {
  return (
    <div className="h-[20px] relative shrink-0 w-[15.5px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-0 not-italic text-[#0a0a0a] text-[14px] text-nowrap top-0 tracking-[-0.1504px]">10</p>
      </div>
    </div>
  );
}

function Container67() {
  return (
    <div className="h-[20px] relative shrink-0 w-[251.5px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[12px] items-center relative size-full">
        <Container66 />
        <Text37 />
        <Text38 />
      </div>
    </div>
  );
}

function Container68() {
  return (
    <div className="bg-[rgba(59,130,246,0)] relative rounded-[3.35544e+07px] shrink-0 size-[12px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid size-full" />
    </div>
  );
}

function Text39() {
  return (
    <div className="basis-0 grow h-[20px] min-h-px min-w-px relative shrink-0" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid overflow-clip relative rounded-[inherit] size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#6c757d] text-[14px] top-0 tracking-[-0.1504px] w-[216px]">NPM Packet capture for Windows</p>
      </div>
    </div>
  );
}

function Text40() {
  return (
    <div className="h-[20px] relative shrink-0 w-[15.5px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-0 not-italic text-[#0a0a0a] text-[14px] text-nowrap top-0 tracking-[-0.1504px]">10</p>
      </div>
    </div>
  );
}

function Container69() {
  return (
    <div className="basis-0 grow min-h-px min-w-px relative shrink-0 w-[251.5px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[12px] items-center relative size-full">
        <Container68 />
        <Text39 />
        <Text40 />
      </div>
    </div>
  );
}

function Container70() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[8px] h-[188px] items-start left-[353.61px] top-0 w-[251.5px]" data-name="Container">
      <Container57 />
      <Container59 />
      <Container61 />
      <Container63 />
      <Container65 />
      <Container67 />
      <Container69 />
    </div>
  );
}

function UnifiedAgentViewV2() {
  return (
    <div className="h-[188px] relative shrink-0 w-[605.109px]" data-name="UnifiedAgentViewV3">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Container54 />
        <Container55 />
        <Container70 />
      </div>
    </div>
  );
}

function Card2() {
  return (
    <div className="absolute bg-white content-stretch flex flex-col h-[230px] items-start left-[755.75px] pb-px pl-[67.313px] pr-px pt-[17px] rounded-[14px] top-0 w-[739.75px]" data-name="Card">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.15)] border-solid inset-0 pointer-events-none rounded-[14px]" />
      <UnifiedAgentViewV2 />
    </div>
  );
}

function UnifiedAgentViewV3() {
  return (
    <div className="h-[230px] relative shrink-0 w-full" data-name="UnifiedAgentViewV3">
      <Card />
      <Card1 />
      <Card2 />
    </div>
  );
}

function Heading2() {
  return (
    <div className="h-[28px] relative shrink-0 w-[289.719px]" data-name="Heading 3">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[28px] left-0 not-italic text-[#0a0a0a] text-[18px] text-nowrap top-0 tracking-[-0.4395px]">Devices installed with unified agent</p>
      </div>
    </div>
  );
}

function Icon56() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute bottom-1/2 left-1/2 right-[8.52%] top-[8.53%]" data-name="Vector">
        <div className="absolute inset-[-10.05%_-10.05%_-10.05%_-10.04%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 8 8">
            <path d={svgPaths.p21866c00} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[11.79%_11.62%_8.35%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-5.22%_-5.21%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
            <path d={svgPaths.p38fa5d80} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button27() {
  return (
    <div className="bg-[#4e4fa9] relative rounded-[4px] shrink-0 size-[28px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pb-0 pt-[6px] px-[6px] relative size-full">
        <Icon56 />
      </div>
    </div>
  );
}

function Icon57() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[12.5%_58.33%_58.33%_12.5%]" data-name="Vector">
        <div className="absolute inset-[-14.29%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6 6">
            <path d={svgPaths.p1ffb1100} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[12.5%_12.5%_58.33%_58.33%]" data-name="Vector">
        <div className="absolute inset-[-14.29%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6 6">
            <path d={svgPaths.p1ffb1100} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[58.33%_12.5%_12.5%_58.33%]" data-name="Vector">
        <div className="absolute inset-[-14.29%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6 6">
            <path d={svgPaths.p1ffb1100} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[58.33%_58.33%_12.5%_12.5%]" data-name="Vector">
        <div className="absolute inset-[-14.29%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6 6">
            <path d={svgPaths.p1ffb1100} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button28() {
  return (
    <div className="basis-0 grow h-[28px] min-h-px min-w-px relative rounded-[4px] shrink-0" data-name="Button">
      <div className="size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pb-0 pt-[6px] px-[6px] relative size-full">
          <Icon57 />
        </div>
      </div>
    </div>
  );
}

function Container71() {
  return (
    <div className="bg-[#f3f4f6] h-[36px] relative rounded-[10px] shrink-0 w-[68px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[4px] items-center px-[4px] py-0 relative size-full">
        <Button27 />
        <Button28 />
      </div>
    </div>
  );
}

function UnifiedAgentViewV4() {
  return (
    <div className="absolute content-stretch flex h-[60px] items-center justify-between left-[24px] top-[24px] w-[1445.5px]" data-name="UnifiedAgentViewV3">
      <Heading2 />
      <Container71 />
    </div>
  );
}

function Heading1() {
  return (
    <div className="h-[20px] relative shrink-0 w-[42.641px]" data-name="Heading 4">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-0 not-italic text-[#0a0a0a] text-[14px] text-nowrap top-0 tracking-[-0.1504px]">Status</p>
      </div>
    </div>
  );
}

function UnifiedAgentViewV5() {
  return (
    <div className="h-[16px] relative shrink-0 w-[74.219px]" data-name="UnifiedAgentViewV3">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[16px] left-0 not-italic text-[#030213] text-[12px] top-0 w-[75px]">1 filter active</p>
      </div>
    </div>
  );
}

function Icon58() {
  return (
    <div className="relative shrink-0 size-[12px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
        <g id="Icon">
          <path d="M9 3L3 9" id="Vector" stroke="var(--stroke-0, #030213)" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M3 3L9 9" id="Vector_2" stroke="var(--stroke-0, #030213)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
      </svg>
    </div>
  );
}

function Badge4() {
  return (
    <div className="bg-[#eceef2] h-[22px] relative rounded-[8px] shrink-0 w-[108.219px]" data-name="Badge">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[6px] items-center justify-center overflow-clip pl-[3px] pr-px py-px relative rounded-[inherit] size-full">
        <UnifiedAgentViewV5 />
        <Icon58 />
      </div>
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function Container72() {
  return (
    <div className="content-stretch flex h-[22px] items-center justify-between relative shrink-0 w-full" data-name="Container">
      <Heading1 />
      <Badge4 />
    </div>
  );
}

function Group9() {
  return (
    <div className="absolute bottom-1/2 left-[10.1%] right-[10%] top-[10%]" data-name="Group">
      <div className="absolute inset-[-1.25%_-0.63%_-1.25%_-0.67%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 81 41">
          <g id="Group">
            <path d={svgPaths.p2e19b880} fill="var(--fill-0, #22C55E)" id="Vector" stroke="var(--stroke-0, white)" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group10() {
  return (
    <div className="absolute inset-[48.6%_55.95%_11.15%_10%]" data-name="Group">
      <div className="absolute inset-[-1.28%_-1.78%_-1.5%_-1.47%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 36 42">
          <g id="Group">
            <path d={svgPaths.pd9e5a80} fill="var(--fill-0, #3B82F6)" id="Vector" stroke="var(--stroke-0, white)" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group11() {
  return (
    <div className="absolute inset-[67.09%_20.8%_10%_41.84%]" data-name="Group">
      <div className="absolute inset-[-3.08%_-1.89%_-2.18%_-1.58%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 39 25">
          <g id="Group">
            <path d={svgPaths.p2e2c9d00} fill="var(--fill-0, #EF4444)" id="Vector" stroke="var(--stroke-0, white)" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group12() {
  return (
    <div className="absolute inset-[50.87%_10.02%_23.7%_68.84%]" data-name="Group">
      <div className="absolute inset-[-2.03%_-2.45%_-2.77%_-3.34%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 23 27">
          <g id="Group">
            <path d={svgPaths.pe937900} fill="var(--fill-0, #9CA3AF)" id="Vector" stroke="var(--stroke-0, white)" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group13() {
  return (
    <div className="absolute contents inset-[10%]" data-name="Group">
      <Group9 />
      <Group10 />
      <Group11 />
      <Group12 />
    </div>
  );
}

function Group14() {
  return (
    <div className="absolute contents inset-[10%]" data-name="Group">
      <Group13 />
    </div>
  );
}

function Icon59() {
  return (
    <div className="absolute left-0 overflow-clip size-[100px] top-0" data-name="Icon">
      <Group14 />
    </div>
  );
}

function Container73() {
  return (
    <div className="absolute left-0 size-[100px] top-0" data-name="Container">
      <Icon59 />
    </div>
  );
}

function Container74() {
  return (
    <div className="bg-[#00c950] relative rounded-[3.35544e+07px] shrink-0 size-[8px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid size-full" />
    </div>
  );
}

function Text41() {
  return (
    <div className="basis-0 grow h-[16px] min-h-px min-w-px relative shrink-0" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[16px] not-italic relative shrink-0 text-[#0a0a0a] text-[12px] text-nowrap">Deployed</p>
      </div>
    </div>
  );
}

function Container75() {
  return (
    <div className="h-[16px] relative shrink-0 w-[69.484px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[6px] items-center relative size-full">
        <Container74 />
        <Text41 />
      </div>
    </div>
  );
}

function Text42() {
  return (
    <div className="h-[16px] relative shrink-0 w-[7.828px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#0a0a0a] text-[12px] text-nowrap">9</p>
      </div>
    </div>
  );
}

function Container76() {
  return (
    <div className="bg-[#f0fdf4] h-[22px] relative rounded-[4px] shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[#b9f8cf] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between px-[5px] py-px relative size-full">
          <Container75 />
          <Text42 />
        </div>
      </div>
    </div>
  );
}

function Container77() {
  return (
    <div className="bg-[#2b7fff] relative rounded-[3.35544e+07px] shrink-0 size-[8px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid size-full" />
    </div>
  );
}

function Text43() {
  return (
    <div className="basis-0 grow h-[16px] min-h-px min-w-px relative shrink-0" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[#0a0a0a] text-[12px] text-nowrap">In Progress</p>
      </div>
    </div>
  );
}

function Container78() {
  return (
    <div className="h-[16px] relative shrink-0 w-[77.703px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[6px] items-center relative size-full">
        <Container77 />
        <Text43 />
      </div>
    </div>
  );
}

function Text44() {
  return (
    <div className="h-[16px] relative shrink-0 w-[7.906px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#0a0a0a] text-[12px] text-nowrap">4</p>
      </div>
    </div>
  );
}

function Container79() {
  return (
    <div className="h-[20px] relative rounded-[4px] shrink-0 w-full" data-name="Container">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between px-[4px] py-0 relative size-full">
          <Container78 />
          <Text44 />
        </div>
      </div>
    </div>
  );
}

function Container80() {
  return (
    <div className="bg-[#fb2c36] relative rounded-[3.35544e+07px] shrink-0 size-[8px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid size-full" />
    </div>
  );
}

function Text45() {
  return (
    <div className="basis-0 grow h-[16px] min-h-px min-w-px relative shrink-0" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[#0a0a0a] text-[12px] text-nowrap">Error</p>
      </div>
    </div>
  );
}

function Container81() {
  return (
    <div className="h-[16px] relative shrink-0 w-[41.891px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[6px] items-center relative size-full">
        <Container80 />
        <Text45 />
      </div>
    </div>
  );
}

function Text46() {
  return (
    <div className="h-[16px] relative shrink-0 w-[7.703px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#0a0a0a] text-[12px] text-nowrap">3</p>
      </div>
    </div>
  );
}

function Container82() {
  return (
    <div className="h-[20px] relative rounded-[4px] shrink-0 w-full" data-name="Container">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between px-[4px] py-0 relative size-full">
          <Container81 />
          <Text46 />
        </div>
      </div>
    </div>
  );
}

function Container83() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[70px] items-start left-[108px] top-[15px] w-[215.375px]" data-name="Container">
      <Container76 />
      <Container79 />
      <Container82 />
    </div>
  );
}

function Container84() {
  return (
    <div className="h-[100px] relative shrink-0 w-full" data-name="Container">
      <Container73 />
      <Container83 />
    </div>
  );
}

function Container85() {
  return (
    <div className="[grid-area:1_/_1] bg-[#f9fafb] place-self-stretch relative rounded-[10px] shrink-0" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.15)] border-solid inset-0 pointer-events-none rounded-[10px]" />
      <div className="size-full">
        <div className="content-stretch flex flex-col gap-[8px] items-start pb-px pt-[13px] px-[13px] relative size-full">
          <Container72 />
          <Container84 />
        </div>
      </div>
    </div>
  );
}

function Heading3() {
  return (
    <div className="absolute h-[20px] left-[13px] top-[13px] w-[49.406px]" data-name="Heading 4">
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-0 not-italic text-[#0a0a0a] text-[14px] text-nowrap top-0 tracking-[-0.1504px]">Version</p>
    </div>
  );
}

function Group15() {
  return (
    <div className="absolute inset-[10%_10%_26.3%_10%]" data-name="Group">
      <div className="absolute inset-[-0.78%_-0.62%_-1.1%_-0.63%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 81 65">
          <g id="Group">
            <path d={svgPaths.pf691480} fill="var(--fill-0, #4E4FA9)" id="Vector" stroke="var(--stroke-0, white)" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group16() {
  return (
    <div className="absolute inset-[65.51%_31.84%_10%_18.62%]" data-name="Group">
      <div className="absolute inset-[-2.87%_-1.36%_-2.04%_-1.42%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 51 26">
          <g id="Group">
            <path d={svgPaths.pb82fa00} fill="var(--fill-0, #6366F1)" id="Vector" stroke="var(--stroke-0, white)" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group17() {
  return (
    <div className="absolute inset-[50.87%_10.02%_15.02%_62.12%]" data-name="Group">
      <div className="absolute inset-[-1.52%_-1.86%_-1.99%_-2.44%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 36">
          <g id="Group">
            <path d={svgPaths.p24f08100} fill="var(--fill-0, #8B5CF6)" id="Vector" stroke="var(--stroke-0, white)" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group18() {
  return (
    <div className="absolute contents inset-[10%]" data-name="Group">
      <Group15 />
      <Group16 />
      <Group17 />
    </div>
  );
}

function Group19() {
  return (
    <div className="absolute contents inset-[10%]" data-name="Group">
      <Group18 />
    </div>
  );
}

function Icon60() {
  return (
    <div className="absolute left-0 overflow-clip size-[100px] top-0" data-name="Icon">
      <Group19 />
    </div>
  );
}

function Container86() {
  return (
    <div className="absolute left-0 size-[100px] top-0" data-name="Container">
      <Icon60 />
    </div>
  );
}

function Container87() {
  return (
    <div className="bg-[#4e4fa9] relative rounded-[3.35544e+07px] shrink-0 size-[8px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid size-full" />
    </div>
  );
}

function Text47() {
  return (
    <div className="basis-0 grow h-[16px] min-h-px min-w-px relative shrink-0" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start overflow-clip relative rounded-[inherit] size-full">
        <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[#0a0a0a] text-[12px] text-nowrap">25.118 BC</p>
      </div>
    </div>
  );
}

function Container88() {
  return (
    <div className="h-[16px] relative shrink-0 w-[70.109px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[6px] items-center relative size-full">
        <Container87 />
        <Text47 />
      </div>
    </div>
  );
}

function Text48() {
  return (
    <div className="h-[16px] relative shrink-0 w-[11.531px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#0a0a0a] text-[12px] text-nowrap">11</p>
      </div>
    </div>
  );
}

function Container89() {
  return (
    <div className="h-[20px] relative rounded-[4px] shrink-0 w-full" data-name="Container">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between px-[4px] py-0 relative size-full">
          <Container88 />
          <Text48 />
        </div>
      </div>
    </div>
  );
}

function Container90() {
  return (
    <div className="bg-[#6366f1] relative rounded-[3.35544e+07px] shrink-0 size-[8px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid size-full" />
    </div>
  );
}

function Text49() {
  return (
    <div className="basis-0 grow h-[16px] min-h-px min-w-px relative shrink-0" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start overflow-clip relative rounded-[inherit] size-full">
        <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[#0a0a0a] text-[12px] text-nowrap">26.110 BC</p>
      </div>
    </div>
  );
}

function Container91() {
  return (
    <div className="h-[16px] relative shrink-0 w-[70.234px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[6px] items-center relative size-full">
        <Container90 />
        <Text49 />
      </div>
    </div>
  );
}

function Text50() {
  return (
    <div className="h-[16px] relative shrink-0 w-[7.906px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#0a0a0a] text-[12px] text-nowrap">4</p>
      </div>
    </div>
  );
}

function Container92() {
  return (
    <div className="h-[20px] relative rounded-[4px] shrink-0 w-full" data-name="Container">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between px-[4px] py-0 relative size-full">
          <Container91 />
          <Text50 />
        </div>
      </div>
    </div>
  );
}

function Container93() {
  return (
    <div className="bg-[#8b5cf6] relative rounded-[3.35544e+07px] shrink-0 size-[8px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid size-full" />
    </div>
  );
}

function Text51() {
  return (
    <div className="basis-0 grow h-[16px] min-h-px min-w-px relative shrink-0" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start overflow-clip relative rounded-[inherit] size-full">
        <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[#0a0a0a] text-[12px] text-nowrap">26.3.1.0</p>
      </div>
    </div>
  );
}

function Container94() {
  return (
    <div className="h-[16px] relative shrink-0 w-[57.938px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[6px] items-center relative size-full">
        <Container93 />
        <Text51 />
      </div>
    </div>
  );
}

function Text52() {
  return (
    <div className="h-[16px] relative shrink-0 w-[7.703px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#0a0a0a] text-[12px] text-nowrap">3</p>
      </div>
    </div>
  );
}

function Container95() {
  return (
    <div className="h-[20px] relative rounded-[4px] shrink-0 w-full" data-name="Container">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between px-[4px] py-0 relative size-full">
          <Container94 />
          <Text52 />
        </div>
      </div>
    </div>
  );
}

function Container96() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[68px] items-start left-[108px] top-[16px] w-[215.375px]" data-name="Container">
      <Container89 />
      <Container92 />
      <Container95 />
    </div>
  );
}

function Container97() {
  return (
    <div className="absolute h-[100px] left-[13px] top-[41px] w-[323.375px]" data-name="Container">
      <Container86 />
      <Container96 />
    </div>
  );
}

function Container98() {
  return (
    <div className="[grid-area:1_/_2] bg-[#f9fafb] place-self-stretch relative rounded-[10px] shrink-0" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.15)] border-solid inset-0 pointer-events-none rounded-[10px]" />
      <Heading3 />
      <Container97 />
    </div>
  );
}

function Heading4() {
  return (
    <div className="absolute h-[20px] left-[13px] top-[13px] w-[80.906px]" data-name="Heading 4">
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-0 not-italic text-[#0a0a0a] text-[14px] text-nowrap top-0 tracking-[-0.1504px]">Device Type</p>
    </div>
  );
}

function Group20() {
  return (
    <div className="absolute inset-[10%_10%_26.3%_10%]" data-name="Group">
      <div className="absolute inset-[-0.78%_-0.62%_-1.1%_-0.63%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 81 65">
          <g id="Group">
            <path d={svgPaths.pf691480} fill="var(--fill-0, #3B82F6)" id="Vector" stroke="var(--stroke-0, white)" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group21() {
  return (
    <div className="absolute inset-[65.51%_31.84%_10%_18.62%]" data-name="Group">
      <div className="absolute inset-[-2.87%_-1.36%_-2.04%_-1.42%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 51 26">
          <g id="Group">
            <path d={svgPaths.pb82fa00} fill="var(--fill-0, #0EA5E9)" id="Vector" stroke="var(--stroke-0, white)" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group22() {
  return (
    <div className="absolute inset-[50.87%_10.02%_15.02%_62.12%]" data-name="Group">
      <div className="absolute inset-[-1.52%_-1.86%_-1.99%_-2.44%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 36">
          <g id="Group">
            <path d={svgPaths.p24f08100} fill="var(--fill-0, #06B6D4)" id="Vector" stroke="var(--stroke-0, white)" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group23() {
  return (
    <div className="absolute contents inset-[10%]" data-name="Group">
      <Group20 />
      <Group21 />
      <Group22 />
    </div>
  );
}

function Group24() {
  return (
    <div className="absolute contents inset-[10%]" data-name="Group">
      <Group23 />
    </div>
  );
}

function Icon61() {
  return (
    <div className="absolute left-0 overflow-clip size-[100px] top-0" data-name="Icon">
      <Group24 />
    </div>
  );
}

function Container99() {
  return (
    <div className="absolute left-0 size-[100px] top-0" data-name="Container">
      <Icon61 />
    </div>
  );
}

function Container100() {
  return (
    <div className="bg-[#3b82f6] relative rounded-[3.35544e+07px] shrink-0 size-[8px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid size-full" />
    </div>
  );
}

function Text53() {
  return (
    <div className="basis-0 grow h-[16px] min-h-px min-w-px relative shrink-0" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="capitalize font-['Inter:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[#0a0a0a] text-[12px] text-nowrap">desktop</p>
      </div>
    </div>
  );
}

function Container101() {
  return (
    <div className="h-[16px] relative shrink-0 w-[61.063px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[6px] items-center relative size-full">
        <Container100 />
        <Text53 />
      </div>
    </div>
  );
}

function Text54() {
  return (
    <div className="h-[16px] relative shrink-0 w-[11.531px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#0a0a0a] text-[12px] text-nowrap">11</p>
      </div>
    </div>
  );
}

function Container102() {
  return (
    <div className="h-[20px] relative rounded-[4px] shrink-0 w-full" data-name="Container">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between px-[4px] py-0 relative size-full">
          <Container101 />
          <Text54 />
        </div>
      </div>
    </div>
  );
}

function Container103() {
  return (
    <div className="bg-[#0ea5e9] relative rounded-[3.35544e+07px] shrink-0 size-[8px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid size-full" />
    </div>
  );
}

function Text55() {
  return (
    <div className="basis-0 grow h-[16px] min-h-px min-w-px relative shrink-0" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="capitalize font-['Inter:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[#0a0a0a] text-[12px] text-nowrap">server</p>
      </div>
    </div>
  );
}

function Container104() {
  return (
    <div className="h-[16px] relative shrink-0 w-[50.828px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[6px] items-center relative size-full">
        <Container103 />
        <Text55 />
      </div>
    </div>
  );
}

function Text56() {
  return (
    <div className="h-[16px] relative shrink-0 w-[7.906px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#0a0a0a] text-[12px] text-nowrap">4</p>
      </div>
    </div>
  );
}

function Container105() {
  return (
    <div className="h-[20px] relative rounded-[4px] shrink-0 w-full" data-name="Container">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between px-[4px] py-0 relative size-full">
          <Container104 />
          <Text56 />
        </div>
      </div>
    </div>
  );
}

function Container106() {
  return (
    <div className="bg-[#06b6d4] relative rounded-[3.35544e+07px] shrink-0 size-[8px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid size-full" />
    </div>
  );
}

function Text57() {
  return (
    <div className="basis-0 grow h-[16px] min-h-px min-w-px relative shrink-0" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="capitalize font-['Inter:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[#0a0a0a] text-[12px] text-nowrap">vdi</p>
      </div>
    </div>
  );
}

function Container107() {
  return (
    <div className="h-[16px] relative shrink-0 w-[31.844px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[6px] items-center relative size-full">
        <Container106 />
        <Text57 />
      </div>
    </div>
  );
}

function Text58() {
  return (
    <div className="h-[16px] relative shrink-0 w-[7.703px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#0a0a0a] text-[12px] text-nowrap">3</p>
      </div>
    </div>
  );
}

function Container108() {
  return (
    <div className="h-[20px] relative rounded-[4px] shrink-0 w-full" data-name="Container">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between px-[4px] py-0 relative size-full">
          <Container107 />
          <Text58 />
        </div>
      </div>
    </div>
  );
}

function Container109() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[68px] items-start left-[108px] top-[16px] w-[215.375px]" data-name="Container">
      <Container102 />
      <Container105 />
      <Container108 />
    </div>
  );
}

function Container110() {
  return (
    <div className="absolute h-[100px] left-[13px] top-[41px] w-[323.375px]" data-name="Container">
      <Container99 />
      <Container109 />
    </div>
  );
}

function Container111() {
  return (
    <div className="[grid-area:1_/_3] bg-[#f9fafb] place-self-stretch relative rounded-[10px] shrink-0" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.15)] border-solid inset-0 pointer-events-none rounded-[10px]" />
      <Heading4 />
      <Container110 />
    </div>
  );
}

function Heading5() {
  return (
    <div className="absolute h-[20px] left-[13px] top-[13px] w-[118.688px]" data-name="Heading 4">
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-0 not-italic text-[#0a0a0a] text-[14px] text-nowrap top-0 tracking-[-0.1504px]">Operating System</p>
    </div>
  );
}

function Group25() {
  return (
    <div className="absolute bottom-1/2 left-[32.05%] right-[10%] top-[10%]" data-name="Group">
      <div className="absolute inset-[-1.25%_-0.86%_-1.25%_-1.16%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 60 41">
          <g id="Group">
            <path d={svgPaths.p286b0180} fill="var(--fill-0, #3B82F6)" id="Vector" stroke="var(--stroke-0, white)" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group26() {
  return (
    <div className="absolute inset-[14.9%_61.99%_26.55%_10%]" data-name="Group">
      <div className="absolute inset-[-1.16%_-2.42%_-1.19%_-1.79%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 60">
          <g id="Group">
            <path d={svgPaths.p2171600} fill="var(--fill-0, #3B82F6)" id="Vector" stroke="var(--stroke-0, white)" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group27() {
  return (
    <div className="absolute inset-[65.35%_45.66%_10%_18.43%]" data-name="Group">
      <div className="absolute inset-[-2.85%_-1.54%_-2.03%_-1.95%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 38 26">
          <g id="Group">
            <path d={svgPaths.peba3600} fill="var(--fill-0, #6B7280)" id="Vector" stroke="var(--stroke-0, white)" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group28() {
  return (
    <div className="absolute inset-[67.01%_20.69%_10.41%_53.58%]" data-name="Group">
      <div className="absolute inset-[-3.13%_-2.75%_-2.51%_-2.2%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 27 24">
          <g id="Group">
            <path d={svgPaths.p1c7a9870} fill="var(--fill-0, #F97316)" id="Vector" stroke="var(--stroke-0, white)" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group29() {
  return (
    <div className="absolute inset-[50.87%_10.02%_23.82%_68.9%]" data-name="Group">
      <div className="absolute inset-[-2.04%_-2.45%_-2.79%_-3.35%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 23 27">
          <g id="Group">
            <path d={svgPaths.p3a72b00} fill="var(--fill-0, #F97316)" id="Vector" stroke="var(--stroke-0, white)" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group30() {
  return (
    <div className="absolute contents inset-[10%]" data-name="Group">
      <Group25 />
      <Group26 />
      <Group27 />
      <Group28 />
      <Group29 />
    </div>
  );
}

function Group31() {
  return (
    <div className="absolute contents inset-[10%]" data-name="Group">
      <Group30 />
    </div>
  );
}

function Icon62() {
  return (
    <div className="absolute left-0 overflow-clip size-[100px] top-0" data-name="Icon">
      <Group31 />
    </div>
  );
}

function Container112() {
  return (
    <div className="absolute left-0 size-[100px] top-0" data-name="Container">
      <Icon62 />
    </div>
  );
}

function Container113() {
  return (
    <div className="bg-[#2b7fff] relative rounded-[3.35544e+07px] shrink-0 size-[8px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid size-full" />
    </div>
  );
}

function Text59() {
  return (
    <div className="basis-0 grow h-[16px] min-h-px min-w-px relative shrink-0" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start overflow-clip relative rounded-[inherit] size-full">
        <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[#0a0a0a] text-[12px] text-nowrap">Windows 11</p>
      </div>
    </div>
  );
}

function Container114() {
  return (
    <div className="h-[16px] relative shrink-0 w-[79.719px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[6px] items-center relative size-full">
        <Container113 />
        <Text59 />
      </div>
    </div>
  );
}

function Text60() {
  return (
    <div className="h-[16px] relative shrink-0 w-[7.828px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#0a0a0a] text-[12px] text-nowrap">6</p>
      </div>
    </div>
  );
}

function Container115() {
  return (
    <div className="h-[20px] relative rounded-[4px] shrink-0 w-full" data-name="Container">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between px-[4px] py-0 relative size-full">
          <Container114 />
          <Text60 />
        </div>
      </div>
    </div>
  );
}

function Container116() {
  return (
    <div className="bg-[#2b7fff] relative rounded-[3.35544e+07px] shrink-0 size-[8px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid size-full" />
    </div>
  );
}

function Text61() {
  return (
    <div className="basis-0 grow h-[16px] min-h-px min-w-px relative shrink-0" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start overflow-clip relative rounded-[inherit] size-full">
        <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[#0a0a0a] text-[12px] text-nowrap">Windows 10</p>
      </div>
    </div>
  );
}

function Container117() {
  return (
    <div className="h-[16px] relative shrink-0 w-[81.719px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[6px] items-center relative size-full">
        <Container116 />
        <Text61 />
      </div>
    </div>
  );
}

function Text62() {
  return (
    <div className="h-[16px] relative shrink-0 w-[7.609px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#0a0a0a] text-[12px] text-nowrap">5</p>
      </div>
    </div>
  );
}

function Container118() {
  return (
    <div className="h-[20px] relative rounded-[4px] shrink-0 w-full" data-name="Container">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between px-[4px] py-0 relative size-full">
          <Container117 />
          <Text62 />
        </div>
      </div>
    </div>
  );
}

function Container119() {
  return (
    <div className="bg-[#6a7282] relative rounded-[3.35544e+07px] shrink-0 size-[8px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid size-full" />
    </div>
  );
}

function Text63() {
  return (
    <div className="basis-0 grow h-[16px] min-h-px min-w-px relative shrink-0" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start overflow-clip relative rounded-[inherit] size-full">
        <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[#0a0a0a] text-[12px] text-nowrap">macOS</p>
      </div>
    </div>
  );
}

function Container120() {
  return (
    <div className="h-[16px] relative shrink-0 w-[54.688px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[6px] items-center relative size-full">
        <Container119 />
        <Text63 />
      </div>
    </div>
  );
}

function Text64() {
  return (
    <div className="h-[16px] relative shrink-0 w-[7.703px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#0a0a0a] text-[12px] text-nowrap">3</p>
      </div>
    </div>
  );
}

function Container121() {
  return (
    <div className="h-[20px] relative rounded-[4px] shrink-0 w-full" data-name="Container">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between px-[4px] py-0 relative size-full">
          <Container120 />
          <Text64 />
        </div>
      </div>
    </div>
  );
}

function Container122() {
  return (
    <div className="bg-[#ff6900] relative rounded-[3.35544e+07px] shrink-0 size-[8px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid size-full" />
    </div>
  );
}

function Text65() {
  return (
    <div className="basis-0 grow h-[16px] min-h-px min-w-px relative shrink-0" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start overflow-clip relative rounded-[inherit] size-full">
        <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[#0a0a0a] text-[12px] text-nowrap">Ubuntu</p>
      </div>
    </div>
  );
}

function Container123() {
  return (
    <div className="h-[16px] relative shrink-0 w-[55.594px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[6px] items-center relative size-full">
        <Container122 />
        <Text65 />
      </div>
    </div>
  );
}

function Text66() {
  return (
    <div className="h-[16px] relative shrink-0 w-[7.406px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#0a0a0a] text-[12px] text-nowrap">2</p>
      </div>
    </div>
  );
}

function Container124() {
  return (
    <div className="h-[20px] relative rounded-[4px] shrink-0 w-full" data-name="Container">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between px-[4px] py-0 relative size-full">
          <Container123 />
          <Text66 />
        </div>
      </div>
    </div>
  );
}

function Container125() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[92px] items-start left-[108px] top-[4px] w-[215.375px]" data-name="Container">
      <Container115 />
      <Container118 />
      <Container121 />
      <Container124 />
    </div>
  );
}

function Container126() {
  return (
    <div className="absolute h-[100px] left-[13px] top-[41px] w-[323.375px]" data-name="Container">
      <Container112 />
      <Container125 />
    </div>
  );
}

function Container127() {
  return (
    <div className="[grid-area:1_/_4] bg-[#f9fafb] place-self-stretch relative rounded-[10px] shrink-0" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.15)] border-solid inset-0 pointer-events-none rounded-[10px]" />
      <Heading5 />
      <Container126 />
    </div>
  );
}

function UnifiedAgentViewV6() {
  return (
    <div className="absolute gap-[16px] grid grid-cols-[repeat(4,_minmax(0px,_1fr))] grid-rows-[repeat(1,_minmax(0px,_1fr))] h-[156px] left-[24px] top-[84px] w-[1445.5px]" data-name="UnifiedAgentViewV3">
      <Container85 />
      <Container98 />
      <Container111 />
      <Container127 />
    </div>
  );
}

function Icon63() {
  return (
    <div className="absolute left-[11px] size-[16px] top-[10px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d="M8 2V10" id="Vector" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p26e09a00} id="Vector_2" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p23ad1400} id="Vector_3" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Button29() {
  return (
    <div className="bg-[#f8f9fa] h-[36px] relative rounded-[8px] shrink-0 w-[93.344px]" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.15)] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Icon63 />
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-[61px] not-italic text-[#0a0a0a] text-[14px] text-center text-nowrap top-[8px] tracking-[-0.1504px] translate-x-[-50%]">Export</p>
      </div>
    </div>
  );
}

function Icon64() {
  return (
    <div className="absolute left-[11px] size-[16px] top-[10px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p19987d80} id="Vector" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M14 2V5.33333H10.6667" id="Vector_2" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p2a3e9c80} id="Vector_3" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M5.33333 10.6667H2V14" id="Vector_4" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Button30() {
  return (
    <div className="bg-[#f8f9fa] h-[36px] relative rounded-[8px] shrink-0 w-[100.984px]" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.15)] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Icon64 />
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-[64.5px] not-italic text-[#0a0a0a] text-[14px] text-center text-nowrap top-[8px] tracking-[-0.1504px] translate-x-[-50%]">Refresh</p>
      </div>
    </div>
  );
}

function Icon65() {
  return (
    <div className="absolute left-[10px] size-[16px] top-[10px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d="M8 10V2" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p23ad1400} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p19411800} id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Button31() {
  return (
    <div className="basis-0 bg-[#4e4fa9] grow h-[36px] min-h-px min-w-px opacity-50 relative rounded-[8px] shrink-0" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Icon65 />
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-[67px] not-italic text-[14px] text-center text-nowrap text-white top-[8px] tracking-[-0.1504px] translate-x-[-50%]">Get Logs</p>
      </div>
    </div>
  );
}

function Container128() {
  return (
    <div className="absolute content-stretch flex gap-[6px] h-[36px] items-center left-[1132.2px] top-0 w-[313.297px]" data-name="Container">
      <Button29 />
      <Button30 />
      <Button31 />
    </div>
  );
}

function Input2() {
  return (
    <div className="absolute bg-[#f1f3f4] h-[36px] left-0 rounded-[8px] top-0 w-[320px]" data-name="Input">
      <div className="content-stretch flex items-center overflow-clip pl-[40px] pr-[12px] py-[4px] relative rounded-[inherit] size-full">
        <p className="font-['Inter:Regular',sans-serif] font-normal leading-[normal] not-italic relative shrink-0 text-[#6c757d] text-[14px] text-nowrap tracking-[-0.1504px]">Search</p>
      </div>
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function Icon66() {
  return (
    <div className="absolute left-[12px] size-[16px] top-[10px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d="M14 14L11.1066 11.1066" id="Vector" stroke="var(--stroke-0, #6C757D)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p107a080} id="Vector_2" stroke="var(--stroke-0, #6C757D)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Container129() {
  return (
    <div className="absolute h-[36px] left-0 top-0 w-[320px]" data-name="Container">
      <Input2 />
      <Icon66 />
    </div>
  );
}

function UnifiedAgentViewV7() {
  return (
    <div className="absolute h-[36px] left-[24px] top-[264px] w-[1445.5px]" data-name="UnifiedAgentViewV3">
      <Container128 />
      <Container129 />
    </div>
  );
}

function Checkbox() {
  return <div className="absolute bg-[#f3f4f6] left-0 size-[13px] top-0" data-name="Checkbox" />;
}

function UnifiedAgentViewV8() {
  return (
    <div className="absolute left-[8px] size-[13px] top-[11.5px]" data-name="UnifiedAgentViewV3">
      <Checkbox />
    </div>
  );
}

function TableCell() {
  return (
    <div className="absolute h-[39px] left-0 top-0 w-[29px]" data-name="TableCell">
      <UnifiedAgentViewV8 />
    </div>
  );
}

function TableCell1() {
  return <div className="absolute h-[39px] left-[29px] top-0 w-[122.344px]" data-name="TableCell" />;
}

function Badge5() {
  return (
    <div className="absolute bg-[#dcfce7] h-[22px] left-[8px] rounded-[8px] top-[8.5px] w-[72.391px]" data-name="Badge">
      <div className="content-stretch flex items-center justify-center overflow-clip px-[9px] py-[3px] relative rounded-[inherit] size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#008236] text-[12px] text-nowrap">Deployed</p>
      </div>
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function TableCell2() {
  return (
    <div className="absolute h-[39px] left-[151.34px] top-0 w-[105.016px]" data-name="TableCell">
      <Badge5 />
    </div>
  );
}

function TableCell3() {
  return (
    <div className="absolute h-[39px] left-[256.36px] top-0 w-[95.344px]" data-name="TableCell">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[8px] not-italic text-[#0a0a0a] text-[14px] text-nowrap top-[9.5px] tracking-[-0.1504px]">25.118 BC</p>
    </div>
  );
}

function TableCell4() {
  return (
    <div className="absolute h-[39px] left-[351.7px] top-0 w-[115.141px]" data-name="TableCell">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[8px] not-italic text-[#0a0a0a] text-[14px] text-nowrap top-[9.5px] tracking-[-0.1504px]">Desktop</p>
    </div>
  );
}

function TableCell5() {
  return (
    <div className="absolute h-[39px] left-[466.84px] top-0 w-[111.094px]" data-name="TableCell">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[8px] not-italic text-[#0a0a0a] text-[14px] text-nowrap top-[9.5px] tracking-[-0.1504px]">Windows 11</p>
    </div>
  );
}

function Badge6() {
  return (
    <div className="absolute bg-[rgba(78,79,169,0.1)] h-[22px] left-0 rounded-[8px] top-0 w-[151.438px]" data-name="Badge">
      <div className="content-stretch flex items-center justify-center overflow-clip px-[9px] py-[3px] relative rounded-[inherit] size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#4e4fa9] text-[12px] text-nowrap">NPM Core for Windows</p>
      </div>
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function Badge7() {
  return (
    <div className="absolute bg-[rgba(78,79,169,0.1)] h-[22px] left-[155.44px] rounded-[8px] top-0 w-[129.938px]" data-name="Badge">
      <div className="content-stretch flex items-center justify-center overflow-clip px-[9px] py-[3px] relative rounded-[inherit] size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#4e4fa9] text-[12px] text-nowrap">NPM Core for Linux</p>
      </div>
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function UnifiedAgentViewV9() {
  return (
    <div className="absolute h-[22px] left-[8px] top-[8.5px] w-[706.766px]" data-name="UnifiedAgentViewV3">
      <Badge6 />
      <Badge7 />
    </div>
  );
}

function TableCell6() {
  return (
    <div className="absolute h-[39px] left-[577.94px] top-0 w-[722.766px]" data-name="TableCell">
      <UnifiedAgentViewV9 />
    </div>
  );
}

function TableCell7() {
  return (
    <div className="absolute h-[39px] left-[1300.7px] top-0 w-[142.797px]" data-name="TableCell">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[8px] not-italic text-[#6c757d] text-[14px] text-nowrap top-[9.5px] tracking-[-0.1504px]">2 min ago</p>
    </div>
  );
}

function TableRow() {
  return (
    <div className="absolute border-[0px_0px_1px] border-[rgba(0,0,0,0.15)] border-solid h-[39px] left-0 top-0 w-[1443.5px]" data-name="TableRow">
      <TableCell />
      <TableCell1 />
      <TableCell2 />
      <TableCell3 />
      <TableCell4 />
      <TableCell5 />
      <TableCell6 />
      <TableCell7 />
    </div>
  );
}

function Checkbox1() {
  return <div className="absolute bg-[#f3f4f6] left-0 size-[13px] top-0" data-name="Checkbox" />;
}

function UnifiedAgentViewV10() {
  return (
    <div className="absolute left-[8px] size-[13px] top-[11.5px]" data-name="UnifiedAgentViewV3">
      <Checkbox1 />
    </div>
  );
}

function TableCell8() {
  return (
    <div className="absolute h-[39px] left-0 top-0 w-[29px]" data-name="TableCell">
      <UnifiedAgentViewV10 />
    </div>
  );
}

function TableCell9() {
  return <div className="absolute h-[39px] left-[29px] top-0 w-[122.344px]" data-name="TableCell" />;
}

function Badge8() {
  return (
    <div className="absolute bg-[#dcfce7] h-[22px] left-[8px] rounded-[8px] top-[8.5px] w-[72.391px]" data-name="Badge">
      <div className="content-stretch flex items-center justify-center overflow-clip px-[9px] py-[3px] relative rounded-[inherit] size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#008236] text-[12px] text-nowrap">Deployed</p>
      </div>
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function TableCell10() {
  return (
    <div className="absolute h-[39px] left-[151.34px] top-0 w-[105.016px]" data-name="TableCell">
      <Badge8 />
    </div>
  );
}

function TableCell11() {
  return (
    <div className="absolute h-[39px] left-[256.36px] top-0 w-[95.344px]" data-name="TableCell">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[8px] not-italic text-[#0a0a0a] text-[14px] text-nowrap top-[9.5px] tracking-[-0.1504px]">25.118 BC</p>
    </div>
  );
}

function TableCell12() {
  return (
    <div className="absolute h-[39px] left-[351.7px] top-0 w-[115.141px]" data-name="TableCell">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[8px] not-italic text-[#0a0a0a] text-[14px] text-nowrap top-[9.5px] tracking-[-0.1504px]">Desktop</p>
    </div>
  );
}

function TableCell13() {
  return (
    <div className="absolute h-[39px] left-[466.84px] top-0 w-[111.094px]" data-name="TableCell">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[8px] not-italic text-[#0a0a0a] text-[14px] text-nowrap top-[9.5px] tracking-[-0.1504px]">Windows 10</p>
    </div>
  );
}

function Badge9() {
  return (
    <div className="absolute bg-[rgba(78,79,169,0.1)] h-[22px] left-0 rounded-[8px] top-0 w-[119.922px]" data-name="Badge">
      <div className="content-stretch flex items-center justify-center overflow-clip px-[9px] py-[3px] relative rounded-[inherit] size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#4e4fa9] text-[12px] text-nowrap">Aternity Recorder</p>
      </div>
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function Badge10() {
  return (
    <div className="absolute bg-[rgba(78,79,169,0.1)] h-[22px] left-[123.92px] rounded-[8px] top-0 w-[119.703px]" data-name="Badge">
      <div className="content-stretch flex items-center justify-center overflow-clip px-[9px] py-[3px] relative rounded-[inherit] size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#4e4fa9] text-[12px] text-nowrap">SteelHead Mobile</p>
      </div>
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function Badge11() {
  return (
    <div className="absolute bg-[rgba(78,79,169,0.1)] h-[22px] left-[247.63px] rounded-[8px] top-0 w-[210.734px]" data-name="Badge">
      <div className="content-stretch flex items-center justify-center overflow-clip px-[9px] py-[3px] relative rounded-[inherit] size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#4e4fa9] text-[12px] text-nowrap">NPM Packet capture for Windows</p>
      </div>
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function UnifiedAgentViewV11() {
  return (
    <div className="absolute h-[22px] left-[8px] top-[8.5px] w-[706.766px]" data-name="UnifiedAgentViewV3">
      <Badge9 />
      <Badge10 />
      <Badge11 />
    </div>
  );
}

function TableCell14() {
  return (
    <div className="absolute h-[39px] left-[577.94px] top-0 w-[722.766px]" data-name="TableCell">
      <UnifiedAgentViewV11 />
    </div>
  );
}

function TableCell15() {
  return (
    <div className="absolute h-[39px] left-[1300.7px] top-0 w-[142.797px]" data-name="TableCell">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[8px] not-italic text-[#6c757d] text-[14px] text-nowrap top-[9.5px] tracking-[-0.1504px]">15 min ago</p>
    </div>
  );
}

function TableRow1() {
  return (
    <div className="absolute border-[0px_0px_1px] border-[rgba(0,0,0,0.15)] border-solid h-[39px] left-0 top-[39px] w-[1443.5px]" data-name="TableRow">
      <TableCell8 />
      <TableCell9 />
      <TableCell10 />
      <TableCell11 />
      <TableCell12 />
      <TableCell13 />
      <TableCell14 />
      <TableCell15 />
    </div>
  );
}

function Checkbox2() {
  return <div className="absolute bg-[#f3f4f6] left-0 size-[13px] top-0" data-name="Checkbox" />;
}

function UnifiedAgentViewV12() {
  return (
    <div className="absolute left-[8px] size-[13px] top-[11.5px]" data-name="UnifiedAgentViewV3">
      <Checkbox2 />
    </div>
  );
}

function TableCell16() {
  return (
    <div className="absolute h-[39px] left-0 top-0 w-[29px]" data-name="TableCell">
      <UnifiedAgentViewV12 />
    </div>
  );
}

function TableCell17() {
  return <div className="absolute h-[39px] left-[29px] top-0 w-[122.344px]" data-name="TableCell" />;
}

function Badge12() {
  return (
    <div className="absolute bg-[#dcfce7] h-[22px] left-[8px] rounded-[8px] top-[8.5px] w-[72.391px]" data-name="Badge">
      <div className="content-stretch flex items-center justify-center overflow-clip px-[9px] py-[3px] relative rounded-[inherit] size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#008236] text-[12px] text-nowrap">Deployed</p>
      </div>
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function TableCell18() {
  return (
    <div className="absolute h-[39px] left-[151.34px] top-0 w-[105.016px]" data-name="TableCell">
      <Badge12 />
    </div>
  );
}

function TableCell19() {
  return (
    <div className="absolute h-[39px] left-[256.36px] top-0 w-[95.344px]" data-name="TableCell">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[8px] not-italic text-[#0a0a0a] text-[14px] text-nowrap top-[9.5px] tracking-[-0.1504px]">25.118 BC</p>
    </div>
  );
}

function TableCell20() {
  return (
    <div className="absolute h-[39px] left-[351.7px] top-0 w-[115.141px]" data-name="TableCell">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[8px] not-italic text-[#0a0a0a] text-[14px] text-nowrap top-[9.5px] tracking-[-0.1504px]">Server</p>
    </div>
  );
}

function TableCell21() {
  return (
    <div className="absolute h-[39px] left-[466.84px] top-0 w-[111.094px]" data-name="TableCell">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[8px] not-italic text-[#0a0a0a] text-[14px] text-nowrap top-[9.5px] tracking-[-0.1504px]">Ubuntu</p>
    </div>
  );
}

function Badge13() {
  return (
    <div className="absolute bg-[rgba(78,79,169,0.1)] h-[22px] left-0 rounded-[8px] top-0 w-[129.938px]" data-name="Badge">
      <div className="content-stretch flex items-center justify-center overflow-clip px-[9px] py-[3px] relative rounded-[inherit] size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#4e4fa9] text-[12px] text-nowrap">NPM Core for Linux</p>
      </div>
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function Badge14() {
  return (
    <div className="absolute bg-[rgba(78,79,169,0.1)] h-[22px] left-[133.94px] rounded-[8px] top-0 w-[119.922px]" data-name="Badge">
      <div className="content-stretch flex items-center justify-center overflow-clip px-[9px] py-[3px] relative rounded-[inherit] size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#4e4fa9] text-[12px] text-nowrap">Aternity Recorder</p>
      </div>
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function Badge15() {
  return (
    <div className="absolute bg-[rgba(78,79,169,0.1)] h-[22px] left-[257.86px] rounded-[8px] top-0 w-[119.703px]" data-name="Badge">
      <div className="content-stretch flex items-center justify-center overflow-clip px-[9px] py-[3px] relative rounded-[inherit] size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#4e4fa9] text-[12px] text-nowrap">SteelHead Mobile</p>
      </div>
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function Badge16() {
  return (
    <div className="absolute bg-[rgba(78,79,169,0.1)] h-[22px] left-[381.56px] rounded-[8px] top-0 w-[210.734px]" data-name="Badge">
      <div className="content-stretch flex items-center justify-center overflow-clip px-[9px] py-[3px] relative rounded-[inherit] size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#4e4fa9] text-[12px] text-nowrap">NPM Packet capture for Windows</p>
      </div>
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function UnifiedAgentViewV13() {
  return (
    <div className="absolute h-[22px] left-[8px] top-[8.5px] w-[706.766px]" data-name="UnifiedAgentViewV3">
      <Badge13 />
      <Badge14 />
      <Badge15 />
      <Badge16 />
    </div>
  );
}

function TableCell22() {
  return (
    <div className="absolute h-[39px] left-[577.94px] top-0 w-[722.766px]" data-name="TableCell">
      <UnifiedAgentViewV13 />
    </div>
  );
}

function TableCell23() {
  return (
    <div className="absolute h-[39px] left-[1300.7px] top-0 w-[142.797px]" data-name="TableCell">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[8px] not-italic text-[#6c757d] text-[14px] text-nowrap top-[9.5px] tracking-[-0.1504px]">1 hour ago</p>
    </div>
  );
}

function TableRow2() {
  return (
    <div className="absolute border-[0px_0px_1px] border-[rgba(0,0,0,0.15)] border-solid h-[39px] left-0 top-[78px] w-[1443.5px]" data-name="TableRow">
      <TableCell16 />
      <TableCell17 />
      <TableCell18 />
      <TableCell19 />
      <TableCell20 />
      <TableCell21 />
      <TableCell22 />
      <TableCell23 />
    </div>
  );
}

function Checkbox3() {
  return <div className="absolute bg-[#f3f4f6] left-0 size-[13px] top-0" data-name="Checkbox" />;
}

function UnifiedAgentViewV14() {
  return (
    <div className="absolute left-[8px] size-[13px] top-[11.5px]" data-name="UnifiedAgentViewV3">
      <Checkbox3 />
    </div>
  );
}

function TableCell24() {
  return (
    <div className="absolute h-[39px] left-0 top-0 w-[29px]" data-name="TableCell">
      <UnifiedAgentViewV14 />
    </div>
  );
}

function TableCell25() {
  return <div className="absolute h-[39px] left-[29px] top-0 w-[122.344px]" data-name="TableCell" />;
}

function Badge17() {
  return (
    <div className="absolute bg-[#dcfce7] h-[22px] left-[8px] rounded-[8px] top-[8.5px] w-[72.391px]" data-name="Badge">
      <div className="content-stretch flex items-center justify-center overflow-clip px-[9px] py-[3px] relative rounded-[inherit] size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#008236] text-[12px] text-nowrap">Deployed</p>
      </div>
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function TableCell26() {
  return (
    <div className="absolute h-[39px] left-[151.34px] top-0 w-[105.016px]" data-name="TableCell">
      <Badge17 />
    </div>
  );
}

function TableCell27() {
  return (
    <div className="absolute h-[39px] left-[256.36px] top-0 w-[95.344px]" data-name="TableCell">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[8px] not-italic text-[#0a0a0a] text-[14px] text-nowrap top-[9.5px] tracking-[-0.1504px]">25.118 BC</p>
    </div>
  );
}

function TableCell28() {
  return (
    <div className="absolute h-[39px] left-[351.7px] top-0 w-[115.141px]" data-name="TableCell">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[8px] not-italic text-[#0a0a0a] text-[14px] text-nowrap top-[9.5px] tracking-[-0.1504px]">Desktop</p>
    </div>
  );
}

function TableCell29() {
  return (
    <div className="absolute h-[39px] left-[466.84px] top-0 w-[111.094px]" data-name="TableCell">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[8px] not-italic text-[#0a0a0a] text-[14px] text-nowrap top-[9.5px] tracking-[-0.1504px]">Windows 10</p>
    </div>
  );
}

function Badge18() {
  return (
    <div className="absolute bg-[rgba(78,79,169,0.1)] h-[22px] left-0 rounded-[8px] top-0 w-[151.438px]" data-name="Badge">
      <div className="content-stretch flex items-center justify-center overflow-clip px-[9px] py-[3px] relative rounded-[inherit] size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#4e4fa9] text-[12px] text-nowrap">NPM Core for Windows</p>
      </div>
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function Badge19() {
  return (
    <div className="absolute bg-[rgba(78,79,169,0.1)] h-[22px] left-[155.44px] rounded-[8px] top-0 w-[129.938px]" data-name="Badge">
      <div className="content-stretch flex items-center justify-center overflow-clip px-[9px] py-[3px] relative rounded-[inherit] size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#4e4fa9] text-[12px] text-nowrap">NPM Core for Linux</p>
      </div>
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function UnifiedAgentViewV15() {
  return (
    <div className="absolute h-[22px] left-[8px] top-[8.5px] w-[706.766px]" data-name="UnifiedAgentViewV3">
      <Badge18 />
      <Badge19 />
    </div>
  );
}

function TableCell30() {
  return (
    <div className="absolute h-[39px] left-[577.94px] top-0 w-[722.766px]" data-name="TableCell">
      <UnifiedAgentViewV15 />
    </div>
  );
}

function TableCell31() {
  return (
    <div className="absolute h-[39px] left-[1300.7px] top-0 w-[142.797px]" data-name="TableCell">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[8px] not-italic text-[#6c757d] text-[14px] text-nowrap top-[9.5px] tracking-[-0.1504px]">3 hours ago</p>
    </div>
  );
}

function TableRow3() {
  return (
    <div className="absolute border-[0px_0px_1px] border-[rgba(0,0,0,0.15)] border-solid h-[39px] left-0 top-[117px] w-[1443.5px]" data-name="TableRow">
      <TableCell24 />
      <TableCell25 />
      <TableCell26 />
      <TableCell27 />
      <TableCell28 />
      <TableCell29 />
      <TableCell30 />
      <TableCell31 />
    </div>
  );
}

function Checkbox4() {
  return <div className="absolute bg-[#f3f4f6] left-0 size-[13px] top-0" data-name="Checkbox" />;
}

function UnifiedAgentViewV16() {
  return (
    <div className="absolute left-[8px] size-[13px] top-[11.5px]" data-name="UnifiedAgentViewV3">
      <Checkbox4 />
    </div>
  );
}

function TableCell32() {
  return (
    <div className="absolute h-[39px] left-0 top-0 w-[29px]" data-name="TableCell">
      <UnifiedAgentViewV16 />
    </div>
  );
}

function TableCell33() {
  return <div className="absolute h-[39px] left-[29px] top-0 w-[122.344px]" data-name="TableCell" />;
}

function Badge20() {
  return (
    <div className="absolute bg-[#dcfce7] h-[22px] left-[8px] rounded-[8px] top-[8.5px] w-[72.391px]" data-name="Badge">
      <div className="content-stretch flex items-center justify-center overflow-clip px-[9px] py-[3px] relative rounded-[inherit] size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#008236] text-[12px] text-nowrap">Deployed</p>
      </div>
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function TableCell34() {
  return (
    <div className="absolute h-[39px] left-[151.34px] top-0 w-[105.016px]" data-name="TableCell">
      <Badge20 />
    </div>
  );
}

function TableCell35() {
  return (
    <div className="absolute h-[39px] left-[256.36px] top-0 w-[95.344px]" data-name="TableCell">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[8px] not-italic text-[#0a0a0a] text-[14px] text-nowrap top-[9.5px] tracking-[-0.1504px]">25.118 BC</p>
    </div>
  );
}

function TableCell36() {
  return (
    <div className="absolute h-[39px] left-[351.7px] top-0 w-[115.141px]" data-name="TableCell">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[8px] not-italic text-[#0a0a0a] text-[14px] text-nowrap top-[9.5px] tracking-[-0.1504px]">VDI</p>
    </div>
  );
}

function TableCell37() {
  return (
    <div className="absolute h-[39px] left-[466.84px] top-0 w-[111.094px]" data-name="TableCell">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[8px] not-italic text-[#0a0a0a] text-[14px] text-nowrap top-[9.5px] tracking-[-0.1504px]">Windows 11</p>
    </div>
  );
}

function Badge21() {
  return (
    <div className="absolute bg-[rgba(78,79,169,0.1)] h-[22px] left-0 rounded-[8px] top-0 w-[119.922px]" data-name="Badge">
      <div className="content-stretch flex items-center justify-center overflow-clip px-[9px] py-[3px] relative rounded-[inherit] size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#4e4fa9] text-[12px] text-nowrap">Aternity Recorder</p>
      </div>
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function Badge22() {
  return (
    <div className="absolute bg-[rgba(78,79,169,0.1)] h-[22px] left-[123.92px] rounded-[8px] top-0 w-[119.703px]" data-name="Badge">
      <div className="content-stretch flex items-center justify-center overflow-clip px-[9px] py-[3px] relative rounded-[inherit] size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#4e4fa9] text-[12px] text-nowrap">SteelHead Mobile</p>
      </div>
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function Badge23() {
  return (
    <div className="absolute bg-[rgba(78,79,169,0.1)] h-[22px] left-[247.63px] rounded-[8px] top-0 w-[210.734px]" data-name="Badge">
      <div className="content-stretch flex items-center justify-center overflow-clip px-[9px] py-[3px] relative rounded-[inherit] size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#4e4fa9] text-[12px] text-nowrap">NPM Packet capture for Windows</p>
      </div>
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function UnifiedAgentViewV17() {
  return (
    <div className="absolute h-[22px] left-[8px] top-[8.5px] w-[706.766px]" data-name="UnifiedAgentViewV3">
      <Badge21 />
      <Badge22 />
      <Badge23 />
    </div>
  );
}

function TableCell38() {
  return (
    <div className="absolute h-[39px] left-[577.94px] top-0 w-[722.766px]" data-name="TableCell">
      <UnifiedAgentViewV17 />
    </div>
  );
}

function TableCell39() {
  return (
    <div className="absolute h-[39px] left-[1300.7px] top-0 w-[142.797px]" data-name="TableCell">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[8px] not-italic text-[#6c757d] text-[14px] text-nowrap top-[9.5px] tracking-[-0.1504px]">1 day ago</p>
    </div>
  );
}

function TableRow4() {
  return (
    <div className="absolute border-[0px_0px_1px] border-[rgba(0,0,0,0.15)] border-solid h-[39px] left-0 top-[156px] w-[1443.5px]" data-name="TableRow">
      <TableCell32 />
      <TableCell33 />
      <TableCell34 />
      <TableCell35 />
      <TableCell36 />
      <TableCell37 />
      <TableCell38 />
      <TableCell39 />
    </div>
  );
}

function Checkbox5() {
  return <div className="absolute bg-[#f3f4f6] left-0 size-[13px] top-0" data-name="Checkbox" />;
}

function UnifiedAgentViewV18() {
  return (
    <div className="absolute left-[8px] size-[13px] top-[11.5px]" data-name="UnifiedAgentViewV3">
      <Checkbox5 />
    </div>
  );
}

function TableCell40() {
  return (
    <div className="absolute h-[39px] left-0 top-0 w-[29px]" data-name="TableCell">
      <UnifiedAgentViewV18 />
    </div>
  );
}

function TableCell41() {
  return <div className="absolute h-[39px] left-[29px] top-0 w-[122.344px]" data-name="TableCell" />;
}

function Badge24() {
  return (
    <div className="absolute bg-[#dcfce7] h-[22px] left-[8px] rounded-[8px] top-[8.5px] w-[72.391px]" data-name="Badge">
      <div className="content-stretch flex items-center justify-center overflow-clip px-[9px] py-[3px] relative rounded-[inherit] size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#008236] text-[12px] text-nowrap">Deployed</p>
      </div>
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function TableCell42() {
  return (
    <div className="absolute h-[39px] left-[151.34px] top-0 w-[105.016px]" data-name="TableCell">
      <Badge24 />
    </div>
  );
}

function TableCell43() {
  return (
    <div className="absolute h-[39px] left-[256.36px] top-0 w-[95.344px]" data-name="TableCell">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[8px] not-italic text-[#0a0a0a] text-[14px] text-nowrap top-[9.5px] tracking-[-0.1504px]">25.118 BC</p>
    </div>
  );
}

function TableCell44() {
  return (
    <div className="absolute h-[39px] left-[351.7px] top-0 w-[115.141px]" data-name="TableCell">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[8px] not-italic text-[#0a0a0a] text-[14px] text-nowrap top-[9.5px] tracking-[-0.1504px]">Desktop</p>
    </div>
  );
}

function TableCell45() {
  return (
    <div className="absolute h-[39px] left-[466.84px] top-0 w-[111.094px]" data-name="TableCell">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[8px] not-italic text-[#0a0a0a] text-[14px] text-nowrap top-[9.5px] tracking-[-0.1504px]">Windows 10</p>
    </div>
  );
}

function Badge25() {
  return (
    <div className="absolute bg-[rgba(78,79,169,0.1)] h-[22px] left-0 rounded-[8px] top-0 w-[129.938px]" data-name="Badge">
      <div className="content-stretch flex items-center justify-center overflow-clip px-[9px] py-[3px] relative rounded-[inherit] size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#4e4fa9] text-[12px] text-nowrap">NPM Core for Linux</p>
      </div>
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function Badge26() {
  return (
    <div className="absolute bg-[rgba(78,79,169,0.1)] h-[22px] left-[133.94px] rounded-[8px] top-0 w-[119.922px]" data-name="Badge">
      <div className="content-stretch flex items-center justify-center overflow-clip px-[9px] py-[3px] relative rounded-[inherit] size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#4e4fa9] text-[12px] text-nowrap">Aternity Recorder</p>
      </div>
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function Badge27() {
  return (
    <div className="absolute bg-[rgba(78,79,169,0.1)] h-[22px] left-[257.86px] rounded-[8px] top-0 w-[119.703px]" data-name="Badge">
      <div className="content-stretch flex items-center justify-center overflow-clip px-[9px] py-[3px] relative rounded-[inherit] size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#4e4fa9] text-[12px] text-nowrap">SteelHead Mobile</p>
      </div>
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function Badge28() {
  return (
    <div className="absolute bg-[rgba(78,79,169,0.1)] h-[22px] left-[381.56px] rounded-[8px] top-0 w-[210.734px]" data-name="Badge">
      <div className="content-stretch flex items-center justify-center overflow-clip px-[9px] py-[3px] relative rounded-[inherit] size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#4e4fa9] text-[12px] text-nowrap">NPM Packet capture for Windows</p>
      </div>
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function UnifiedAgentViewV19() {
  return (
    <div className="absolute h-[22px] left-[8px] top-[8.5px] w-[706.766px]" data-name="UnifiedAgentViewV3">
      <Badge25 />
      <Badge26 />
      <Badge27 />
      <Badge28 />
    </div>
  );
}

function TableCell46() {
  return (
    <div className="absolute h-[39px] left-[577.94px] top-0 w-[722.766px]" data-name="TableCell">
      <UnifiedAgentViewV19 />
    </div>
  );
}

function TableCell47() {
  return (
    <div className="absolute h-[39px] left-[1300.7px] top-0 w-[142.797px]" data-name="TableCell">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[8px] not-italic text-[#6c757d] text-[14px] text-nowrap top-[9.5px] tracking-[-0.1504px]">Just now</p>
    </div>
  );
}

function TableRow5() {
  return (
    <div className="absolute border-[0px_0px_1px] border-[rgba(0,0,0,0.15)] border-solid h-[39px] left-0 top-[195px] w-[1443.5px]" data-name="TableRow">
      <TableCell40 />
      <TableCell41 />
      <TableCell42 />
      <TableCell43 />
      <TableCell44 />
      <TableCell45 />
      <TableCell46 />
      <TableCell47 />
    </div>
  );
}

function Checkbox6() {
  return <div className="absolute bg-[#f3f4f6] left-0 size-[13px] top-0" data-name="Checkbox" />;
}

function UnifiedAgentViewV20() {
  return (
    <div className="absolute left-[8px] size-[13px] top-[11.5px]" data-name="UnifiedAgentViewV3">
      <Checkbox6 />
    </div>
  );
}

function TableCell48() {
  return (
    <div className="absolute h-[39px] left-0 top-0 w-[29px]" data-name="TableCell">
      <UnifiedAgentViewV20 />
    </div>
  );
}

function TableCell49() {
  return <div className="absolute h-[39px] left-[29px] top-0 w-[122.344px]" data-name="TableCell" />;
}

function Badge29() {
  return (
    <div className="absolute bg-[#dcfce7] h-[22px] left-[8px] rounded-[8px] top-[8.5px] w-[72.391px]" data-name="Badge">
      <div className="content-stretch flex items-center justify-center overflow-clip px-[9px] py-[3px] relative rounded-[inherit] size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#008236] text-[12px] text-nowrap">Deployed</p>
      </div>
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function TableCell50() {
  return (
    <div className="absolute h-[39px] left-[151.34px] top-0 w-[105.016px]" data-name="TableCell">
      <Badge29 />
    </div>
  );
}

function TableCell51() {
  return (
    <div className="absolute h-[39px] left-[256.36px] top-0 w-[95.344px]" data-name="TableCell">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[8px] not-italic text-[#0a0a0a] text-[14px] text-nowrap top-[9.5px] tracking-[-0.1504px]">25.118 BC</p>
    </div>
  );
}

function TableCell52() {
  return (
    <div className="absolute h-[39px] left-[351.7px] top-0 w-[115.141px]" data-name="TableCell">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[8px] not-italic text-[#0a0a0a] text-[14px] text-nowrap top-[9.5px] tracking-[-0.1504px]">Server</p>
    </div>
  );
}

function TableCell53() {
  return (
    <div className="absolute h-[39px] left-[466.84px] top-0 w-[111.094px]" data-name="TableCell">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[8px] not-italic text-[#0a0a0a] text-[14px] text-nowrap top-[9.5px] tracking-[-0.1504px]">CentOS</p>
    </div>
  );
}

function Badge30() {
  return (
    <div className="absolute bg-[rgba(78,79,169,0.1)] h-[22px] left-0 rounded-[8px] top-0 w-[109.891px]" data-name="Badge">
      <div className="content-stretch flex items-center justify-center overflow-clip px-[9px] py-[3px] relative rounded-[inherit] size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#4e4fa9] text-[12px] text-nowrap">Aternity Module</p>
      </div>
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function Badge31() {
  return (
    <div className="absolute bg-[rgba(78,79,169,0.1)] h-[22px] left-[113.89px] rounded-[8px] top-0 w-[126.219px]" data-name="Badge">
      <div className="content-stretch flex items-center justify-center overflow-clip px-[9px] py-[3px] relative rounded-[inherit] size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#4e4fa9] text-[12px] text-nowrap">Aternity Sentiment</p>
      </div>
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function UnifiedAgentViewV21() {
  return (
    <div className="absolute h-[22px] left-[8px] top-[8.5px] w-[706.766px]" data-name="UnifiedAgentViewV3">
      <Badge30 />
      <Badge31 />
    </div>
  );
}

function TableCell54() {
  return (
    <div className="absolute h-[39px] left-[577.94px] top-0 w-[722.766px]" data-name="TableCell">
      <UnifiedAgentViewV21 />
    </div>
  );
}

function TableCell55() {
  return (
    <div className="absolute h-[39px] left-[1300.7px] top-0 w-[142.797px]" data-name="TableCell">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[8px] not-italic text-[#6c757d] text-[14px] text-nowrap top-[9.5px] tracking-[-0.1504px]">2 min ago</p>
    </div>
  );
}

function TableRow6() {
  return (
    <div className="absolute border-[0px_0px_1px] border-[rgba(0,0,0,0.15)] border-solid h-[39px] left-0 top-[234px] w-[1443.5px]" data-name="TableRow">
      <TableCell48 />
      <TableCell49 />
      <TableCell50 />
      <TableCell51 />
      <TableCell52 />
      <TableCell53 />
      <TableCell54 />
      <TableCell55 />
    </div>
  );
}

function Checkbox7() {
  return <div className="absolute bg-[#f3f4f6] left-0 size-[13px] top-0" data-name="Checkbox" />;
}

function UnifiedAgentViewV22() {
  return (
    <div className="absolute left-[8px] size-[13px] top-[11.5px]" data-name="UnifiedAgentViewV3">
      <Checkbox7 />
    </div>
  );
}

function TableCell56() {
  return (
    <div className="absolute h-[39px] left-0 top-0 w-[29px]" data-name="TableCell">
      <UnifiedAgentViewV22 />
    </div>
  );
}

function TableCell57() {
  return <div className="absolute h-[39px] left-[29px] top-0 w-[122.344px]" data-name="TableCell" />;
}

function Badge32() {
  return (
    <div className="absolute bg-[#dcfce7] h-[22px] left-[8px] rounded-[8px] top-[8.5px] w-[72.391px]" data-name="Badge">
      <div className="content-stretch flex items-center justify-center overflow-clip px-[9px] py-[3px] relative rounded-[inherit] size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#008236] text-[12px] text-nowrap">Deployed</p>
      </div>
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function TableCell58() {
  return (
    <div className="absolute h-[39px] left-[151.34px] top-0 w-[105.016px]" data-name="TableCell">
      <Badge32 />
    </div>
  );
}

function TableCell59() {
  return (
    <div className="absolute h-[39px] left-[256.36px] top-0 w-[95.344px]" data-name="TableCell">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[8px] not-italic text-[#0a0a0a] text-[14px] text-nowrap top-[9.5px] tracking-[-0.1504px]">26.110 BC</p>
    </div>
  );
}

function TableCell60() {
  return (
    <div className="absolute h-[39px] left-[351.7px] top-0 w-[115.141px]" data-name="TableCell">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[8px] not-italic text-[#0a0a0a] text-[14px] text-nowrap top-[9.5px] tracking-[-0.1504px]">Desktop</p>
    </div>
  );
}

function TableCell61() {
  return (
    <div className="absolute h-[39px] left-[466.84px] top-0 w-[111.094px]" data-name="TableCell">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[8px] not-italic text-[#0a0a0a] text-[14px] text-nowrap top-[9.5px] tracking-[-0.1504px]">Windows 11</p>
    </div>
  );
}

function Badge33() {
  return (
    <div className="absolute bg-[rgba(78,79,169,0.1)] h-[22px] left-0 rounded-[8px] top-0 w-[129.938px]" data-name="Badge">
      <div className="content-stretch flex items-center justify-center overflow-clip px-[9px] py-[3px] relative rounded-[inherit] size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#4e4fa9] text-[12px] text-nowrap">NPM Core for Linux</p>
      </div>
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function Badge34() {
  return (
    <div className="absolute bg-[rgba(78,79,169,0.1)] h-[22px] left-[133.94px] rounded-[8px] top-0 w-[119.922px]" data-name="Badge">
      <div className="content-stretch flex items-center justify-center overflow-clip px-[9px] py-[3px] relative rounded-[inherit] size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#4e4fa9] text-[12px] text-nowrap">Aternity Recorder</p>
      </div>
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function Badge35() {
  return (
    <div className="absolute bg-[rgba(78,79,169,0.1)] h-[22px] left-[257.86px] rounded-[8px] top-0 w-[119.703px]" data-name="Badge">
      <div className="content-stretch flex items-center justify-center overflow-clip px-[9px] py-[3px] relative rounded-[inherit] size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#4e4fa9] text-[12px] text-nowrap">SteelHead Mobile</p>
      </div>
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function UnifiedAgentViewV23() {
  return (
    <div className="absolute h-[22px] left-[8px] top-[8.5px] w-[706.766px]" data-name="UnifiedAgentViewV3">
      <Badge33 />
      <Badge34 />
      <Badge35 />
    </div>
  );
}

function TableCell62() {
  return (
    <div className="absolute h-[39px] left-[577.94px] top-0 w-[722.766px]" data-name="TableCell">
      <UnifiedAgentViewV23 />
    </div>
  );
}

function TableCell63() {
  return (
    <div className="absolute h-[39px] left-[1300.7px] top-0 w-[142.797px]" data-name="TableCell">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[8px] not-italic text-[#6c757d] text-[14px] text-nowrap top-[9.5px] tracking-[-0.1504px]">15 min ago</p>
    </div>
  );
}

function TableRow7() {
  return (
    <div className="absolute border-[0px_0px_1px] border-[rgba(0,0,0,0.15)] border-solid h-[39px] left-0 top-[273px] w-[1443.5px]" data-name="TableRow">
      <TableCell56 />
      <TableCell57 />
      <TableCell58 />
      <TableCell59 />
      <TableCell60 />
      <TableCell61 />
      <TableCell62 />
      <TableCell63 />
    </div>
  );
}

function Checkbox8() {
  return <div className="absolute bg-[#f3f4f6] left-0 size-[13px] top-0" data-name="Checkbox" />;
}

function UnifiedAgentViewV24() {
  return (
    <div className="absolute left-[8px] size-[13px] top-[11.5px]" data-name="UnifiedAgentViewV3">
      <Checkbox8 />
    </div>
  );
}

function TableCell64() {
  return (
    <div className="absolute h-[38.5px] left-0 top-0 w-[29px]" data-name="TableCell">
      <UnifiedAgentViewV24 />
    </div>
  );
}

function TableCell65() {
  return <div className="absolute h-[38.5px] left-[29px] top-0 w-[122.344px]" data-name="TableCell" />;
}

function Badge36() {
  return (
    <div className="absolute bg-[#dcfce7] h-[22px] left-[8px] rounded-[8px] top-[8.5px] w-[72.391px]" data-name="Badge">
      <div className="content-stretch flex items-center justify-center overflow-clip px-[9px] py-[3px] relative rounded-[inherit] size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#008236] text-[12px] text-nowrap">Deployed</p>
      </div>
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function TableCell66() {
  return (
    <div className="absolute h-[38.5px] left-[151.34px] top-0 w-[105.016px]" data-name="TableCell">
      <Badge36 />
    </div>
  );
}

function TableCell67() {
  return (
    <div className="absolute h-[38.5px] left-[256.36px] top-0 w-[95.344px]" data-name="TableCell">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[8px] not-italic text-[#0a0a0a] text-[14px] text-nowrap top-[9.5px] tracking-[-0.1504px]">26.110 BC</p>
    </div>
  );
}

function TableCell68() {
  return (
    <div className="absolute h-[38.5px] left-[351.7px] top-0 w-[115.141px]" data-name="TableCell">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[8px] not-italic text-[#0a0a0a] text-[14px] text-nowrap top-[9.5px] tracking-[-0.1504px]">Server</p>
    </div>
  );
}

function TableCell69() {
  return (
    <div className="absolute h-[38.5px] left-[466.84px] top-0 w-[111.094px]" data-name="TableCell">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[8px] not-italic text-[#0a0a0a] text-[14px] text-nowrap top-[9.5px] tracking-[-0.1504px]">CentOS</p>
    </div>
  );
}

function Badge37() {
  return (
    <div className="absolute bg-[rgba(78,79,169,0.1)] h-[22px] left-0 rounded-[8px] top-0 w-[119.922px]" data-name="Badge">
      <div className="content-stretch flex items-center justify-center overflow-clip px-[9px] py-[3px] relative rounded-[inherit] size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#4e4fa9] text-[12px] text-nowrap">Aternity Recorder</p>
      </div>
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function Badge38() {
  return (
    <div className="absolute bg-[rgba(78,79,169,0.1)] h-[22px] left-[123.92px] rounded-[8px] top-0 w-[119.703px]" data-name="Badge">
      <div className="content-stretch flex items-center justify-center overflow-clip px-[9px] py-[3px] relative rounded-[inherit] size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#4e4fa9] text-[12px] text-nowrap">SteelHead Mobile</p>
      </div>
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function Badge39() {
  return (
    <div className="absolute bg-[rgba(78,79,169,0.1)] h-[22px] left-[247.63px] rounded-[8px] top-0 w-[210.734px]" data-name="Badge">
      <div className="content-stretch flex items-center justify-center overflow-clip px-[9px] py-[3px] relative rounded-[inherit] size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16px] not-italic relative shrink-0 text-[#4e4fa9] text-[12px] text-nowrap">NPM Packet capture for Windows</p>
      </div>
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function UnifiedAgentViewV25() {
  return (
    <div className="absolute h-[22px] left-[8px] top-[8.5px] w-[706.766px]" data-name="UnifiedAgentViewV3">
      <Badge37 />
      <Badge38 />
      <Badge39 />
    </div>
  );
}

function TableCell70() {
  return (
    <div className="absolute h-[38.5px] left-[577.94px] top-0 w-[722.766px]" data-name="TableCell">
      <UnifiedAgentViewV25 />
    </div>
  );
}

function TableCell71() {
  return (
    <div className="absolute h-[38.5px] left-[1300.7px] top-0 w-[142.797px]" data-name="TableCell">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[8px] not-italic text-[#6c757d] text-[14px] text-nowrap top-[9.5px] tracking-[-0.1504px]">1 hour ago</p>
    </div>
  );
}

function TableRow8() {
  return (
    <div className="absolute h-[38.5px] left-0 top-[312px] w-[1443.5px]" data-name="TableRow">
      <TableCell64 />
      <TableCell65 />
      <TableCell66 />
      <TableCell67 />
      <TableCell68 />
      <TableCell69 />
      <TableCell70 />
      <TableCell71 />
    </div>
  );
}

function TableBody() {
  return (
    <div className="absolute h-[350.5px] left-0 top-[40px] w-[1443.5px]" data-name="TableBody">
      <TableRow />
      <TableRow1 />
      <TableRow2 />
      <TableRow3 />
      <TableRow4 />
      <TableRow5 />
      <TableRow6 />
      <TableRow7 />
      <TableRow8 />
    </div>
  );
}

function Table() {
  return (
    <div className="absolute h-[390.5px] left-0 top-0 w-[1443.5px]" data-name="Table">
      <TableBody />
    </div>
  );
}

function UnifiedAgentViewV26() {
  return (
    <div className="absolute left-[7px] overflow-clip size-px top-[57.5px]" data-name="UnifiedAgentViewV3">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#0a0a0a] text-[14px] text-nowrap top-0 tracking-[-0.1504px]">Select device</p>
    </div>
  );
}

function UnifiedAgentViewV27() {
  return (
    <div className="absolute left-[7px] overflow-clip size-px top-[96.5px]" data-name="UnifiedAgentViewV3">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#0a0a0a] text-[14px] text-nowrap top-0 tracking-[-0.1504px]">Select device</p>
    </div>
  );
}

function UnifiedAgentViewV28() {
  return (
    <div className="absolute left-[7px] overflow-clip size-px top-[135.5px]" data-name="UnifiedAgentViewV3">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#0a0a0a] text-[14px] text-nowrap top-0 tracking-[-0.1504px]">Select device</p>
    </div>
  );
}

function UnifiedAgentViewV29() {
  return (
    <div className="absolute left-[7px] overflow-clip size-px top-[174.5px]" data-name="UnifiedAgentViewV3">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#0a0a0a] text-[14px] text-nowrap top-0 tracking-[-0.1504px]">Select device</p>
    </div>
  );
}

function UnifiedAgentViewV30() {
  return (
    <div className="absolute left-[7px] overflow-clip size-px top-[213.5px]" data-name="UnifiedAgentViewV3">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#0a0a0a] text-[14px] text-nowrap top-0 tracking-[-0.1504px]">Select device</p>
    </div>
  );
}

function UnifiedAgentViewV31() {
  return (
    <div className="absolute left-[7px] overflow-clip size-px top-[252.5px]" data-name="UnifiedAgentViewV3">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#0a0a0a] text-[14px] text-nowrap top-0 tracking-[-0.1504px]">Select device</p>
    </div>
  );
}

function UnifiedAgentViewV32() {
  return (
    <div className="absolute left-[7px] overflow-clip size-px top-[291.5px]" data-name="UnifiedAgentViewV3">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#0a0a0a] text-[14px] text-nowrap top-0 tracking-[-0.1504px]">Select device</p>
    </div>
  );
}

function UnifiedAgentViewV33() {
  return (
    <div className="absolute left-[7px] overflow-clip size-px top-[330.5px]" data-name="UnifiedAgentViewV3">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#0a0a0a] text-[14px] text-nowrap top-0 tracking-[-0.1504px]">Select device</p>
    </div>
  );
}

function UnifiedAgentViewV34() {
  return (
    <div className="absolute left-[7px] overflow-clip size-px top-[369.5px]" data-name="UnifiedAgentViewV3">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#0a0a0a] text-[14px] text-nowrap top-0 tracking-[-0.1504px]">Select device</p>
    </div>
  );
}

function Checkbox9() {
  return <div className="absolute bg-[#f3f4f6] left-0 size-[13px] top-0" data-name="Checkbox" />;
}

function UnifiedAgentViewV35() {
  return (
    <div className="absolute left-[8px] size-[13px] top-[11.75px]" data-name="UnifiedAgentViewV3">
      <Checkbox9 />
    </div>
  );
}

function TableHead() {
  return (
    <div className="absolute h-[40px] left-0 top-0 w-[29px]" data-name="TableHead">
      <UnifiedAgentViewV35 />
    </div>
  );
}

function TableHead1() {
  return (
    <div className="absolute h-[40px] left-[29px] top-0 w-[122.344px]" data-name="TableHead">
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-[8px] not-italic text-[#0a0a0a] text-[14px] text-nowrap top-[9.75px] tracking-[-0.1504px]">Device Name</p>
    </div>
  );
}

function TableHead2() {
  return (
    <div className="absolute h-[40px] left-[151.34px] top-0 w-[105.016px]" data-name="TableHead">
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-[8px] not-italic text-[#0a0a0a] text-[14px] text-nowrap top-[9.75px] tracking-[-0.1504px]">Status</p>
    </div>
  );
}

function TableHead3() {
  return (
    <div className="absolute h-[40px] left-[256.36px] top-0 w-[95.344px]" data-name="TableHead">
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-[8px] not-italic text-[#0a0a0a] text-[14px] text-nowrap top-[9.75px] tracking-[-0.1504px]">Version</p>
    </div>
  );
}

function TableHead4() {
  return (
    <div className="absolute h-[40px] left-[351.7px] top-0 w-[115.141px]" data-name="TableHead">
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-[8px] not-italic text-[#0a0a0a] text-[14px] text-nowrap top-[9.75px] tracking-[-0.1504px]">Device Type</p>
    </div>
  );
}

function TableHead5() {
  return (
    <div className="absolute h-[40px] left-[466.84px] top-0 w-[111.094px]" data-name="TableHead">
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-[8px] not-italic text-[#0a0a0a] text-[14px] text-nowrap top-[9.75px] tracking-[-0.1504px]">OS</p>
    </div>
  );
}

function TableHead6() {
  return (
    <div className="absolute h-[40px] left-[577.94px] top-0 w-[722.766px]" data-name="TableHead">
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-[8px] not-italic text-[#0a0a0a] text-[14px] text-nowrap top-[9.75px] tracking-[-0.1504px]">Modules</p>
    </div>
  );
}

function TableHead7() {
  return (
    <div className="absolute h-[40px] left-[1300.7px] top-0 w-[142.797px]" data-name="TableHead">
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-[8px] not-italic text-[#0a0a0a] text-[14px] text-nowrap top-[9.75px] tracking-[-0.1504px]">Last Connected</p>
    </div>
  );
}

function TableRow9() {
  return (
    <div className="absolute border-[0px_0px_1px] border-[rgba(0,0,0,0.15)] border-solid h-[40px] left-0 top-0 w-[1443.5px]" data-name="TableRow">
      <TableHead />
      <TableHead1 />
      <TableHead2 />
      <TableHead3 />
      <TableHead4 />
      <TableHead5 />
      <TableHead6 />
      <TableHead7 />
    </div>
  );
}

function UnifiedAgentViewV36() {
  return (
    <div className="absolute left-[7px] overflow-clip size-px top-[17.75px]" data-name="UnifiedAgentViewV3">
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-0 not-italic text-[#0a0a0a] text-[14px] text-nowrap top-0 tracking-[-0.1504px]">Select all</p>
    </div>
  );
}

function TableHeader() {
  return (
    <div className="absolute bg-[#f8f9fa] h-[40px] left-0 top-0 w-[1443.5px]" data-name="TableHeader">
      <TableRow9 />
      <UnifiedAgentViewV36 />
    </div>
  );
}

function Table1() {
  return (
    <div className="h-[390.5px] overflow-clip relative shrink-0 w-full" data-name="Table">
      <Table />
      <UnifiedAgentViewV26 />
      <UnifiedAgentViewV27 />
      <UnifiedAgentViewV28 />
      <UnifiedAgentViewV29 />
      <UnifiedAgentViewV30 />
      <UnifiedAgentViewV31 />
      <UnifiedAgentViewV32 />
      <UnifiedAgentViewV33 />
      <UnifiedAgentViewV34 />
      <TableHeader />
    </div>
  );
}

function Container130() {
  return (
    <div className="basis-0 grow min-h-px min-w-px relative rounded-[10px] shrink-0 w-[1445.5px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start overflow-clip p-px relative rounded-[inherit] size-full">
        <Table1 />
      </div>
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.15)] border-solid inset-0 pointer-events-none rounded-[10px]" />
    </div>
  );
}

function UnifiedAgentViewV37() {
  return (
    <div className="absolute content-stretch flex flex-col h-[382px] items-start left-[24px] overflow-clip top-[324px] w-[1445.5px]" data-name="UnifiedAgentViewV3">
      <Container130 />
    </div>
  );
}

function Text67() {
  return (
    <div className="absolute content-stretch flex h-[17px] items-start left-[58.91px] top-px w-[9.203px]" data-name="Text">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[20px] not-italic relative shrink-0 text-[#0a0a0a] text-[14px] text-nowrap tracking-[-0.1504px]">9</p>
    </div>
  );
}

function Text68() {
  return (
    <div className="absolute content-stretch flex h-[17px] items-start left-[88.73px] top-px w-[16.094px]" data-name="Text">
      <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[20px] not-italic relative shrink-0 text-[#0a0a0a] text-[14px] text-nowrap tracking-[-0.1504px]">18</p>
    </div>
  );
}

function Container131() {
  return (
    <div className="h-[20px] relative shrink-0 w-[158.234px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#6c757d] text-[14px] text-nowrap top-0 tracking-[-0.1504px]">Showing</p>
        <Text67 />
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[68.11px] not-italic text-[#6c757d] text-[14px] text-nowrap top-0 tracking-[-0.1504px]">of</p>
        <Text68 />
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[104.83px] not-italic text-[#6c757d] text-[14px] text-nowrap top-0 tracking-[-0.1504px]">devices</p>
      </div>
    </div>
  );
}

function Icon67() {
  return (
    <div className="absolute left-[11px] size-[16px] top-[8px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p12949080} id="Vector" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M2 2V5.33333H5.33333" id="Vector_2" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Button32() {
  return (
    <div className="bg-[#f8f9fa] h-[32px] relative rounded-[8px] shrink-0 w-[109.906px]" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.15)] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Icon67 />
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-[70px] not-italic text-[#0a0a0a] text-[14px] text-center text-nowrap top-[6px] tracking-[-0.1504px] translate-x-[-50%]">Reset All</p>
      </div>
    </div>
  );
}

function UnifiedAgentViewV38() {
  return (
    <div className="absolute content-stretch flex h-[36px] items-center justify-between left-[24px] top-[706px] w-[1445.5px]" data-name="UnifiedAgentViewV3">
      <Container131 />
      <Button32 />
    </div>
  );
}

function CardContent() {
  return (
    <div className="basis-0 grow min-h-px min-w-px relative shrink-0 w-[1493.5px]" data-name="CardContent">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid overflow-clip relative rounded-[inherit] size-full">
        <UnifiedAgentViewV4 />
        <UnifiedAgentViewV6 />
        <UnifiedAgentViewV7 />
        <UnifiedAgentViewV37 />
        <UnifiedAgentViewV38 />
      </div>
    </div>
  );
}

function Card3() {
  return (
    <div className="bg-white content-stretch flex flex-col h-[768px] items-start p-px relative rounded-[14px] shrink-0 w-full" data-name="Card">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.15)] border-solid inset-0 pointer-events-none rounded-[14px]" />
      <CardContent />
    </div>
  );
}

function UnifiedAgentView2() {
  return (
    <div className="content-stretch flex flex-col gap-[24px] h-[1098px] items-start relative shrink-0 w-full" data-name="UnifiedAgentView">
      <Container48 />
      <UnifiedAgentViewV3 />
      <Card3 />
    </div>
  );
}

function Panel() {
  return (
    <div className="absolute content-stretch flex flex-col h-[1154px] items-start left-[515.5px] overflow-clip pb-0 pt-[24px] px-[24px] top-0 w-[1543.5px]" data-name="Panel">
      <UnifiedAgentView2 />
    </div>
  );
}

function Icon68() {
  return (
    <div className="relative shrink-0 size-[10px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10 10">
        <g id="Icon">
          <path d={svgPaths.p39b1a1f0} id="Vector" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.833333" />
          <path d={svgPaths.p9de6900} id="Vector_2" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.833333" />
          <path d={svgPaths.p3c2d9800} id="Vector_3" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.833333" />
          <path d={svgPaths.p4108a80} id="Vector_4" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.833333" />
          <path d={svgPaths.pc415840} id="Vector_5" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.833333" />
          <path d={svgPaths.p2b0e9000} id="Vector_6" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.833333" />
        </g>
      </svg>
    </div>
  );
}

function ResizableHandle() {
  return (
    <div className="bg-[rgba(0,0,0,0.15)] h-[16px] relative rounded-[2px] shrink-0 w-[12px]" data-name="ResizableHandle">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.15)] border-solid inset-0 pointer-events-none rounded-[2px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center p-px relative size-full">
        <Icon68 />
      </div>
    </div>
  );
}

function PanelResizeHandle() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0.15)] content-stretch flex h-[1154px] items-center justify-center left-[514.5px] top-0 w-px" data-name="PanelResizeHandle">
      <ResizableHandle />
    </div>
  );
}

function PanelGroup() {
  return (
    <div className="h-[1154px] overflow-clip relative shrink-0 w-full" data-name="PanelGroup">
      <UnifiedAgentView1 />
      <Panel />
      <PanelResizeHandle />
    </div>
  );
}

function ContentArea() {
  return (
    <div className="basis-0 grow min-h-px min-w-px relative shrink-0 w-[2059px]" data-name="ContentArea">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start overflow-clip relative rounded-[inherit] size-full">
        <PanelGroup />
      </div>
    </div>
  );
}

function App() {
  return (
    <div className="absolute content-stretch flex flex-col h-[1211px] items-start left-0 overflow-clip top-0 w-[2059px]" data-name="App">
      <Toolbar1 />
      <ContentArea />
    </div>
  );
}

function Icon69() {
  return (
    <div className="absolute left-[8px] size-[16px] top-[8px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p19d57600} id="Vector" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M6 2V14" id="Vector_2" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Button33() {
  return (
    <div className="absolute left-[12px] rounded-[8px] size-[32px] top-[12px]" data-name="Button">
      <Icon69 />
    </div>
  );
}

function Panel1() {
  return (
    <div className="absolute h-[1211px] left-0 overflow-clip top-0 w-[2059px]" data-name="Panel">
      <App />
      <Button33 />
    </div>
  );
}

function PanelGroup1() {
  return (
    <div className="h-[1211px] overflow-clip relative shrink-0 w-full" data-name="PanelGroup">
      <Panel1 />
    </div>
  );
}

function Container132() {
  return (
    <div className="basis-0 bg-[rgba(233,236,239,0.2)] grow min-h-px min-w-px relative shrink-0 w-[2059px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start overflow-clip relative rounded-[inherit] size-full">
        <PanelGroup1 />
      </div>
    </div>
  );
}

export default function RiverbedPrototype() {
  return (
    <div className="bg-[#f8f9fa] content-stretch flex flex-col items-start relative size-full" data-name="RIVERBED PROTOTYPE">
      <Header />
      <Container132 />
    </div>
  );
}