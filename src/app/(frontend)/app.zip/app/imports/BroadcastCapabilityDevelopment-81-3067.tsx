import svgPaths from "./svg-0olijwqmg7";

function Icon() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Icon">
          <path d={svgPaths.p3c61fe80} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function Container() {
  return (
    <div className="bg-[#59168b] h-[40px] relative rounded-[10px] shrink-0 w-[34.922px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <Icon />
      </div>
    </div>
  );
}

function Heading() {
  return (
    <div className="h-[48px] relative shrink-0 w-full" data-name="Heading 1">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[16px] text-white top-[-0.5px] tracking-[-0.3125px] w-[114px]">End-user Communication</p>
    </div>
  );
}

function Paragraph() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[14px] text-[rgba(218,178,255,0.7)] text-nowrap top-[0.5px] tracking-[-0.1504px]">Unified Platform</p>
    </div>
  );
}

function Container1() {
  return (
    <div className="basis-0 grow h-[68px] min-h-px min-w-px relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Heading />
        <Paragraph />
      </div>
    </div>
  );
}

function Container2() {
  return (
    <div className="content-stretch flex gap-[12px] h-[68px] items-center relative shrink-0 w-full" data-name="Container">
      <Container />
      <Container1 />
    </div>
  );
}

function Container3() {
  return (
    <div className="absolute content-stretch flex flex-col h-[117px] items-start left-0 pb-px pt-[24px] px-[24px] top-0 w-[256px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[0px_0px_1px] border-[rgba(60,3,102,0.5)] border-solid inset-0 pointer-events-none" />
      <Container2 />
    </div>
  );
}

function Icon1() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p1fc96a00} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d={svgPaths.p33089d00} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d={svgPaths.p49cfa80} id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d={svgPaths.p1cfbf300} id="Vector_4" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
      </svg>
    </div>
  );
}

function Text() {
  return (
    <div className="h-[24px] relative shrink-0 w-[73.313px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-[37.5px] not-italic text-[16px] text-center text-nowrap text-white top-[-0.5px] tracking-[-0.3125px] translate-x-[-50%]">Messages</p>
      </div>
    </div>
  );
}

function Button() {
  return (
    <div className="absolute bg-[#59168b] content-stretch flex gap-[12px] h-[44px] items-center left-0 pl-[12px] pr-0 py-0 rounded-[10px] shadow-[0px_10px_15px_-3px_rgba(89,22,139,0.5),0px_4px_6px_-4px_rgba(89,22,139,0.5)] top-0 w-[224px]" data-name="Button">
      <Icon1 />
      <Text />
    </div>
  );
}

function ListItem() {
  return (
    <div className="h-[44px] relative shrink-0 w-full" data-name="List Item">
      <Button />
    </div>
  );
}

function Icon2() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.pcfbcf00} id="Vector" stroke="var(--stroke-0, #E9D4FF)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.8" strokeWidth="1.66667" />
          <path d={svgPaths.pd2076c0} id="Vector_2" stroke="var(--stroke-0, #E9D4FF)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.8" strokeWidth="1.66667" />
          <path d="M8.33333 7.5H6.66667" id="Vector_3" stroke="var(--stroke-0, #E9D4FF)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.8" strokeWidth="1.66667" />
          <path d="M13.3333 10.8333H6.66667" id="Vector_4" stroke="var(--stroke-0, #E9D4FF)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.8" strokeWidth="1.66667" />
          <path d="M13.3333 14.1667H6.66667" id="Vector_5" stroke="var(--stroke-0, #E9D4FF)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.8" strokeWidth="1.66667" />
        </g>
      </svg>
    </div>
  );
}

function Text1() {
  return (
    <div className="h-[24px] relative shrink-0 w-[74.68px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-[37px] not-italic text-[16px] text-[rgba(233,212,255,0.8)] text-center text-nowrap top-[-0.5px] tracking-[-0.3125px] translate-x-[-50%]">Templates</p>
      </div>
    </div>
  );
}

function Button1() {
  return (
    <div className="absolute content-stretch flex gap-[12px] h-[44px] items-center left-0 pl-[12px] pr-0 py-0 rounded-[10px] top-0 w-[224px]" data-name="Button">
      <Icon2 />
      <Text1 />
    </div>
  );
}

function ListItem1() {
  return (
    <div className="h-[44px] relative shrink-0 w-full" data-name="List Item">
      <Button1 />
    </div>
  );
}

function Icon3() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p372c1fe0} id="Vector" stroke="var(--stroke-0, #E9D4FF)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.8" strokeWidth="1.66667" />
          <path d={svgPaths.p1fe4d500} id="Vector_2" stroke="var(--stroke-0, #E9D4FF)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.8" strokeWidth="1.66667" />
          <path d={svgPaths.p25499600} id="Vector_3" stroke="var(--stroke-0, #E9D4FF)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.8" strokeWidth="1.66667" />
          <path d={svgPaths.p34c45780} id="Vector_4" stroke="var(--stroke-0, #E9D4FF)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.8" strokeWidth="1.66667" />
          <path d={svgPaths.p3779d880} id="Vector_5" stroke="var(--stroke-0, #E9D4FF)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.8" strokeWidth="1.66667" />
        </g>
      </svg>
    </div>
  );
}

function Text2() {
  return (
    <div className="h-[24px] relative shrink-0 w-[67.43px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-[34.5px] not-italic text-[16px] text-[rgba(233,212,255,0.8)] text-center text-nowrap top-[-0.5px] tracking-[-0.3125px] translate-x-[-50%]">Channels</p>
      </div>
    </div>
  );
}

function Button2() {
  return (
    <div className="absolute content-stretch flex gap-[12px] h-[44px] items-center left-0 pl-[12px] pr-0 py-0 rounded-[10px] top-0 w-[224px]" data-name="Button">
      <Icon3 />
      <Text2 />
    </div>
  );
}

function ListItem2() {
  return (
    <div className="h-[44px] relative shrink-0 w-full" data-name="List Item">
      <Button2 />
    </div>
  );
}

function Icon4() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p1f5dba00} id="Vector" stroke="var(--stroke-0, #E9D4FF)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.3" strokeWidth="1.66667" />
          <path d={svgPaths.p17f7d000} id="Vector_2" stroke="var(--stroke-0, #E9D4FF)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.3" strokeWidth="1.66667" />
          <path d={svgPaths.p42d6b00} id="Vector_3" stroke="var(--stroke-0, #E9D4FF)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.3" strokeWidth="1.66667" />
        </g>
      </svg>
    </div>
  );
}

function Text3() {
  return (
    <div className="h-[24px] relative shrink-0 w-[121.813px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-[61px] not-italic text-[16px] text-[rgba(233,212,255,0.3)] text-center text-nowrap top-[-0.5px] tracking-[-0.3125px] translate-x-[-50%]">Interactive Flows</p>
      </div>
    </div>
  );
}

function Button3() {
  return (
    <div className="absolute content-stretch flex gap-[12px] h-[44px] items-center left-0 pl-[12px] pr-0 py-0 rounded-[10px] top-0 w-[224px]" data-name="Button">
      <Icon4 />
      <Text3 />
    </div>
  );
}

function ListItem3() {
  return (
    <div className="h-[44px] relative shrink-0 w-full" data-name="List Item">
      <Button3 />
    </div>
  );
}

function Icon5() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g clipPath="url(#clip0_67_1519)" id="Icon">
          <path d={svgPaths.p3bcc1200} id="Vector" stroke="var(--stroke-0, #E9D4FF)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.8" strokeWidth="1.66667" />
          <path d={svgPaths.p14899500} fill="var(--fill-0, #E9D4FF)" fillOpacity="0.8" id="Vector_2" stroke="var(--stroke-0, #E9D4FF)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.8" strokeWidth="1.66667" />
          <path d={svgPaths.pa15a670} fill="var(--fill-0, #E9D4FF)" fillOpacity="0.8" id="Vector_3" stroke="var(--stroke-0, #E9D4FF)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.8" strokeWidth="1.66667" />
          <path d={svgPaths.p295c7f00} fill="var(--fill-0, #E9D4FF)" fillOpacity="0.8" id="Vector_4" stroke="var(--stroke-0, #E9D4FF)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.8" strokeWidth="1.66667" />
          <path d={svgPaths.p3ad59a00} fill="var(--fill-0, #E9D4FF)" fillOpacity="0.8" id="Vector_5" stroke="var(--stroke-0, #E9D4FF)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.8" strokeWidth="1.66667" />
        </g>
        <defs>
          <clipPath id="clip0_67_1519">
            <rect fill="white" height="20" width="20" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Text4() {
  return (
    <div className="h-[24px] relative shrink-0 w-[65.141px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-[33px] not-italic text-[16px] text-[rgba(233,212,255,0.8)] text-center text-nowrap top-[-0.5px] tracking-[-0.3125px] translate-x-[-50%]">Branding</p>
      </div>
    </div>
  );
}

function Button4() {
  return (
    <div className="absolute content-stretch flex gap-[12px] h-[44px] items-center left-0 pl-[12px] pr-0 py-0 rounded-[10px] top-0 w-[224px]" data-name="Button">
      <Icon5 />
      <Text4 />
    </div>
  );
}

function ListItem4() {
  return (
    <div className="h-[44px] relative shrink-0 w-full" data-name="List Item">
      <Button4 />
    </div>
  );
}

function Icon6() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p17390300} id="Vector" stroke="var(--stroke-0, #E9D4FF)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.8" strokeWidth="1.66667" />
          <path d={svgPaths.p3b27f100} id="Vector_2" stroke="var(--stroke-0, #E9D4FF)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.8" strokeWidth="1.66667" />
        </g>
      </svg>
    </div>
  );
}

function Text5() {
  return (
    <div className="h-[24px] relative shrink-0 w-[102.602px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-[51.5px] not-italic text-[16px] text-[rgba(233,212,255,0.8)] text-center text-nowrap top-[-0.5px] tracking-[-0.3125px] translate-x-[-50%]">Delivery Rules</p>
      </div>
    </div>
  );
}

function Button5() {
  return (
    <div className="absolute content-stretch flex gap-[12px] h-[44px] items-center left-0 pl-[12px] pr-0 py-0 rounded-[10px] top-0 w-[224px]" data-name="Button">
      <Icon6 />
      <Text5 />
    </div>
  );
}

function ListItem5() {
  return (
    <div className="h-[44px] relative shrink-0 w-full" data-name="List Item">
      <Button5 />
    </div>
  );
}

function Icon7() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p140c1100} id="Vector" stroke="var(--stroke-0, #E9D4FF)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.3" strokeWidth="1.66667" />
          <path d="M15 14.1667V7.5" id="Vector_2" stroke="var(--stroke-0, #E9D4FF)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.3" strokeWidth="1.66667" />
          <path d="M10.8333 14.1667V4.16667" id="Vector_3" stroke="var(--stroke-0, #E9D4FF)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.3" strokeWidth="1.66667" />
          <path d="M6.66667 14.1667V11.6667" id="Vector_4" stroke="var(--stroke-0, #E9D4FF)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.3" strokeWidth="1.66667" />
        </g>
      </svg>
    </div>
  );
}

function Text6() {
  return (
    <div className="h-[24px] relative shrink-0 w-[65.961px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-[33.5px] not-italic text-[16px] text-[rgba(233,212,255,0.3)] text-center text-nowrap top-[-0.5px] tracking-[-0.3125px] translate-x-[-50%]">Analytics</p>
      </div>
    </div>
  );
}

function Button6() {
  return (
    <div className="absolute content-stretch flex gap-[12px] h-[44px] items-center left-0 pl-[12px] pr-0 py-0 rounded-[10px] top-0 w-[224px]" data-name="Button">
      <Icon7 />
      <Text6 />
    </div>
  );
}

function ListItem6() {
  return (
    <div className="h-[44px] relative shrink-0 w-full" data-name="List Item">
      <Button6 />
    </div>
  );
}

function List() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[332px] items-start left-[16px] top-[133px] w-[224px]" data-name="List">
      <ListItem />
      <ListItem1 />
      <ListItem2 />
      <ListItem3 />
      <ListItem4 />
      <ListItem5 />
      <ListItem6 />
    </div>
  );
}

function Container4() {
  return <div className="absolute border-[1px_0px_0px] border-[rgba(60,3,102,0.5)] border-solid h-[33px] left-0 top-[1235px] w-[256px]" data-name="Container" />;
}

function Sidebar() {
  return (
    <div className="bg-[#1a0f2e] h-[1268px] relative shrink-0 w-[256px]" data-name="Sidebar">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Container3 />
        <List />
        <Container4 />
      </div>
    </div>
  );
}

function Heading1() {
  return (
    <div className="absolute h-[20px] left-[17px] top-[17px] w-[230.539px]" data-name="Heading 2">
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-0 not-italic text-[#101828] text-[14px] text-nowrap top-[0.5px] tracking-[-0.1504px]">Messages filtered by active criteria</p>
    </div>
  );
}

function Label() {
  return (
    <div className="h-[16px] relative shrink-0 w-full" data-name="Label">
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[16px] left-0 not-italic text-[#364153] text-[12px] text-nowrap top-px">Status</p>
    </div>
  );
}

function Container5() {
  return (
    <div className="bg-[#86efac] relative rounded-[1.67772e+07px] shrink-0 size-[8px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid size-full" />
    </div>
  );
}

function Text7() {
  return (
    <div className="basis-0 grow h-[16px] min-h-px min-w-px relative shrink-0" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16px] left-[18px] not-italic text-[#364153] text-[12px] text-center text-nowrap top-px translate-x-[-50%]">Active</p>
      </div>
    </div>
  );
}

function Text8() {
  return (
    <div className="h-[16px] relative shrink-0 w-[22.711px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[16px] left-[11.5px] not-italic text-[#364153] text-[12px] text-center top-px translate-x-[-50%] w-[23px]">(12)</p>
      </div>
    </div>
  );
}

function Button7() {
  return (
    <div className="absolute bg-white content-stretch flex gap-[6px] h-[26px] items-center left-0 px-[11px] py-px rounded-[4px] top-0 w-[99.727px]" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[#e5e7eb] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <Container5 />
      <Text7 />
      <Text8 />
    </div>
  );
}

function Container6() {
  return (
    <div className="bg-[#e2e8f0] relative rounded-[1.67772e+07px] shrink-0 size-[8px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid size-full" />
    </div>
  );
}

function Text9() {
  return (
    <div className="basis-0 grow h-[16px] min-h-px min-w-px relative shrink-0" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16px] left-[14.5px] not-italic text-[#364153] text-[12px] text-center text-nowrap top-px translate-x-[-50%]">Draft</p>
      </div>
    </div>
  );
}

function Text10() {
  return (
    <div className="h-[16px] relative shrink-0 w-[16.953px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[16px] left-[8.5px] not-italic text-[#364153] text-[12px] text-center top-px translate-x-[-50%] w-[17px]">(2)</p>
      </div>
    </div>
  );
}

function Button8() {
  return (
    <div className="absolute bg-white content-stretch flex gap-[6px] h-[26px] items-center left-[105.73px] px-[11px] py-px rounded-[4px] top-0 w-[87.57px]" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[#e5e7eb] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <Container6 />
      <Text9 />
      <Text10 />
    </div>
  );
}

function Container7() {
  return (
    <div className="bg-[#93c5fd] relative rounded-[1.67772e+07px] shrink-0 size-[8px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid size-full" />
    </div>
  );
}

function Text11() {
  return (
    <div className="basis-0 grow h-[16px] min-h-px min-w-px relative shrink-0" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16px] left-[30.5px] not-italic text-[#364153] text-[12px] text-center text-nowrap top-px translate-x-[-50%]">Scheduled</p>
      </div>
    </div>
  );
}

function Text12() {
  return (
    <div className="h-[16px] relative shrink-0 w-[17.242px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[16px] left-[9px] not-italic text-[#364153] text-[12px] text-center top-px translate-x-[-50%] w-[18px]">(3)</p>
      </div>
    </div>
  );
}

function Button9() {
  return (
    <div className="absolute bg-white content-stretch flex gap-[6px] h-[26px] items-center left-[199.3px] px-[11px] py-px rounded-[4px] top-0 w-[119.156px]" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[#e5e7eb] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <Container7 />
      <Text11 />
      <Text12 />
    </div>
  );
}

function Container8() {
  return (
    <div className="bg-[#c4b5fd] relative rounded-[1.67772e+07px] shrink-0 size-[8px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid size-full" />
    </div>
  );
}

function Text13() {
  return (
    <div className="basis-0 grow h-[16px] min-h-px min-w-px relative shrink-0" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16px] left-[31.5px] not-italic text-[#364153] text-[12px] text-center text-nowrap top-px translate-x-[-50%]">Completed</p>
      </div>
    </div>
  );
}

function Text14() {
  return (
    <div className="h-[16px] relative shrink-0 w-[17.242px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[16px] left-[9px] not-italic text-[#364153] text-[12px] text-center top-px translate-x-[-50%] w-[18px]">(3)</p>
      </div>
    </div>
  );
}

function Button10() {
  return (
    <div className="absolute bg-white content-stretch flex gap-[6px] h-[26px] items-center left-[324.45px] px-[11px] py-px rounded-[4px] top-0 w-[121.078px]" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[#e5e7eb] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <Container8 />
      <Text13 />
      <Text14 />
    </div>
  );
}

function Container9() {
  return (
    <div className="h-[26px] relative shrink-0 w-full" data-name="Container">
      <Button7 />
      <Button8 />
      <Button9 />
      <Button10 />
    </div>
  );
}

function Container10() {
  return (
    <div className="content-stretch flex flex-col gap-[6px] h-[48px] items-start relative shrink-0 w-full" data-name="Container">
      <Label />
      <Container9 />
    </div>
  );
}

function Label1() {
  return (
    <div className="h-[16px] relative shrink-0 w-full" data-name="Label">
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[16px] left-0 not-italic text-[#364153] text-[12px] text-nowrap top-px">Message Type</p>
    </div>
  );
}

function Container11() {
  return (
    <div className="bg-[#c4b5fd] relative rounded-[1.67772e+07px] shrink-0 size-[8px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid size-full" />
    </div>
  );
}

function Text15() {
  return (
    <div className="basis-0 grow h-[16px] min-h-px min-w-px relative shrink-0" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16px] left-[19px] not-italic text-[#364153] text-[12px] text-center text-nowrap top-px translate-x-[-50%]">Survey</p>
      </div>
    </div>
  );
}

function Text16() {
  return (
    <div className="h-[16px] relative shrink-0 w-[17.445px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[16px] left-[9px] not-italic text-[#364153] text-[12px] text-center top-px translate-x-[-50%] w-[18px]">(4)</p>
      </div>
    </div>
  );
}

function Button11() {
  return (
    <div className="absolute bg-white content-stretch flex gap-[6px] h-[26px] items-center left-0 px-[11px] py-px rounded-[4px] top-0 w-[98.25px]" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[#e5e7eb] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <Container11 />
      <Text15 />
      <Text16 />
    </div>
  );
}

function Container12() {
  return (
    <div className="bg-[#fcd34d] relative rounded-[1.67772e+07px] shrink-0 size-[8px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid size-full" />
    </div>
  );
}

function Text17() {
  return (
    <div className="basis-0 grow h-[16px] min-h-px min-w-px relative shrink-0" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16px] left-[37px] not-italic text-[#364153] text-[12px] text-center text-nowrap top-px translate-x-[-50%]">Confirmation</p>
      </div>
    </div>
  );
}

function Text18() {
  return (
    <div className="h-[16px] relative shrink-0 w-[17.445px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[16px] left-[9px] not-italic text-[#364153] text-[12px] text-center top-px translate-x-[-50%] w-[18px]">(4)</p>
      </div>
    </div>
  );
}

function Button12() {
  return (
    <div className="absolute bg-white content-stretch flex gap-[6px] h-[26px] items-center left-[104.25px] px-[11px] py-px rounded-[4px] top-0 w-[132.602px]" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[#e5e7eb] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <Container12 />
      <Text17 />
      <Text18 />
    </div>
  );
}

function Container13() {
  return (
    <div className="bg-[#93c5fd] relative rounded-[1.67772e+07px] shrink-0 size-[8px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid size-full" />
    </div>
  );
}

function Text19() {
  return (
    <div className="basis-0 grow h-[16px] min-h-px min-w-px relative shrink-0" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16px] left-[33px] not-italic text-[#364153] text-[12px] text-center text-nowrap top-px translate-x-[-50%]">Notification</p>
      </div>
    </div>
  );
}

function Text20() {
  return (
    <div className="h-[16px] relative shrink-0 w-[17.445px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[16px] left-[9px] not-italic text-[#364153] text-[12px] text-center top-px translate-x-[-50%] w-[18px]">(4)</p>
      </div>
    </div>
  );
}

function Button13() {
  return (
    <div className="absolute bg-white content-stretch flex gap-[6px] h-[26px] items-center left-[242.85px] px-[11px] py-px rounded-[4px] top-0 w-[124.828px]" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[#e5e7eb] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <Container13 />
      <Text19 />
      <Text20 />
    </div>
  );
}

function Container14() {
  return (
    <div className="bg-[#fde68a] relative rounded-[1.67772e+07px] shrink-0 size-[8px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid size-full" />
    </div>
  );
}

function Text21() {
  return (
    <div className="basis-0 grow h-[16px] min-h-px min-w-px relative shrink-0" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16px] left-[27px] not-italic text-[#364153] text-[12px] text-center text-nowrap top-px translate-x-[-50%]">Reminder</p>
      </div>
    </div>
  );
}

function Text22() {
  return (
    <div className="h-[16px] relative shrink-0 w-[17.445px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[16px] left-[9px] not-italic text-[#364153] text-[12px] text-center top-px translate-x-[-50%] w-[18px]">(4)</p>
      </div>
    </div>
  );
}

function Button14() {
  return (
    <div className="absolute bg-white content-stretch flex gap-[6px] h-[26px] items-center left-[373.68px] px-[11px] py-px rounded-[4px] top-0 w-[113.172px]" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[#e5e7eb] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <Container14 />
      <Text21 />
      <Text22 />
    </div>
  );
}

function Container15() {
  return (
    <div className="bg-[#86efac] relative rounded-[1.67772e+07px] shrink-0 size-[8px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid size-full" />
    </div>
  );
}

function Text23() {
  return (
    <div className="basis-0 grow h-[16px] min-h-px min-w-px relative shrink-0" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16px] left-[35px] not-italic text-[#364153] text-[12px] text-center text-nowrap top-px translate-x-[-50%]">Self-Service</p>
      </div>
    </div>
  );
}

function Text24() {
  return (
    <div className="h-[16px] relative shrink-0 w-[17.445px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[16px] left-[9px] not-italic text-[#364153] text-[12px] text-center top-px translate-x-[-50%] w-[18px]">(4)</p>
      </div>
    </div>
  );
}

function Button15() {
  return (
    <div className="absolute bg-white content-stretch flex gap-[6px] h-[26px] items-center left-[492.85px] px-[11px] py-px rounded-[4px] top-0 w-[128.867px]" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[#e5e7eb] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <Container15 />
      <Text23 />
      <Text24 />
    </div>
  );
}

function Container16() {
  return (
    <div className="h-[26px] relative shrink-0 w-full" data-name="Container">
      <Button11 />
      <Button12 />
      <Button13 />
      <Button14 />
      <Button15 />
    </div>
  );
}

function Container17() {
  return (
    <div className="content-stretch flex flex-col gap-[6px] h-[48px] items-start relative shrink-0 w-full" data-name="Container">
      <Label1 />
      <Container16 />
    </div>
  );
}

function Label2() {
  return (
    <div className="h-[16px] relative shrink-0 w-full" data-name="Label">
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[16px] left-0 not-italic text-[#364153] text-[12px] text-nowrap top-px">Channel</p>
    </div>
  );
}

function Container18() {
  return (
    <div className="bg-[#a5b4fc] relative rounded-[1.67772e+07px] shrink-0 size-[8px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid size-full" />
    </div>
  );
}

function Text25() {
  return (
    <div className="basis-0 grow h-[16px] min-h-px min-w-px relative shrink-0" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16px] left-[25.5px] not-italic text-[#364153] text-[12px] text-center text-nowrap top-px translate-x-[-50%]">Riverbed</p>
      </div>
    </div>
  );
}

function Text26() {
  return (
    <div className="h-[16px] relative shrink-0 w-[17.375px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[16px] left-[9px] not-italic text-[#364153] text-[12px] text-center top-px translate-x-[-50%] w-[18px]">(6)</p>
      </div>
    </div>
  );
}

function Button16() {
  return (
    <div className="absolute bg-white content-stretch flex gap-[6px] h-[26px] items-center left-0 px-[11px] py-px rounded-[4px] top-0 w-[109.477px]" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[#e5e7eb] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <Container18 />
      <Text25 />
      <Text26 />
    </div>
  );
}

function Container19() {
  return (
    <div className="bg-[#93c5fd] relative rounded-[1.67772e+07px] shrink-0 size-[8px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid size-full" />
    </div>
  );
}

function Text27() {
  return (
    <div className="basis-0 grow h-[16px] min-h-px min-w-px relative shrink-0" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16px] left-[18px] not-italic text-[#364153] text-[12px] text-center text-nowrap top-px translate-x-[-50%]">Teams</p>
      </div>
    </div>
  );
}

function Text28() {
  return (
    <div className="h-[16px] relative shrink-0 w-[17.148px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[16px] left-[9px] not-italic text-[#364153] text-[12px] text-center top-px translate-x-[-50%] w-[18px]">(5)</p>
      </div>
    </div>
  );
}

function Button17() {
  return (
    <div className="absolute bg-white content-stretch flex gap-[6px] h-[26px] items-center left-[115.48px] px-[11px] py-px rounded-[4px] top-0 w-[95.781px]" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[#e5e7eb] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <Container19 />
      <Text27 />
      <Text28 />
    </div>
  );
}

function Container20() {
  return (
    <div className="bg-[#fda4af] relative rounded-[1.67772e+07px] shrink-0 size-[8px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid size-full" />
    </div>
  );
}

function Text29() {
  return (
    <div className="basis-0 grow h-[16px] min-h-px min-w-px relative shrink-0" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16px] left-[15.5px] not-italic text-[#364153] text-[12px] text-center text-nowrap top-px translate-x-[-50%]">Slack</p>
      </div>
    </div>
  );
}

function Text30() {
  return (
    <div className="h-[16px] relative shrink-0 w-[17.148px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[16px] left-[9px] not-italic text-[#364153] text-[12px] text-center top-px translate-x-[-50%] w-[18px]">(5)</p>
      </div>
    </div>
  );
}

function Button18() {
  return (
    <div className="absolute bg-white content-stretch flex gap-[6px] h-[26px] items-center left-[217.26px] px-[11px] py-px rounded-[4px] top-0 w-[89.688px]" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[#e5e7eb] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <Container20 />
      <Text29 />
      <Text30 />
    </div>
  );
}

function Container21() {
  return (
    <div className="bg-[#86efac] relative rounded-[1.67772e+07px] shrink-0 size-[8px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid size-full" />
    </div>
  );
}

function Text31() {
  return (
    <div className="basis-0 grow h-[16px] min-h-px min-w-px relative shrink-0" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16px] left-[15.5px] not-italic text-[#364153] text-[12px] text-center text-nowrap top-px translate-x-[-50%]">Email</p>
      </div>
    </div>
  );
}

function Text32() {
  return (
    <div className="h-[16px] relative shrink-0 w-[17.445px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[16px] left-[9px] not-italic text-[#364153] text-[12px] text-center top-px translate-x-[-50%] w-[18px]">(4)</p>
      </div>
    </div>
  );
}

function Button19() {
  return (
    <div className="absolute bg-white content-stretch flex gap-[6px] h-[26px] items-center left-[312.95px] px-[11px] py-px rounded-[4px] top-0 w-[89.656px]" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[#e5e7eb] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <Container21 />
      <Text31 />
      <Text32 />
    </div>
  );
}

function Container22() {
  return (
    <div className="h-[26px] relative shrink-0 w-full" data-name="Container">
      <Button16 />
      <Button17 />
      <Button18 />
      <Button19 />
    </div>
  );
}

function Container23() {
  return (
    <div className="content-stretch flex flex-col gap-[6px] h-[48px] items-start relative shrink-0 w-full" data-name="Container">
      <Label2 />
      <Container22 />
    </div>
  );
}

function Label3() {
  return (
    <div className="h-[16px] relative shrink-0 w-full" data-name="Label">
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[16px] left-0 not-italic text-[#364153] text-[12px] text-nowrap top-px">Delivery Mode</p>
    </div>
  );
}

function Container24() {
  return (
    <div className="bg-[#fca5a1] relative rounded-[1.67772e+07px] shrink-0 size-[8px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid size-full" />
    </div>
  );
}

function Text33() {
  return (
    <div className="basis-0 grow h-[16px] min-h-px min-w-px relative shrink-0" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16px] left-[24.5px] not-italic text-[#364153] text-[12px] text-center text-nowrap top-px translate-x-[-50%]">Intrusive</p>
      </div>
    </div>
  );
}

function Text34() {
  return (
    <div className="h-[16px] relative shrink-0 w-[17.438px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[16px] left-[9px] not-italic text-[#364153] text-[12px] text-center top-px translate-x-[-50%] w-[18px]">(8)</p>
      </div>
    </div>
  );
}

function Button20() {
  return (
    <div className="absolute bg-white content-stretch flex gap-[6px] h-[26px] items-center left-0 px-[11px] py-px rounded-[4px] top-0 w-[107.953px]" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[#e5e7eb] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <Container24 />
      <Text33 />
      <Text34 />
    </div>
  );
}

function Container25() {
  return (
    <div className="bg-[#86efac] relative rounded-[1.67772e+07px] shrink-0 size-[8px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid size-full" />
    </div>
  );
}

function Text35() {
  return (
    <div className="basis-0 grow h-[16px] min-h-px min-w-px relative shrink-0" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16px] left-[39px] not-italic text-[#364153] text-[12px] text-center text-nowrap top-px translate-x-[-50%]">Non-Intrusive</p>
      </div>
    </div>
  );
}

function Text36() {
  return (
    <div className="h-[16px] relative shrink-0 w-[22.711px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[16px] left-[11.5px] not-italic text-[#364153] text-[12px] text-center top-px translate-x-[-50%] w-[23px]">(12)</p>
      </div>
    </div>
  );
}

function Button21() {
  return (
    <div className="absolute bg-white content-stretch flex gap-[6px] h-[26px] items-center left-[113.95px] px-[11px] py-px rounded-[4px] top-0 w-[141.891px]" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[#e5e7eb] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <Container25 />
      <Text35 />
      <Text36 />
    </div>
  );
}

function Container26() {
  return (
    <div className="h-[26px] relative shrink-0 w-full" data-name="Container">
      <Button20 />
      <Button21 />
    </div>
  );
}

function Container27() {
  return (
    <div className="content-stretch flex flex-col gap-[6px] h-[48px] items-start relative shrink-0 w-full" data-name="Container">
      <Label3 />
      <Container26 />
    </div>
  );
}

function Container28() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[12px] h-[228px] items-start left-[17px] top-[53px] w-[1677px]" data-name="Container">
      <Container10 />
      <Container17 />
      <Container23 />
      <Container27 />
    </div>
  );
}

function Container29() {
  return (
    <div className="bg-white h-[298px] relative rounded-[10px] shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[#e5e7eb] border-solid inset-0 pointer-events-none rounded-[10px]" />
      <Heading1 />
      <Container28 />
    </div>
  );
}

function Table() {
  return <div className="absolute h-[49px] left-0 top-0 w-[1709px]" data-name="Table" />;
}

function HeaderCell() {
  return (
    <div className="absolute h-[48.5px] left-0 top-0 w-[346.125px]" data-name="Header Cell">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[24px] left-[24px] not-italic text-[#4a5565] text-[16px] text-nowrap top-[11.5px] tracking-[-0.3125px]">Message Name</p>
    </div>
  );
}

function HeaderCell1() {
  return (
    <div className="absolute h-[48.5px] left-[346.13px] top-0 w-[173.063px]" data-name="Header Cell">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[24px] left-[24px] not-italic text-[#4a5565] text-[16px] text-nowrap top-[11.5px] tracking-[-0.3125px]">Type</p>
    </div>
  );
}

function HeaderCell2() {
  return (
    <div className="absolute h-[48.5px] left-[519.19px] top-0 w-[173.063px]" data-name="Header Cell">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[24px] left-[24px] not-italic text-[#4a5565] text-[16px] text-nowrap top-[11.5px] tracking-[-0.3125px]">Channel</p>
    </div>
  );
}

function HeaderCell3() {
  return (
    <div className="absolute h-[48.5px] left-[692.25px] top-0 w-[173.063px]" data-name="Header Cell">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[24px] left-[24px] not-italic text-[#4a5565] text-[16px] text-nowrap top-[11.5px] tracking-[-0.3125px]">Mode</p>
    </div>
  );
}

function HeaderCell4() {
  return (
    <div className="absolute h-[48.5px] left-[865.31px] top-0 w-[173.063px]" data-name="Header Cell">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[24px] left-[24px] not-italic text-[#4a5565] text-[16px] text-nowrap top-[11.5px] tracking-[-0.3125px]">Status</p>
    </div>
  );
}

function HeaderCell5() {
  return (
    <div className="absolute h-[48.5px] left-[1038.38px] top-0 w-[216.328px]" data-name="Header Cell">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[24px] left-[24px] not-italic text-[#4a5565] text-[16px] text-nowrap top-[11.5px] tracking-[-0.3125px]">Response Rate</p>
    </div>
  );
}

function HeaderCell6() {
  return (
    <div className="absolute h-[48.5px] left-[1254.7px] top-0 w-[259.594px]" data-name="Header Cell">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[24px] left-[24px] not-italic text-[#4a5565] text-[16px] text-nowrap top-[11.5px] tracking-[-0.3125px]">Template</p>
    </div>
  );
}

function HeaderCell7() {
  return (
    <div className="absolute h-[48.5px] left-[1514.3px] top-0 w-[194.703px]" data-name="Header Cell">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[24px] left-[24px] not-italic text-[#4a5565] text-[16px] text-nowrap top-[11.5px] tracking-[-0.3125px]">Actions</p>
    </div>
  );
}

function TableRow() {
  return (
    <div className="absolute h-[48.5px] left-0 top-0 w-[1709px]" data-name="Table Row">
      <HeaderCell />
      <HeaderCell1 />
      <HeaderCell2 />
      <HeaderCell3 />
      <HeaderCell4 />
      <HeaderCell5 />
      <HeaderCell6 />
      <HeaderCell7 />
    </div>
  );
}

function TableHeader() {
  return (
    <div className="absolute bg-[#f9fafb] border-[#e5e7eb] border-[0px_0px_1px] border-solid h-[48.5px] left-0 top-0 w-[1709px]" data-name="Table Header">
      <TableRow />
    </div>
  );
}

function Container30() {
  return (
    <div className="h-[49px] overflow-clip relative shrink-0 w-full" data-name="Container">
      <Table />
      <TableHeader />
    </div>
  );
}

function Paragraph1() {
  return (
    <div className="h-[24px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[#101828] text-[16px] text-nowrap top-[-0.5px] tracking-[-0.3125px]">Win11 Migration Survey</p>
    </div>
  );
}

function Paragraph2() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#6a7282] text-[14px] text-nowrap top-[0.5px] tracking-[-0.1504px]">All Employees</p>
    </div>
  );
}

function Container31() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[48px] items-start left-[24px] top-[16px] w-[285.758px]" data-name="Container">
      <Paragraph1 />
      <Paragraph2 />
    </div>
  );
}

function TableCell() {
  return (
    <div className="absolute h-[80.5px] left-0 top-0 w-[333.758px]" data-name="Table Cell">
      <Container31 />
    </div>
  );
}

function Text37() {
  return (
    <div className="absolute bg-[#f3e8ff] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26px] w-[64.367px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#6e11b0] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">survey</p>
    </div>
  );
}

function TableCell1() {
  return (
    <div className="absolute h-[80.5px] left-[333.76px] top-0 w-[197.578px]" data-name="Table Cell">
      <Text37 />
    </div>
  );
}

function Text38() {
  return (
    <div className="absolute bg-[#f3f4f6] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26px] w-[77.25px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#1e2939] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">riverbed</p>
    </div>
  );
}

function TableCell2() {
  return (
    <div className="absolute h-[80.5px] left-[531.34px] top-0 w-[166.875px]" data-name="Table Cell">
      <Text38 />
    </div>
  );
}

function Text39() {
  return (
    <div className="absolute content-stretch flex h-[16.5px] items-start left-[24px] top-[32.5px] w-[55.25px]" data-name="Text">
      <p className="capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] not-italic relative shrink-0 text-[#101828] text-[14px] text-nowrap tracking-[-0.1504px]">intrusive</p>
    </div>
  );
}

function TableCell3() {
  return (
    <div className="absolute h-[80.5px] left-[698.21px] top-0 w-[166.875px]" data-name="Table Cell">
      <Text39 />
    </div>
  );
}

function Text40() {
  return (
    <div className="absolute bg-[#dcfce7] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26px] w-[59.953px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#016630] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">active</p>
    </div>
  );
}

function TableCell4() {
  return (
    <div className="absolute h-[80.5px] left-[865.09px] top-0 w-[180.945px]" data-name="Table Cell">
      <Text40 />
    </div>
  );
}

function Container32() {
  return <div className="bg-[#59168b] h-[8px] rounded-[1.67772e+07px] shrink-0 w-full" data-name="Container" />;
}

function Container33() {
  return (
    <div className="basis-0 bg-[#e5e7eb] grow h-[8px] min-h-px min-w-px relative rounded-[1.67772e+07px] shrink-0" data-name="Container">
      <div className="size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pl-0 pr-[36.461px] py-0 relative size-full">
          <Container32 />
        </div>
      </div>
    </div>
  );
}

function Text41() {
  return (
    <div className="h-[20px] relative shrink-0 w-[28.664px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#101828] text-[14px] top-[0.5px] tracking-[-0.1504px] w-[29px]">74%</p>
      </div>
    </div>
  );
}

function Container34() {
  return (
    <div className="content-stretch flex gap-[8px] h-[20px] items-center relative shrink-0 w-full" data-name="Container">
      <Container33 />
      <Text41 />
    </div>
  );
}

function Paragraph3() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#6a7282] text-[14px] top-[0.5px] tracking-[-0.1504px] w-[78px]">1823 / 2450</p>
    </div>
  );
}

function Container35() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[44px] items-start left-[24px] top-[18px] w-[176.875px]" data-name="Container">
      <Container34 />
      <Paragraph3 />
    </div>
  );
}

function TableCell5() {
  return (
    <div className="absolute h-[80.5px] left-[1046.03px] top-0 w-[224.875px]" data-name="Table Cell">
      <Container35 />
    </div>
  );
}

function Paragraph4() {
  return (
    <div className="absolute h-[20px] left-[24px] top-[20px] w-[202.32px]" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#101828] text-[14px] text-nowrap top-[0.5px] tracking-[-0.1504px]">Multi-step Survey</p>
    </div>
  );
}

function Paragraph5() {
  return (
    <div className="absolute h-[16px] left-[24px] top-[44px] w-[202.32px]" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16px] left-0 not-italic text-[#59168b] text-[12px] text-nowrap top-px">Interactive Flow</p>
    </div>
  );
}

function TableCell6() {
  return (
    <div className="absolute h-[80.5px] left-[1270.91px] top-0 w-[250.32px]" data-name="Table Cell">
      <Paragraph4 />
      <Paragraph5 />
    </div>
  );
}

function Icon8() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[20.84%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%_-5%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 11">
            <path d={svgPaths.pb85f580} id="Vector" stroke="var(--stroke-0, #59168B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[37.5%]" data-name="Vector">
        <div className="absolute inset-[-16.67%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6 6">
            <path d={svgPaths.p36446d40} id="Vector" stroke="var(--stroke-0, #59168B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button22() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon8 />
      </div>
    </div>
  );
}

function Icon9() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[12.5%]" data-name="Vector">
        <div className="absolute inset-[-5.56%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
            <path d={svgPaths.p73e95c0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.35%_8.35%_33.32%_33.32%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p47c19f0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button23() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon9 />
      </div>
    </div>
  );
}

function Icon10() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[33.33%_8.33%_8.33%_33.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p4611e00} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.33%_33.33%_33.33%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p26970a80} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button24() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon10 />
      </div>
    </div>
  );
}

function Icon11() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[8.32%_8.32%_8.33%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-5%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
            <path d={svgPaths.p185227c0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.95%_8.94%_45.48%_45.47%]" data-name="Vector">
        <div className="absolute inset-[-9.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9 9">
            <path d={svgPaths.p2db0e900} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button25() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon11 />
      </div>
    </div>
  );
}

function Container36() {
  return (
    <div className="absolute content-stretch flex gap-[8px] h-[16px] items-center left-[24px] top-[32px] w-[139.773px]" data-name="Container">
      <Button22 />
      <Button23 />
      <Button24 />
      <Button25 />
    </div>
  );
}

function TableCell7() {
  return (
    <div className="absolute h-[80.5px] left-[1521.23px] top-0 w-[187.773px]" data-name="Table Cell">
      <Container36 />
    </div>
  );
}

function TableRow1() {
  return (
    <div className="absolute border-[#e5e7eb] border-[0px_0px_1px] border-solid h-[80.5px] left-0 top-0 w-[1709px]" data-name="Table Row">
      <TableCell />
      <TableCell1 />
      <TableCell2 />
      <TableCell3 />
      <TableCell4 />
      <TableCell5 />
      <TableCell6 />
      <TableCell7 />
    </div>
  );
}

function Paragraph6() {
  return (
    <div className="h-[24px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[#101828] text-[16px] text-nowrap top-[-0.5px] tracking-[-0.3125px]">Network Issue Auto-Fix Confirmation</p>
    </div>
  );
}

function Paragraph7() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#6a7282] text-[14px] text-nowrap top-[0.5px] tracking-[-0.1504px]">Engineering Dept</p>
    </div>
  );
}

function Container37() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[48px] items-start left-[24px] top-[16.5px] w-[285.758px]" data-name="Container">
      <Paragraph6 />
      <Paragraph7 />
    </div>
  );
}

function TableCell8() {
  return (
    <div className="absolute h-[81px] left-0 top-0 w-[333.758px]" data-name="Table Cell">
      <Container37 />
    </div>
  );
}

function Text42() {
  return (
    <div className="absolute bg-[#ffedd4] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[103.547px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#9f2d00] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">confirmation</p>
    </div>
  );
}

function TableCell9() {
  return (
    <div className="absolute h-[81px] left-[333.76px] top-0 w-[197.578px]" data-name="Table Cell">
      <Text42 />
    </div>
  );
}

function Text43() {
  return (
    <div className="absolute bg-[#f3f4f6] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[77.25px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#1e2939] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">riverbed</p>
    </div>
  );
}

function TableCell10() {
  return (
    <div className="absolute h-[81px] left-[531.34px] top-0 w-[166.875px]" data-name="Table Cell">
      <Text43 />
    </div>
  );
}

function Text44() {
  return (
    <div className="absolute content-stretch flex h-[16.5px] items-start left-[24px] top-[33px] w-[55.25px]" data-name="Text">
      <p className="capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] not-italic relative shrink-0 text-[#101828] text-[14px] text-nowrap tracking-[-0.1504px]">intrusive</p>
    </div>
  );
}

function TableCell11() {
  return (
    <div className="absolute h-[81px] left-[698.21px] top-0 w-[166.875px]" data-name="Table Cell">
      <Text44 />
    </div>
  );
}

function Text45() {
  return (
    <div className="absolute bg-[#dcfce7] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[59.953px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#016630] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">active</p>
    </div>
  );
}

function TableCell12() {
  return (
    <div className="absolute h-[81px] left-[865.09px] top-0 w-[180.945px]" data-name="Table Cell">
      <Text45 />
    </div>
  );
}

function Container38() {
  return <div className="bg-[#59168b] h-[8px] rounded-[1.67772e+07px] shrink-0 w-full" data-name="Container" />;
}

function Container39() {
  return (
    <div className="basis-0 bg-[#e5e7eb] grow h-[8px] min-h-px min-w-px relative rounded-[1.67772e+07px] shrink-0" data-name="Container">
      <div className="size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pl-0 pr-[23.57px] py-0 relative size-full">
          <Container38 />
        </div>
      </div>
    </div>
  );
}

function Text46() {
  return (
    <div className="h-[20px] relative shrink-0 w-[30.227px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#101828] text-[14px] top-[0.5px] tracking-[-0.1504px] w-[31px]">83%</p>
      </div>
    </div>
  );
}

function Container40() {
  return (
    <div className="content-stretch flex gap-[8px] h-[20px] items-center relative shrink-0 w-full" data-name="Container">
      <Container39 />
      <Text46 />
    </div>
  );
}

function Paragraph8() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#6a7282] text-[14px] top-[0.5px] tracking-[-0.1504px] w-[45px]">72 / 87</p>
    </div>
  );
}

function Container41() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[44px] items-start left-[24px] top-[18.5px] w-[176.875px]" data-name="Container">
      <Container40 />
      <Paragraph8 />
    </div>
  );
}

function TableCell13() {
  return (
    <div className="absolute h-[81px] left-[1046.03px] top-0 w-[224.875px]" data-name="Table Cell">
      <Container41 />
    </div>
  );
}

function Paragraph9() {
  return (
    <div className="absolute h-[20px] left-[24px] top-[20.5px] w-[202.32px]" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#101828] text-[14px] text-nowrap top-[0.5px] tracking-[-0.1504px]">Remediation Confirmation</p>
    </div>
  );
}

function Paragraph10() {
  return (
    <div className="absolute h-[16px] left-[24px] top-[44.5px] w-[202.32px]" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16px] left-0 not-italic text-[#59168b] text-[12px] text-nowrap top-px">Interactive Flow</p>
    </div>
  );
}

function TableCell14() {
  return (
    <div className="absolute h-[81px] left-[1270.91px] top-0 w-[250.32px]" data-name="Table Cell">
      <Paragraph9 />
      <Paragraph10 />
    </div>
  );
}

function Icon12() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[20.84%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%_-5%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 11">
            <path d={svgPaths.pb85f580} id="Vector" stroke="var(--stroke-0, #59168B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[37.5%]" data-name="Vector">
        <div className="absolute inset-[-16.67%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6 6">
            <path d={svgPaths.p36446d40} id="Vector" stroke="var(--stroke-0, #59168B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button26() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon12 />
      </div>
    </div>
  );
}

function Icon13() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[12.5%]" data-name="Vector">
        <div className="absolute inset-[-5.56%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
            <path d={svgPaths.p73e95c0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.35%_8.35%_33.32%_33.32%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p47c19f0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button27() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon13 />
      </div>
    </div>
  );
}

function Icon14() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[33.33%_8.33%_8.33%_33.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p4611e00} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.33%_33.33%_33.33%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p26970a80} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button28() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon14 />
      </div>
    </div>
  );
}

function Icon15() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[8.32%_8.32%_8.33%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-5%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
            <path d={svgPaths.p185227c0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.95%_8.94%_45.48%_45.47%]" data-name="Vector">
        <div className="absolute inset-[-9.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9 9">
            <path d={svgPaths.p2db0e900} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button29() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon15 />
      </div>
    </div>
  );
}

function Container42() {
  return (
    <div className="absolute content-stretch flex gap-[8px] h-[16px] items-center left-[24px] top-[32.5px] w-[139.773px]" data-name="Container">
      <Button26 />
      <Button27 />
      <Button28 />
      <Button29 />
    </div>
  );
}

function TableCell15() {
  return (
    <div className="absolute h-[81px] left-[1521.23px] top-0 w-[187.773px]" data-name="Table Cell">
      <Container42 />
    </div>
  );
}

function TableRow2() {
  return (
    <div className="absolute border-[#e5e7eb] border-[0px_0px_1px] border-solid h-[81px] left-0 top-[80.5px] w-[1709px]" data-name="Table Row">
      <TableCell8 />
      <TableCell9 />
      <TableCell10 />
      <TableCell11 />
      <TableCell12 />
      <TableCell13 />
      <TableCell14 />
      <TableCell15 />
    </div>
  );
}

function Paragraph11() {
  return (
    <div className="h-[24px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[#101828] text-[16px] text-nowrap top-[-0.5px] tracking-[-0.3125px]">Issue Resolved Notification</p>
    </div>
  );
}

function Paragraph12() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#6a7282] text-[14px] text-nowrap top-[0.5px] tracking-[-0.1504px]">Remote Workers</p>
    </div>
  );
}

function Container43() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[48px] items-start left-[24px] top-[16.5px] w-[285.758px]" data-name="Container">
      <Paragraph11 />
      <Paragraph12 />
    </div>
  );
}

function TableCell16() {
  return (
    <div className="absolute h-[81px] left-0 top-0 w-[333.758px]" data-name="Table Cell">
      <Container43 />
    </div>
  );
}

function Text47() {
  return (
    <div className="absolute bg-[#dbeafe] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[94.477px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#193cb8] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">notification</p>
    </div>
  );
}

function TableCell17() {
  return (
    <div className="absolute h-[81px] left-[333.76px] top-0 w-[197.578px]" data-name="Table Cell">
      <Text47 />
    </div>
  );
}

function Text48() {
  return (
    <div className="absolute bg-[#e0e7ff] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[61.992px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#372aac] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">teams</p>
    </div>
  );
}

function TableCell18() {
  return (
    <div className="absolute h-[81px] left-[531.34px] top-0 w-[166.875px]" data-name="Table Cell">
      <Text48 />
    </div>
  );
}

function Text49() {
  return (
    <div className="absolute content-stretch flex h-[16.5px] items-start left-[24px] top-[33px] w-[88.086px]" data-name="Text">
      <p className="capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] not-italic relative shrink-0 text-[#101828] text-[14px] text-nowrap tracking-[-0.1504px]">non-intrusive</p>
    </div>
  );
}

function TableCell19() {
  return (
    <div className="absolute h-[81px] left-[698.21px] top-0 w-[166.875px]" data-name="Table Cell">
      <Text49 />
    </div>
  );
}

function Text50() {
  return (
    <div className="absolute bg-[#dcfce7] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[59.953px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#016630] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">active</p>
    </div>
  );
}

function TableCell20() {
  return (
    <div className="absolute h-[81px] left-[865.09px] top-0 w-[180.945px]" data-name="Table Cell">
      <Text50 />
    </div>
  );
}

function Container44() {
  return <div className="bg-[#59168b] h-[8px] rounded-[1.67772e+07px] shrink-0 w-full" data-name="Container" />;
}

function Container45() {
  return (
    <div className="basis-0 bg-[#e5e7eb] grow h-[8px] min-h-px min-w-px relative rounded-[1.67772e+07px] shrink-0" data-name="Container">
      <div className="size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pl-0 pr-[11.125px] py-0 relative size-full">
          <Container44 />
        </div>
      </div>
    </div>
  );
}

function Text51() {
  return (
    <div className="h-[20px] relative shrink-0 w-[29.867px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#101828] text-[14px] top-[0.5px] tracking-[-0.1504px] w-[30px]">92%</p>
      </div>
    </div>
  );
}

function Container46() {
  return (
    <div className="content-stretch flex gap-[8px] h-[20px] items-center relative shrink-0 w-full" data-name="Container">
      <Container45 />
      <Text51 />
    </div>
  );
}

function Paragraph13() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#6a7282] text-[14px] top-[0.5px] tracking-[-0.1504px] w-[60px]">143 / 156</p>
    </div>
  );
}

function Container47() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[44px] items-start left-[24px] top-[18.5px] w-[176.875px]" data-name="Container">
      <Container46 />
      <Paragraph13 />
    </div>
  );
}

function TableCell21() {
  return (
    <div className="absolute h-[81px] left-[1046.03px] top-0 w-[224.875px]" data-name="Table Cell">
      <Container47 />
    </div>
  );
}

function Paragraph14() {
  return (
    <div className="absolute h-[20px] left-[24px] top-[30.5px] w-[202.32px]" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#101828] text-[14px] text-nowrap top-[0.5px] tracking-[-0.1504px]">Success Notification</p>
    </div>
  );
}

function TableCell22() {
  return (
    <div className="absolute h-[81px] left-[1270.91px] top-0 w-[250.32px]" data-name="Table Cell">
      <Paragraph14 />
    </div>
  );
}

function Icon16() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[20.84%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%_-5%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 11">
            <path d={svgPaths.pb85f580} id="Vector" stroke="var(--stroke-0, #59168B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[37.5%]" data-name="Vector">
        <div className="absolute inset-[-16.67%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6 6">
            <path d={svgPaths.p36446d40} id="Vector" stroke="var(--stroke-0, #59168B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button30() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon16 />
      </div>
    </div>
  );
}

function Icon17() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[12.5%]" data-name="Vector">
        <div className="absolute inset-[-5.56%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
            <path d={svgPaths.p73e95c0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.35%_8.35%_33.32%_33.32%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p47c19f0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button31() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon17 />
      </div>
    </div>
  );
}

function Icon18() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[33.33%_8.33%_8.33%_33.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p4611e00} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.33%_33.33%_33.33%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p26970a80} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button32() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon18 />
      </div>
    </div>
  );
}

function Icon19() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[8.32%_8.32%_8.33%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-5%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
            <path d={svgPaths.p185227c0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.95%_8.94%_45.48%_45.47%]" data-name="Vector">
        <div className="absolute inset-[-9.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9 9">
            <path d={svgPaths.p2db0e900} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button33() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon19 />
      </div>
    </div>
  );
}

function Container48() {
  return (
    <div className="absolute content-stretch flex gap-[8px] h-[16px] items-center left-[24px] top-[32.5px] w-[139.773px]" data-name="Container">
      <Button30 />
      <Button31 />
      <Button32 />
      <Button33 />
    </div>
  );
}

function TableCell23() {
  return (
    <div className="absolute h-[81px] left-[1521.23px] top-0 w-[187.773px]" data-name="Table Cell">
      <Container48 />
    </div>
  );
}

function TableRow3() {
  return (
    <div className="absolute border-[#e5e7eb] border-[0px_0px_1px] border-solid h-[81px] left-0 top-[161.5px] w-[1709px]" data-name="Table Row">
      <TableCell16 />
      <TableCell17 />
      <TableCell18 />
      <TableCell19 />
      <TableCell20 />
      <TableCell21 />
      <TableCell22 />
      <TableCell23 />
    </div>
  );
}

function Paragraph15() {
  return (
    <div className="h-[24px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[#101828] text-[16px] text-nowrap top-[-0.5px] tracking-[-0.3125px]">Snoozed Remediation Reminder</p>
    </div>
  );
}

function Paragraph16() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#6a7282] text-[14px] text-nowrap top-[0.5px] tracking-[-0.1504px]">Sales Dept</p>
    </div>
  );
}

function Container49() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[48px] items-start left-[24px] top-[16.5px] w-[285.758px]" data-name="Container">
      <Paragraph15 />
      <Paragraph16 />
    </div>
  );
}

function TableCell24() {
  return (
    <div className="absolute h-[81px] left-0 top-0 w-[333.758px]" data-name="Table Cell">
      <Container49 />
    </div>
  );
}

function Text52() {
  return (
    <div className="absolute bg-[#fef9c2] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[81.477px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#894b00] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">reminder</p>
    </div>
  );
}

function TableCell25() {
  return (
    <div className="absolute h-[81px] left-[333.76px] top-0 w-[197.578px]" data-name="Table Cell">
      <Text52 />
    </div>
  );
}

function Text53() {
  return (
    <div className="absolute bg-[#f3f4f6] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[77.25px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#1e2939] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">riverbed</p>
    </div>
  );
}

function TableCell26() {
  return (
    <div className="absolute h-[81px] left-[531.34px] top-0 w-[166.875px]" data-name="Table Cell">
      <Text53 />
    </div>
  );
}

function Text54() {
  return (
    <div className="absolute content-stretch flex h-[16.5px] items-start left-[24px] top-[33px] w-[55.25px]" data-name="Text">
      <p className="capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] not-italic relative shrink-0 text-[#101828] text-[14px] text-nowrap tracking-[-0.1504px]">intrusive</p>
    </div>
  );
}

function TableCell27() {
  return (
    <div className="absolute h-[81px] left-[698.21px] top-0 w-[166.875px]" data-name="Table Cell">
      <Text54 />
    </div>
  );
}

function Text55() {
  return (
    <div className="absolute bg-[#dbeafe] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[88.547px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#193cb8] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">scheduled</p>
    </div>
  );
}

function TableCell28() {
  return (
    <div className="absolute h-[81px] left-[865.09px] top-0 w-[180.945px]" data-name="Table Cell">
      <Text55 />
    </div>
  );
}

function Container50() {
  return <div className="bg-[#59168b] h-[8px] rounded-[1.67772e+07px] shrink-0 w-full" data-name="Container" />;
}

function Container51() {
  return (
    <div className="basis-0 bg-[#e5e7eb] grow h-[8px] min-h-px min-w-px relative rounded-[1.67772e+07px] shrink-0" data-name="Container">
      <div className="size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pl-0 pr-[147.398px] py-0 relative size-full">
          <Container50 />
        </div>
      </div>
    </div>
  );
}

function Text56() {
  return (
    <div className="h-[20px] relative shrink-0 w-[21.477px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#101828] text-[14px] top-[0.5px] tracking-[-0.1504px] w-[22px]">0%</p>
      </div>
    </div>
  );
}

function Container52() {
  return (
    <div className="content-stretch flex gap-[8px] h-[20px] items-center relative shrink-0 w-full" data-name="Container">
      <Container51 />
      <Text56 />
    </div>
  );
}

function Paragraph17() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#6a7282] text-[14px] top-[0.5px] tracking-[-0.1504px] w-[30px]">0 / 0</p>
    </div>
  );
}

function Container53() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[44px] items-start left-[24px] top-[18.5px] w-[176.875px]" data-name="Container">
      <Container52 />
      <Paragraph17 />
    </div>
  );
}

function TableCell29() {
  return (
    <div className="absolute h-[81px] left-[1046.03px] top-0 w-[224.875px]" data-name="Table Cell">
      <Container53 />
    </div>
  );
}

function Paragraph18() {
  return (
    <div className="absolute h-[20px] left-[24px] top-[30.5px] w-[202.32px]" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#101828] text-[14px] text-nowrap top-[0.5px] tracking-[-0.1504px]">Remediation Reminder</p>
    </div>
  );
}

function TableCell30() {
  return (
    <div className="absolute h-[81px] left-[1270.91px] top-0 w-[250.32px]" data-name="Table Cell">
      <Paragraph18 />
    </div>
  );
}

function Icon20() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[20.84%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%_-5%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 11">
            <path d={svgPaths.pb85f580} id="Vector" stroke="var(--stroke-0, #59168B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[37.5%]" data-name="Vector">
        <div className="absolute inset-[-16.67%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6 6">
            <path d={svgPaths.p36446d40} id="Vector" stroke="var(--stroke-0, #59168B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button34() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon20 />
      </div>
    </div>
  );
}

function Icon21() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[12.5%]" data-name="Vector">
        <div className="absolute inset-[-5.56%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
            <path d={svgPaths.p73e95c0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.35%_8.35%_33.32%_33.32%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p47c19f0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button35() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon21 />
      </div>
    </div>
  );
}

function Icon22() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[33.33%_8.33%_8.33%_33.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p4611e00} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.33%_33.33%_33.33%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p26970a80} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button36() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon22 />
      </div>
    </div>
  );
}

function Icon23() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[8.32%_8.32%_8.33%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-5%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
            <path d={svgPaths.p185227c0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.95%_8.94%_45.48%_45.47%]" data-name="Vector">
        <div className="absolute inset-[-9.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9 9">
            <path d={svgPaths.p2db0e900} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button37() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon23 />
      </div>
    </div>
  );
}

function Container54() {
  return (
    <div className="absolute content-stretch flex gap-[8px] h-[16px] items-center left-[24px] top-[32.5px] w-[139.773px]" data-name="Container">
      <Button34 />
      <Button35 />
      <Button36 />
      <Button37 />
    </div>
  );
}

function TableCell31() {
  return (
    <div className="absolute h-[81px] left-[1521.23px] top-0 w-[187.773px]" data-name="Table Cell">
      <Container54 />
    </div>
  );
}

function TableRow4() {
  return (
    <div className="absolute border-[#e5e7eb] border-[0px_0px_1px] border-solid h-[81px] left-0 top-[242.5px] w-[1709px]" data-name="Table Row">
      <TableCell24 />
      <TableCell25 />
      <TableCell26 />
      <TableCell27 />
      <TableCell28 />
      <TableCell29 />
      <TableCell30 />
      <TableCell31 />
    </div>
  );
}

function Paragraph19() {
  return (
    <div className="h-[24px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[#101828] text-[16px] text-nowrap top-[-0.5px] tracking-[-0.3125px]">Device Health Self-Service</p>
    </div>
  );
}

function Paragraph20() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#6a7282] text-[14px] text-nowrap top-[0.5px] tracking-[-0.1504px]">VIP Users</p>
    </div>
  );
}

function Container55() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[48px] items-start left-[24px] top-[16.5px] w-[285.758px]" data-name="Container">
      <Paragraph19 />
      <Paragraph20 />
    </div>
  );
}

function TableCell32() {
  return (
    <div className="absolute h-[81px] left-0 top-0 w-[333.758px]" data-name="Table Cell">
      <Container55 />
    </div>
  );
}

function Text57() {
  return (
    <div className="absolute bg-[#dcfce7] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[99.188px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#016630] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">self-service</p>
    </div>
  );
}

function TableCell33() {
  return (
    <div className="absolute h-[81px] left-[333.76px] top-0 w-[197.578px]" data-name="Table Cell">
      <Text57 />
    </div>
  );
}

function Text58() {
  return (
    <div className="absolute bg-[#e0e7ff] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[61.992px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#372aac] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">teams</p>
    </div>
  );
}

function TableCell34() {
  return (
    <div className="absolute h-[81px] left-[531.34px] top-0 w-[166.875px]" data-name="Table Cell">
      <Text58 />
    </div>
  );
}

function Text59() {
  return (
    <div className="absolute content-stretch flex h-[16.5px] items-start left-[24px] top-[33px] w-[88.086px]" data-name="Text">
      <p className="capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] not-italic relative shrink-0 text-[#101828] text-[14px] text-nowrap tracking-[-0.1504px]">non-intrusive</p>
    </div>
  );
}

function TableCell35() {
  return (
    <div className="absolute h-[81px] left-[698.21px] top-0 w-[166.875px]" data-name="Table Cell">
      <Text59 />
    </div>
  );
}

function Text60() {
  return (
    <div className="absolute bg-[#dcfce7] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[59.953px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#016630] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">active</p>
    </div>
  );
}

function TableCell36() {
  return (
    <div className="absolute h-[81px] left-[865.09px] top-0 w-[180.945px]" data-name="Table Cell">
      <Text60 />
    </div>
  );
}

function Container56() {
  return <div className="bg-[#59168b] h-[8px] rounded-[1.67772e+07px] shrink-0 w-full" data-name="Container" />;
}

function Container57() {
  return (
    <div className="basis-0 bg-[#e5e7eb] grow h-[8px] min-h-px min-w-px relative rounded-[1.67772e+07px] shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Container56 />
      </div>
    </div>
  );
}

function Text61() {
  return (
    <div className="h-[20px] relative shrink-0 w-[36.484px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#101828] text-[14px] top-[0.5px] tracking-[-0.1504px] w-[37px]">100%</p>
      </div>
    </div>
  );
}

function Container58() {
  return (
    <div className="content-stretch flex gap-[8px] h-[20px] items-center relative shrink-0 w-full" data-name="Container">
      <Container57 />
      <Text61 />
    </div>
  );
}

function Paragraph21() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#6a7282] text-[14px] top-[0.5px] tracking-[-0.1504px] w-[47px]">34 / 34</p>
    </div>
  );
}

function Container59() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[44px] items-start left-[24px] top-[18.5px] w-[176.875px]" data-name="Container">
      <Container58 />
      <Paragraph21 />
    </div>
  );
}

function TableCell37() {
  return (
    <div className="absolute h-[81px] left-[1046.03px] top-0 w-[224.875px]" data-name="Table Cell">
      <Container59 />
    </div>
  );
}

function Paragraph22() {
  return (
    <div className="absolute h-[20px] left-[24px] top-[20.5px] w-[202.32px]" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#101828] text-[14px] text-nowrap top-[0.5px] tracking-[-0.1504px]">Chat Interface</p>
    </div>
  );
}

function Paragraph23() {
  return (
    <div className="absolute h-[16px] left-[24px] top-[44.5px] w-[202.32px]" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16px] left-0 not-italic text-[#59168b] text-[12px] text-nowrap top-px">Interactive Flow</p>
    </div>
  );
}

function TableCell38() {
  return (
    <div className="absolute h-[81px] left-[1270.91px] top-0 w-[250.32px]" data-name="Table Cell">
      <Paragraph22 />
      <Paragraph23 />
    </div>
  );
}

function Icon24() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[20.84%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%_-5%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 11">
            <path d={svgPaths.pb85f580} id="Vector" stroke="var(--stroke-0, #59168B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[37.5%]" data-name="Vector">
        <div className="absolute inset-[-16.67%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6 6">
            <path d={svgPaths.p36446d40} id="Vector" stroke="var(--stroke-0, #59168B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button38() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon24 />
      </div>
    </div>
  );
}

function Icon25() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[12.5%]" data-name="Vector">
        <div className="absolute inset-[-5.56%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
            <path d={svgPaths.p73e95c0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.35%_8.35%_33.32%_33.32%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p47c19f0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button39() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon25 />
      </div>
    </div>
  );
}

function Icon26() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[33.33%_8.33%_8.33%_33.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p4611e00} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.33%_33.33%_33.33%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p26970a80} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button40() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon26 />
      </div>
    </div>
  );
}

function Icon27() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[8.32%_8.32%_8.33%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-5%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
            <path d={svgPaths.p185227c0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.95%_8.94%_45.48%_45.47%]" data-name="Vector">
        <div className="absolute inset-[-9.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9 9">
            <path d={svgPaths.p2db0e900} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button41() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon27 />
      </div>
    </div>
  );
}

function Container60() {
  return (
    <div className="absolute content-stretch flex gap-[8px] h-[16px] items-center left-[24px] top-[32.5px] w-[139.773px]" data-name="Container">
      <Button38 />
      <Button39 />
      <Button40 />
      <Button41 />
    </div>
  );
}

function TableCell39() {
  return (
    <div className="absolute h-[81px] left-[1521.23px] top-0 w-[187.773px]" data-name="Table Cell">
      <Container60 />
    </div>
  );
}

function TableRow5() {
  return (
    <div className="absolute border-[#e5e7eb] border-[0px_0px_1px] border-solid h-[81px] left-0 top-[323.5px] w-[1709px]" data-name="Table Row">
      <TableCell32 />
      <TableCell33 />
      <TableCell34 />
      <TableCell35 />
      <TableCell36 />
      <TableCell37 />
      <TableCell38 />
      <TableCell39 />
    </div>
  );
}

function Paragraph24() {
  return (
    <div className="h-[24px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[#101828] text-[16px] text-nowrap top-[-0.5px] tracking-[-0.3125px]">Employee Satisfaction Survey</p>
    </div>
  );
}

function Paragraph25() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#6a7282] text-[14px] text-nowrap top-[0.5px] tracking-[-0.1504px]">All Employees</p>
    </div>
  );
}

function Container61() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[48px] items-start left-[24px] top-[16.5px] w-[285.758px]" data-name="Container">
      <Paragraph24 />
      <Paragraph25 />
    </div>
  );
}

function TableCell40() {
  return (
    <div className="absolute h-[81px] left-0 top-0 w-[333.758px]" data-name="Table Cell">
      <Container61 />
    </div>
  );
}

function Text62() {
  return (
    <div className="absolute bg-[#f3e8ff] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[64.367px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#6e11b0] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">survey</p>
    </div>
  );
}

function TableCell41() {
  return (
    <div className="absolute h-[81px] left-[333.76px] top-0 w-[197.578px]" data-name="Table Cell">
      <Text62 />
    </div>
  );
}

function Text63() {
  return (
    <div className="absolute bg-[#cbfbf1] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[54.5px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#005f5a] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">email</p>
    </div>
  );
}

function TableCell42() {
  return (
    <div className="absolute h-[81px] left-[531.34px] top-0 w-[166.875px]" data-name="Table Cell">
      <Text63 />
    </div>
  );
}

function Text64() {
  return (
    <div className="absolute content-stretch flex h-[16.5px] items-start left-[24px] top-[33px] w-[88.086px]" data-name="Text">
      <p className="capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] not-italic relative shrink-0 text-[#101828] text-[14px] text-nowrap tracking-[-0.1504px]">non-intrusive</p>
    </div>
  );
}

function TableCell43() {
  return (
    <div className="absolute h-[81px] left-[698.21px] top-0 w-[166.875px]" data-name="Table Cell">
      <Text64 />
    </div>
  );
}

function Text65() {
  return (
    <div className="absolute bg-[#dcfce7] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[59.953px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#016630] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">active</p>
    </div>
  );
}

function TableCell44() {
  return (
    <div className="absolute h-[81px] left-[865.09px] top-0 w-[180.945px]" data-name="Table Cell">
      <Text65 />
    </div>
  );
}

function Container62() {
  return <div className="bg-[#59168b] h-[8px] rounded-[1.67772e+07px] shrink-0 w-full" data-name="Container" />;
}

function Container63() {
  return (
    <div className="basis-0 bg-[#e5e7eb] grow h-[8px] min-h-px min-w-px relative rounded-[1.67772e+07px] shrink-0" data-name="Container">
      <div className="size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pl-0 pr-[46.031px] py-0 relative size-full">
          <Container62 />
        </div>
      </div>
    </div>
  );
}

function Text66() {
  return (
    <div className="h-[20px] relative shrink-0 w-[29.391px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#101828] text-[14px] top-[0.5px] tracking-[-0.1504px] w-[30px]">67%</p>
      </div>
    </div>
  );
}

function Container64() {
  return (
    <div className="content-stretch flex gap-[8px] h-[20px] items-center relative shrink-0 w-full" data-name="Container">
      <Container63 />
      <Text66 />
    </div>
  );
}

function Paragraph26() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#6a7282] text-[14px] top-[0.5px] tracking-[-0.1504px] w-[78px]">2145 / 3200</p>
    </div>
  );
}

function Container65() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[44px] items-start left-[24px] top-[18.5px] w-[176.875px]" data-name="Container">
      <Container64 />
      <Paragraph26 />
    </div>
  );
}

function TableCell45() {
  return (
    <div className="absolute h-[81px] left-[1046.03px] top-0 w-[224.875px]" data-name="Table Cell">
      <Container65 />
    </div>
  );
}

function Paragraph27() {
  return (
    <div className="absolute h-[20px] left-[24px] top-[30.5px] w-[202.32px]" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#101828] text-[14px] text-nowrap top-[0.5px] tracking-[-0.1504px]">Annual Survey</p>
    </div>
  );
}

function TableCell46() {
  return (
    <div className="absolute h-[81px] left-[1270.91px] top-0 w-[250.32px]" data-name="Table Cell">
      <Paragraph27 />
    </div>
  );
}

function Icon28() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[20.84%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%_-5%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 11">
            <path d={svgPaths.pb85f580} id="Vector" stroke="var(--stroke-0, #59168B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[37.5%]" data-name="Vector">
        <div className="absolute inset-[-16.67%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6 6">
            <path d={svgPaths.p36446d40} id="Vector" stroke="var(--stroke-0, #59168B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button42() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon28 />
      </div>
    </div>
  );
}

function Icon29() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[12.5%]" data-name="Vector">
        <div className="absolute inset-[-5.56%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
            <path d={svgPaths.p73e95c0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.35%_8.35%_33.32%_33.32%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p47c19f0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button43() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon29 />
      </div>
    </div>
  );
}

function Icon30() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[33.33%_8.33%_8.33%_33.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p4611e00} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.33%_33.33%_33.33%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p26970a80} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button44() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon30 />
      </div>
    </div>
  );
}

function Icon31() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[8.32%_8.32%_8.33%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-5%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
            <path d={svgPaths.p185227c0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.95%_8.94%_45.48%_45.47%]" data-name="Vector">
        <div className="absolute inset-[-9.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9 9">
            <path d={svgPaths.p2db0e900} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button45() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon31 />
      </div>
    </div>
  );
}

function Container66() {
  return (
    <div className="absolute content-stretch flex gap-[8px] h-[16px] items-center left-[24px] top-[32.5px] w-[139.773px]" data-name="Container">
      <Button42 />
      <Button43 />
      <Button44 />
      <Button45 />
    </div>
  );
}

function TableCell47() {
  return (
    <div className="absolute h-[81px] left-[1521.23px] top-0 w-[187.773px]" data-name="Table Cell">
      <Container66 />
    </div>
  );
}

function TableRow6() {
  return (
    <div className="absolute border-[#e5e7eb] border-[0px_0px_1px] border-solid h-[81px] left-0 top-[404.5px] w-[1709px]" data-name="Table Row">
      <TableCell40 />
      <TableCell41 />
      <TableCell42 />
      <TableCell43 />
      <TableCell44 />
      <TableCell45 />
      <TableCell46 />
      <TableCell47 />
    </div>
  );
}

function Paragraph28() {
  return (
    <div className="h-[24px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[#101828] text-[16px] text-nowrap top-[-0.5px] tracking-[-0.3125px]">Security Patch Confirmation</p>
    </div>
  );
}

function Paragraph29() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#6a7282] text-[14px] text-nowrap top-[0.5px] tracking-[-0.1504px]">IT Security Team</p>
    </div>
  );
}

function Container67() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[48px] items-start left-[24px] top-[16.5px] w-[285.758px]" data-name="Container">
      <Paragraph28 />
      <Paragraph29 />
    </div>
  );
}

function TableCell48() {
  return (
    <div className="absolute h-[81px] left-0 top-0 w-[333.758px]" data-name="Table Cell">
      <Container67 />
    </div>
  );
}

function Text67() {
  return (
    <div className="absolute bg-[#ffedd4] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[103.547px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#9f2d00] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">confirmation</p>
    </div>
  );
}

function TableCell49() {
  return (
    <div className="absolute h-[81px] left-[333.76px] top-0 w-[197.578px]" data-name="Table Cell">
      <Text67 />
    </div>
  );
}

function Text68() {
  return (
    <div className="absolute bg-[#fce7f3] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[54.875px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#a3004c] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">slack</p>
    </div>
  );
}

function TableCell50() {
  return (
    <div className="absolute h-[81px] left-[531.34px] top-0 w-[166.875px]" data-name="Table Cell">
      <Text68 />
    </div>
  );
}

function Text69() {
  return (
    <div className="absolute content-stretch flex h-[16.5px] items-start left-[24px] top-[33px] w-[55.25px]" data-name="Text">
      <p className="capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] not-italic relative shrink-0 text-[#101828] text-[14px] text-nowrap tracking-[-0.1504px]">intrusive</p>
    </div>
  );
}

function TableCell51() {
  return (
    <div className="absolute h-[81px] left-[698.21px] top-0 w-[166.875px]" data-name="Table Cell">
      <Text69 />
    </div>
  );
}

function Text70() {
  return (
    <div className="absolute bg-[#dcfce7] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[59.953px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#016630] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">active</p>
    </div>
  );
}

function TableCell52() {
  return (
    <div className="absolute h-[81px] left-[865.09px] top-0 w-[180.945px]" data-name="Table Cell">
      <Text70 />
    </div>
  );
}

function Container68() {
  return <div className="bg-[#59168b] h-[8px] rounded-[1.67772e+07px] shrink-0 w-full" data-name="Container" />;
}

function Container69() {
  return (
    <div className="basis-0 bg-[#e5e7eb] grow h-[8px] min-h-px min-w-px relative rounded-[1.67772e+07px] shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Container68 />
      </div>
    </div>
  );
}

function Text71() {
  return (
    <div className="h-[20px] relative shrink-0 w-[36.484px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#101828] text-[14px] top-[0.5px] tracking-[-0.1504px] w-[37px]">100%</p>
      </div>
    </div>
  );
}

function Container70() {
  return (
    <div className="content-stretch flex gap-[8px] h-[20px] items-center relative shrink-0 w-full" data-name="Container">
      <Container69 />
      <Text71 />
    </div>
  );
}

function Paragraph30() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#6a7282] text-[14px] top-[0.5px] tracking-[-0.1504px] w-[47px]">45 / 45</p>
    </div>
  );
}

function Container71() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[44px] items-start left-[24px] top-[18.5px] w-[176.875px]" data-name="Container">
      <Container70 />
      <Paragraph30 />
    </div>
  );
}

function TableCell53() {
  return (
    <div className="absolute h-[81px] left-[1046.03px] top-0 w-[224.875px]" data-name="Table Cell">
      <Container71 />
    </div>
  );
}

function Paragraph31() {
  return (
    <div className="absolute h-[20px] left-[24px] top-[20.5px] w-[202.32px]" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#101828] text-[14px] text-nowrap top-[0.5px] tracking-[-0.1504px]">Urgent Confirmation</p>
    </div>
  );
}

function Paragraph32() {
  return (
    <div className="absolute h-[16px] left-[24px] top-[44.5px] w-[202.32px]" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16px] left-0 not-italic text-[#59168b] text-[12px] text-nowrap top-px">Interactive Flow</p>
    </div>
  );
}

function TableCell54() {
  return (
    <div className="absolute h-[81px] left-[1270.91px] top-0 w-[250.32px]" data-name="Table Cell">
      <Paragraph31 />
      <Paragraph32 />
    </div>
  );
}

function Icon32() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[20.84%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%_-5%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 11">
            <path d={svgPaths.pb85f580} id="Vector" stroke="var(--stroke-0, #59168B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[37.5%]" data-name="Vector">
        <div className="absolute inset-[-16.67%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6 6">
            <path d={svgPaths.p36446d40} id="Vector" stroke="var(--stroke-0, #59168B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button46() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon32 />
      </div>
    </div>
  );
}

function Icon33() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[12.5%]" data-name="Vector">
        <div className="absolute inset-[-5.56%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
            <path d={svgPaths.p73e95c0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.35%_8.35%_33.32%_33.32%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p47c19f0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button47() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon33 />
      </div>
    </div>
  );
}

function Icon34() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[33.33%_8.33%_8.33%_33.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p4611e00} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.33%_33.33%_33.33%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p26970a80} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button48() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon34 />
      </div>
    </div>
  );
}

function Icon35() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[8.32%_8.32%_8.33%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-5%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
            <path d={svgPaths.p185227c0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.95%_8.94%_45.48%_45.47%]" data-name="Vector">
        <div className="absolute inset-[-9.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9 9">
            <path d={svgPaths.p2db0e900} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button49() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon35 />
      </div>
    </div>
  );
}

function Container72() {
  return (
    <div className="absolute content-stretch flex gap-[8px] h-[16px] items-center left-[24px] top-[32.5px] w-[139.773px]" data-name="Container">
      <Button46 />
      <Button47 />
      <Button48 />
      <Button49 />
    </div>
  );
}

function TableCell55() {
  return (
    <div className="absolute h-[81px] left-[1521.23px] top-0 w-[187.773px]" data-name="Table Cell">
      <Container72 />
    </div>
  );
}

function TableRow7() {
  return (
    <div className="absolute border-[#e5e7eb] border-[0px_0px_1px] border-solid h-[81px] left-0 top-[485.5px] w-[1709px]" data-name="Table Row">
      <TableCell48 />
      <TableCell49 />
      <TableCell50 />
      <TableCell51 />
      <TableCell52 />
      <TableCell53 />
      <TableCell54 />
      <TableCell55 />
    </div>
  );
}

function Paragraph33() {
  return (
    <div className="h-[24px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[#101828] text-[16px] text-nowrap top-[-0.5px] tracking-[-0.3125px]">Maintenance Window Notification</p>
    </div>
  );
}

function Paragraph34() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#6a7282] text-[14px] text-nowrap top-[0.5px] tracking-[-0.1504px]">All Users</p>
    </div>
  );
}

function Container73() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[48px] items-start left-[24px] top-[16.5px] w-[285.758px]" data-name="Container">
      <Paragraph33 />
      <Paragraph34 />
    </div>
  );
}

function TableCell56() {
  return (
    <div className="absolute h-[81px] left-0 top-0 w-[333.758px]" data-name="Table Cell">
      <Container73 />
    </div>
  );
}

function Text72() {
  return (
    <div className="absolute bg-[#dbeafe] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[94.477px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#193cb8] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">notification</p>
    </div>
  );
}

function TableCell57() {
  return (
    <div className="absolute h-[81px] left-[333.76px] top-0 w-[197.578px]" data-name="Table Cell">
      <Text72 />
    </div>
  );
}

function Text73() {
  return (
    <div className="absolute bg-[#f3f4f6] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[77.25px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#1e2939] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">riverbed</p>
    </div>
  );
}

function TableCell58() {
  return (
    <div className="absolute h-[81px] left-[531.34px] top-0 w-[166.875px]" data-name="Table Cell">
      <Text73 />
    </div>
  );
}

function Text74() {
  return (
    <div className="absolute content-stretch flex h-[16.5px] items-start left-[24px] top-[33px] w-[88.086px]" data-name="Text">
      <p className="capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] not-italic relative shrink-0 text-[#101828] text-[14px] text-nowrap tracking-[-0.1504px]">non-intrusive</p>
    </div>
  );
}

function TableCell59() {
  return (
    <div className="absolute h-[81px] left-[698.21px] top-0 w-[166.875px]" data-name="Table Cell">
      <Text74 />
    </div>
  );
}

function Text75() {
  return (
    <div className="absolute bg-[#dbeafe] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[88.547px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#193cb8] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">scheduled</p>
    </div>
  );
}

function TableCell60() {
  return (
    <div className="absolute h-[81px] left-[865.09px] top-0 w-[180.945px]" data-name="Table Cell">
      <Text75 />
    </div>
  );
}

function Container74() {
  return <div className="bg-[#59168b] h-[8px] rounded-[1.67772e+07px] shrink-0 w-full" data-name="Container" />;
}

function Container75() {
  return (
    <div className="basis-0 bg-[#e5e7eb] grow h-[8px] min-h-px min-w-px relative rounded-[1.67772e+07px] shrink-0" data-name="Container">
      <div className="size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pl-0 pr-[147.398px] py-0 relative size-full">
          <Container74 />
        </div>
      </div>
    </div>
  );
}

function Text76() {
  return (
    <div className="h-[20px] relative shrink-0 w-[21.477px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#101828] text-[14px] top-[0.5px] tracking-[-0.1504px] w-[22px]">0%</p>
      </div>
    </div>
  );
}

function Container76() {
  return (
    <div className="content-stretch flex gap-[8px] h-[20px] items-center relative shrink-0 w-full" data-name="Container">
      <Container75 />
      <Text76 />
    </div>
  );
}

function Paragraph35() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#6a7282] text-[14px] top-[0.5px] tracking-[-0.1504px] w-[30px]">0 / 0</p>
    </div>
  );
}

function Container77() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[44px] items-start left-[24px] top-[18.5px] w-[176.875px]" data-name="Container">
      <Container76 />
      <Paragraph35 />
    </div>
  );
}

function TableCell61() {
  return (
    <div className="absolute h-[81px] left-[1046.03px] top-0 w-[224.875px]" data-name="Table Cell">
      <Container77 />
    </div>
  );
}

function Paragraph36() {
  return (
    <div className="absolute h-[20px] left-[24px] top-[30.5px] w-[202.32px]" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#101828] text-[14px] text-nowrap top-[0.5px] tracking-[-0.1504px]">System Notification</p>
    </div>
  );
}

function TableCell62() {
  return (
    <div className="absolute h-[81px] left-[1270.91px] top-0 w-[250.32px]" data-name="Table Cell">
      <Paragraph36 />
    </div>
  );
}

function Icon36() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[20.84%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%_-5%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 11">
            <path d={svgPaths.pb85f580} id="Vector" stroke="var(--stroke-0, #59168B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[37.5%]" data-name="Vector">
        <div className="absolute inset-[-16.67%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6 6">
            <path d={svgPaths.p36446d40} id="Vector" stroke="var(--stroke-0, #59168B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button50() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon36 />
      </div>
    </div>
  );
}

function Icon37() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[12.5%]" data-name="Vector">
        <div className="absolute inset-[-5.56%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
            <path d={svgPaths.p73e95c0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.35%_8.35%_33.32%_33.32%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p47c19f0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button51() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon37 />
      </div>
    </div>
  );
}

function Icon38() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[33.33%_8.33%_8.33%_33.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p4611e00} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.33%_33.33%_33.33%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p26970a80} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button52() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon38 />
      </div>
    </div>
  );
}

function Icon39() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[8.32%_8.32%_8.33%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-5%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
            <path d={svgPaths.p185227c0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.95%_8.94%_45.48%_45.47%]" data-name="Vector">
        <div className="absolute inset-[-9.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9 9">
            <path d={svgPaths.p2db0e900} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button53() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon39 />
      </div>
    </div>
  );
}

function Container78() {
  return (
    <div className="absolute content-stretch flex gap-[8px] h-[16px] items-center left-[24px] top-[32.5px] w-[139.773px]" data-name="Container">
      <Button50 />
      <Button51 />
      <Button52 />
      <Button53 />
    </div>
  );
}

function TableCell63() {
  return (
    <div className="absolute h-[81px] left-[1521.23px] top-0 w-[187.773px]" data-name="Table Cell">
      <Container78 />
    </div>
  );
}

function TableRow8() {
  return (
    <div className="absolute border-[#e5e7eb] border-[0px_0px_1px] border-solid h-[81px] left-0 top-[566.5px] w-[1709px]" data-name="Table Row">
      <TableCell56 />
      <TableCell57 />
      <TableCell58 />
      <TableCell59 />
      <TableCell60 />
      <TableCell61 />
      <TableCell62 />
      <TableCell63 />
    </div>
  );
}

function Paragraph37() {
  return (
    <div className="h-[24px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[#101828] text-[16px] text-nowrap top-[-0.5px] tracking-[-0.3125px]">Password Expiry Reminder</p>
    </div>
  );
}

function Paragraph38() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#6a7282] text-[14px] text-nowrap top-[0.5px] tracking-[-0.1504px]">Finance Dept</p>
    </div>
  );
}

function Container79() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[48px] items-start left-[24px] top-[16.5px] w-[285.758px]" data-name="Container">
      <Paragraph37 />
      <Paragraph38 />
    </div>
  );
}

function TableCell64() {
  return (
    <div className="absolute h-[81px] left-0 top-0 w-[333.758px]" data-name="Table Cell">
      <Container79 />
    </div>
  );
}

function Text77() {
  return (
    <div className="absolute bg-[#fef9c2] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[81.477px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#894b00] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">reminder</p>
    </div>
  );
}

function TableCell65() {
  return (
    <div className="absolute h-[81px] left-[333.76px] top-0 w-[197.578px]" data-name="Table Cell">
      <Text77 />
    </div>
  );
}

function Text78() {
  return (
    <div className="absolute bg-[#cbfbf1] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[54.5px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#005f5a] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">email</p>
    </div>
  );
}

function TableCell66() {
  return (
    <div className="absolute h-[81px] left-[531.34px] top-0 w-[166.875px]" data-name="Table Cell">
      <Text78 />
    </div>
  );
}

function Text79() {
  return (
    <div className="absolute content-stretch flex h-[16.5px] items-start left-[24px] top-[33px] w-[88.086px]" data-name="Text">
      <p className="capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] not-italic relative shrink-0 text-[#101828] text-[14px] text-nowrap tracking-[-0.1504px]">non-intrusive</p>
    </div>
  );
}

function TableCell67() {
  return (
    <div className="absolute h-[81px] left-[698.21px] top-0 w-[166.875px]" data-name="Table Cell">
      <Text79 />
    </div>
  );
}

function Text80() {
  return (
    <div className="absolute bg-[#dcfce7] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[59.953px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#016630] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">active</p>
    </div>
  );
}

function TableCell68() {
  return (
    <div className="absolute h-[81px] left-[865.09px] top-0 w-[180.945px]" data-name="Table Cell">
      <Text80 />
    </div>
  );
}

function Container80() {
  return <div className="bg-[#59168b] h-[8px] rounded-[1.67772e+07px] shrink-0 w-full" data-name="Container" />;
}

function Container81() {
  return (
    <div className="basis-0 bg-[#e5e7eb] grow h-[8px] min-h-px min-w-px relative rounded-[1.67772e+07px] shrink-0" data-name="Container">
      <div className="size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pl-0 pr-[25.023px] py-0 relative size-full">
          <Container80 />
        </div>
      </div>
    </div>
  );
}

function Text81() {
  return (
    <div className="h-[20px] relative shrink-0 w-[29.898px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#101828] text-[14px] top-[0.5px] tracking-[-0.1504px] w-[30px]">82%</p>
      </div>
    </div>
  );
}

function Container82() {
  return (
    <div className="content-stretch flex gap-[8px] h-[20px] items-center relative shrink-0 w-full" data-name="Container">
      <Container81 />
      <Text81 />
    </div>
  );
}

function Paragraph39() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#6a7282] text-[14px] top-[0.5px] tracking-[-0.1504px] w-[53px]">98 / 120</p>
    </div>
  );
}

function Container83() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[44px] items-start left-[24px] top-[18.5px] w-[176.875px]" data-name="Container">
      <Container82 />
      <Paragraph39 />
    </div>
  );
}

function TableCell69() {
  return (
    <div className="absolute h-[81px] left-[1046.03px] top-0 w-[224.875px]" data-name="Table Cell">
      <Container83 />
    </div>
  );
}

function Paragraph40() {
  return (
    <div className="absolute h-[20px] left-[24px] top-[30.5px] w-[202.32px]" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#101828] text-[14px] text-nowrap top-[0.5px] tracking-[-0.1504px]">Scheduled Reminder</p>
    </div>
  );
}

function TableCell70() {
  return (
    <div className="absolute h-[81px] left-[1270.91px] top-0 w-[250.32px]" data-name="Table Cell">
      <Paragraph40 />
    </div>
  );
}

function Icon40() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[20.84%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%_-5%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 11">
            <path d={svgPaths.pb85f580} id="Vector" stroke="var(--stroke-0, #59168B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[37.5%]" data-name="Vector">
        <div className="absolute inset-[-16.67%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6 6">
            <path d={svgPaths.p36446d40} id="Vector" stroke="var(--stroke-0, #59168B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button54() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon40 />
      </div>
    </div>
  );
}

function Icon41() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[12.5%]" data-name="Vector">
        <div className="absolute inset-[-5.56%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
            <path d={svgPaths.p73e95c0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.35%_8.35%_33.32%_33.32%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p47c19f0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button55() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon41 />
      </div>
    </div>
  );
}

function Icon42() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[33.33%_8.33%_8.33%_33.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p4611e00} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.33%_33.33%_33.33%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p26970a80} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button56() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon42 />
      </div>
    </div>
  );
}

function Icon43() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[8.32%_8.32%_8.33%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-5%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
            <path d={svgPaths.p185227c0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.95%_8.94%_45.48%_45.47%]" data-name="Vector">
        <div className="absolute inset-[-9.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9 9">
            <path d={svgPaths.p2db0e900} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button57() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon43 />
      </div>
    </div>
  );
}

function Container84() {
  return (
    <div className="absolute content-stretch flex gap-[8px] h-[16px] items-center left-[24px] top-[32.5px] w-[139.773px]" data-name="Container">
      <Button54 />
      <Button55 />
      <Button56 />
      <Button57 />
    </div>
  );
}

function TableCell71() {
  return (
    <div className="absolute h-[81px] left-[1521.23px] top-0 w-[187.773px]" data-name="Table Cell">
      <Container84 />
    </div>
  );
}

function TableRow9() {
  return (
    <div className="absolute border-[#e5e7eb] border-[0px_0px_1px] border-solid h-[81px] left-0 top-[647.5px] w-[1709px]" data-name="Table Row">
      <TableCell64 />
      <TableCell65 />
      <TableCell66 />
      <TableCell67 />
      <TableCell68 />
      <TableCell69 />
      <TableCell70 />
      <TableCell71 />
    </div>
  );
}

function Paragraph41() {
  return (
    <div className="h-[24px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[#101828] text-[16px] text-nowrap top-[-0.5px] tracking-[-0.3125px]">Help Desk Self-Service Portal</p>
    </div>
  );
}

function Paragraph42() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#6a7282] text-[14px] text-nowrap top-[0.5px] tracking-[-0.1504px]">All Employees</p>
    </div>
  );
}

function Container85() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[48px] items-start left-[24px] top-[16.5px] w-[285.758px]" data-name="Container">
      <Paragraph41 />
      <Paragraph42 />
    </div>
  );
}

function TableCell72() {
  return (
    <div className="absolute h-[81px] left-0 top-0 w-[333.758px]" data-name="Table Cell">
      <Container85 />
    </div>
  );
}

function Text82() {
  return (
    <div className="absolute bg-[#dcfce7] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[99.188px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#016630] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">self-service</p>
    </div>
  );
}

function TableCell73() {
  return (
    <div className="absolute h-[81px] left-[333.76px] top-0 w-[197.578px]" data-name="Table Cell">
      <Text82 />
    </div>
  );
}

function Text83() {
  return (
    <div className="absolute bg-[#f3f4f6] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[77.25px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#1e2939] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">riverbed</p>
    </div>
  );
}

function TableCell74() {
  return (
    <div className="absolute h-[81px] left-[531.34px] top-0 w-[166.875px]" data-name="Table Cell">
      <Text83 />
    </div>
  );
}

function Text84() {
  return (
    <div className="absolute content-stretch flex h-[16.5px] items-start left-[24px] top-[33px] w-[88.086px]" data-name="Text">
      <p className="capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] not-italic relative shrink-0 text-[#101828] text-[14px] text-nowrap tracking-[-0.1504px]">non-intrusive</p>
    </div>
  );
}

function TableCell75() {
  return (
    <div className="absolute h-[81px] left-[698.21px] top-0 w-[166.875px]" data-name="Table Cell">
      <Text84 />
    </div>
  );
}

function Text85() {
  return (
    <div className="absolute bg-[#dcfce7] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[59.953px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#016630] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">active</p>
    </div>
  );
}

function TableCell76() {
  return (
    <div className="absolute h-[81px] left-[865.09px] top-0 w-[180.945px]" data-name="Table Cell">
      <Text85 />
    </div>
  );
}

function Container86() {
  return <div className="bg-[#59168b] h-[8px] rounded-[1.67772e+07px] shrink-0 w-full" data-name="Container" />;
}

function Container87() {
  return (
    <div className="basis-0 bg-[#e5e7eb] grow h-[8px] min-h-px min-w-px relative rounded-[1.67772e+07px] shrink-0" data-name="Container">
      <div className="size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pl-0 pr-[34.977px] py-0 relative size-full">
          <Container86 />
        </div>
      </div>
    </div>
  );
}

function Text86() {
  return (
    <div className="h-[20px] relative shrink-0 w-[28.992px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#101828] text-[14px] top-[0.5px] tracking-[-0.1504px] w-[29px]">75%</p>
      </div>
    </div>
  );
}

function Container88() {
  return (
    <div className="content-stretch flex gap-[8px] h-[20px] items-center relative shrink-0 w-full" data-name="Container">
      <Container87 />
      <Text86 />
    </div>
  );
}

function Paragraph43() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#6a7282] text-[14px] top-[0.5px] tracking-[-0.1504px] w-[63px]">423 / 567</p>
    </div>
  );
}

function Container89() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[44px] items-start left-[24px] top-[18.5px] w-[176.875px]" data-name="Container">
      <Container88 />
      <Paragraph43 />
    </div>
  );
}

function TableCell77() {
  return (
    <div className="absolute h-[81px] left-[1046.03px] top-0 w-[224.875px]" data-name="Table Cell">
      <Container89 />
    </div>
  );
}

function Paragraph44() {
  return (
    <div className="absolute h-[20px] left-[24px] top-[20.5px] w-[202.32px]" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#101828] text-[14px] text-nowrap top-[0.5px] tracking-[-0.1504px]">Interactive Portal</p>
    </div>
  );
}

function Paragraph45() {
  return (
    <div className="absolute h-[16px] left-[24px] top-[44.5px] w-[202.32px]" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16px] left-0 not-italic text-[#59168b] text-[12px] text-nowrap top-px">Interactive Flow</p>
    </div>
  );
}

function TableCell78() {
  return (
    <div className="absolute h-[81px] left-[1270.91px] top-0 w-[250.32px]" data-name="Table Cell">
      <Paragraph44 />
      <Paragraph45 />
    </div>
  );
}

function Icon44() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[20.84%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%_-5%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 11">
            <path d={svgPaths.pb85f580} id="Vector" stroke="var(--stroke-0, #59168B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[37.5%]" data-name="Vector">
        <div className="absolute inset-[-16.67%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6 6">
            <path d={svgPaths.p36446d40} id="Vector" stroke="var(--stroke-0, #59168B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button58() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon44 />
      </div>
    </div>
  );
}

function Icon45() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[12.5%]" data-name="Vector">
        <div className="absolute inset-[-5.56%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
            <path d={svgPaths.p73e95c0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.35%_8.35%_33.32%_33.32%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p47c19f0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button59() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon45 />
      </div>
    </div>
  );
}

function Icon46() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[33.33%_8.33%_8.33%_33.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p4611e00} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.33%_33.33%_33.33%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p26970a80} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button60() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon46 />
      </div>
    </div>
  );
}

function Icon47() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[8.32%_8.32%_8.33%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-5%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
            <path d={svgPaths.p185227c0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.95%_8.94%_45.48%_45.47%]" data-name="Vector">
        <div className="absolute inset-[-9.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9 9">
            <path d={svgPaths.p2db0e900} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button61() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon47 />
      </div>
    </div>
  );
}

function Container90() {
  return (
    <div className="absolute content-stretch flex gap-[8px] h-[16px] items-center left-[24px] top-[32.5px] w-[139.773px]" data-name="Container">
      <Button58 />
      <Button59 />
      <Button60 />
      <Button61 />
    </div>
  );
}

function TableCell79() {
  return (
    <div className="absolute h-[81px] left-[1521.23px] top-0 w-[187.773px]" data-name="Table Cell">
      <Container90 />
    </div>
  );
}

function TableRow10() {
  return (
    <div className="absolute border-[#e5e7eb] border-[0px_0px_1px] border-solid h-[81px] left-0 top-[728.5px] w-[1709px]" data-name="Table Row">
      <TableCell72 />
      <TableCell73 />
      <TableCell74 />
      <TableCell75 />
      <TableCell76 />
      <TableCell77 />
      <TableCell78 />
      <TableCell79 />
    </div>
  );
}

function Paragraph46() {
  return (
    <div className="h-[24px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[#101828] text-[16px] text-nowrap top-[-0.5px] tracking-[-0.3125px]">IT Equipment Feedback Survey</p>
    </div>
  );
}

function Paragraph47() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#6a7282] text-[14px] text-nowrap top-[0.5px] tracking-[-0.1504px]">Marketing Dept</p>
    </div>
  );
}

function Container91() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[48px] items-start left-[24px] top-[16.5px] w-[285.758px]" data-name="Container">
      <Paragraph46 />
      <Paragraph47 />
    </div>
  );
}

function TableCell80() {
  return (
    <div className="absolute h-[81px] left-0 top-0 w-[333.758px]" data-name="Table Cell">
      <Container91 />
    </div>
  );
}

function Text87() {
  return (
    <div className="absolute bg-[#f3e8ff] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[64.367px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#6e11b0] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">survey</p>
    </div>
  );
}

function TableCell81() {
  return (
    <div className="absolute h-[81px] left-[333.76px] top-0 w-[197.578px]" data-name="Table Cell">
      <Text87 />
    </div>
  );
}

function Text88() {
  return (
    <div className="absolute bg-[#e0e7ff] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[61.992px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#372aac] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">teams</p>
    </div>
  );
}

function TableCell82() {
  return (
    <div className="absolute h-[81px] left-[531.34px] top-0 w-[166.875px]" data-name="Table Cell">
      <Text88 />
    </div>
  );
}

function Text89() {
  return (
    <div className="absolute content-stretch flex h-[16.5px] items-start left-[24px] top-[33px] w-[55.25px]" data-name="Text">
      <p className="capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] not-italic relative shrink-0 text-[#101828] text-[14px] text-nowrap tracking-[-0.1504px]">intrusive</p>
    </div>
  );
}

function TableCell83() {
  return (
    <div className="absolute h-[81px] left-[698.21px] top-0 w-[166.875px]" data-name="Table Cell">
      <Text89 />
    </div>
  );
}

function Text90() {
  return (
    <div className="absolute bg-[#f3e8ff] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[90.789px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#6e11b0] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">completed</p>
    </div>
  );
}

function TableCell84() {
  return (
    <div className="absolute h-[81px] left-[865.09px] top-0 w-[180.945px]" data-name="Table Cell">
      <Text90 />
    </div>
  );
}

function Container92() {
  return <div className="bg-[#59168b] h-[8px] rounded-[1.67772e+07px] shrink-0 w-full" data-name="Container" />;
}

function Container93() {
  return (
    <div className="basis-0 bg-[#e5e7eb] grow h-[8px] min-h-px min-w-px relative rounded-[1.67772e+07px] shrink-0" data-name="Container">
      <div className="size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pl-0 pr-[20.82px] py-0 relative size-full">
          <Container92 />
        </div>
      </div>
    </div>
  );
}

function Text91() {
  return (
    <div className="h-[20px] relative shrink-0 w-[30.102px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#101828] text-[14px] top-[0.5px] tracking-[-0.1504px] w-[31px]">85%</p>
      </div>
    </div>
  );
}

function Container94() {
  return (
    <div className="content-stretch flex gap-[8px] h-[20px] items-center relative shrink-0 w-full" data-name="Container">
      <Container93 />
      <Text91 />
    </div>
  );
}

function Paragraph48() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#6a7282] text-[14px] top-[0.5px] tracking-[-0.1504px] w-[46px]">76 / 89</p>
    </div>
  );
}

function Container95() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[44px] items-start left-[24px] top-[18.5px] w-[176.875px]" data-name="Container">
      <Container94 />
      <Paragraph48 />
    </div>
  );
}

function TableCell85() {
  return (
    <div className="absolute h-[81px] left-[1046.03px] top-0 w-[224.875px]" data-name="Table Cell">
      <Container95 />
    </div>
  );
}

function Paragraph49() {
  return (
    <div className="absolute h-[20px] left-[24px] top-[20.5px] w-[202.32px]" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#101828] text-[14px] text-nowrap top-[0.5px] tracking-[-0.1504px]">Quick Poll</p>
    </div>
  );
}

function Paragraph50() {
  return (
    <div className="absolute h-[16px] left-[24px] top-[44.5px] w-[202.32px]" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16px] left-0 not-italic text-[#59168b] text-[12px] text-nowrap top-px">Interactive Flow</p>
    </div>
  );
}

function TableCell86() {
  return (
    <div className="absolute h-[81px] left-[1270.91px] top-0 w-[250.32px]" data-name="Table Cell">
      <Paragraph49 />
      <Paragraph50 />
    </div>
  );
}

function Icon48() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[20.84%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%_-5%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 11">
            <path d={svgPaths.pb85f580} id="Vector" stroke="var(--stroke-0, #59168B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[37.5%]" data-name="Vector">
        <div className="absolute inset-[-16.67%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6 6">
            <path d={svgPaths.p36446d40} id="Vector" stroke="var(--stroke-0, #59168B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button62() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon48 />
      </div>
    </div>
  );
}

function Icon49() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[12.5%]" data-name="Vector">
        <div className="absolute inset-[-5.56%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
            <path d={svgPaths.p73e95c0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.35%_8.35%_33.32%_33.32%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p47c19f0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button63() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon49 />
      </div>
    </div>
  );
}

function Icon50() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[33.33%_8.33%_8.33%_33.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p4611e00} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.33%_33.33%_33.33%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p26970a80} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button64() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon50 />
      </div>
    </div>
  );
}

function Icon51() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[8.32%_8.32%_8.33%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-5%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
            <path d={svgPaths.p185227c0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.95%_8.94%_45.48%_45.47%]" data-name="Vector">
        <div className="absolute inset-[-9.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9 9">
            <path d={svgPaths.p2db0e900} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button65() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon51 />
      </div>
    </div>
  );
}

function Container96() {
  return (
    <div className="absolute content-stretch flex gap-[8px] h-[16px] items-center left-[24px] top-[32.5px] w-[139.773px]" data-name="Container">
      <Button62 />
      <Button63 />
      <Button64 />
      <Button65 />
    </div>
  );
}

function TableCell87() {
  return (
    <div className="absolute h-[81px] left-[1521.23px] top-0 w-[187.773px]" data-name="Table Cell">
      <Container96 />
    </div>
  );
}

function TableRow11() {
  return (
    <div className="absolute border-[#e5e7eb] border-[0px_0px_1px] border-solid h-[81px] left-0 top-[809.5px] w-[1709px]" data-name="Table Row">
      <TableCell80 />
      <TableCell81 />
      <TableCell82 />
      <TableCell83 />
      <TableCell84 />
      <TableCell85 />
      <TableCell86 />
      <TableCell87 />
    </div>
  );
}

function Paragraph51() {
  return (
    <div className="h-[24px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[#101828] text-[16px] text-nowrap top-[-0.5px] tracking-[-0.3125px]">Policy Acceptance Confirmation</p>
    </div>
  );
}

function Paragraph52() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#6a7282] text-[14px] text-nowrap top-[0.5px] tracking-[-0.1504px]">New Hires</p>
    </div>
  );
}

function Container97() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[48px] items-start left-[24px] top-[16.5px] w-[285.758px]" data-name="Container">
      <Paragraph51 />
      <Paragraph52 />
    </div>
  );
}

function TableCell88() {
  return (
    <div className="absolute h-[81px] left-0 top-0 w-[333.758px]" data-name="Table Cell">
      <Container97 />
    </div>
  );
}

function Text92() {
  return (
    <div className="absolute bg-[#ffedd4] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[103.547px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#9f2d00] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">confirmation</p>
    </div>
  );
}

function TableCell89() {
  return (
    <div className="absolute h-[81px] left-[333.76px] top-0 w-[197.578px]" data-name="Table Cell">
      <Text92 />
    </div>
  );
}

function Text93() {
  return (
    <div className="absolute bg-[#cbfbf1] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[54.5px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#005f5a] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">email</p>
    </div>
  );
}

function TableCell90() {
  return (
    <div className="absolute h-[81px] left-[531.34px] top-0 w-[166.875px]" data-name="Table Cell">
      <Text93 />
    </div>
  );
}

function Text94() {
  return (
    <div className="absolute content-stretch flex h-[16.5px] items-start left-[24px] top-[33px] w-[55.25px]" data-name="Text">
      <p className="capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] not-italic relative shrink-0 text-[#101828] text-[14px] text-nowrap tracking-[-0.1504px]">intrusive</p>
    </div>
  );
}

function TableCell91() {
  return (
    <div className="absolute h-[81px] left-[698.21px] top-0 w-[166.875px]" data-name="Table Cell">
      <Text94 />
    </div>
  );
}

function Text95() {
  return (
    <div className="absolute bg-[#dcfce7] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[59.953px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#016630] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">active</p>
    </div>
  );
}

function TableCell92() {
  return (
    <div className="absolute h-[81px] left-[865.09px] top-0 w-[180.945px]" data-name="Table Cell">
      <Text95 />
    </div>
  );
}

function Container98() {
  return <div className="bg-[#59168b] h-[8px] rounded-[1.67772e+07px] shrink-0 w-full" data-name="Container" />;
}

function Container99() {
  return (
    <div className="basis-0 bg-[#e5e7eb] grow h-[8px] min-h-px min-w-px relative rounded-[1.67772e+07px] shrink-0" data-name="Container">
      <div className="size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pl-0 pr-[30.727px] py-0 relative size-full">
          <Container98 />
        </div>
      </div>
    </div>
  );
}

function Text96() {
  return (
    <div className="h-[20px] relative shrink-0 w-[29.211px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#101828] text-[14px] top-[0.5px] tracking-[-0.1504px] w-[30px]">78%</p>
      </div>
    </div>
  );
}

function Container100() {
  return (
    <div className="content-stretch flex gap-[8px] h-[20px] items-center relative shrink-0 w-full" data-name="Container">
      <Container99 />
      <Text96 />
    </div>
  );
}

function Paragraph53() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#6a7282] text-[14px] top-[0.5px] tracking-[-0.1504px] w-[44px]">18 / 23</p>
    </div>
  );
}

function Container101() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[44px] items-start left-[24px] top-[18.5px] w-[176.875px]" data-name="Container">
      <Container100 />
      <Paragraph53 />
    </div>
  );
}

function TableCell93() {
  return (
    <div className="absolute h-[81px] left-[1046.03px] top-0 w-[224.875px]" data-name="Table Cell">
      <Container101 />
    </div>
  );
}

function Paragraph54() {
  return (
    <div className="absolute h-[20px] left-[24px] top-[30.5px] w-[202.32px]" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#101828] text-[14px] text-nowrap top-[0.5px] tracking-[-0.1504px]">Legal Confirmation</p>
    </div>
  );
}

function TableCell94() {
  return (
    <div className="absolute h-[81px] left-[1270.91px] top-0 w-[250.32px]" data-name="Table Cell">
      <Paragraph54 />
    </div>
  );
}

function Icon52() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[20.84%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%_-5%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 11">
            <path d={svgPaths.pb85f580} id="Vector" stroke="var(--stroke-0, #59168B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[37.5%]" data-name="Vector">
        <div className="absolute inset-[-16.67%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6 6">
            <path d={svgPaths.p36446d40} id="Vector" stroke="var(--stroke-0, #59168B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button66() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon52 />
      </div>
    </div>
  );
}

function Icon53() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[12.5%]" data-name="Vector">
        <div className="absolute inset-[-5.56%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
            <path d={svgPaths.p73e95c0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.35%_8.35%_33.32%_33.32%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p47c19f0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button67() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon53 />
      </div>
    </div>
  );
}

function Icon54() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[33.33%_8.33%_8.33%_33.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p4611e00} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.33%_33.33%_33.33%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p26970a80} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button68() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon54 />
      </div>
    </div>
  );
}

function Icon55() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[8.32%_8.32%_8.33%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-5%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
            <path d={svgPaths.p185227c0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.95%_8.94%_45.48%_45.47%]" data-name="Vector">
        <div className="absolute inset-[-9.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9 9">
            <path d={svgPaths.p2db0e900} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button69() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon55 />
      </div>
    </div>
  );
}

function Container102() {
  return (
    <div className="absolute content-stretch flex gap-[8px] h-[16px] items-center left-[24px] top-[32.5px] w-[139.773px]" data-name="Container">
      <Button66 />
      <Button67 />
      <Button68 />
      <Button69 />
    </div>
  );
}

function TableCell95() {
  return (
    <div className="absolute h-[81px] left-[1521.23px] top-0 w-[187.773px]" data-name="Table Cell">
      <Container102 />
    </div>
  );
}

function TableRow12() {
  return (
    <div className="absolute border-[#e5e7eb] border-[0px_0px_1px] border-solid h-[81px] left-0 top-[890.5px] w-[1709px]" data-name="Table Row">
      <TableCell88 />
      <TableCell89 />
      <TableCell90 />
      <TableCell91 />
      <TableCell92 />
      <TableCell93 />
      <TableCell94 />
      <TableCell95 />
    </div>
  );
}

function Paragraph55() {
  return (
    <div className="h-[24px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[#101828] text-[16px] text-nowrap top-[-0.5px] tracking-[-0.3125px]">System Update Complete</p>
    </div>
  );
}

function Paragraph56() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#6a7282] text-[14px] text-nowrap top-[0.5px] tracking-[-0.1504px]">Development Team</p>
    </div>
  );
}

function Container103() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[48px] items-start left-[24px] top-[16.5px] w-[285.758px]" data-name="Container">
      <Paragraph55 />
      <Paragraph56 />
    </div>
  );
}

function TableCell96() {
  return (
    <div className="absolute h-[81px] left-0 top-0 w-[333.758px]" data-name="Table Cell">
      <Container103 />
    </div>
  );
}

function Text97() {
  return (
    <div className="absolute bg-[#dbeafe] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[94.477px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#193cb8] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">notification</p>
    </div>
  );
}

function TableCell97() {
  return (
    <div className="absolute h-[81px] left-[333.76px] top-0 w-[197.578px]" data-name="Table Cell">
      <Text97 />
    </div>
  );
}

function Text98() {
  return (
    <div className="absolute bg-[#fce7f3] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[54.875px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#a3004c] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">slack</p>
    </div>
  );
}

function TableCell98() {
  return (
    <div className="absolute h-[81px] left-[531.34px] top-0 w-[166.875px]" data-name="Table Cell">
      <Text98 />
    </div>
  );
}

function Text99() {
  return (
    <div className="absolute content-stretch flex h-[16.5px] items-start left-[24px] top-[33px] w-[88.086px]" data-name="Text">
      <p className="capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] not-italic relative shrink-0 text-[#101828] text-[14px] text-nowrap tracking-[-0.1504px]">non-intrusive</p>
    </div>
  );
}

function TableCell99() {
  return (
    <div className="absolute h-[81px] left-[698.21px] top-0 w-[166.875px]" data-name="Table Cell">
      <Text99 />
    </div>
  );
}

function Text100() {
  return (
    <div className="absolute bg-[#f3e8ff] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[90.789px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#6e11b0] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">completed</p>
    </div>
  );
}

function TableCell100() {
  return (
    <div className="absolute h-[81px] left-[865.09px] top-0 w-[180.945px]" data-name="Table Cell">
      <Text100 />
    </div>
  );
}

function Container104() {
  return <div className="bg-[#59168b] h-[8px] rounded-[1.67772e+07px] shrink-0 w-full" data-name="Container" />;
}

function Container105() {
  return (
    <div className="basis-0 bg-[#e5e7eb] grow h-[8px] min-h-px min-w-px relative rounded-[1.67772e+07px] shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Container104 />
      </div>
    </div>
  );
}

function Text101() {
  return (
    <div className="h-[20px] relative shrink-0 w-[36.484px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#101828] text-[14px] top-[0.5px] tracking-[-0.1504px] w-[37px]">100%</p>
      </div>
    </div>
  );
}

function Container106() {
  return (
    <div className="content-stretch flex gap-[8px] h-[20px] items-center relative shrink-0 w-full" data-name="Container">
      <Container105 />
      <Text101 />
    </div>
  );
}

function Paragraph57() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#6a7282] text-[14px] top-[0.5px] tracking-[-0.1504px] w-[45px]">67 / 67</p>
    </div>
  );
}

function Container107() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[44px] items-start left-[24px] top-[18.5px] w-[176.875px]" data-name="Container">
      <Container106 />
      <Paragraph57 />
    </div>
  );
}

function TableCell101() {
  return (
    <div className="absolute h-[81px] left-[1046.03px] top-0 w-[224.875px]" data-name="Table Cell">
      <Container107 />
    </div>
  );
}

function Paragraph58() {
  return (
    <div className="absolute h-[20px] left-[24px] top-[30.5px] w-[202.32px]" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#101828] text-[14px] text-nowrap top-[0.5px] tracking-[-0.1504px]">Success Message</p>
    </div>
  );
}

function TableCell102() {
  return (
    <div className="absolute h-[81px] left-[1270.91px] top-0 w-[250.32px]" data-name="Table Cell">
      <Paragraph58 />
    </div>
  );
}

function Icon56() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[20.84%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%_-5%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 11">
            <path d={svgPaths.pb85f580} id="Vector" stroke="var(--stroke-0, #59168B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[37.5%]" data-name="Vector">
        <div className="absolute inset-[-16.67%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6 6">
            <path d={svgPaths.p36446d40} id="Vector" stroke="var(--stroke-0, #59168B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button70() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon56 />
      </div>
    </div>
  );
}

function Icon57() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[12.5%]" data-name="Vector">
        <div className="absolute inset-[-5.56%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
            <path d={svgPaths.p73e95c0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.35%_8.35%_33.32%_33.32%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p47c19f0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button71() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon57 />
      </div>
    </div>
  );
}

function Icon58() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[33.33%_8.33%_8.33%_33.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p4611e00} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.33%_33.33%_33.33%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p26970a80} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button72() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon58 />
      </div>
    </div>
  );
}

function Icon59() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[8.32%_8.32%_8.33%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-5%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
            <path d={svgPaths.p185227c0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.95%_8.94%_45.48%_45.47%]" data-name="Vector">
        <div className="absolute inset-[-9.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9 9">
            <path d={svgPaths.p2db0e900} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button73() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon59 />
      </div>
    </div>
  );
}

function Container108() {
  return (
    <div className="absolute content-stretch flex gap-[8px] h-[16px] items-center left-[24px] top-[32.5px] w-[139.773px]" data-name="Container">
      <Button70 />
      <Button71 />
      <Button72 />
      <Button73 />
    </div>
  );
}

function TableCell103() {
  return (
    <div className="absolute h-[81px] left-[1521.23px] top-0 w-[187.773px]" data-name="Table Cell">
      <Container108 />
    </div>
  );
}

function TableRow13() {
  return (
    <div className="absolute border-[#e5e7eb] border-[0px_0px_1px] border-solid h-[81px] left-0 top-[971.5px] w-[1709px]" data-name="Table Row">
      <TableCell96 />
      <TableCell97 />
      <TableCell98 />
      <TableCell99 />
      <TableCell100 />
      <TableCell101 />
      <TableCell102 />
      <TableCell103 />
    </div>
  );
}

function Paragraph59() {
  return (
    <div className="h-[24px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[#101828] text-[16px] text-nowrap top-[-0.5px] tracking-[-0.3125px]">Software License Renewal Reminder</p>
    </div>
  );
}

function Paragraph60() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#6a7282] text-[14px] text-nowrap top-[0.5px] tracking-[-0.1504px]">IT Managers</p>
    </div>
  );
}

function Container109() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[48px] items-start left-[24px] top-[16.5px] w-[285.758px]" data-name="Container">
      <Paragraph59 />
      <Paragraph60 />
    </div>
  );
}

function TableCell104() {
  return (
    <div className="absolute h-[81px] left-0 top-0 w-[333.758px]" data-name="Table Cell">
      <Container109 />
    </div>
  );
}

function Text102() {
  return (
    <div className="absolute bg-[#fef9c2] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[81.477px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#894b00] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">reminder</p>
    </div>
  );
}

function TableCell105() {
  return (
    <div className="absolute h-[81px] left-[333.76px] top-0 w-[197.578px]" data-name="Table Cell">
      <Text102 />
    </div>
  );
}

function Text103() {
  return (
    <div className="absolute bg-[#e0e7ff] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[61.992px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#372aac] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">teams</p>
    </div>
  );
}

function TableCell106() {
  return (
    <div className="absolute h-[81px] left-[531.34px] top-0 w-[166.875px]" data-name="Table Cell">
      <Text103 />
    </div>
  );
}

function Text104() {
  return (
    <div className="absolute content-stretch flex h-[16.5px] items-start left-[24px] top-[33px] w-[55.25px]" data-name="Text">
      <p className="capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] not-italic relative shrink-0 text-[#101828] text-[14px] text-nowrap tracking-[-0.1504px]">intrusive</p>
    </div>
  );
}

function TableCell107() {
  return (
    <div className="absolute h-[81px] left-[698.21px] top-0 w-[166.875px]" data-name="Table Cell">
      <Text104 />
    </div>
  );
}

function Text105() {
  return (
    <div className="absolute bg-[#dcfce7] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[59.953px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#016630] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">active</p>
    </div>
  );
}

function TableCell108() {
  return (
    <div className="absolute h-[81px] left-[865.09px] top-0 w-[180.945px]" data-name="Table Cell">
      <Text105 />
    </div>
  );
}

function Container110() {
  return <div className="bg-[#59168b] h-[8px] rounded-[1.67772e+07px] shrink-0 w-full" data-name="Container" />;
}

function Container111() {
  return (
    <div className="basis-0 bg-[#e5e7eb] grow h-[8px] min-h-px min-w-px relative rounded-[1.67772e+07px] shrink-0" data-name="Container">
      <div className="size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pl-0 pr-[23.57px] py-0 relative size-full">
          <Container110 />
        </div>
      </div>
    </div>
  );
}

function Text106() {
  return (
    <div className="h-[20px] relative shrink-0 w-[30.227px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#101828] text-[14px] top-[0.5px] tracking-[-0.1504px] w-[31px]">83%</p>
      </div>
    </div>
  );
}

function Container112() {
  return (
    <div className="content-stretch flex gap-[8px] h-[20px] items-center relative shrink-0 w-full" data-name="Container">
      <Container111 />
      <Text106 />
    </div>
  );
}

function Paragraph61() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#6a7282] text-[14px] top-[0.5px] tracking-[-0.1504px] w-[42px]">10 / 12</p>
    </div>
  );
}

function Container113() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[44px] items-start left-[24px] top-[18.5px] w-[176.875px]" data-name="Container">
      <Container112 />
      <Paragraph61 />
    </div>
  );
}

function TableCell109() {
  return (
    <div className="absolute h-[81px] left-[1046.03px] top-0 w-[224.875px]" data-name="Table Cell">
      <Container113 />
    </div>
  );
}

function Paragraph62() {
  return (
    <div className="absolute h-[20px] left-[24px] top-[30.5px] w-[202.32px]" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#101828] text-[14px] text-nowrap top-[0.5px] tracking-[-0.1504px]">Urgent Reminder</p>
    </div>
  );
}

function TableCell110() {
  return (
    <div className="absolute h-[81px] left-[1270.91px] top-0 w-[250.32px]" data-name="Table Cell">
      <Paragraph62 />
    </div>
  );
}

function Icon60() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[20.84%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%_-5%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 11">
            <path d={svgPaths.pb85f580} id="Vector" stroke="var(--stroke-0, #59168B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[37.5%]" data-name="Vector">
        <div className="absolute inset-[-16.67%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6 6">
            <path d={svgPaths.p36446d40} id="Vector" stroke="var(--stroke-0, #59168B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button74() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon60 />
      </div>
    </div>
  );
}

function Icon61() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[12.5%]" data-name="Vector">
        <div className="absolute inset-[-5.56%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
            <path d={svgPaths.p73e95c0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.35%_8.35%_33.32%_33.32%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p47c19f0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button75() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon61 />
      </div>
    </div>
  );
}

function Icon62() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[33.33%_8.33%_8.33%_33.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p4611e00} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.33%_33.33%_33.33%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p26970a80} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button76() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon62 />
      </div>
    </div>
  );
}

function Icon63() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[8.32%_8.32%_8.33%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-5%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
            <path d={svgPaths.p185227c0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.95%_8.94%_45.48%_45.47%]" data-name="Vector">
        <div className="absolute inset-[-9.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9 9">
            <path d={svgPaths.p2db0e900} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button77() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon63 />
      </div>
    </div>
  );
}

function Container114() {
  return (
    <div className="absolute content-stretch flex gap-[8px] h-[16px] items-center left-[24px] top-[32.5px] w-[139.773px]" data-name="Container">
      <Button74 />
      <Button75 />
      <Button76 />
      <Button77 />
    </div>
  );
}

function TableCell111() {
  return (
    <div className="absolute h-[81px] left-[1521.23px] top-0 w-[187.773px]" data-name="Table Cell">
      <Container114 />
    </div>
  );
}

function TableRow14() {
  return (
    <div className="absolute border-[#e5e7eb] border-[0px_0px_1px] border-solid h-[81px] left-0 top-[1052.5px] w-[1709px]" data-name="Table Row">
      <TableCell104 />
      <TableCell105 />
      <TableCell106 />
      <TableCell107 />
      <TableCell108 />
      <TableCell109 />
      <TableCell110 />
      <TableCell111 />
    </div>
  );
}

function Paragraph63() {
  return (
    <div className="h-[24px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[#101828] text-[16px] text-nowrap top-[-0.5px] tracking-[-0.3125px]">Troubleshooting Assistant</p>
    </div>
  );
}

function Paragraph64() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#6a7282] text-[14px] text-nowrap top-[0.5px] tracking-[-0.1504px]">Remote Workers</p>
    </div>
  );
}

function Container115() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[48px] items-start left-[24px] top-[16.5px] w-[285.758px]" data-name="Container">
      <Paragraph63 />
      <Paragraph64 />
    </div>
  );
}

function TableCell112() {
  return (
    <div className="absolute h-[81px] left-0 top-0 w-[333.758px]" data-name="Table Cell">
      <Container115 />
    </div>
  );
}

function Text107() {
  return (
    <div className="absolute bg-[#dcfce7] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[99.188px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#016630] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">self-service</p>
    </div>
  );
}

function TableCell113() {
  return (
    <div className="absolute h-[81px] left-[333.76px] top-0 w-[197.578px]" data-name="Table Cell">
      <Text107 />
    </div>
  );
}

function Text108() {
  return (
    <div className="absolute bg-[#fce7f3] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[54.875px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#a3004c] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">slack</p>
    </div>
  );
}

function TableCell114() {
  return (
    <div className="absolute h-[81px] left-[531.34px] top-0 w-[166.875px]" data-name="Table Cell">
      <Text108 />
    </div>
  );
}

function Text109() {
  return (
    <div className="absolute content-stretch flex h-[16.5px] items-start left-[24px] top-[33px] w-[88.086px]" data-name="Text">
      <p className="capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] not-italic relative shrink-0 text-[#101828] text-[14px] text-nowrap tracking-[-0.1504px]">non-intrusive</p>
    </div>
  );
}

function TableCell115() {
  return (
    <div className="absolute h-[81px] left-[698.21px] top-0 w-[166.875px]" data-name="Table Cell">
      <Text109 />
    </div>
  );
}

function Text110() {
  return (
    <div className="absolute bg-[#dcfce7] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[59.953px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#016630] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">active</p>
    </div>
  );
}

function TableCell116() {
  return (
    <div className="absolute h-[81px] left-[865.09px] top-0 w-[180.945px]" data-name="Table Cell">
      <Text110 />
    </div>
  );
}

function Container116() {
  return <div className="bg-[#59168b] h-[8px] rounded-[1.67772e+07px] shrink-0 w-full" data-name="Container" />;
}

function Container117() {
  return (
    <div className="basis-0 bg-[#e5e7eb] grow h-[8px] min-h-px min-w-px relative rounded-[1.67772e+07px] shrink-0" data-name="Container">
      <div className="size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pl-0 pr-[26.781px] py-0 relative size-full">
          <Container116 />
        </div>
      </div>
    </div>
  );
}

function Text111() {
  return (
    <div className="h-[20px] relative shrink-0 w-[27.945px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#101828] text-[14px] top-[0.5px] tracking-[-0.1504px] w-[28px]">81%</p>
      </div>
    </div>
  );
}

function Container118() {
  return (
    <div className="content-stretch flex gap-[8px] h-[20px] items-center relative shrink-0 w-full" data-name="Container">
      <Container117 />
      <Text111 />
    </div>
  );
}

function Paragraph65() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#6a7282] text-[14px] top-[0.5px] tracking-[-0.1504px] w-[62px]">189 / 234</p>
    </div>
  );
}

function Container119() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[44px] items-start left-[24px] top-[18.5px] w-[176.875px]" data-name="Container">
      <Container118 />
      <Paragraph65 />
    </div>
  );
}

function TableCell117() {
  return (
    <div className="absolute h-[81px] left-[1046.03px] top-0 w-[224.875px]" data-name="Table Cell">
      <Container119 />
    </div>
  );
}

function Paragraph66() {
  return (
    <div className="absolute h-[20px] left-[24px] top-[20.5px] w-[202.32px]" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#101828] text-[14px] text-nowrap top-[0.5px] tracking-[-0.1504px]">AI Assistant</p>
    </div>
  );
}

function Paragraph67() {
  return (
    <div className="absolute h-[16px] left-[24px] top-[44.5px] w-[202.32px]" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16px] left-0 not-italic text-[#59168b] text-[12px] text-nowrap top-px">Interactive Flow</p>
    </div>
  );
}

function TableCell118() {
  return (
    <div className="absolute h-[81px] left-[1270.91px] top-0 w-[250.32px]" data-name="Table Cell">
      <Paragraph66 />
      <Paragraph67 />
    </div>
  );
}

function Icon64() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[20.84%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%_-5%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 11">
            <path d={svgPaths.pb85f580} id="Vector" stroke="var(--stroke-0, #59168B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[37.5%]" data-name="Vector">
        <div className="absolute inset-[-16.67%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6 6">
            <path d={svgPaths.p36446d40} id="Vector" stroke="var(--stroke-0, #59168B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button78() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon64 />
      </div>
    </div>
  );
}

function Icon65() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[12.5%]" data-name="Vector">
        <div className="absolute inset-[-5.56%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
            <path d={svgPaths.p73e95c0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.35%_8.35%_33.32%_33.32%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p47c19f0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button79() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon65 />
      </div>
    </div>
  );
}

function Icon66() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[33.33%_8.33%_8.33%_33.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p4611e00} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.33%_33.33%_33.33%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p26970a80} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button80() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon66 />
      </div>
    </div>
  );
}

function Icon67() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[8.32%_8.32%_8.33%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-5%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
            <path d={svgPaths.p185227c0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.95%_8.94%_45.48%_45.47%]" data-name="Vector">
        <div className="absolute inset-[-9.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9 9">
            <path d={svgPaths.p2db0e900} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button81() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon67 />
      </div>
    </div>
  );
}

function Container120() {
  return (
    <div className="absolute content-stretch flex gap-[8px] h-[16px] items-center left-[24px] top-[32.5px] w-[139.773px]" data-name="Container">
      <Button78 />
      <Button79 />
      <Button80 />
      <Button81 />
    </div>
  );
}

function TableCell119() {
  return (
    <div className="absolute h-[81px] left-[1521.23px] top-0 w-[187.773px]" data-name="Table Cell">
      <Container120 />
    </div>
  );
}

function TableRow15() {
  return (
    <div className="absolute border-[#e5e7eb] border-[0px_0px_1px] border-solid h-[81px] left-0 top-[1133.5px] w-[1709px]" data-name="Table Row">
      <TableCell112 />
      <TableCell113 />
      <TableCell114 />
      <TableCell115 />
      <TableCell116 />
      <TableCell117 />
      <TableCell118 />
      <TableCell119 />
    </div>
  );
}

function Paragraph68() {
  return (
    <div className="h-[24px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[#101828] text-[16px] text-nowrap top-[-0.5px] tracking-[-0.3125px]">Quarterly IT Training Survey</p>
    </div>
  );
}

function Paragraph69() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#6a7282] text-[14px] text-nowrap top-[0.5px] tracking-[-0.1504px]">All Employees</p>
    </div>
  );
}

function Container121() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[48px] items-start left-[24px] top-[16.5px] w-[285.758px]" data-name="Container">
      <Paragraph68 />
      <Paragraph69 />
    </div>
  );
}

function TableCell120() {
  return (
    <div className="absolute h-[81px] left-0 top-0 w-[333.758px]" data-name="Table Cell">
      <Container121 />
    </div>
  );
}

function Text112() {
  return (
    <div className="absolute bg-[#f3e8ff] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[64.367px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#6e11b0] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">survey</p>
    </div>
  );
}

function TableCell121() {
  return (
    <div className="absolute h-[81px] left-[333.76px] top-0 w-[197.578px]" data-name="Table Cell">
      <Text112 />
    </div>
  );
}

function Text113() {
  return (
    <div className="absolute bg-[#fce7f3] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[54.875px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#a3004c] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">slack</p>
    </div>
  );
}

function TableCell122() {
  return (
    <div className="absolute h-[81px] left-[531.34px] top-0 w-[166.875px]" data-name="Table Cell">
      <Text113 />
    </div>
  );
}

function Text114() {
  return (
    <div className="absolute content-stretch flex h-[16.5px] items-start left-[24px] top-[33px] w-[88.086px]" data-name="Text">
      <p className="capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] not-italic relative shrink-0 text-[#101828] text-[14px] text-nowrap tracking-[-0.1504px]">non-intrusive</p>
    </div>
  );
}

function TableCell123() {
  return (
    <div className="absolute h-[81px] left-[698.21px] top-0 w-[166.875px]" data-name="Table Cell">
      <Text114 />
    </div>
  );
}

function Text115() {
  return (
    <div className="absolute bg-[#f3f4f6] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[52.633px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#1e2939] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">draft</p>
    </div>
  );
}

function TableCell124() {
  return (
    <div className="absolute h-[81px] left-[865.09px] top-0 w-[180.945px]" data-name="Table Cell">
      <Text115 />
    </div>
  );
}

function Container122() {
  return <div className="bg-[#59168b] h-[8px] rounded-[1.67772e+07px] shrink-0 w-full" data-name="Container" />;
}

function Container123() {
  return (
    <div className="basis-0 bg-[#e5e7eb] grow h-[8px] min-h-px min-w-px relative rounded-[1.67772e+07px] shrink-0" data-name="Container">
      <div className="size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pl-0 pr-[147.398px] py-0 relative size-full">
          <Container122 />
        </div>
      </div>
    </div>
  );
}

function Text116() {
  return (
    <div className="h-[20px] relative shrink-0 w-[21.477px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#101828] text-[14px] top-[0.5px] tracking-[-0.1504px] w-[22px]">0%</p>
      </div>
    </div>
  );
}

function Container124() {
  return (
    <div className="content-stretch flex gap-[8px] h-[20px] items-center relative shrink-0 w-full" data-name="Container">
      <Container123 />
      <Text116 />
    </div>
  );
}

function Paragraph70() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#6a7282] text-[14px] top-[0.5px] tracking-[-0.1504px] w-[30px]">0 / 0</p>
    </div>
  );
}

function Container125() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[44px] items-start left-[24px] top-[18.5px] w-[176.875px]" data-name="Container">
      <Container124 />
      <Paragraph70 />
    </div>
  );
}

function TableCell125() {
  return (
    <div className="absolute h-[81px] left-[1046.03px] top-0 w-[224.875px]" data-name="Table Cell">
      <Container125 />
    </div>
  );
}

function Paragraph71() {
  return (
    <div className="absolute h-[20px] left-[24px] top-[30.5px] w-[202.32px]" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#101828] text-[14px] text-nowrap top-[0.5px] tracking-[-0.1504px]">Feedback Form</p>
    </div>
  );
}

function TableCell126() {
  return (
    <div className="absolute h-[81px] left-[1270.91px] top-0 w-[250.32px]" data-name="Table Cell">
      <Paragraph71 />
    </div>
  );
}

function Icon68() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[20.84%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%_-5%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 11">
            <path d={svgPaths.pb85f580} id="Vector" stroke="var(--stroke-0, #59168B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[37.5%]" data-name="Vector">
        <div className="absolute inset-[-16.67%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6 6">
            <path d={svgPaths.p36446d40} id="Vector" stroke="var(--stroke-0, #59168B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button82() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon68 />
      </div>
    </div>
  );
}

function Icon69() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[12.5%]" data-name="Vector">
        <div className="absolute inset-[-5.56%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
            <path d={svgPaths.p73e95c0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.35%_8.35%_33.32%_33.32%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p47c19f0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button83() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon69 />
      </div>
    </div>
  );
}

function Icon70() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[33.33%_8.33%_8.33%_33.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p4611e00} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.33%_33.33%_33.33%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p26970a80} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button84() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon70 />
      </div>
    </div>
  );
}

function Icon71() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[8.32%_8.32%_8.33%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-5%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
            <path d={svgPaths.p185227c0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.95%_8.94%_45.48%_45.47%]" data-name="Vector">
        <div className="absolute inset-[-9.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9 9">
            <path d={svgPaths.p2db0e900} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button85() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon71 />
      </div>
    </div>
  );
}

function Container126() {
  return (
    <div className="absolute content-stretch flex gap-[8px] h-[16px] items-center left-[24px] top-[32.5px] w-[139.773px]" data-name="Container">
      <Button82 />
      <Button83 />
      <Button84 />
      <Button85 />
    </div>
  );
}

function TableCell127() {
  return (
    <div className="absolute h-[81px] left-[1521.23px] top-0 w-[187.773px]" data-name="Table Cell">
      <Container126 />
    </div>
  );
}

function TableRow16() {
  return (
    <div className="absolute border-[#e5e7eb] border-[0px_0px_1px] border-solid h-[81px] left-0 top-[1214.5px] w-[1709px]" data-name="Table Row">
      <TableCell120 />
      <TableCell121 />
      <TableCell122 />
      <TableCell123 />
      <TableCell124 />
      <TableCell125 />
      <TableCell126 />
      <TableCell127 />
    </div>
  );
}

function Paragraph72() {
  return (
    <div className="h-[24px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[#101828] text-[16px] text-nowrap top-[-0.5px] tracking-[-0.3125px]">Data Backup Confirmation</p>
    </div>
  );
}

function Paragraph73() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#6a7282] text-[14px] text-nowrap top-[0.5px] tracking-[-0.1504px]">Data Owners</p>
    </div>
  );
}

function Container127() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[48px] items-start left-[24px] top-[16.5px] w-[285.758px]" data-name="Container">
      <Paragraph72 />
      <Paragraph73 />
    </div>
  );
}

function TableCell128() {
  return (
    <div className="absolute h-[81px] left-0 top-0 w-[333.758px]" data-name="Table Cell">
      <Container127 />
    </div>
  );
}

function Text117() {
  return (
    <div className="absolute bg-[#ffedd4] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[103.547px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#9f2d00] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">confirmation</p>
    </div>
  );
}

function TableCell129() {
  return (
    <div className="absolute h-[81px] left-[333.76px] top-0 w-[197.578px]" data-name="Table Cell">
      <Text117 />
    </div>
  );
}

function Text118() {
  return (
    <div className="absolute bg-[#e0e7ff] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[61.992px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#372aac] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">teams</p>
    </div>
  );
}

function TableCell130() {
  return (
    <div className="absolute h-[81px] left-[531.34px] top-0 w-[166.875px]" data-name="Table Cell">
      <Text118 />
    </div>
  );
}

function Text119() {
  return (
    <div className="absolute content-stretch flex h-[16.5px] items-start left-[24px] top-[33px] w-[88.086px]" data-name="Text">
      <p className="capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] not-italic relative shrink-0 text-[#101828] text-[14px] text-nowrap tracking-[-0.1504px]">non-intrusive</p>
    </div>
  );
}

function TableCell131() {
  return (
    <div className="absolute h-[81px] left-[698.21px] top-0 w-[166.875px]" data-name="Table Cell">
      <Text119 />
    </div>
  );
}

function Text120() {
  return (
    <div className="absolute bg-[#dbeafe] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[88.547px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#193cb8] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">scheduled</p>
    </div>
  );
}

function TableCell132() {
  return (
    <div className="absolute h-[81px] left-[865.09px] top-0 w-[180.945px]" data-name="Table Cell">
      <Text120 />
    </div>
  );
}

function Container128() {
  return <div className="bg-[#59168b] h-[8px] rounded-[1.67772e+07px] shrink-0 w-full" data-name="Container" />;
}

function Container129() {
  return (
    <div className="basis-0 bg-[#e5e7eb] grow h-[8px] min-h-px min-w-px relative rounded-[1.67772e+07px] shrink-0" data-name="Container">
      <div className="size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pl-0 pr-[147.398px] py-0 relative size-full">
          <Container128 />
        </div>
      </div>
    </div>
  );
}

function Text121() {
  return (
    <div className="h-[20px] relative shrink-0 w-[21.477px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#101828] text-[14px] top-[0.5px] tracking-[-0.1504px] w-[22px]">0%</p>
      </div>
    </div>
  );
}

function Container130() {
  return (
    <div className="content-stretch flex gap-[8px] h-[20px] items-center relative shrink-0 w-full" data-name="Container">
      <Container129 />
      <Text121 />
    </div>
  );
}

function Paragraph74() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#6a7282] text-[14px] top-[0.5px] tracking-[-0.1504px] w-[30px]">0 / 0</p>
    </div>
  );
}

function Container131() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[44px] items-start left-[24px] top-[18.5px] w-[176.875px]" data-name="Container">
      <Container130 />
      <Paragraph74 />
    </div>
  );
}

function TableCell133() {
  return (
    <div className="absolute h-[81px] left-[1046.03px] top-0 w-[224.875px]" data-name="Table Cell">
      <Container131 />
    </div>
  );
}

function Paragraph75() {
  return (
    <div className="absolute h-[20px] left-[24px] top-[30.5px] w-[202.32px]" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#101828] text-[14px] text-nowrap top-[0.5px] tracking-[-0.1504px]">Backup Confirmation</p>
    </div>
  );
}

function TableCell134() {
  return (
    <div className="absolute h-[81px] left-[1270.91px] top-0 w-[250.32px]" data-name="Table Cell">
      <Paragraph75 />
    </div>
  );
}

function Icon72() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[20.84%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%_-5%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 11">
            <path d={svgPaths.pb85f580} id="Vector" stroke="var(--stroke-0, #59168B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[37.5%]" data-name="Vector">
        <div className="absolute inset-[-16.67%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6 6">
            <path d={svgPaths.p36446d40} id="Vector" stroke="var(--stroke-0, #59168B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button86() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon72 />
      </div>
    </div>
  );
}

function Icon73() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[12.5%]" data-name="Vector">
        <div className="absolute inset-[-5.56%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
            <path d={svgPaths.p73e95c0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.35%_8.35%_33.32%_33.32%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p47c19f0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button87() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon73 />
      </div>
    </div>
  );
}

function Icon74() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[33.33%_8.33%_8.33%_33.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p4611e00} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.33%_33.33%_33.33%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p26970a80} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button88() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon74 />
      </div>
    </div>
  );
}

function Icon75() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[8.32%_8.32%_8.33%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-5%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
            <path d={svgPaths.p185227c0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.95%_8.94%_45.48%_45.47%]" data-name="Vector">
        <div className="absolute inset-[-9.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9 9">
            <path d={svgPaths.p2db0e900} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button89() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon75 />
      </div>
    </div>
  );
}

function Container132() {
  return (
    <div className="absolute content-stretch flex gap-[8px] h-[16px] items-center left-[24px] top-[32.5px] w-[139.773px]" data-name="Container">
      <Button86 />
      <Button87 />
      <Button88 />
      <Button89 />
    </div>
  );
}

function TableCell135() {
  return (
    <div className="absolute h-[81px] left-[1521.23px] top-0 w-[187.773px]" data-name="Table Cell">
      <Container132 />
    </div>
  );
}

function TableRow17() {
  return (
    <div className="absolute border-[#e5e7eb] border-[0px_0px_1px] border-solid h-[81px] left-0 top-[1295.5px] w-[1709px]" data-name="Table Row">
      <TableCell128 />
      <TableCell129 />
      <TableCell130 />
      <TableCell131 />
      <TableCell132 />
      <TableCell133 />
      <TableCell134 />
      <TableCell135 />
    </div>
  );
}

function Paragraph76() {
  return (
    <div className="h-[24px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[#101828] text-[16px] text-nowrap top-[-0.5px] tracking-[-0.3125px]">Critical Security Alert</p>
    </div>
  );
}

function Paragraph77() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#6a7282] text-[14px] text-nowrap top-[0.5px] tracking-[-0.1504px]">All Users</p>
    </div>
  );
}

function Container133() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[48px] items-start left-[24px] top-[16.5px] w-[285.758px]" data-name="Container">
      <Paragraph76 />
      <Paragraph77 />
    </div>
  );
}

function TableCell136() {
  return (
    <div className="absolute h-[81px] left-0 top-0 w-[333.758px]" data-name="Table Cell">
      <Container133 />
    </div>
  );
}

function Text122() {
  return (
    <div className="absolute bg-[#dbeafe] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[94.477px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#193cb8] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">notification</p>
    </div>
  );
}

function TableCell137() {
  return (
    <div className="absolute h-[81px] left-[333.76px] top-0 w-[197.578px]" data-name="Table Cell">
      <Text122 />
    </div>
  );
}

function Text123() {
  return (
    <div className="absolute bg-[#f3f4f6] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[77.25px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#1e2939] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">riverbed</p>
    </div>
  );
}

function TableCell138() {
  return (
    <div className="absolute h-[81px] left-[531.34px] top-0 w-[166.875px]" data-name="Table Cell">
      <Text123 />
    </div>
  );
}

function Text124() {
  return (
    <div className="absolute content-stretch flex h-[16.5px] items-start left-[24px] top-[33px] w-[55.25px]" data-name="Text">
      <p className="capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] not-italic relative shrink-0 text-[#101828] text-[14px] text-nowrap tracking-[-0.1504px]">intrusive</p>
    </div>
  );
}

function TableCell139() {
  return (
    <div className="absolute h-[81px] left-[698.21px] top-0 w-[166.875px]" data-name="Table Cell">
      <Text124 />
    </div>
  );
}

function Text125() {
  return (
    <div className="absolute bg-[#dcfce7] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[59.953px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#016630] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">active</p>
    </div>
  );
}

function TableCell140() {
  return (
    <div className="absolute h-[81px] left-[865.09px] top-0 w-[180.945px]" data-name="Table Cell">
      <Text125 />
    </div>
  );
}

function Container134() {
  return <div className="bg-[#59168b] h-[8px] rounded-[1.67772e+07px] shrink-0 w-full" data-name="Container" />;
}

function Container135() {
  return (
    <div className="basis-0 bg-[#e5e7eb] grow h-[8px] min-h-px min-w-px relative rounded-[1.67772e+07px] shrink-0" data-name="Container">
      <div className="size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pl-0 pr-[5.547px] py-0 relative size-full">
          <Container134 />
        </div>
      </div>
    </div>
  );
}

function Text126() {
  return (
    <div className="h-[20px] relative shrink-0 w-[30.336px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#101828] text-[14px] top-[0.5px] tracking-[-0.1504px] w-[31px]">96%</p>
      </div>
    </div>
  );
}

function Container136() {
  return (
    <div className="content-stretch flex gap-[8px] h-[20px] items-center relative shrink-0 w-full" data-name="Container">
      <Container135 />
      <Text126 />
    </div>
  );
}

function Paragraph78() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#6a7282] text-[14px] top-[0.5px] tracking-[-0.1504px] w-[79px]">4321 / 4500</p>
    </div>
  );
}

function Container137() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[44px] items-start left-[24px] top-[18.5px] w-[176.875px]" data-name="Container">
      <Container136 />
      <Paragraph78 />
    </div>
  );
}

function TableCell141() {
  return (
    <div className="absolute h-[81px] left-[1046.03px] top-0 w-[224.875px]" data-name="Table Cell">
      <Container137 />
    </div>
  );
}

function Paragraph79() {
  return (
    <div className="absolute h-[20px] left-[24px] top-[20.5px] w-[202.32px]" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#101828] text-[14px] text-nowrap top-[0.5px] tracking-[-0.1504px]">Emergency Alert</p>
    </div>
  );
}

function Paragraph80() {
  return (
    <div className="absolute h-[16px] left-[24px] top-[44.5px] w-[202.32px]" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16px] left-0 not-italic text-[#59168b] text-[12px] text-nowrap top-px">Interactive Flow</p>
    </div>
  );
}

function TableCell142() {
  return (
    <div className="absolute h-[81px] left-[1270.91px] top-0 w-[250.32px]" data-name="Table Cell">
      <Paragraph79 />
      <Paragraph80 />
    </div>
  );
}

function Icon76() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[20.84%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%_-5%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 11">
            <path d={svgPaths.pb85f580} id="Vector" stroke="var(--stroke-0, #59168B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[37.5%]" data-name="Vector">
        <div className="absolute inset-[-16.67%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6 6">
            <path d={svgPaths.p36446d40} id="Vector" stroke="var(--stroke-0, #59168B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button90() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon76 />
      </div>
    </div>
  );
}

function Icon77() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[12.5%]" data-name="Vector">
        <div className="absolute inset-[-5.56%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
            <path d={svgPaths.p73e95c0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.35%_8.35%_33.32%_33.32%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p47c19f0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button91() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon77 />
      </div>
    </div>
  );
}

function Icon78() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[33.33%_8.33%_8.33%_33.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p4611e00} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.33%_33.33%_33.33%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p26970a80} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button92() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon78 />
      </div>
    </div>
  );
}

function Icon79() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[8.32%_8.32%_8.33%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-5%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
            <path d={svgPaths.p185227c0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.95%_8.94%_45.48%_45.47%]" data-name="Vector">
        <div className="absolute inset-[-9.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9 9">
            <path d={svgPaths.p2db0e900} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button93() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon79 />
      </div>
    </div>
  );
}

function Container138() {
  return (
    <div className="absolute content-stretch flex gap-[8px] h-[16px] items-center left-[24px] top-[32.5px] w-[139.773px]" data-name="Container">
      <Button90 />
      <Button91 />
      <Button92 />
      <Button93 />
    </div>
  );
}

function TableCell143() {
  return (
    <div className="absolute h-[81px] left-[1521.23px] top-0 w-[187.773px]" data-name="Table Cell">
      <Container138 />
    </div>
  );
}

function TableRow18() {
  return (
    <div className="absolute border-[#e5e7eb] border-[0px_0px_1px] border-solid h-[81px] left-0 top-[1376.5px] w-[1709px]" data-name="Table Row">
      <TableCell136 />
      <TableCell137 />
      <TableCell138 />
      <TableCell139 />
      <TableCell140 />
      <TableCell141 />
      <TableCell142 />
      <TableCell143 />
    </div>
  );
}

function Paragraph81() {
  return (
    <div className="h-[24px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[#101828] text-[16px] text-nowrap top-[-0.5px] tracking-[-0.3125px]">Training Session Reminder</p>
    </div>
  );
}

function Paragraph82() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#6a7282] text-[14px] text-nowrap top-[0.5px] tracking-[-0.1504px]">Engineering Dept</p>
    </div>
  );
}

function Container139() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[48px] items-start left-[24px] top-[16.5px] w-[285.758px]" data-name="Container">
      <Paragraph81 />
      <Paragraph82 />
    </div>
  );
}

function TableCell144() {
  return (
    <div className="absolute h-[81px] left-0 top-0 w-[333.758px]" data-name="Table Cell">
      <Container139 />
    </div>
  );
}

function Text127() {
  return (
    <div className="absolute bg-[#fef9c2] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[81.477px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#894b00] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">reminder</p>
    </div>
  );
}

function TableCell145() {
  return (
    <div className="absolute h-[81px] left-[333.76px] top-0 w-[197.578px]" data-name="Table Cell">
      <Text127 />
    </div>
  );
}

function Text128() {
  return (
    <div className="absolute bg-[#fce7f3] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[54.875px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#a3004c] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">slack</p>
    </div>
  );
}

function TableCell146() {
  return (
    <div className="absolute h-[81px] left-[531.34px] top-0 w-[166.875px]" data-name="Table Cell">
      <Text128 />
    </div>
  );
}

function Text129() {
  return (
    <div className="absolute content-stretch flex h-[16.5px] items-start left-[24px] top-[33px] w-[88.086px]" data-name="Text">
      <p className="capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] not-italic relative shrink-0 text-[#101828] text-[14px] text-nowrap tracking-[-0.1504px]">non-intrusive</p>
    </div>
  );
}

function TableCell147() {
  return (
    <div className="absolute h-[81px] left-[698.21px] top-0 w-[166.875px]" data-name="Table Cell">
      <Text129 />
    </div>
  );
}

function Text130() {
  return (
    <div className="absolute bg-[#f3e8ff] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[90.789px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#6e11b0] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">completed</p>
    </div>
  );
}

function TableCell148() {
  return (
    <div className="absolute h-[81px] left-[865.09px] top-0 w-[180.945px]" data-name="Table Cell">
      <Text130 />
    </div>
  );
}

function Container140() {
  return <div className="bg-[#59168b] h-[8px] rounded-[1.67772e+07px] shrink-0 w-full" data-name="Container" />;
}

function Container141() {
  return (
    <div className="basis-0 bg-[#e5e7eb] grow h-[8px] min-h-px min-w-px relative rounded-[1.67772e+07px] shrink-0" data-name="Container">
      <div className="size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pl-0 pr-[11.125px] py-0 relative size-full">
          <Container140 />
        </div>
      </div>
    </div>
  );
}

function Text131() {
  return (
    <div className="h-[20px] relative shrink-0 w-[29.867px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#101828] text-[14px] top-[0.5px] tracking-[-0.1504px] w-[30px]">92%</p>
      </div>
    </div>
  );
}

function Container142() {
  return (
    <div className="content-stretch flex gap-[8px] h-[20px] items-center relative shrink-0 w-full" data-name="Container">
      <Container141 />
      <Text131 />
    </div>
  );
}

function Paragraph83() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#6a7282] text-[14px] top-[0.5px] tracking-[-0.1504px] w-[45px]">72 / 78</p>
    </div>
  );
}

function Container143() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[44px] items-start left-[24px] top-[18.5px] w-[176.875px]" data-name="Container">
      <Container142 />
      <Paragraph83 />
    </div>
  );
}

function TableCell149() {
  return (
    <div className="absolute h-[81px] left-[1046.03px] top-0 w-[224.875px]" data-name="Table Cell">
      <Container143 />
    </div>
  );
}

function Paragraph84() {
  return (
    <div className="absolute h-[20px] left-[24px] top-[30.5px] w-[202.32px]" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#101828] text-[14px] text-nowrap top-[0.5px] tracking-[-0.1504px]">Event Reminder</p>
    </div>
  );
}

function TableCell150() {
  return (
    <div className="absolute h-[81px] left-[1270.91px] top-0 w-[250.32px]" data-name="Table Cell">
      <Paragraph84 />
    </div>
  );
}

function Icon80() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[20.84%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%_-5%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 11">
            <path d={svgPaths.pb85f580} id="Vector" stroke="var(--stroke-0, #59168B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[37.5%]" data-name="Vector">
        <div className="absolute inset-[-16.67%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6 6">
            <path d={svgPaths.p36446d40} id="Vector" stroke="var(--stroke-0, #59168B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button94() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon80 />
      </div>
    </div>
  );
}

function Icon81() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[12.5%]" data-name="Vector">
        <div className="absolute inset-[-5.56%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
            <path d={svgPaths.p73e95c0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.35%_8.35%_33.32%_33.32%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p47c19f0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button95() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon81 />
      </div>
    </div>
  );
}

function Icon82() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[33.33%_8.33%_8.33%_33.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p4611e00} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.33%_33.33%_33.33%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p26970a80} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button96() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon82 />
      </div>
    </div>
  );
}

function Icon83() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[8.32%_8.32%_8.33%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-5%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
            <path d={svgPaths.p185227c0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.95%_8.94%_45.48%_45.47%]" data-name="Vector">
        <div className="absolute inset-[-9.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9 9">
            <path d={svgPaths.p2db0e900} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button97() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon83 />
      </div>
    </div>
  );
}

function Container144() {
  return (
    <div className="absolute content-stretch flex gap-[8px] h-[16px] items-center left-[24px] top-[32.5px] w-[139.773px]" data-name="Container">
      <Button94 />
      <Button95 />
      <Button96 />
      <Button97 />
    </div>
  );
}

function TableCell151() {
  return (
    <div className="absolute h-[81px] left-[1521.23px] top-0 w-[187.773px]" data-name="Table Cell">
      <Container144 />
    </div>
  );
}

function TableRow19() {
  return (
    <div className="absolute border-[#e5e7eb] border-[0px_0px_1px] border-solid h-[81px] left-0 top-[1457.5px] w-[1709px]" data-name="Table Row">
      <TableCell144 />
      <TableCell145 />
      <TableCell146 />
      <TableCell147 />
      <TableCell148 />
      <TableCell149 />
      <TableCell150 />
      <TableCell151 />
    </div>
  );
}

function Paragraph85() {
  return (
    <div className="h-[24px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[#101828] text-[16px] text-nowrap top-[-0.5px] tracking-[-0.3125px]">Quick Fix Wizard</p>
    </div>
  );
}

function Paragraph86() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#6a7282] text-[14px] text-nowrap top-[0.5px] tracking-[-0.1504px]">Sales Dept</p>
    </div>
  );
}

function Container145() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[48px] items-start left-[24px] top-[16.5px] w-[285.758px]" data-name="Container">
      <Paragraph85 />
      <Paragraph86 />
    </div>
  );
}

function TableCell152() {
  return (
    <div className="absolute h-[80.5px] left-0 top-0 w-[333.758px]" data-name="Table Cell">
      <Container145 />
    </div>
  );
}

function Text132() {
  return (
    <div className="absolute bg-[#dcfce7] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[99.188px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#016630] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">self-service</p>
    </div>
  );
}

function TableCell153() {
  return (
    <div className="absolute h-[80.5px] left-[333.76px] top-0 w-[197.578px]" data-name="Table Cell">
      <Text132 />
    </div>
  );
}

function Text133() {
  return (
    <div className="absolute bg-[#cbfbf1] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[54.5px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#005f5a] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">email</p>
    </div>
  );
}

function TableCell154() {
  return (
    <div className="absolute h-[80.5px] left-[531.34px] top-0 w-[166.875px]" data-name="Table Cell">
      <Text133 />
    </div>
  );
}

function Text134() {
  return (
    <div className="absolute content-stretch flex h-[16.5px] items-start left-[24px] top-[33px] w-[88.086px]" data-name="Text">
      <p className="capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] not-italic relative shrink-0 text-[#101828] text-[14px] text-nowrap tracking-[-0.1504px]">non-intrusive</p>
    </div>
  );
}

function TableCell155() {
  return (
    <div className="absolute h-[80.5px] left-[698.21px] top-0 w-[166.875px]" data-name="Table Cell">
      <Text134 />
    </div>
  );
}

function Text135() {
  return (
    <div className="absolute bg-[#f3f4f6] h-[28px] left-[24px] rounded-[1.67772e+07px] top-[26.5px] w-[52.633px]" data-name="Text">
      <p className="absolute capitalize font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-[10px] not-italic text-[#1e2939] text-[14px] text-nowrap top-[4.5px] tracking-[-0.1504px]">draft</p>
    </div>
  );
}

function TableCell156() {
  return (
    <div className="absolute h-[80.5px] left-[865.09px] top-0 w-[180.945px]" data-name="Table Cell">
      <Text135 />
    </div>
  );
}

function Container146() {
  return <div className="bg-[#59168b] h-[8px] rounded-[1.67772e+07px] shrink-0 w-full" data-name="Container" />;
}

function Container147() {
  return (
    <div className="basis-0 bg-[#e5e7eb] grow h-[8px] min-h-px min-w-px relative rounded-[1.67772e+07px] shrink-0" data-name="Container">
      <div className="size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pl-0 pr-[147.398px] py-0 relative size-full">
          <Container146 />
        </div>
      </div>
    </div>
  );
}

function Text136() {
  return (
    <div className="h-[20px] relative shrink-0 w-[21.477px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#101828] text-[14px] top-[0.5px] tracking-[-0.1504px] w-[22px]">0%</p>
      </div>
    </div>
  );
}

function Container148() {
  return (
    <div className="content-stretch flex gap-[8px] h-[20px] items-center relative shrink-0 w-full" data-name="Container">
      <Container147 />
      <Text136 />
    </div>
  );
}

function Paragraph87() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#6a7282] text-[14px] top-[0.5px] tracking-[-0.1504px] w-[30px]">0 / 0</p>
    </div>
  );
}

function Container149() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[44px] items-start left-[24px] top-[18.5px] w-[176.875px]" data-name="Container">
      <Container148 />
      <Paragraph87 />
    </div>
  );
}

function TableCell157() {
  return (
    <div className="absolute h-[80.5px] left-[1046.03px] top-0 w-[224.875px]" data-name="Table Cell">
      <Container149 />
    </div>
  );
}

function Paragraph88() {
  return (
    <div className="absolute h-[20px] left-[24px] top-[20.5px] w-[202.32px]" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#101828] text-[14px] text-nowrap top-[0.5px] tracking-[-0.1504px]">Step-by-Step Guide</p>
    </div>
  );
}

function Paragraph89() {
  return (
    <div className="absolute h-[16px] left-[24px] top-[44.5px] w-[202.32px]" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16px] left-0 not-italic text-[#59168b] text-[12px] text-nowrap top-px">Interactive Flow</p>
    </div>
  );
}

function TableCell158() {
  return (
    <div className="absolute h-[80.5px] left-[1270.91px] top-0 w-[250.32px]" data-name="Table Cell">
      <Paragraph88 />
      <Paragraph89 />
    </div>
  );
}

function Icon84() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[20.84%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%_-5%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 11">
            <path d={svgPaths.pb85f580} id="Vector" stroke="var(--stroke-0, #59168B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[37.5%]" data-name="Vector">
        <div className="absolute inset-[-16.67%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6 6">
            <path d={svgPaths.p36446d40} id="Vector" stroke="var(--stroke-0, #59168B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button98() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon84 />
      </div>
    </div>
  );
}

function Icon85() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[12.5%]" data-name="Vector">
        <div className="absolute inset-[-5.56%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
            <path d={svgPaths.p73e95c0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.35%_8.35%_33.32%_33.32%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p47c19f0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button99() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon85 />
      </div>
    </div>
  );
}

function Icon86() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[33.33%_8.33%_8.33%_33.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p4611e00} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.33%_33.33%_33.33%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
            <path d={svgPaths.p26970a80} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button100() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon86 />
      </div>
    </div>
  );
}

function Icon87() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[8.32%_8.32%_8.33%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-5%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
            <path d={svgPaths.p185227c0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.95%_8.94%_45.48%_45.47%]" data-name="Vector">
        <div className="absolute inset-[-9.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9 9">
            <path d={svgPaths.p2db0e900} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button101() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon87 />
      </div>
    </div>
  );
}

function Container150() {
  return (
    <div className="absolute content-stretch flex gap-[8px] h-[16px] items-center left-[24px] top-[32.5px] w-[139.773px]" data-name="Container">
      <Button98 />
      <Button99 />
      <Button100 />
      <Button101 />
    </div>
  );
}

function TableCell159() {
  return (
    <div className="absolute h-[80.5px] left-[1521.23px] top-0 w-[187.773px]" data-name="Table Cell">
      <Container150 />
    </div>
  );
}

function TableRow20() {
  return (
    <div className="absolute h-[80.5px] left-0 top-[1538.5px] w-[1709px]" data-name="Table Row">
      <TableCell152 />
      <TableCell153 />
      <TableCell154 />
      <TableCell155 />
      <TableCell156 />
      <TableCell157 />
      <TableCell158 />
      <TableCell159 />
    </div>
  );
}

function TableBody() {
  return (
    <div className="absolute h-[1619px] left-0 top-0 w-[1709px]" data-name="Table Body">
      <TableRow1 />
      <TableRow2 />
      <TableRow3 />
      <TableRow4 />
      <TableRow5 />
      <TableRow6 />
      <TableRow7 />
      <TableRow8 />
      <TableRow9 />
      <TableRow10 />
      <TableRow11 />
      <TableRow12 />
      <TableRow13 />
      <TableRow14 />
      <TableRow15 />
      <TableRow16 />
      <TableRow17 />
      <TableRow18 />
      <TableRow19 />
      <TableRow20 />
    </div>
  );
}

function Table1() {
  return (
    <div className="h-[1619px] relative shrink-0 w-full" data-name="Table">
      <TableBody />
    </div>
  );
}

function Container151() {
  return (
    <div className="content-stretch flex flex-col h-[600px] items-start overflow-clip relative shrink-0 w-full" data-name="Container">
      <Table1 />
    </div>
  );
}

function MessagesOverview() {
  return (
    <div className="bg-white h-[651px] relative rounded-[10px] shrink-0 w-full" data-name="MessagesOverview">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col items-start p-px relative size-full">
          <Container30 />
          <Container151 />
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[#e5e7eb] border-solid inset-0 pointer-events-none rounded-[10px]" />
    </div>
  );
}

function MessageFilterPanel() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[16px] h-[965px] items-start left-[32px] top-[185px] w-[1711px]" data-name="MessageFilterPanel">
      <Container29 />
      <MessagesOverview />
    </div>
  );
}

function Heading2() {
  return (
    <div className="h-[36px] relative shrink-0 w-full" data-name="Heading 1">
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[36px] left-0 not-italic text-[#101828] text-[24px] text-nowrap top-0 tracking-[0.0703px]">Messages</p>
    </div>
  );
}

function Paragraph90() {
  return (
    <div className="h-[24px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[#4a5565] text-[16px] text-nowrap top-[-0.5px] tracking-[-0.3125px]">Manage all end-user communications across channels</p>
    </div>
  );
}

function Container152() {
  return (
    <div className="h-[64px] relative shrink-0 w-[393.164px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[4px] items-start relative size-full">
        <Heading2 />
        <Paragraph90 />
      </div>
    </div>
  );
}

function Icon88() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[12.5%]" data-name="Vector">
        <div className="absolute inset-[-5.56%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
            <path d={svgPaths.p311aedc0} id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute bottom-[29.17%] left-3/4 right-1/4 top-[37.5%]" data-name="Vector">
        <div className="absolute inset-[-12.5%_-0.67px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 2 7">
            <path d="M0.666667 6V0.666667" id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[20.83%_45.83%_29.17%_54.17%]" data-name="Vector">
        <div className="absolute inset-[-8.33%_-0.67px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 2 10">
            <path d="M0.666667 8.66667V0.666667" id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[58.33%_66.67%_29.17%_33.33%]" data-name="Vector">
        <div className="absolute inset-[-33.33%_-0.67px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 2 4">
            <path d="M0.666667 2.66667V0.666667" id="Vector" stroke="var(--stroke-0, #4A5565)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button102() {
  return (
    <div className="relative rounded-[4px] shrink-0 size-[28px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pb-0 pt-[6px] px-[6px] relative size-full">
        <Icon88 />
      </div>
    </div>
  );
}

function Icon89() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute bottom-1/2 left-[12.5%] right-[87.46%] top-1/2" data-name="Vector">
        <div className="absolute inset-[-0.67px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 2 2">
            <path d="M0.666667 0.666667H0.673333" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute bottom-1/4 left-[12.5%] right-[87.46%] top-3/4" data-name="Vector">
        <div className="absolute inset-[-0.67px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 2 2">
            <path d="M0.666667 0.666667H0.673333" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute bottom-3/4 left-[12.5%] right-[87.46%] top-1/4" data-name="Vector">
        <div className="absolute inset-[-0.67px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 2 2">
            <path d="M0.666667 0.666667H0.673333" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute bottom-1/2 left-[33.33%] right-[12.5%] top-1/2" data-name="Vector">
        <div className="absolute inset-[-0.67px_-7.69%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10 2">
            <path d="M0.666667 0.666667H9.33333" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute bottom-1/4 left-[33.33%] right-[12.5%] top-3/4" data-name="Vector">
        <div className="absolute inset-[-0.67px_-7.69%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10 2">
            <path d="M0.666667 0.666667H9.33333" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
      <div className="absolute bottom-3/4 left-[33.33%] right-[12.5%] top-1/4" data-name="Vector">
        <div className="absolute inset-[-0.67px_-7.69%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10 2">
            <path d="M0.666667 0.666667H9.33333" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button103() {
  return (
    <div className="basis-0 bg-[#59168b] grow h-[28px] min-h-px min-w-px relative rounded-[4px] shrink-0" data-name="Button">
      <div className="size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pb-0 pt-[6px] px-[6px] relative size-full">
          <Icon89 />
        </div>
      </div>
    </div>
  );
}

function Container153() {
  return (
    <div className="bg-white h-[38px] relative rounded-[10px] shrink-0 w-[70px]" data-name="Container">
      <div aria-hidden="true" className="absolute border border-[#e5e7eb] border-solid inset-0 pointer-events-none rounded-[10px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[4px] items-center px-[5px] py-px relative size-full">
        <Button102 />
        <Button103 />
      </div>
    </div>
  );
}

function Icon90() {
  return (
    <div className="absolute left-[17px] size-[20px] top-[11px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p2f15de00} id="Vector" stroke="var(--stroke-0, #364153)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d={svgPaths.p3b27f100} id="Vector_2" stroke="var(--stroke-0, #364153)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
      </svg>
    </div>
  );
}

function Button104() {
  return (
    <div className="basis-0 bg-white grow h-[42px] min-h-px min-w-px relative rounded-[10px] shrink-0" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[#d1d5dc] border-solid inset-0 pointer-events-none rounded-[10px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Icon90 />
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-[101.5px] not-italic text-[#364153] text-[16px] text-center text-nowrap top-[8.5px] tracking-[-0.3125px] translate-x-[-50%]">Preview Design</p>
      </div>
    </div>
  );
}

function Icon91() {
  return (
    <div className="absolute left-[16px] size-[20px] top-[10px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d="M4.16667 10H15.8333" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d="M10 4.16667V15.8333" id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
      </svg>
    </div>
  );
}

function Button105() {
  return (
    <div className="bg-[#59168b] h-[40px] relative rounded-[10px] shrink-0 w-[161.906px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Icon91 />
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-[95.5px] not-italic text-[16px] text-center text-nowrap text-white top-[7.5px] tracking-[-0.3125px] translate-x-[-50%]">New Message</p>
      </div>
    </div>
  );
}

function Container154() {
  return (
    <div className="h-[42px] relative shrink-0 w-[429.375px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[12px] items-center relative size-full">
        <Container153 />
        <Button104 />
        <Button105 />
      </div>
    </div>
  );
}

function Container155() {
  return (
    <div className="content-stretch flex h-[64px] items-center justify-between relative shrink-0 w-full" data-name="Container">
      <Container152 />
      <Container154 />
    </div>
  );
}

function MessagesOverview1() {
  return (
    <div className="absolute bg-[#f9fafb] content-stretch flex flex-col h-[153px] items-start left-0 pb-px pt-[32px] px-[32px] top-0 w-[1775px]" data-name="MessagesOverview">
      <div aria-hidden="true" className="absolute border-[#e5e7eb] border-[0px_0px_1px] border-solid inset-0 pointer-events-none" />
      <Container155 />
    </div>
  );
}

function MainContent() {
  return (
    <div className="basis-0 grow h-[1268px] min-h-px min-w-px relative shrink-0" data-name="Main Content">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid overflow-clip relative rounded-[inherit] size-full">
        <MessageFilterPanel />
        <MessagesOverview1 />
      </div>
    </div>
  );
}

function UnifiedCommunicationPlatform() {
  return (
    <div className="bg-[#f9fafb] content-stretch flex h-[1268px] items-start relative shrink-0 w-full" data-name="UnifiedCommunicationPlatform">
      <Sidebar />
      <MainContent />
    </div>
  );
}

export default function BroadcastCapabilityDevelopment() {
  return (
    <div className="bg-white content-stretch flex flex-col items-start relative size-full" data-name="Broadcast Capability Development">
      <UnifiedCommunicationPlatform />
    </div>
  );
}