import { useState } from 'react';
import { MessageList } from './MessageList';
import { CreateMessageForm } from './CreateMessageForm';
import { MessagePreview } from './MessagePreview';
import { Plus } from 'lucide-react';

export interface BroadcastMessage {
  id: string;
  title: string;
  content: string;
  targetGroup: string;
  expirationPeriod: number;
  expirationUnit: 'hours' | 'days' | 'weeks';
  createdAt: Date;
  createdBy: string;
  status: 'active' | 'expired' | 'draft';
  acknowledgedCount: number;
  totalTargets: number;
  link?: string;
  branding?: 'default' | 'remediation';
}

export function BroadcastDashboard() {
  const [view, setView] = useState<'list' | 'create'>('list');
  const [previewMessage, setPreviewMessage] = useState<BroadcastMessage | null>(null);
  const [messages, setMessages] = useState<BroadcastMessage[]>([
    {
      id: '1',
      title: 'System Maintenance Notice',
      content: 'Scheduled maintenance will occur on Saturday from 2 AM to 6 AM EST. During this time, some services may be unavailable.',
      targetGroup: 'All Devices',
      expirationPeriod: 7,
      expirationUnit: 'days',
      createdAt: new Date('2024-11-28'),
      createdBy: 'admin@company.com',
      status: 'active',
      acknowledgedCount: 1247,
      totalTargets: 2500,
      branding: 'remediation'
    },
    {
      id: '2',
      title: 'Security Policy Update',
      content: 'Our security policies have been updated. Please review the new guidelines in the company portal.',
      targetGroup: 'Corporate Laptops',
      expirationPeriod: 14,
      expirationUnit: 'days',
      createdAt: new Date('2024-11-25'),
      createdBy: 'security@company.com',
      status: 'active',
      acknowledgedCount: 856,
      totalTargets: 1200,
      link: 'https://portal.company.com/security-policies',
      branding: 'remediation'
    },
    {
      id: '3',
      title: 'Holiday Schedule',
      content: 'Office closure dates for the upcoming holidays have been announced.',
      targetGroup: 'Remote Workers',
      expirationPeriod: 30,
      expirationUnit: 'days',
      createdAt: new Date('2024-11-20'),
      createdBy: 'hr@company.com',
      status: 'expired',
      acknowledgedCount: 445,
      totalTargets: 500,
      branding: 'default'
    }
  ]);

  const handleCreateMessage = (message: Omit<BroadcastMessage, 'id' | 'createdAt' | 'createdBy' | 'acknowledgedCount' | 'totalTargets'>) => {
    const newMessage: BroadcastMessage = {
      ...message,
      id: Date.now().toString(),
      createdAt: new Date(),
      createdBy: 'current.user@company.com',
      acknowledgedCount: 0,
      totalTargets: 0
    };
    setMessages([newMessage, ...messages]);
    setView('list');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-gray-900">Broadcast Message Center</h1>
              <p className="text-gray-600 mt-1">Send targeted communications to end-user devices</p>
            </div>
            {view === 'list' && (
              <button
                onClick={() => setView('create')}
                className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
              >
                <Plus className="w-5 h-5" />
                New Broadcast
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {view === 'list' ? (
          <MessageList 
            messages={messages} 
            onPreview={setPreviewMessage}
            onEdit={(message) => {
              // In a real app, this would open the edit form
              setPreviewMessage(message);
            }}
          />
        ) : (
          <CreateMessageForm 
            onSubmit={handleCreateMessage}
            onCancel={() => setView('list')}
            onPreview={setPreviewMessage}
          />
        )}
      </div>

      {/* Preview Modal */}
      {previewMessage && (
        <MessagePreview 
          message={previewMessage}
          onClose={() => setPreviewMessage(null)}
        />
      )}
    </div>
  );
}
