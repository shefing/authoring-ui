import { useState } from 'react';
import { Radio, CheckCircle, XCircle, Settings, ExternalLink } from 'lucide-react';

interface Channel {
  id: string;
  name: string;
  type: 'riverbed' | 'teams' | 'slack' | 'email';
  enabled: boolean;
  configured: boolean;
  supportedMessageTypes: string[];
  serverSideOnly: boolean;
  requiresAuth: boolean;
  description: string;
}

const initialChannels: Channel[] = [
  {
    id: '1',
    name: 'Riverbed Agent',
    type: 'riverbed',
    enabled: true,
    configured: true,
    supportedMessageTypes: ['survey', 'confirmation', 'notification', 'reminder'],
    serverSideOnly: false,
    requiresAuth: false,
    description: 'Native Riverbed agent communication via IOT. Primary channel for intrusive messages.'
  },
  {
    id: '2',
    name: 'Microsoft Teams',
    type: 'teams',
    enabled: true,
    configured: true,
    supportedMessageTypes: ['notification', 'self-service', 'reminder'],
    serverSideOnly: true,
    requiresAuth: true,
    description: 'Teams integration for non-intrusive messages and self-service chat. Supports server-only flows.'
  },
  {
    id: '3',
    name: 'Slack',
    type: 'slack',
    enabled: false,
    configured: false,
    supportedMessageTypes: ['notification', 'self-service'],
    serverSideOnly: true,
    requiresAuth: true,
    description: 'Slack workspace integration for collaborative notifications and support.'
  },
  {
    id: '4',
    name: 'Email',
    type: 'email',
    enabled: false,
    configured: false,
    supportedMessageTypes: ['notification', 'reminder'],
    serverSideOnly: true,
    requiresAuth: false,
    description: 'Email delivery for non-urgent notifications and reminders.'
  }
];

export function ChannelConfiguration() {
  const [channels, setChannels] = useState<Channel[]>(initialChannels);

  const toggleChannelStatus = (id: string) => {
    setChannels(channels.map(channel =>
      channel.id === id ? { ...channel, enabled: !channel.enabled } : channel
    ));
  };

  return (
    <div className="p-8">
      {/* Channel Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {channels.map((channel) => (
          <div 
            key={channel.id} 
            className={`bg-white rounded-lg border-2 transition-all cursor-pointer flex flex-col ${
              channel.enabled 
                ? 'border-blue-500 shadow-lg' 
                : 'border-gray-200 hover:border-gray-300'
            }`}
          >
            {/* Channel Header */}
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${
                    channel.enabled ? 'bg-blue-100' : 'bg-gray-100'
                  }`}>
                    <Radio className={`w-6 h-6 ${channel.enabled ? 'text-blue-600' : 'text-gray-400'}`} />
                  </div>
                  <div>
                    <h3 className="text-gray-900">{channel.name}</h3>
                    <p className="text-gray-500 text-sm mt-1 capitalize">{channel.type}</p>
                  </div>
                </div>
                <div className="flex flex-col items-end gap-2">
                  {channel.enabled ? (
                    <span className="flex items-center gap-1 text-green-600 text-sm">
                      <CheckCircle className="w-4 h-4" />
                      Enabled
                    </span>
                  ) : (
                    <span className="flex items-center gap-1 text-gray-400 text-sm">
                      <XCircle className="w-4 h-4" />
                      Disabled
                    </span>
                  )}
                  {channel.configured ? (
                    <span className="text-green-600 text-xs">Configured</span>
                  ) : (
                    <span className="text-orange-600 text-xs">Not Configured</span>
                  )}
                </div>
              </div>
            </div>

            {/* Channel Details */}
            <div className="p-6 space-y-4 flex-1">
              <p className="text-gray-700 text-sm">{channel.description}</p>

              {/* Capabilities */}
              <div>
                <p className="text-gray-600 text-sm mb-2">Capabilities</p>
                <div className="flex flex-wrap gap-2">
                  {channel.serverSideOnly && (
                    <span className="bg-purple-50 text-purple-700 px-2 py-1 rounded text-xs">
                      Server-Side Only
                    </span>
                  )}
                  {channel.requiresAuth && (
                    <span className="bg-orange-50 text-orange-700 px-2 py-1 rounded text-xs">
                      Requires OAuth
                    </span>
                  )}
                </div>
              </div>

              {/* Supported Message Types */}
              <div>
                <p className="text-gray-600 text-sm mb-2">Supported Message Types</p>
                <div className="flex flex-wrap gap-2">
                  {channel.supportedMessageTypes.map((type) => (
                    <span key={type} className="bg-gray-100 text-gray-700 px-2 py-1 rounded text-xs capitalize">
                      {type}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="px-6 py-4 bg-gray-50 border-t border-gray-200 flex items-center justify-between mt-auto">
              <button className="text-blue-600 hover:text-blue-800 flex items-center gap-1 text-sm">
                <Settings className="w-4 h-4" />
                Configure
              </button>
              {channel.requiresAuth && (
                <button className="text-gray-600 hover:text-gray-800 flex items-center gap-1 text-sm">
                  <ExternalLink className="w-4 h-4" />
                  OAuth Setup
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}