import { useState, useRef } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';
import { Label } from './ui/label';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { MessageType, Channel, DeliveryMode, Message } from './MessagesOverview';
import { AlertCircle, MessageSquare, Settings, Users, Zap, Plus, X, ListChecks, Eye, Check, Link2, Globe, Palette, Code, Bold, Italic, Underline, List, ListOrdered, Link } from 'lucide-react';
import { Template } from './TemplateManager';
import { BrandingLogo } from './UnifiedCommunicationPlatform';

interface CreateMessageDialogProps {
  open: boolean;
  onClose: () => void;
  onSubmit?: (messageData: any) => void;
  editMessage?: Message | null;
  templates?: Template[];
  brandingLogo?: BrandingLogo | null;
}

interface SurveyQuestion {
  id: string;
  text: string;
  type: 'open' | 'closed';
  required: boolean;
  options?: string[]; // For closed questions
}

interface MessageLink {
  id: string;
  text: string;
  url: string;
  type: 'primary' | 'secondary' | 'knowledge-base' | 'ticket';
  openInNewTab: boolean;
}

interface TranslationContent {
  language: string;
  messageTitle: string;
  messageContent: string;
  links: MessageLink[];
}

interface SecurityAlarm {
  id: string;
  title: string;
  severity: 'Critical' | 'High' | 'Medium' | 'Low';
  cve: string;
  description: string;
  affected: number;
  detectedAt: string;
}

interface RemediationAction {
  id: string;
  name: string;
  actionType: 'System' | 'Software' | 'Security' | 'Network' | 'Hardware';
  severity: 'Critical' | 'High' | 'Medium' | 'Low';
  application?: string;
  description: string;
  suggestedTitle: string;
  suggestedMessage: string;
  requiredActions: string[];
  estimatedTime: string;
  requiresReboot: boolean;
}

// Rich Text Formatting Toolbar Component
function FormattingToolbar({ onFormat }: { onFormat: (tag: string) => void }) {
  return (
    <div className="flex items-center gap-1 p-2 bg-gray-50 border border-gray-200 rounded-t-lg">
      <button
        type="button"
        onClick={() => onFormat('bold')}
        className="p-1.5 hover:bg-gray-200 rounded transition-colors"
        title="Bold"
      >
        <Bold className="w-4 h-4 text-gray-700" />
      </button>
      <button
        type="button"
        onClick={() => onFormat('italic')}
        className="p-1.5 hover:bg-gray-200 rounded transition-colors"
        title="Italic"
      >
        <Italic className="w-4 h-4 text-gray-700" />
      </button>
      <button
        type="button"
        onClick={() => onFormat('underline')}
        className="p-1.5 hover:bg-gray-200 rounded transition-colors"
        title="Underline"
      >
        <Underline className="w-4 h-4 text-gray-700" />
      </button>
      <div className="w-px h-6 bg-gray-300 mx-1" />
      <button
        type="button"
        onClick={() => onFormat('ul')}
        className="p-1.5 hover:bg-gray-200 rounded transition-colors"
        title="Bullet List"
      >
        <List className="w-4 h-4 text-gray-700" />
      </button>
      <button
        type="button"
        onClick={() => onFormat('ol')}
        className="p-1.5 hover:bg-gray-200 rounded transition-colors"
        title="Numbered List"
      >
        <ListOrdered className="w-4 h-4 text-gray-700" />
      </button>
      <div className="w-px h-6 bg-gray-300 mx-1" />
      <button
        type="button"
        onClick={() => onFormat('link')}
        className="p-1.5 hover:bg-gray-200 rounded transition-colors"
        title="Insert Link"
      >
        <Link className="w-4 h-4 text-gray-700" />
      </button>
      <div className="ml-auto text-xs text-gray-500">
        Select text to format
      </div>
    </div>
  );
}

export function CreateMessageDialog({ open, onClose, onSubmit, editMessage, templates = [], brandingLogo = null }: CreateMessageDialogProps) {
  const [currentStep, setCurrentStep] = useState(1);
  const [selectedAlarm, setSelectedAlarm] = useState<SecurityAlarm | null>(null);
  const [selectedRemediationAction, setSelectedRemediationAction] = useState<RemediationAction | null>(null);
  const [previewQuestionIndex, setPreviewQuestionIndex] = useState(0);
  
  // Refs for rich text editing
  const titleInputRef = useRef<HTMLInputElement>(null);
  const descriptionInputRef = useRef<HTMLInputElement>(null);
  const contentTextareaRef = useRef<HTMLTextAreaElement>(null);
  
  // Remediation Actions Database
  const remediationActions: RemediationAction[] = [
    {
      id: 'check-disk',
      name: 'Check Disk Diagnostic',
      actionType: 'System',
      severity: 'High',
      application: 'Windows System',
      description: 'Perform an offline Check Disk diagnostic to scan and fix file system errors',
      suggestedTitle: 'Action Required: Check Disk Diagnostic',
      suggestedMessage: 'Your system requires a Check Disk diagnostic to ensure file system integrity. This process will scan for and repair any errors on your hard drive.',
      requiredActions: [
        'Close all open applications',
        'Save your work',
        'System will restart automatically',
        'Process may take 15-30 minutes'
      ],
      estimatedTime: '15-30 minutes',
      requiresReboot: true
    },
    {
      id: 'memory-diagnostic',
      name: 'Windows Memory Diagnostic',
      actionType: 'Hardware',
      severity: 'Critical',
      application: 'Windows System',
      description: 'Run comprehensive memory diagnostic to detect RAM issues',
      suggestedTitle: 'Critical: Memory Diagnostic Required',
      suggestedMessage: 'Potential memory issues have been detected. Please run Windows Memory Diagnostic to identify and resolve RAM-related problems.',
      requiredActions: [
        'Save all work before proceeding',
        'System will restart to run diagnostic',
        'Do not interrupt the diagnostic process',
        'Review results after restart'
      ],
      estimatedTime: '20-45 minutes',
      requiresReboot: true
    },
    {
      id: 'update-drivers',
      name: 'Update Device Drivers',
      actionType: 'Software',
      severity: 'Medium',
      application: 'Device Manager',
      description: 'Update outdated device drivers to improve system stability and performance',
      suggestedTitle: 'Update Required: Device Drivers',
      suggestedMessage: 'Outdated device drivers have been detected on your system. Updating them will improve stability and performance.',
      requiredActions: [
        'Backup important data before updating',
        'Ensure stable internet connection',
        'Allow driver installation to complete',
        'Restart may be required'
      ],
      estimatedTime: '10-20 minutes',
      requiresReboot: false
    },
    {
      id: 'system-file-checker',
      name: 'System File Checker (SFC)',
      actionType: 'System',
      severity: 'High',
      application: 'Windows System',
      description: 'Scan and repair corrupted system files',
      suggestedTitle: 'System Repair Required',
      suggestedMessage: 'Corrupted system files have been detected. Running System File Checker will scan and repair these files to restore system stability.',
      requiredActions: [
        'Close all applications',
        'Diagnostic will run in background',
        'Do not shut down during scan',
        'Review scan results when complete'
      ],
      estimatedTime: '15-45 minutes',
      requiresReboot: false
    },
    {
      id: 'windows-security-update',
      name: 'Windows Security Update',
      actionType: 'Security',
      severity: 'Critical',
      application: 'Windows Update',
      description: 'Install critical security patches to protect against vulnerabilities',
      suggestedTitle: 'Critical Security Update Available',
      suggestedMessage: 'Important security updates are available for your system. Please install them immediately to protect against known vulnerabilities.',
      requiredActions: [
        'Save all work before installing',
        'Ensure power is connected',
        'Maintain internet connection',
        'System will restart automatically'
      ],
      estimatedTime: '10-25 minutes',
      requiresReboot: true
    },
    {
      id: 'clear-dns',
      name: 'Clear DNS Cache',
      actionType: 'Network',
      severity: 'Low',
      application: 'Network Services',
      description: 'Flush DNS cache to resolve connectivity issues',
      suggestedTitle: 'Network Optimization: Clear DNS Cache',
      suggestedMessage: 'Network connectivity issues have been detected. Clearing the DNS cache will refresh your network connections and improve performance.',
      requiredActions: [
        'Close web browsers',
        'DNS cache will be flushed',
        'Network may briefly disconnect',
        'Reconnect after completion'
      ],
      estimatedTime: '1-2 minutes',
      requiresReboot: false
    },
    {
      id: 'reset-network',
      name: 'Reset Network Adapters',
      actionType: 'Network',
      severity: 'Medium',
      application: 'Network Services',
      description: 'Reset network adapters to resolve persistent connection issues',
      suggestedTitle: 'Network Reset Required',
      suggestedMessage: 'Persistent network issues require a network adapter reset. This will restore your network settings to defaults and resolve connectivity problems.',
      requiredActions: [
        'Save all work',
        'Close network-dependent applications',
        'Wi-Fi passwords may need to be re-entered',
        'System restart required'
      ],
      estimatedTime: '5-10 minutes',
      requiresReboot: true
    },
    {
      id: 'disk-cleanup',
      name: 'Disk Cleanup and Optimization',
      actionType: 'System',
      severity: 'Low',
      application: 'Disk Cleanup',
      description: 'Remove temporary files and optimize disk space',
      suggestedTitle: 'Disk Optimization Recommended',
      suggestedMessage: 'Your system is running low on disk space. Running Disk Cleanup will remove temporary files and free up storage space.',
      requiredActions: [
        'Close unnecessary applications',
        'Review files to be deleted',
        'Cleanup process will run',
        'No restart required'
      ],
      estimatedTime: '10-15 minutes',
      requiresReboot: false
    },
    {
      id: 'browser-cache-clear',
      name: 'Clear Browser Cache',
      actionType: 'Software',
      severity: 'Low',
      application: 'Web Browsers',
      description: 'Clear browser cache to resolve web application issues',
      suggestedTitle: 'Browser Optimization Required',
      suggestedMessage: 'Web application issues have been detected. Clearing your browser cache will resolve loading problems and improve performance.',
      requiredActions: [
        'Close all browser windows',
        'Cache and cookies will be cleared',
        'You may need to re-login to websites',
        'Bookmarks will be preserved'
      ],
      estimatedTime: '2-5 minutes',
      requiresReboot: false
    },
    {
      id: 'antivirus-scan',
      name: 'Full Antivirus Scan',
      actionType: 'Security',
      severity: 'High',
      application: 'Windows Defender',
      description: 'Run comprehensive antivirus scan to detect and remove threats',
      suggestedTitle: 'Security Scan Required',
      suggestedMessage: 'A full system security scan is required to ensure your device is free from malware and threats.',
      requiredActions: [
        'Scan will run in background',
        'May slow system performance during scan',
        'Do not shut down during scan',
        'Review quarantined items after scan'
      ],
      estimatedTime: '30-60 minutes',
      requiresReboot: false
    }
  ];
  
  // Mock security alarms
  const securityAlarms: SecurityAlarm[] = [
    {
      id: '1',
      title: 'Remote Code Execution Vulnerability',
      severity: 'Critical',
      cve: 'CVE-2024-12345',
      description: 'Critical security vulnerability allows remote code execution through unsanitized input.',
      affected: 142,
      detectedAt: '2024-12-11 09:30 AM'
    },
    {
      id: '2',
      title: 'SQL Injection Attack Vector',
      severity: 'High',
      cve: 'CVE-2024-12346',
      description: 'Database vulnerability detected that could allow unauthorized data access.',
      affected: 87,
      detectedAt: '2024-12-11 08:15 AM'
    },
    {
      id: '3',
      title: 'Cross-Site Scripting (XSS) Vulnerability',
      severity: 'High',
      cve: 'CVE-2024-12347',
      description: 'XSS vulnerability found in user input fields allowing script injection.',
      affected: 203,
      detectedAt: '2024-12-11 07:00 AM'
    },
    {
      id: '4',
      title: 'Outdated SSL/TLS Certificate',
      severity: 'Medium',
      cve: 'CVE-2024-12348',
      description: 'SSL certificate approaching expiration, requires renewal to maintain secure connections.',
      affected: 56,
      detectedAt: '2024-12-10 03:45 PM'
    },
    {
      id: '5',
      title: 'Weak Password Policy Detected',
      severity: 'Low',
      cve: 'SEC-2024-001',
      description: 'User accounts with weak passwords detected, recommend enforcing stronger password requirements.',
      affected: 34,
      detectedAt: '2024-12-10 11:20 AM'
    }
  ];
  
  // Initialize form data with editMessage if provided, otherwise use defaults
  const getInitialFormData = () => ({
    name: editMessage?.name || '',
    description: '',
    type: editMessage?.type || 'notification' as MessageType,
    channel: editMessage?.channel || 'riverbed' as Channel,
    deliveryMode: editMessage?.deliveryMode || 'non-intrusive' as DeliveryMode,
    template: editMessage?.template || '',
    targetGroup: editMessage?.targetGroup || '',
    requiresResponse: editMessage?.requiresResponse || false,
    hasInteractiveFlow: editMessage?.hasInteractiveFlow || false,
    flowId: '',
    priority: 'normal' as 'low' | 'normal' | 'high' | 'critical',
    fatiguePrevention: true,
    vipHandling: false,
    scheduleType: 'immediate' as 'immediate' | 'scheduled' | 'recurring',
    scheduledDate: '',
    dynamicParams: [] as string[],
    surveyQuestions: [] as SurveyQuestion[],
    feedbackPrompt: '',
    reminderText: '',
    remediationAction: '',
    messageTitle: editMessage?.messageTitle || '', // Actual title shown to end users
    messageContent: editMessage?.messageContent || '', // Actual content shown to end users
    messageDescription: editMessage?.messageDescription || '', // Description shown to end users
    // Remediation-specific fields
    remediationActionId: '',
    remediationActionType: '',
    remediationSeverity: '',
    remediationApplication: '',
    remediationRequiredActions: [] as string[],
    remediationEstimatedTime: '',
    remediationRequiresReboot: false,
    // Advanced Features
    links: editMessage?.links || [] as MessageLink[],
    customCSS: editMessage?.customCSS || '',
    brandingProfile: (editMessage?.brandingProfile as 'default' | 'security' | 'it' | 'hr' | 'custom') || 'default',
    translations: [] as TranslationContent[],
    primaryLanguage: 'en' as string,
    enableAutoRouting: false,
    autoRoutingRules: {
      automaticFlows: 'riverbed' as Channel,
      selfServiceFlows: 'teams' as Channel,
      criticalAlerts: 'riverbed' as Channel,
    },
    // Template display configuration
    showHeader: editMessage?.showHeader !== undefined ? editMessage.showHeader : true,
    showDescription: editMessage?.showDescription !== undefined ? editMessage.showDescription : true,
    showBody: editMessage?.showBody !== undefined ? editMessage.showBody : true,
    showButton1: editMessage?.showButton1 || false,
    showButton2: editMessage?.showButton2 || false,
    showButton3: editMessage?.showButton3 || false,
    button1Type: (editMessage?.button1Type as 'primary' | 'secondary' | 'tertiary') || 'primary',
    button2Type: (editMessage?.button2Type as 'primary' | 'secondary' | 'tertiary') || 'secondary',
    button3Type: (editMessage?.button3Type as 'primary' | 'secondary' | 'tertiary') || 'tertiary',
    buttonPrimary: editMessage?.buttonPrimary || '',
    buttonSecondary: editMessage?.buttonSecondary || '',
    buttonTertiary: editMessage?.buttonTertiary || '',
    showLogo: editMessage?.showLogo !== undefined ? editMessage.showLogo : true,
    logoPosition: (editMessage?.logoPosition as 'top-left' | 'top-center' | 'top-right') || 'top-left',
  });

  const [formData, setFormData] = useState(getInitialFormData());
  const [contentTab, setContentTab] = useState<'title' | 'description' | 'body'>('title');

  const totalSteps = 4; // Reorganized: 1-Basic Config, 2-Template/Content, 3-Schedule, 4-Target Group & Final Review

  const handleChange = (field: string, value: any) => {
    setFormData(prev => {
      // If message type is changing, clear template and related fields
      if (field === 'type') {
        setPreviewQuestionIndex(0); // Reset preview when type changes
        return {
          ...prev,
          [field]: value,
          template: '',
          messageTitle: '',
          messageContent: '',
          reminderText: '',
          feedbackPrompt: '',
          remediationAction: '',
          surveyQuestions: []
        };
      }
      
      // If template is changing and it's a custom template, pre-populate fields
      if (field === 'template' && value.startsWith('custom-')) {
        setPreviewQuestionIndex(0);
        const templateId = value.replace('custom-', '');
        const selectedTemplate = templates.find(t => t.id === templateId);
        
        if (selectedTemplate) {
          return {
            ...prev,
            template: value,
            messageTitle: selectedTemplate.title || '',
            messageContent: selectedTemplate.body || '',
            messageDescription: selectedTemplate.messageDescription || '',
            brandingProfile: selectedTemplate.brandingProfile || 'default',
            customCSS: selectedTemplate.customCSS || '',
            // Template display configuration
            showHeader: selectedTemplate.showHeader !== undefined ? selectedTemplate.showHeader : true,
            showDescription: selectedTemplate.showDescription !== undefined ? selectedTemplate.showDescription : true,
            showBody: selectedTemplate.showBody !== undefined ? selectedTemplate.showBody : true,
            showButton1: selectedTemplate.showButton1 || false,
            showButton2: selectedTemplate.showButton2 || false,
            showButton3: selectedTemplate.showButton3 || false,
            buttonPrimary: selectedTemplate.buttonPrimary || '',
            buttonSecondary: selectedTemplate.buttonSecondary || '',
            buttonTertiary: selectedTemplate.buttonTertiary || '',
            showLogo: selectedTemplate.showLogo !== undefined ? selectedTemplate.showLogo : true,
            logoPosition: selectedTemplate.logoPosition || 'top-left',
          };
        }
      }
      
      // Reset preview when template changes
      if (field === 'template') {
        setPreviewQuestionIndex(0);
      }
      return { ...prev, [field]: value };
    });
  };

  // Handle remediation action selection with auto-population
  const handleRemediationActionSelect = (actionId: string) => {
    const action = remediationActions.find(a => a.id === actionId);
    
    if (action) {
      setSelectedRemediationAction(action);
      setFormData(prev => ({
        ...prev,
        remediationActionId: action.id,
        remediationAction: action.name,
        remediationActionType: action.actionType,
        remediationSeverity: action.severity,
        remediationApplication: action.application || '',
        remediationRequiredActions: action.requiredActions,
        remediationEstimatedTime: action.estimatedTime,
        remediationRequiresReboot: action.requiresReboot,
        // Auto-populate message title and content
        messageTitle: action.suggestedTitle,
        messageContent: action.suggestedMessage,
        reminderText: action.suggestedMessage,
      }));
    } else {
      setSelectedRemediationAction(null);
      setFormData(prev => ({
        ...prev,
        remediationActionId: '',
        remediationAction: '',
        remediationActionType: '',
        remediationSeverity: '',
        remediationApplication: '',
        remediationRequiredActions: [],
        remediationEstimatedTime: '',
        remediationRequiresReboot: false,
        messageTitle: '',
        messageContent: '',
        reminderText: '',
      }));
    }
  };

  // Survey question management functions
  const addSurveyQuestion = () => {
    const newQuestion: SurveyQuestion = {
      id: Date.now().toString(),
      text: '',
      type: 'open',
      required: false,
      options: []
    };
    setFormData(prev => ({
      ...prev,
      surveyQuestions: [...prev.surveyQuestions, newQuestion]
    }));
    // Reset preview to last question when adding new one
    setPreviewQuestionIndex(formData.surveyQuestions.length);
  };

  const removeSurveyQuestion = (id: string) => {
    setFormData(prev => ({
      ...prev,
      surveyQuestions: prev.surveyQuestions.filter(q => q.id !== id)
    }));
    // Reset preview to first question when removing
    setPreviewQuestionIndex(0);
  };

  const updateSurveyQuestion = (id: string, field: keyof SurveyQuestion, value: any) => {
    setFormData(prev => ({
      ...prev,
      surveyQuestions: prev.surveyQuestions.map(q =>
        q.id === id ? { ...q, [field]: value } : q
      )
    }));
  };

  const addQuestionOption = (questionId: string) => {
    setFormData(prev => ({
      ...prev,
      surveyQuestions: prev.surveyQuestions.map(q =>
        q.id === questionId 
          ? { ...q, options: [...(q.options || []), ''] }
          : q
      )
    }));
  };

  const updateQuestionOption = (questionId: string, optionIndex: number, value: string) => {
    setFormData(prev => ({
      ...prev,
      surveyQuestions: prev.surveyQuestions.map(q =>
        q.id === questionId
          ? { ...q, options: q.options?.map((opt, idx) => idx === optionIndex ? value : opt) }
          : q
      )
    }));
  };

  const removeQuestionOption = (questionId: string, optionIndex: number) => {
    setFormData(prev => ({
      ...prev,
      surveyQuestions: prev.surveyQuestions.map(q =>
        q.id === questionId
          ? { ...q, options: q.options?.filter((_, idx) => idx !== optionIndex) }
          : q
      )
    }));
  };

  // Link Management
  const addLink = () => {
    const newLink: MessageLink = {
      id: Date.now().toString(),
      text: '',
      url: '',
      type: 'primary',
      openInNewTab: true
    };
    setFormData(prev => ({
      ...prev,
      links: [...prev.links, newLink]
    }));
  };

  const removeLink = (id: string) => {
    setFormData(prev => ({
      ...prev,
      links: prev.links.filter(link => link.id !== id)
    }));
  };

  const updateLink = (id: string, field: keyof MessageLink, value: any) => {
    setFormData(prev => ({
      ...prev,
      links: prev.links.map(link =>
        link.id === id ? { ...link, [field]: value } : link
      )
    }));
  };

  // Translation Management
  const addTranslation = () => {
    const newTranslation: TranslationContent = {
      language: '',
      messageTitle: '',
      messageContent: '',
      links: []
    };
    setFormData(prev => ({
      ...prev,
      translations: [...prev.translations, newTranslation]
    }));
  };

  const removeTranslation = (index: number) => {
    setFormData(prev => ({
      ...prev,
      translations: prev.translations.filter((_, idx) => idx !== index)
    }));
  };

  const updateTranslation = (index: number, field: keyof TranslationContent, value: any) => {
    setFormData(prev => ({
      ...prev,
      translations: prev.translations.map((trans, idx) =>
        idx === index ? { ...trans, [field]: value } : trans
      )
    }));
  };

  const handleNext = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSubmit = () => {
    onSubmit?.(formData);
    handleClose();
  };

  const handleClose = () => {
    setFormData(getInitialFormData());
    setCurrentStep(1);
    setPreviewQuestionIndex(0);
    onClose();
  };

  const isStepValid = () => {
    switch (currentStep) {
      case 1:
        return formData.name.trim() !== '' && formData.type && formData.channel;
      case 2:
        return formData.template !== '';
      case 3:
        return true; // Schedule step - always optional
      case 4:
        return formData.targetGroup.trim() !== ''; // Target Group & Final Review - requires target group
      default:
        return false;
    }
  };

  // Helper to render links in preview
  const renderPreviewLinks = () => {
    if (formData.links.length === 0) return null;
    
    return (
      <div className="flex flex-col gap-2">
        {formData.links.map((link, idx) => {
          const linkTypeStyles = {
            'primary': 'bg-purple-700 text-white hover:bg-purple-800',
            'secondary': 'bg-gray-200 text-gray-800 hover:bg-gray-300',
            'knowledge-base': 'bg-blue-100 text-blue-700 hover:bg-blue-200 border border-blue-300',
            'ticket': 'bg-orange-100 text-orange-700 hover:bg-orange-200 border border-orange-300'
          };
          
          return (
            <button
              key={idx}
              className={`w-full px-3 py-2 rounded text-xs transition-colors ${linkTypeStyles[link.type] || linkTypeStyles.secondary}`}
            >
              {link.text || 'Link'}
            </button>
          );
        })}
      </div>
    );
  };

  // Helper to wrap selected text with formatting tags
  const applyFormatting = (field: string, tag: string, textareaRef?: HTMLTextAreaElement | HTMLInputElement | null) => {
    if (!textareaRef) return;
    
    const start = textareaRef.selectionStart || 0;
    const end = textareaRef.selectionEnd || 0;
    const text = formData[field as keyof typeof formData] as string || '';
    const selectedText = text.substring(start, end);
    
    let newText = '';
    let newCursorPos = start;
    
    if (tag === 'bold') {
      newText = text.substring(0, start) + '<strong>' + selectedText + '</strong>' + text.substring(end);
      newCursorPos = start + 8; // length of '<strong>'
    } else if (tag === 'italic') {
      newText = text.substring(0, start) + '<em>' + selectedText + '</em>' + text.substring(end);
      newCursorPos = start + 4; // length of '<em>'
    } else if (tag === 'underline') {
      newText = text.substring(0, start) + '<u>' + selectedText + '</u>' + text.substring(end);
      newCursorPos = start + 3; // length of '<u>'
    } else if (tag === 'link') {
      const url = prompt('Enter URL:');
      if (url) {
        newText = text.substring(0, start) + '<a href="' + url + '">' + (selectedText || 'Link') + '</a>' + text.substring(end);
        newCursorPos = start + 9 + url.length; // length of '<a href="URL">'
      } else {
        return;
      }
    } else if (tag === 'ul') {
      newText = text.substring(0, start) + '<ul>\n  <li>' + (selectedText || 'List item') + '</li>\n</ul>' + text.substring(end);
      newCursorPos = start + 10; // position after '<ul>\n  <li>'
    } else if (tag === 'ol') {
      newText = text.substring(0, start) + '<ol>\n  <li>' + (selectedText || 'List item') + '</li>\n</ol>' + text.substring(end);
      newCursorPos = start + 10; // position after '<ol>\n  <li>'
    }
    
    handleChange(field, newText);
    
    // Restore cursor position after state update
    setTimeout(() => {
      if (textareaRef) {
        textareaRef.focus();
        textareaRef.setSelectionRange(newCursorPos, newCursorPos);
      }
    }, 0);
  };

  // Render template preview based on selected template
  const renderTemplatePreview = () => {
    if (!formData.template) return null;

    const getPreviewContent = () => {
      // Feedback Survey Preview
      if (formData.template === 'feedback-survey') {
        return (
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 space-y-4 max-w-sm mx-auto">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="inline-block px-2.5 py-0.5 bg-purple-100 text-purple-700 rounded-full text-xs mb-2">
                  Feedback Survey
                </div>
                <h4 className="text-gray-900 text-sm">{formData.messageTitle || 'Feedback Survey'}</h4>
                {formData.messageContent && (
                  <p className="text-xs text-gray-600 mt-1 mb-1">{formData.messageContent}</p>
                )}
                <p className="text-xs text-gray-700 mt-1">
                  {formData.feedbackPrompt || 'How satisfied are you with this?'}
                </p>
              </div>
              <button className="text-gray-400 p-1">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex items-center justify-between px-2">
              {['😊', '🙂', '😐', '🙁', '😞'].map((emoji, idx) => (
                <button
                  key={idx}
                  className="flex flex-col items-center gap-1 p-1.5 rounded hover:bg-gray-50 transition-colors"
                >
                  <span className="text-xl">{emoji}</span>
                </button>
              ))}
            </div>
            <div className="text-xs text-gray-500 text-center">Powered by Riverbed</div>
          </div>
        );
      }

      // Single Step Survey Preview
      if (formData.template === 'single-step-survey') {
        const question = formData.surveyQuestions[0];
        const options = question?.options || ['Option 1', 'Option 2', 'Option 3'];
        
        return (
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 space-y-4 max-w-sm mx-auto">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="inline-block px-2.5 py-0.5 bg-purple-100 text-purple-700 rounded-full text-xs mb-2">
                  Quick Survey
                </div>
                <h4 className="text-gray-900 text-sm">{formData.messageTitle || 'Survey'}</h4>
                {formData.messageContent && (
                  <p className="text-xs text-gray-600 mt-1">{formData.messageContent}</p>
                )}
              </div>
              <button className="text-gray-400 p-1">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2">
              <label className="text-xs text-gray-900">
                {question?.text || 'Your survey question here'}
              </label>
              {question?.type === 'closed' ? (
                <div className="space-y-1.5">
                  {options.slice(0, 4).map((option, idx) => (
                    <button
                      key={idx}
                      className="w-full text-left px-3 py-2 rounded border border-gray-300 hover:border-gray-400 bg-white transition-colors text-xs"
                    >
                      {option || `Option ${idx + 1}`}
                    </button>
                  ))}
                </div>
              ) : (
                <textarea
                  placeholder="Type your answer..."
                  className="w-full px-3 py-2 border border-gray-300 rounded text-xs"
                  rows={3}
                  disabled
                />
              )}
            </div>

            <button className="w-full px-3 py-2 bg-purple-700 text-white rounded text-xs hover:bg-purple-800 transition-colors">
              Submit Response
            </button>
            <div className="text-xs text-gray-500 text-center">Powered by Riverbed</div>
          </div>
        );
      }

      // Multi-step Survey Preview (Interactive)
      if (formData.template === 'multi-step-survey') {
        const currentQuestion = formData.surveyQuestions[previewQuestionIndex];
        const totalQuestions = formData.surveyQuestions.length;
        const isFirstQuestion = previewQuestionIndex === 0;
        const isLastQuestion = previewQuestionIndex === totalQuestions - 1;
        
        return (
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 space-y-4 max-w-sm mx-auto">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="inline-block px-2.5 py-0.5 bg-purple-100 text-purple-700 rounded-full text-xs mb-2">
                  Survey
                </div>
                <h4 className="text-gray-900 text-sm">{formData.messageTitle || 'Survey'}</h4>
                {formData.messageContent && (
                  <p className="text-xs text-gray-600 mt-1">{formData.messageContent}</p>
                )}
              </div>
              <button className="text-gray-400 p-1">
                <X className="w-4 h-4" />
              </button>
            </div>

            {currentQuestion ? (
              <>
                {/* Progress Indicator */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-purple-700">Question {previewQuestionIndex + 1} of {totalQuestions}</span>
                    <span className="text-xs text-gray-500">{Math.round(((previewQuestionIndex + 1) / totalQuestions) * 100)}% complete</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-1.5">
                    <div 
                      className="bg-purple-600 h-1.5 rounded-full transition-all duration-300"
                      style={{ width: `${((previewQuestionIndex + 1) / totalQuestions) * 100}%` }}
                    ></div>
                  </div>
                </div>

                {/* Question */}
                <div className="space-y-2">
                  <div className="flex items-start justify-between">
                    <label className="text-sm text-gray-900">
                      {currentQuestion.text || `Question ${previewQuestionIndex + 1}`}
                      {currentQuestion.required && <span className="text-red-500 ml-1">*</span>}
                    </label>
                  </div>
                  {currentQuestion.type === 'closed' && currentQuestion.options && currentQuestion.options.length > 0 ? (
                    <div className="space-y-1.5">
                      {currentQuestion.options.map((option, idx) => (
                        <button
                          key={idx}
                          className="w-full text-left px-3 py-2 rounded border border-gray-300 hover:border-purple-400 hover:bg-purple-50 bg-white transition-colors text-xs"
                        >
                          {option || `Option ${idx + 1}`}
                        </button>
                      ))}
                    </div>
                  ) : (
                    <textarea
                      placeholder="Type your answer..."
                      className="w-full px-3 py-2 border border-gray-300 rounded text-xs focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                      rows={3}
                      disabled
                    />
                  )}
                </div>

                {/* Navigation Buttons */}
                <div className="flex gap-2">
                  {!isFirstQuestion && (
                    <button 
                      onClick={() => setPreviewQuestionIndex(prev => Math.max(0, prev - 1))}
                      className="flex-1 px-3 py-2 bg-gray-100 text-gray-700 rounded text-xs hover:bg-gray-200 transition-colors"
                    >
                      ← Previous
                    </button>
                  )}
                  <button 
                    onClick={() => {
                      if (!isLastQuestion) {
                        setPreviewQuestionIndex(prev => Math.min(totalQuestions - 1, prev + 1));
                      }
                    }}
                    className="flex-1 px-3 py-2 bg-purple-700 text-white rounded text-xs hover:bg-purple-800 transition-colors"
                  >
                    {isLastQuestion ? 'Submit Survey' : 'Next Question →'}
                  </button>
                </div>
              </>
            ) : (
              <p className="text-xs text-gray-500 text-center py-4">No questions configured yet</p>
            )}

            <div className="text-xs text-gray-500 text-center">Powered by Riverbed</div>
          </div>
        );
      }

      // Remediation Confirmation Preview
      if (formData.template === 'remediation-confirmation' || formData.template === 'action-confirmation') {
        return (
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 space-y-3 max-w-sm mx-auto">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="inline-block px-2.5 py-0.5 bg-orange-100 text-orange-700 rounded-full text-xs mb-2">
                  Action Required
                </div>
                <h4 className="text-gray-900 text-sm">{formData.messageTitle || 'Confirmation Required'}</h4>
                <p className="text-xs text-gray-700 mt-1">
                  {formData.messageContent || 'Please confirm the remediation action to resolve the detected issue.'}
                </p>
              </div>
              <button className="text-gray-400 p-1">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="bg-gray-50 border border-gray-200 rounded p-2 text-xs">
              <p className="text-gray-600">Action:</p>
              <p className="text-gray-900">System Remediation</p>
            </div>

            <div className="flex gap-2">
              <button className="flex-1 px-3 py-2 bg-gray-100 text-gray-700 rounded text-xs hover:bg-gray-200 transition-colors">
                Decline
              </button>
              <button className="flex-1 px-3 py-2 bg-purple-700 text-white rounded text-xs hover:bg-purple-800 transition-colors">
                Confirm
              </button>
            </div>
            {renderPreviewLinks()}
            <div className="text-xs text-gray-500 text-center">Powered by Riverbed</div>
          </div>
        );
      }

      // Notification Preview
      if (formData.template.includes('notification') || formData.template.includes('alert')) {
        // Success Notification
        if (formData.template === 'success-notification') {
          return (
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 space-y-3 max-w-sm mx-auto">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="inline-block px-2.5 py-0.5 bg-green-100 text-green-700 rounded-full text-xs mb-2">
                    ✓ Success
                  </div>
                  <h4 className="text-gray-900 text-sm">{formData.messageTitle || 'Success Notification'}</h4>
                  <p className="text-xs text-gray-700 mt-1">
                    {formData.messageContent || 'Your system has been successfully updated to the latest version. All security patches have been applied.'}
                  </p>
                </div>
                <button className="text-gray-400 p-1">
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="bg-green-50 border border-green-200 rounded p-2">
                <div className="flex items-center gap-2 text-xs text-green-700">
                  <Check className="w-3.5 h-3.5" />
                  <span>Operation completed successfully</span>
                </div>
              </div>

              <div className="flex items-center gap-2 text-xs text-gray-500">
                <span>Just now</span>
                <span>•</span>
                <span className="capitalize">Via {formData.channel}</span>
              </div>

              {formData.links.length === 0 ? (
                <button className="w-full px-3 py-2 bg-gray-100 text-gray-700 rounded text-xs hover:bg-gray-200 transition-colors">
                  Dismiss
                </button>
              ) : (
                <>
                  {renderPreviewLinks()}
                  <button className="w-full px-3 py-2 bg-gray-100 text-gray-700 rounded text-xs hover:bg-gray-200 transition-colors">
                    Dismiss
                  </button>
                </>
              )}
              <div className="text-xs text-gray-500 text-center">Powered by Riverbed</div>
            </div>
          );
        }

        // Security Alert
        if (formData.template === 'security-alert') {
          const getSeverityColor = (severity: string) => {
            switch (severity) {
              case 'Critical': return 'text-red-900 bg-red-100';
              case 'High': return 'text-red-700 bg-red-50';
              case 'Medium': return 'text-orange-700 bg-orange-50';
              case 'Low': return 'text-yellow-700 bg-yellow-50';
              default: return 'text-gray-700 bg-gray-50';
            }
          };

          const alarm = selectedAlarm;
          
          return (
            <div className="bg-white rounded-lg shadow-sm border-l-4 border-red-500 p-4 space-y-3 max-w-sm mx-auto">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="inline-block px-2.5 py-0.5 bg-red-100 text-red-700 rounded-full text-xs mb-2">
                    🛡️ Security Alert
                  </div>
                  <h4 className="text-gray-900 text-sm">
                    {formData.messageTitle || alarm?.title || 'Security Alert - Engineering'}
                  </h4>
                  <p className="text-xs text-gray-700 mt-1">
                    {formData.messageContent || alarm?.description || 'Critical security vulnerability detected on your device. Immediate attention required to maintain system security.'}
                  </p>
                </div>
                <button className="text-gray-400 p-1">
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="bg-red-50 border border-red-200 rounded p-2 space-y-1">
                <div className="flex items-center gap-2 text-xs">
                  <AlertCircle className="w-3.5 h-3.5 text-red-700" />
                  <span className={`px-2 py-0.5 rounded ${getSeverityColor(alarm?.severity || 'High')}`}>
                    Severity: {alarm?.severity || 'High'}
                  </span>
                </div>
                <p className="text-xs text-red-600 pl-5">
                  {alarm?.cve || 'CVE-2024-12345'} - {alarm?.title || 'Remote Code Execution'}
                </p>
                {alarm && (
                  <p className="text-xs text-gray-600 pl-5">
                    {alarm.affected} devices affected • Detected {alarm.detectedAt}
                  </p>
                )}
              </div>

              <div className="flex items-center gap-2 text-xs text-gray-500">
                <span>Just now</span>
                <span>•</span>
                <span className="capitalize">Via {formData.channel}</span>
              </div>

              <div className="flex gap-2">
                <button className="flex-1 px-3 py-2 bg-gray-100 text-gray-700 rounded text-xs hover:bg-gray-200 transition-colors">
                  Learn More
                </button>
                <button className="flex-1 px-3 py-2 bg-red-600 text-white rounded text-xs hover:bg-red-700 transition-colors">
                  Fix Now
                </button>
              </div>
              <div className="text-xs text-gray-500 text-center">Powered by Riverbed</div>
            </div>
          );
        }

        // Information Notification (default)
        return (
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 space-y-3 max-w-sm mx-auto">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="inline-block px-2.5 py-0.5 bg-blue-100 text-blue-700 rounded-full text-xs mb-2">
                  ℹ️ Information
                </div>
                <h4 className="text-gray-900 text-sm">{formData.messageTitle || 'Information Notification'}</h4>
                <p className="text-xs text-gray-700 mt-1">
                  {formData.messageContent || 'System maintenance is scheduled for this weekend. Your device will automatically update during off-hours.'}
                </p>
              </div>
              <button className="text-gray-400 p-1">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded p-2">
              <div className="flex items-center gap-2 text-xs text-blue-700">
                <span>📅</span>
                <span>Scheduled: Saturday, Dec 14 at 11:00 PM</span>
              </div>
            </div>

            <div className="flex items-center gap-2 text-xs text-gray-500">
              <span>Just now</span>
              <span>•</span>
              <span className="capitalize">Via {formData.channel}</span>
            </div>

            <button className="w-full px-3 py-2 bg-gray-100 text-gray-700 rounded text-xs hover:bg-gray-200 transition-colors">
              Dismiss
            </button>
            <div className="text-xs text-gray-500 text-center">Powered by Riverbed</div>
          </div>
        );
      }

      // Remediation Reminder Preview
      if (formData.template === 'remediation-reminder') {
        return (
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 space-y-3 max-w-sm mx-auto">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="inline-block px-2.5 py-0.5 bg-yellow-100 text-yellow-700 rounded-full text-xs mb-2">
                  Remediation Reminder
                </div>
                <h4 className="text-gray-900 text-sm">{formData.name || 'Remediation Reminder'}</h4>
                <p className="text-xs text-gray-700 mt-1">
                  {formData.reminderText || 'Please complete the required remediation action'}
                </p>
              </div>
              <button className="text-gray-400 p-1">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="bg-red-50 border border-red-200 rounded p-2 space-y-1">
              <div className="flex items-center gap-2 text-xs text-red-700">
                <span>⚠️</span>
                <span>Issue: Security vulnerability detected</span>
              </div>
              <p className="text-xs text-red-600 pl-5">Action required by 2:00 PM today</p>
            </div>

            <div className="flex gap-2">
              <button className="flex-1 px-3 py-2 bg-gray-100 text-gray-700 rounded text-xs hover:bg-gray-200 transition-colors">
                Remind in 1 hour
              </button>
              <button className="flex-1 px-3 py-2 bg-purple-700 text-white rounded text-xs hover:bg-purple-800 transition-colors">
                Remediate Now
              </button>
            </div>
            <div className="text-xs text-gray-500 text-center">Powered by Riverbed</div>
          </div>
        );
      }

      // VIP Reminder Preview
      if (formData.template === 'vip-reminder') {
        return (
          <div className="bg-gradient-to-br from-purple-50 to-blue-50 rounded-lg shadow-md border-2 border-purple-300 p-4 space-y-3 max-w-sm mx-auto">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <div className="inline-block px-2.5 py-0.5 bg-gradient-to-r from-purple-100 to-blue-100 text-purple-800 rounded-full text-xs">
                    ⭐ VIP Priority
                  </div>
                </div>
                <h4 className="text-gray-900">{formData.name || 'VIP Reminder'}</h4>
                <p className="text-xs text-gray-700 mt-1">
                  {formData.reminderText || 'Your priority action requires attention'}
                </p>
              </div>
              <button className="text-gray-400 p-1">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="bg-white border border-purple-200 rounded p-2">
              <p className="text-xs text-gray-600">Priority Support Available</p>
              <p className="text-xs text-purple-700">Contact: VIP-Support@riverbed.com</p>
            </div>

            <div className="flex gap-2">
              <button className="flex-1 px-3 py-2 bg-white border border-purple-300 text-purple-700 rounded text-xs hover:bg-purple-50 transition-colors">
                Defer (1 day)
              </button>
              <button className="flex-1 px-3 py-2 bg-gradient-to-r from-purple-700 to-purple-600 text-white rounded text-xs hover:from-purple-800 hover:to-purple-700 transition-colors">
                Take Action
              </button>
            </div>
            <div className="text-xs text-gray-500 text-center">Powered by Riverbed</div>
          </div>
        );
      }

      // Deadline Reminder Preview
      if (formData.template === 'deadline-reminder') {
        return (
          <div className="bg-white rounded-lg shadow-sm border-l-4 border-orange-500 p-4 space-y-3 max-w-sm mx-auto">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="inline-block px-2.5 py-0.5 bg-orange-100 text-orange-700 rounded-full text-xs mb-2">
                  ⏰ Deadline Approaching
                </div>
                <h4 className="text-gray-900 text-sm">{formData.name || 'Deadline Reminder'}</h4>
                <p className="text-xs text-gray-700 mt-1">
                  {formData.reminderText || 'Complete your action before the deadline'}
                </p>
              </div>
              <button className="text-gray-400 p-1">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="bg-gradient-to-r from-orange-50 to-red-50 border border-orange-200 rounded p-3 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs text-gray-700">Time Remaining:</span>
                <span className="text-sm text-orange-700">4 hours 23 mins</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-1.5">
                <div className="bg-gradient-to-r from-orange-500 to-red-500 h-1.5 rounded-full" style={{ width: '75%' }}></div>
              </div>
              <p className="text-xs text-orange-700">Due: Today at 5:00 PM</p>
            </div>

            <div className="flex gap-2">
              <button className="flex-1 px-3 py-2 bg-gray-100 text-gray-700 rounded text-xs hover:bg-gray-200 transition-colors">
                Snooze
              </button>
              <button className="flex-1 px-3 py-2 bg-orange-600 text-white rounded text-xs hover:bg-orange-700 transition-colors">
                Complete Now
              </button>
            </div>
            <div className="text-xs text-gray-500 text-center">Powered by Riverbed</div>
          </div>
        );
      }

      // Self-Service Preview
      if (formData.template.includes('self-service') || formData.template.includes('chat') || formData.template.includes('troubleshooting') || formData.template.includes('knowledge')) {
        // Chat Interface
        if (formData.template === 'chat-interface') {
          return (
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 space-y-3 max-w-sm mx-auto">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="inline-block px-2.5 py-0.5 bg-green-100 text-green-700 rounded-full text-xs mb-2">
                    💬 Live Chat
                  </div>
                  <h4 className="text-gray-900 text-sm">{formData.messageTitle || 'Chat Interface'}</h4>
                  <p className="text-xs text-gray-700 mt-1">
                    {formData.messageContent || 'Get instant help from our support team.'}
                  </p>
                </div>
                <button className="text-gray-400 p-1">
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="bg-gray-50 rounded-lg p-3 space-y-2">
                <div className="flex items-start gap-2">
                  <div className="w-6 h-6 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-xs">🤖</span>
                  </div>
                  <div className="flex-1 bg-white rounded p-2 text-xs text-gray-700">
                    Hi! How can I help you today?
                  </div>
                </div>
              </div>

              <div className="flex gap-2">
                <input 
                  type="text" 
                  placeholder="Type your message..." 
                  className="flex-1 px-3 py-2 border border-gray-300 rounded text-xs"
                  disabled
                />
                <button className="px-3 py-2 bg-purple-700 text-white rounded text-xs hover:bg-purple-800 transition-colors">
                  Send
                </button>
              </div>
              <div className="text-xs text-gray-500 text-center">Powered by Riverbed</div>
            </div>
          );
        }

        // Troubleshooting Guide
        if (formData.template === 'troubleshooting-guide') {
          return (
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 space-y-3 max-w-sm mx-auto">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="inline-block px-2.5 py-0.5 bg-orange-100 text-orange-700 rounded-full text-xs mb-2">
                    🔧 Troubleshooting
                  </div>
                  <h4 className="text-gray-900 text-sm">{formData.messageTitle || 'Troubleshooting Guide'}</h4>
                  <p className="text-xs text-gray-700 mt-1">
                    {formData.messageContent || 'Follow these steps to resolve the issue.'}
                  </p>
                </div>
                <button className="text-gray-400 p-1">
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-2">
                <div className="bg-gray-50 border border-gray-200 rounded p-2 space-y-1">
                  <div className="flex items-start gap-2">
                    <div className="w-5 h-5 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <span className="text-xs">1</span>
                    </div>
                    <p className="text-xs text-gray-700">Check your network connection</p>
                  </div>
                </div>
                <div className="bg-gray-50 border border-gray-200 rounded p-2 space-y-1">
                  <div className="flex items-start gap-2">
                    <div className="w-5 h-5 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <span className="text-xs">2</span>
                    </div>
                    <p className="text-xs text-gray-700">Restart the application</p>
                  </div>
                </div>
                <div className="bg-gray-50 border border-gray-200 rounded p-2 space-y-1">
                  <div className="flex items-start gap-2">
                    <div className="w-5 h-5 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <span className="text-xs">3</span>
                    </div>
                    <p className="text-xs text-gray-700">Contact support if issue persists</p>
                  </div>
                </div>
              </div>

              <button className="w-full px-3 py-2 bg-gray-100 text-gray-700 rounded text-xs hover:bg-gray-200 transition-colors">
                Mark as Resolved
              </button>
              <div className="text-xs text-gray-500 text-center">Powered by Riverbed</div>
            </div>
          );
        }

        // Knowledge Base Article (default)
        return (
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 space-y-3 max-w-sm mx-auto">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="inline-block px-2.5 py-0.5 bg-blue-100 text-blue-700 rounded-full text-xs mb-2">
                  📚 Knowledge Base
                </div>
                <h4 className="text-gray-900 text-sm">{formData.messageTitle || 'Knowledge Base Article'}</h4>
                <p className="text-xs text-gray-700 mt-1">
                  {formData.messageContent || 'Learn more about this topic.'}
                </p>
              </div>
              <button className="text-gray-400 p-1">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded p-3 space-y-2">
              <p className="text-xs text-gray-700">
                <strong>Quick Summary:</strong> This article provides detailed information and best practices.
              </p>
              <div className="flex items-center gap-2 text-xs text-blue-600">
                <span>⏱️ 5 min read</span>
                <span>•</span>
                <span>Last updated: Dec 2024</span>
              </div>
            </div>

            <div className="space-y-1.5">
              <button className="w-full text-left px-3 py-2 bg-gray-50 hover:bg-gray-100 border border-gray-200 rounded transition-colors">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-gray-900">Overview</span>
                  <span className="text-gray-400">→</span>
                </div>
              </button>
              <button className="w-full text-left px-3 py-2 bg-gray-50 hover:bg-gray-100 border border-gray-200 rounded transition-colors">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-gray-900">Common Issues</span>
                  <span className="text-gray-400">→</span>
                </div>
              </button>
              <button className="w-full text-left px-3 py-2 bg-gray-50 hover:bg-gray-100 border border-gray-200 rounded transition-colors">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-gray-900">Related Articles</span>
                  <span className="text-gray-400">→</span>
                </div>
              </button>
            </div>

            <button className="w-full px-3 py-2 bg-purple-700 text-white rounded text-xs hover:bg-purple-800 transition-colors">
              Read Full Article
            </button>
            <div className="text-xs text-gray-500 text-center">Powered by Riverbed</div>
          </div>
        );
      }

      return null;
    };

    const previewContent = getPreviewContent();
    if (!previewContent) return null;

    // Apply branding profile styles
    const getBrandingStyles = () => {
      const baseStyles = "border border-blue-200 rounded-lg p-4 space-y-3";
      
      switch (formData.brandingProfile) {
        case 'security':
          return `${baseStyles} bg-gradient-to-br from-red-50 to-orange-50`;
        case 'it':
          return `${baseStyles} bg-gradient-to-br from-blue-50 to-cyan-50`;
        case 'hr':
          return `${baseStyles} bg-gradient-to-br from-green-50 to-emerald-50`;
        case 'custom':
          return baseStyles; // Custom CSS will be applied inline
        default:
          return `${baseStyles} bg-gradient-to-br from-blue-50 to-purple-50`;
      }
    };

    const getBrandingColor = () => {
      switch (formData.brandingProfile) {
        case 'security':
          return { border: 'border-red-200', text: 'text-red-900', subtitle: 'text-red-700' };
        case 'it':
          return { border: 'border-blue-200', text: 'text-blue-900', subtitle: 'text-blue-700' };
        case 'hr':
          return { border: 'border-green-200', text: 'text-green-900', subtitle: 'text-green-700' };
        default:
          return { border: 'border-blue-200', text: 'text-blue-900', subtitle: 'text-blue-700' };
      }
    };

    const brandingColors = getBrandingColor();

    return (
      <div className={getBrandingStyles()} style={formData.brandingProfile === 'custom' && formData.customCSS ? { cssText: formData.customCSS } : undefined}>
        <div className={`flex items-center gap-2 ${brandingColors.text}`}>
          <Eye className="w-4 h-4" />
          <h4 className="text-sm">Live Preview</h4>
          {formData.brandingProfile !== 'default' && (
            <span className="ml-auto text-xs px-2 py-0.5 bg-white rounded-full border">
              {formData.brandingProfile === 'custom' ? '🎨 Custom CSS' : `${formData.brandingProfile.toUpperCase()} Theme`}
            </span>
          )}
        </div>
        <p className={`text-xs ${brandingColors.subtitle}`}>
          This is how end users will see this message
          {formData.translations.length > 0 && ` (showing ${formData.primaryLanguage.toUpperCase()} version)`}
        </p>
        {previewContent}
      </div>
    );
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-[80vw] w-[80vw] max-h-[90vh] overflow-y-auto top-[5%] -translate-y-0">
        <DialogHeader>
          <DialogTitle>{editMessage ? 'Edit Message' : 'Create New Message'}</DialogTitle>
          <DialogDescription>
            {editMessage 
              ? 'Update your message configuration, template, delivery channel, and targeting rules'
              : 'Configure a new end-user communication with template, delivery channel, and targeting rules'}
          </DialogDescription>
        </DialogHeader>

        {/* Progress Steps */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            {[1, 2, 3, 4].map((step) => (
              <div key={step} className="flex items-center flex-1">
                <div className={`flex items-center justify-center w-8 h-8 rounded-full border-2 transition-colors ${
                  step === currentStep 
                    ? 'border-purple-900 bg-purple-900 text-white' 
                    : step < currentStep 
                    ? 'border-purple-900 bg-purple-900 text-white' 
                    : 'border-gray-300 bg-white text-gray-400'
                }`}>
                  <span className="text-sm">{step}</span>
                </div>
                {step < 4 && (
                  <div className={`h-0.5 flex-1 mx-2 ${
                    step < currentStep ? 'bg-purple-900' : 'bg-gray-300'
                  }`} />
                )}
              </div>
            ))}
          </div>
          <div className="flex items-center justify-between text-xs">
            <span className={`flex-1 text-center ${currentStep === 1 ? 'text-purple-900 font-medium' : 'text-gray-500'}`}>
              Basic Config
            </span>
            <span className={`flex-1 text-center ${currentStep === 2 ? 'text-purple-900 font-medium' : 'text-gray-500'}`}>
              Template & Content
            </span>
            <span className={`flex-1 text-center ${currentStep === 3 ? 'text-purple-900 font-medium' : 'text-gray-500'}`}>
              Schedule
            </span>
            <span className={`flex-1 text-center ${currentStep === 4 ? 'text-purple-900 font-medium' : 'text-gray-500'}`}>
              Target & Review
            </span>
          </div>
        </div>

        {/* Step Content */}
        <div className="space-y-4">
          {/* Step 1: Basic Configuration */}
          {currentStep === 1 && (
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-gray-900 mb-4">
                <MessageSquare className="w-5 h-5 text-blue-600" />
                <h3>Basic Configuration</h3>
              </div>

              <div className="space-y-2">
                <Label htmlFor="name">Message Name *</Label>
                <Input
                  id="name"
                  placeholder="e.g., Network Issue Notification"
                  value={formData.name}
                  onChange={(e) => handleChange('name', e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  placeholder="Brief description of this message's purpose..."
                  value={formData.description}
                  onChange={(e) => handleChange('description', e.target.value)}
                  rows={3}
                  className="border border-gray-300"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="type">Message Type *</Label>
                <select
                  id="type"
                  value={formData.type}
                  onChange={(e) => handleChange('type', e.target.value as MessageType)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="survey">Survey</option>
                  <option value="confirmation">Confirmation</option>
                  <option value="notification">Notification</option>
                  <option value="reminder">Reminder</option>
                  <option value="self-service">Self-Service</option>
                </select>
                <p className="text-xs text-gray-500">
                  Determines message behavior and available options
                </p>
              </div>
            </div>
          )}

          {/* Step 2: Template Selection & Interactive Flow */}
          {currentStep === 2 && (
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-gray-900 mb-4">
                <Settings className="w-5 h-5 text-blue-600" />
                <h3>Template Configuration</h3>
              </div>

              <div className="space-y-2">
                <Label htmlFor="template">Select Template *</Label>
                <select
                  id="template"
                  value={formData.template}
                  onChange={(e) => handleChange('template', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="">-- Select a template --</option>
                  {/* Built-in Templates */}
                  <optgroup label="Built-in Templates">
                    {[
                      { id: 'multi-step-survey', label: 'Multi-step Survey', type: 'survey' },
                      { id: 'single-step-survey', label: 'Single Step Survey', type: 'survey' },
                      { id: 'feedback-survey', label: 'Feedback Survey', type: 'survey' },
                      { id: 'remediation-confirmation', label: 'Remediation Confirmation', type: 'confirmation' },
                      { id: 'action-confirmation', label: 'Action Confirmation', type: 'confirmation' },
                      { id: 'success-notification', label: 'Success Notification', type: 'notification' },
                      { id: 'security-alert', label: 'Security Alert - Engineering', type: 'notification' },
                      { id: 'info-notification', label: 'Information Notification', type: 'notification' },
                      { id: 'remediation-reminder', label: 'Remediation Reminder', type: 'reminder' },
                      { id: 'vip-reminder', label: 'VIP User Reminder', type: 'reminder' },
                      { id: 'deadline-reminder', label: 'Deadline Reminder', type: 'reminder' },
                      { id: 'chat-interface', label: 'Chat Interface', type: 'self-service' },
                      { id: 'troubleshooting-guide', label: 'Troubleshooting Guide', type: 'self-service' },
                      { id: 'knowledge-base', label: 'Knowledge Base Article', type: 'self-service' },
                    ].filter(template => template.type === formData.type).map(template => (
                      <option key={template.id} value={template.id}>{template.label}</option>
                    ))}
                  </optgroup>
                  {/* Custom Templates */}
                  {templates.filter(t => t.type === formData.type).length > 0 && (
                    <optgroup label="Custom Templates">
                      {templates.filter(t => t.type === formData.type).map(template => (
                        <option key={`custom-${template.id}`} value={`custom-${template.id}`}>
                          {template.name} ({template.division})
                        </option>
                      ))}
                    </optgroup>
                  )}
                </select>
                <p className="text-xs text-gray-500">
                  Templates include branding, styling, and dynamic parameters. Custom templates created in Template Manager appear below.
                </p>
              </div>

              {/* Security Alarm Selection - Only for Security Alert Template */}
              {formData.template === 'security-alert' && (
                <div className="border border-red-200 rounded-lg p-4 space-y-4 bg-red-50">
                  <div className="flex items-center gap-2">
                    <AlertCircle className="w-5 h-5 text-red-600" />
                    <h4 className="text-gray-900">Select Security Alarm</h4>
                  </div>

                  <div className="space-y-2">
                    <Label>Current Security Alarms *</Label>
                    <div className="space-y-2 max-h-64 overflow-y-auto">
                      {securityAlarms.map((alarm) => {
                        const getSeverityColorClass = (severity: string) => {
                          switch (severity) {
                            case 'Critical': return 'border-red-500 bg-red-50 hover:bg-red-100';
                            case 'High': return 'border-orange-500 bg-orange-50 hover:bg-orange-100';
                            case 'Medium': return 'border-yellow-500 bg-yellow-50 hover:bg-yellow-100';
                            case 'Low': return 'border-blue-500 bg-blue-50 hover:bg-blue-100';
                            default: return 'border-gray-300 bg-white hover:bg-gray-50';
                          }
                        };

                        return (
                          <button
                            key={alarm.id}
                            type="button"
                            onClick={() => setSelectedAlarm(alarm)}
                            className={`w-full text-left p-3 rounded-lg border-2 transition-all bg-white ${
                              selectedAlarm?.id === alarm.id
                                ? 'border-red-600 ring-2 ring-red-600'
                                : 'border-gray-200 hover:border-gray-300'
                            }`}
                          >
                            <div className="flex items-start justify-between gap-2">
                              <div className="flex-1">
                                <div className="flex items-center gap-2 mb-1">
                                  <span className={`text-xs px-2 py-0.5 rounded ${
                                    alarm.severity === 'Critical' ? 'bg-red-200 text-red-900' :
                                    alarm.severity === 'High' ? 'bg-orange-200 text-orange-900' :
                                    alarm.severity === 'Medium' ? 'bg-yellow-200 text-yellow-900' :
                                    'bg-blue-200 text-blue-900'
                                  }`}>
                                    {alarm.severity}
                                  </span>
                                  <span className="text-xs text-gray-600">{alarm.cve}</span>
                                </div>
                                <p className="text-sm text-gray-900 mb-1">{alarm.title}</p>
                                <p className="text-xs text-gray-600 line-clamp-2">{alarm.description}</p>
                                <div className="flex items-center gap-3 mt-2 text-xs text-gray-500">
                                  <span>{alarm.affected} devices affected</span>
                                  <span>•</span>
                                  <span>Detected {alarm.detectedAt}</span>
                                </div>
                              </div>
                              {selectedAlarm?.id === alarm.id && (
                                <Check className="w-5 h-5 text-red-600 flex-shrink-0" />
                              )}
                            </div>
                          </button>
                        );
                      })}
                    </div>
                    <p className="text-xs text-gray-600">
                      Select an alarm to populate the message with alarm details
                    </p>
                  </div>
                </div>
              )}

              {/* Message Content Configuration - Shows when template is selected */}
              {formData.template !== '' && formData.type !== 'survey' && formData.type !== 'reminder' && (
                <div className="border border-purple-200 rounded-lg p-4 space-y-4 bg-purple-50">
                  <div className="flex items-center gap-2">
                    <MessageSquare className="w-5 h-5 text-purple-600" />
                    <h4 className="text-gray-900">Message Content</h4>
                  </div>

                  {/* Remediation Selector - Only show for remediation-related messages */}
                  {formData.type !== 'notification' && (
                  <div className="space-y-2">
                    <Label htmlFor="remediationType">Remediation Type *</Label>
                    <select
                      id="remediationType"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                      value={formData.remediationType || ''}
                      onChange={(e) => {
                        const type = e.target.value;
                        handleChange('remediationType', type);
                        
                        // Auto-populate based on remediation type
                        if (type === 'software-update') {
                          handleChange('messageTitle', 'Software Update Required');
                          handleChange('messageContent', 'A critical software update is required for {application}. Please complete the update to ensure your system remains secure and compliant.');
                          handleChange('severity', 'high');
                        } else if (type === 'security-patch') {
                          handleChange('messageTitle', 'Security Patch Required');
                          handleChange('messageContent', 'A security vulnerability has been detected in {application}. Please apply the security patch immediately to protect your device.');
                          handleChange('severity', 'critical');
                        } else if (type === 'policy-compliance') {
                          handleChange('messageTitle', 'Policy Compliance Action Required');
                          handleChange('messageContent', 'Your device is not compliant with {policy}. Please take action to restore compliance.');
                          handleChange('severity', 'medium');
                        } else if (type === 'custom') {
                          handleChange('messageTitle', '');
                          handleChange('messageContent', '');
                          handleChange('severity', 'low');
                        }
                      }}
                    >
                      <option value="">Select remediation type...</option>
                      <option value="software-update">Software Update</option>
                      <option value="security-patch">Security Patch</option>
                      <option value="policy-compliance">Policy Compliance</option>
                      <option value="configuration-change">Configuration Change</option>
                      <option value="custom">Custom Remediation</option>
                    </select>
                  </div>
                  )}

                  {/* Application/Software Selector */}
                  {formData.remediationType && (
                    <div className="space-y-2">
                      <Label htmlFor="application">Application/Software *</Label>
                      <Input
                        id="application"
                        placeholder="e.g., Chrome, Windows Defender, Zoom"
                        value={formData.application || ''}
                        onChange={(e) => handleChange('application', e.target.value)}
                      />
                      <p className="text-xs text-gray-500">
                        Use {'{application}'} in your message to dynamically insert this value
                      </p>
                    </div>
                  )}

                  {/* Severity Level */}
                  {formData.remediationType && (
                    <div className="space-y-2">
                      <Label htmlFor="severity">Severity Level *</Label>
                      <select
                        id="severity"
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                        value={formData.severity || 'low'}
                        onChange={(e) => handleChange('severity', e.target.value)}
                      >
                        <option value="low">Low - Informational</option>
                        <option value="medium">Medium - Action Recommended</option>
                        <option value="high">High - Action Required</option>
                        <option value="critical">Critical - Immediate Action Required</option>
                      </select>
                    </div>
                  )}

                  {/* Content Tabs */}
                  <div className="space-y-2">
                    <div className="flex border-b border-gray-300">
                      <button
                        type="button"
                        onClick={() => setContentTab('title')}
                        className={`px-4 py-2 text-sm transition-colors ${
                          contentTab === 'title'
                            ? 'border-b-2 border-purple-900 text-purple-900'
                            : 'text-gray-600 hover:text-gray-900'
                        }`}
                      >
                        Title *
                      </button>
                      <button
                        type="button"
                        onClick={() => setContentTab('description')}
                        className={`px-4 py-2 text-sm transition-colors ${
                          contentTab === 'description'
                            ? 'border-b-2 border-purple-900 text-purple-900'
                            : 'text-gray-600 hover:text-gray-900'
                        }`}
                      >
                        Description
                      </button>
                      <button
                        type="button"
                        onClick={() => setContentTab('body')}
                        className={`px-4 py-2 text-sm transition-colors ${
                          contentTab === 'body'
                            ? 'border-b-2 border-purple-900 text-purple-900'
                            : 'text-gray-600 hover:text-gray-900'
                        }`}
                      >
                        Body *
                      </button>
                    </div>

                    {/* Title Tab */}
                    {contentTab === 'title' && (
                      <div className="space-y-2">
                        <div>
                          <FormattingToolbar onFormat={(tag) => applyFormatting('messageTitle', tag, titleInputRef.current)} />
                          <Input
                            ref={titleInputRef}
                            id="messageTitle"
                            placeholder="e.g., Security Alert, Update Complete, Action Required"
                            value={formData.messageTitle}
                            onChange={(e) => handleChange('messageTitle', e.target.value)}
                            className="rounded-t-none border-t-0 h-20"
                          />
                        </div>
                        <p className="text-xs text-gray-500">
                          The title that end users will see (supports HTML formatting)
                        </p>
                      </div>
                    )}

                    {/* Description Tab */}
                    {contentTab === 'description' && (
                      <div className="space-y-2">
                        <div>
                          <FormattingToolbar onFormat={(tag) => applyFormatting('messageDescription', tag, descriptionInputRef.current)} />
                          <Input
                            ref={descriptionInputRef}
                            id="messageDescription"
                            placeholder="e.g., Brief summary or subtitle for the message"
                            value={formData.messageDescription || ''}
                            onChange={(e) => handleChange('messageDescription', e.target.value)}
                            className="rounded-t-none border-t-0 h-20"
                          />
                        </div>
                        <p className="text-xs text-gray-500">
                          Optional short description or subtitle (supports HTML formatting)
                        </p>
                      </div>
                    )}

                    {/* Body Tab */}
                    {contentTab === 'body' && (
                      <div className="space-y-2">
                        <div>
                          <FormattingToolbar onFormat={(tag) => applyFormatting('messageContent', tag, contentTextareaRef.current)} />
                          <Textarea
                            ref={contentTextareaRef}
                            id="messageContent"
                            placeholder="e.g., Your system update has been completed successfully. No further action is required."
                            value={formData.messageContent}
                            onChange={(e) => handleChange('messageContent', e.target.value)}
                            rows={3}
                            className="rounded-t-none border-t-0"
                          />
                        </div>
                        <p className="text-xs text-gray-500">
                          The main message content that end users will see (supports HTML formatting)
                        </p>
                      </div>
                    )}
                  </div>

                  {/* Required Actions */}
                  {formData.remediationType && (
                    <div className="space-y-2">
                      <Label>Required Actions</Label>
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            id="requireConfirmation"
                            checked={formData.requireConfirmation || false}
                            onChange={(e) => handleChange('requireConfirmation', e.target.checked)}
                            className="w-4 h-4 text-purple-600 rounded border-gray-300 focus:ring-purple-500"
                          />
                          <label htmlFor="requireConfirmation" className="text-sm text-gray-700">
                            Require user confirmation
                          </label>
                        </div>
                        <div className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            id="requireReboot"
                            checked={formData.requireReboot || false}
                            onChange={(e) => handleChange('requireReboot', e.target.checked)}
                            className="w-4 h-4 text-purple-600 rounded border-gray-300 focus:ring-purple-500"
                          />
                          <label htmlFor="requireReboot" className="text-sm text-gray-700">
                            Require system reboot
                          </label>
                        </div>
                        <div className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            id="trackCompletion"
                            checked={formData.trackCompletion || false}
                            onChange={(e) => handleChange('trackCompletion', e.target.checked)}
                            className="w-4 h-4 text-purple-600 rounded border-gray-300 focus:ring-purple-500"
                          />
                          <label htmlFor="trackCompletion" className="text-sm text-gray-700">
                            Track completion status
                          </label>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Message Content Configuration - For Survey Templates */}
              {formData.template !== '' && formData.type === 'survey' && (
                <div className="border border-purple-200 rounded-lg p-4 space-y-4 bg-purple-50">
                  <div className="flex items-center gap-2">
                    <MessageSquare className="w-5 h-5 text-purple-600" />
                    <h4 className="text-gray-900">Survey Message Content</h4>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="messageTitle">Survey Title *</Label>
                    <Input
                      id="messageTitle"
                      placeholder="e.g., Help Us Improve, Quick Feedback, Your Opinion Matters"
                      value={formData.messageTitle}
                      onChange={(e) => handleChange('messageTitle', e.target.value)}
                    />
                    <p className="text-xs text-gray-500">
                      The title shown to users when they receive the survey
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="messageContent">Survey Introduction *</Label>
                    <Textarea
                      id="messageContent"
                      placeholder="e.g., We'd love to hear your thoughts on the recent changes. Your feedback helps us improve."
                      value={formData.messageContent}
                      onChange={(e) => handleChange('messageContent', e.target.value)}
                      rows={2}
                    />
                    <p className="text-xs text-gray-500">
                      Brief introduction shown before the survey questions
                    </p>
                  </div>
                </div>
              )}

              {/* Survey Questions Configuration - Only for Multi-step Survey Template */}
              {formData.template === 'multi-step-survey' && (
                <div className="border border-purple-200 rounded-lg p-4 space-y-4 bg-purple-50">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <ListChecks className="w-5 h-5 text-purple-600" />
                      <h4 className="text-gray-900">Multi-Step Questions Configuration</h4>
                    </div>
                    <button
                      type="button"
                      onClick={addSurveyQuestion}
                      className="flex items-center gap-1 px-3 py-1.5 text-sm bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
                    >
                      <Plus className="w-4 h-4" />
                      Add Question
                    </button>
                  </div>

                  {formData.surveyQuestions.length === 0 ? (
                    <div className="text-center py-8 text-gray-500">
                      <ListChecks className="w-12 h-12 mx-auto mb-2 opacity-30" />
                      <p className="text-sm">No questions added yet</p>
                      <p className="text-xs">Click "Add Question" to configure multi-step survey questions</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {formData.surveyQuestions.map((question, index) => (
                        <div 
                          key={question.id} 
                          className={`border rounded-lg p-4 bg-white space-y-3 transition-all ${
                            previewQuestionIndex === index 
                              ? 'border-purple-500 ring-2 ring-purple-200 shadow-md' 
                              : 'border-gray-300'
                          }`}
                        >
                          <div className="flex items-start justify-between gap-3">
                            <div className="flex-1 space-y-3">
                              <div className="space-y-2">
                                <div className="flex items-center justify-between">
                                  <div className="flex items-center gap-2">
                                    <Label htmlFor={`question-${question.id}`}>Question {index + 1} *</Label>
                                    {previewQuestionIndex === index && (
                                      <span className="inline-flex items-center px-2 py-0.5 bg-purple-100 text-purple-700 text-xs rounded-full">
                                        <Eye className="w-3 h-3 mr-1" />
                                        Previewing
                                      </span>
                                    )}
                                  </div>
                                  <div className="flex items-center gap-2">
                                    {previewQuestionIndex !== index && (
                                      <button
                                        type="button"
                                        onClick={() => setPreviewQuestionIndex(index)}
                                        className="text-purple-600 hover:text-purple-700 text-xs px-2 py-1 rounded hover:bg-purple-50"
                                      >
                                        Preview
                                      </button>
                                    )}
                                    <button
                                      type="button"
                                      onClick={() => removeSurveyQuestion(question.id)}
                                      className="text-red-600 hover:text-red-700 p-1"
                                    >
                                      <X className="w-4 h-4" />
                                    </button>
                                  </div>
                                </div>
                                <Input
                                  id={`question-${question.id}`}
                                  placeholder="Enter your question..."
                                  value={question.text}
                                  onChange={(e) => updateSurveyQuestion(question.id, 'text', e.target.value)}
                                />
                              </div>

                              <div className="grid grid-cols-2 gap-3">
                                <div className="space-y-2">
                                  <Label htmlFor={`type-${question.id}`}>Question Type *</Label>
                                  <select
                                    id={`type-${question.id}`}
                                    value={question.type}
                                    onChange={(e) => updateSurveyQuestion(question.id, 'type', e.target.value)}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                                  >
                                    <option value="open">Open-ended (Text)</option>
                                    <option value="closed">Closed (Multiple Choice)</option>
                                  </select>
                                </div>

                                <div className="flex items-center gap-2 pt-7">
                                  <input
                                    type="checkbox"
                                    id={`required-${question.id}`}
                                    checked={question.required}
                                    onChange={(e) => updateSurveyQuestion(question.id, 'required', e.target.checked)}
                                    className="w-4 h-4 text-purple-600 rounded border-gray-300 focus:ring-purple-500"
                                  />
                                  <Label htmlFor={`required-${question.id}`} className="cursor-pointer">
                                    Required Question
                                  </Label>
                                </div>
                              </div>

                              {/* Answer Options for Closed Questions */}
                              {question.type === 'closed' && (
                                <div className="space-y-2 pl-4 border-l-2 border-purple-300">
                                  <div className="flex items-center justify-between">
                                    <Label className="text-sm">Answer Options</Label>
                                    <button
                                      type="button"
                                      onClick={() => addQuestionOption(question.id)}
                                      className="flex items-center gap-1 px-2 py-1 text-xs bg-purple-100 text-purple-700 rounded hover:bg-purple-200 transition-colors"
                                    >
                                      <Plus className="w-3 h-3" />
                                      Add Option
                                    </button>
                                  </div>
                                  
                                  {(!question.options || question.options.length === 0) ? (
                                    <p className="text-xs text-gray-500 italic">No options added yet</p>
                                  ) : (
                                    <div className="space-y-2">
                                      {question.options.map((option, optionIndex) => (
                                        <div key={optionIndex} className="flex items-center gap-2">
                                          <span className="text-sm text-gray-500 w-6">{String.fromCharCode(65 + optionIndex)}.</span>
                                          <Input
                                            placeholder={`Option ${optionIndex + 1}`}
                                            value={option}
                                            onChange={(e) => updateQuestionOption(question.id, optionIndex, e.target.value)}
                                            className="flex-1"
                                          />
                                          <button
                                            type="button"
                                            onClick={() => removeQuestionOption(question.id, optionIndex)}
                                            className="text-red-500 hover:text-red-600 p-1"
                                          >
                                            <X className="w-4 h-4" />
                                          </button>
                                        </div>
                                      ))}
                                    </div>
                                  )}
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  <div className="bg-purple-100 border border-purple-300 rounded p-3">
                    <div className="flex items-start gap-2">
                      <AlertCircle className="w-4 h-4 text-purple-700 mt-0.5 flex-shrink-0" />
                      <p className="text-xs text-purple-900">
                        Configure multi-step survey questions that will be presented to users when this message is delivered.
                        Each question can be open-ended (text response) or closed (multiple choice).
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* Single Step Survey Configuration - Only for Single-step Survey Template */}
              {formData.template === 'single-step-survey' && (
                <div className="border border-purple-200 rounded-lg p-4 space-y-4 bg-purple-50">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <ListChecks className="w-5 h-5 text-purple-600" />
                      <h4 className="text-gray-900">Single Question Configuration</h4>
                    </div>
                    {formData.surveyQuestions.length === 0 && (
                      <button
                        type="button"
                        onClick={addSurveyQuestion}
                        className="flex items-center gap-1 px-3 py-1.5 text-sm bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
                      >
                        <Plus className="w-4 h-4" />
                        Add Question
                      </button>
                    )}
                  </div>

                  {formData.surveyQuestions.length === 0 ? (
                    <div className="text-center py-8 text-gray-500">
                      <ListChecks className="w-12 h-12 mx-auto mb-2 opacity-30" />
                      <p className="text-sm">No question added yet</p>
                      <p className="text-xs">Click "Add Question" to configure your single survey question</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {formData.surveyQuestions.slice(0, 1).map((question, index) => (
                        <div key={question.id} className="border border-gray-300 rounded-lg p-4 bg-white space-y-3">
                          <div className="flex items-start justify-between gap-3">
                            <div className="flex-1 space-y-3">
                              <div className="space-y-2">
                                <div className="flex items-center justify-between">
                                  <Label htmlFor={`question-${question.id}`}>Survey Question *</Label>
                                  <button
                                    type="button"
                                    onClick={() => removeSurveyQuestion(question.id)}
                                    className="text-red-600 hover:text-red-700 p-1"
                                  >
                                    <X className="w-4 h-4" />
                                  </button>
                                </div>
                                <Input
                                  id={`question-${question.id}`}
                                  placeholder="Enter your question..."
                                  value={question.text}
                                  onChange={(e) => updateSurveyQuestion(question.id, 'text', e.target.value)}
                                />
                              </div>

                              <div className="grid grid-cols-2 gap-3">
                                <div className="space-y-2">
                                  <Label htmlFor={`type-${question.id}`}>Question Type *</Label>
                                  <select
                                    id={`type-${question.id}`}
                                    value={question.type}
                                    onChange={(e) => updateSurveyQuestion(question.id, 'type', e.target.value)}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                                  >
                                    <option value="open">Open-ended (Text)</option>
                                    <option value="closed">Closed (Multiple Choice)</option>
                                  </select>
                                </div>

                                <div className="flex items-center gap-2 pt-7">
                                  <input
                                    type="checkbox"
                                    id={`required-${question.id}`}
                                    checked={question.required}
                                    onChange={(e) => updateSurveyQuestion(question.id, 'required', e.target.checked)}
                                    className="w-4 h-4 text-purple-600 rounded border-gray-300 focus:ring-purple-500"
                                  />
                                  <Label htmlFor={`required-${question.id}`} className="cursor-pointer">
                                    Required Question
                                  </Label>
                                </div>
                              </div>

                              {/* Answer Options for Closed Questions */}
                              {question.type === 'closed' && (
                                <div className="space-y-2 pl-4 border-l-2 border-purple-300">
                                  <div className="flex items-center justify-between">
                                    <Label className="text-sm">Answer Options</Label>
                                    <button
                                      type="button"
                                      onClick={() => addQuestionOption(question.id)}
                                      className="flex items-center gap-1 px-2 py-1 text-xs bg-purple-100 text-purple-700 rounded hover:bg-purple-200 transition-colors"
                                    >
                                      <Plus className="w-3 h-3" />
                                      Add Option
                                    </button>
                                  </div>
                                  
                                  {(!question.options || question.options.length === 0) ? (
                                    <p className="text-xs text-gray-500 italic">No options added yet</p>
                                  ) : (
                                    <div className="space-y-2">
                                      {question.options.map((option, optionIndex) => (
                                        <div key={optionIndex} className="flex items-center gap-2">
                                          <span className="text-sm text-gray-500 w-6">{String.fromCharCode(65 + optionIndex)}.</span>
                                          <Input
                                            placeholder={`Option ${optionIndex + 1}`}
                                            value={option}
                                            onChange={(e) => updateQuestionOption(question.id, optionIndex, e.target.value)}
                                            className="flex-1"
                                          />
                                          <button
                                            type="button"
                                            onClick={() => removeQuestionOption(question.id, optionIndex)}
                                            className="text-red-500 hover:text-red-600 p-1"
                                          >
                                            <X className="w-4 h-4" />
                                          </button>
                                        </div>
                                      ))}
                                    </div>
                                  )}
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  <div className="bg-purple-100 border border-purple-300 rounded p-3">
                    <div className="flex items-start gap-2">
                      <AlertCircle className="w-4 h-4 text-purple-700 mt-0.5 flex-shrink-0" />
                      <div className="text-xs text-purple-900 space-y-1">
                        <p>Configure multi-step survey questions. The question can be open-ended (text response) or closed (multiple choice).</p>
                        <p className="flex items-center gap-1">
                          <Eye className="w-3 h-3" />
                          <span>Use the interactive preview below to navigate through all questions. Click "Preview" on any question or use Previous/Next buttons in the preview.</span>
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Feedback Survey Configuration - Only for Feedback Survey Template */}
              {formData.template === 'feedback-survey' && (
                <div className="border border-purple-200 rounded-lg p-4 space-y-4 bg-purple-50">
                  <div className="flex items-center gap-2">
                    <MessageSquare className="w-5 h-5 text-purple-600" />
                    <h4 className="text-gray-900">Feedback Survey Configuration</h4>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="feedbackPrompt">Feedback Prompt *</Label>
                    <Input
                      id="feedbackPrompt"
                      placeholder="e.g., How satisfied are you with this update?"
                      value={formData.feedbackPrompt}
                      onChange={(e) => handleChange('feedbackPrompt', e.target.value)}
                    />
                    <p className="text-xs text-gray-500">
                      This text will be displayed above the happiness scale
                    </p>
                  </div>

                  {formData.feedbackPrompt && (
                    <div className="border border-gray-300 rounded-lg p-4 bg-white space-y-3">
                      <div className="text-center space-y-3">
                        <p className="text-sm text-gray-900">
                          {formData.feedbackPrompt}
                        </p>
                        
                        <div className="flex items-center justify-center gap-2">
                          <button className="flex flex-col items-center gap-1 p-2 rounded-lg hover:bg-gray-50 transition-colors">
                            <span className="text-2xl">😊</span>
                            <span className="text-xs text-gray-600">Very Happy</span>
                          </button>
                          <button className="flex flex-col items-center gap-1 p-2 rounded-lg hover:bg-gray-50 transition-colors">
                            <span className="text-2xl">🙂</span>
                            <span className="text-xs text-gray-600">Happy</span>
                          </button>
                          <button className="flex flex-col items-center gap-1 p-2 rounded-lg hover:bg-gray-50 transition-colors">
                            <span className="text-2xl">😐</span>
                            <span className="text-xs text-gray-600">Neutral</span>
                          </button>
                          <button className="flex flex-col items-center gap-1 p-2 rounded-lg hover:bg-gray-50 transition-colors">
                            <span className="text-2xl">🙁</span>
                            <span className="text-xs text-gray-600">Unhappy</span>
                          </button>
                          <button className="flex flex-col items-center gap-1 p-2 rounded-lg hover:bg-gray-50 transition-colors">
                            <span className="text-2xl">😞</span>
                            <span className="text-xs text-gray-600">Very Unhappy</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  )}

                  <div className="bg-purple-100 border border-purple-300 rounded p-3">
                    <div className="flex items-start gap-2">
                      <AlertCircle className="w-4 h-4 text-purple-700 mt-0.5 flex-shrink-0" />
                      <p className="text-xs text-purple-900">
                        Feedback surveys use a 5-point happiness scale from Very Happy to Very Unhappy. Users can quickly provide sentiment feedback with a single click.
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* Reminder Configuration - Only for Reminder Templates */}
              {formData.template !== '' && formData.type === 'reminder' && (
                <div className="border border-yellow-200 rounded-lg p-4 space-y-4 bg-yellow-50">
                  <div className="flex items-center gap-2">
                    <MessageSquare className="w-5 h-5 text-yellow-600" />
                    <h4 className="text-gray-900">Reminder Configuration & Preview</h4>
                  </div>

                  {/* Remediation Action Selector - Only for Remediation Reminder */}
                  {formData.template === 'remediation-reminder' && (
                    <div className="border border-red-200 rounded-lg p-4 space-y-4 bg-red-50">
                      <div className="flex items-center gap-2">
                        <Settings className="w-5 h-5 text-red-600" />
                        <h4 className="text-gray-900">Step 1: Select Remediation Action</h4>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="remediationActionSelect">Choose Remediation Action *</Label>
                        <select
                          id="remediationActionSelect"
                          value={formData.remediationActionId}
                          onChange={(e) => handleRemediationActionSelect(e.target.value)}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent bg-white"
                        >
                          <option value="">-- Select a remediation action --</option>
                          {remediationActions.map(action => (
                            <option key={action.id} value={action.id}>
                              {action.name} ({action.actionType} - {action.severity})
                            </option>
                          ))}
                        </select>
                        <p className="text-xs text-gray-500">
                          Select the remediation action that users need to perform. This will auto-populate the message title and content.
                        </p>
                      </div>

                      {selectedRemediationAction && (
                        <div className="border border-gray-300 rounded-lg p-4 bg-white space-y-3">
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <p className="text-xs text-gray-500 mb-1">Action Type</p>
                              <div className="inline-flex items-center px-2.5 py-1 bg-blue-100 text-blue-700 rounded-full text-xs">
                                {selectedRemediationAction.actionType}
                              </div>
                            </div>
                            <div>
                              <p className="text-xs text-gray-500 mb-1">Severity</p>
                              <div className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs ${
                                selectedRemediationAction.severity === 'Critical' ? 'bg-red-100 text-red-700' :
                                selectedRemediationAction.severity === 'High' ? 'bg-orange-100 text-orange-700' :
                                selectedRemediationAction.severity === 'Medium' ? 'bg-yellow-100 text-yellow-700' :
                                'bg-green-100 text-green-700'
                              }`}>
                                {selectedRemediationAction.severity}
                              </div>
                            </div>
                            {selectedRemediationAction.application && (
                              <div>
                                <p className="text-xs text-gray-500 mb-1">Application</p>
                                <p className="text-sm text-gray-900">{selectedRemediationAction.application}</p>
                              </div>
                            )}
                            <div>
                              <p className="text-xs text-gray-500 mb-1">Estimated Time</p>
                              <p className="text-sm text-gray-900">{selectedRemediationAction.estimatedTime}</p>
                            </div>
                          </div>

                          <div>
                            <p className="text-xs text-gray-500 mb-2">Description</p>
                            <p className="text-sm text-gray-700">{selectedRemediationAction.description}</p>
                          </div>

                          <div>
                            <p className="text-xs text-gray-500 mb-2">Required Actions</p>
                            <ul className="space-y-1">
                              {selectedRemediationAction.requiredActions.map((action, idx) => (
                                <li key={idx} className="flex items-start gap-2 text-sm text-gray-700">
                                  <Check className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                                  <span>{action}</span>
                                </li>
                              ))}
                            </ul>
                          </div>

                          {selectedRemediationAction.requiresReboot && (
                            <div className="bg-orange-50 border border-orange-200 rounded p-2 flex items-start gap-2">
                              <AlertCircle className="w-4 h-4 text-orange-600 mt-0.5 flex-shrink-0" />
                              <p className="text-xs text-orange-800">
                                ⚠️ This remediation action requires a system reboot to complete
                              </p>
                            </div>
                          )}
                        </div>
                      )}

                      <div className="bg-red-100 border border-red-300 rounded p-3">
                        <div className="flex items-start gap-2">
                          <AlertCircle className="w-4 h-4 text-red-700 mt-0.5 flex-shrink-0" />
                          <p className="text-xs text-red-900">
                            Selecting a remediation action will automatically populate the message title and content below. You can customize these fields after selection.
                          </p>
                        </div>
                      </div>
                    </div>
                  )}

                  <div className="space-y-2">
                    <Label htmlFor="messageTitle">
                      {formData.template === 'remediation-reminder' ? 'Step 2: Message Title *' : 'Reminder Title *'}
                    </Label>
                    <Input
                      id="messageTitle"
                      placeholder="e.g., Action Required, Reminder, Important Update"
                      value={formData.messageTitle}
                      onChange={(e) => handleChange('messageTitle', e.target.value)}
                    />
                    <p className="text-xs text-gray-500">
                      The title that end users will see
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="reminderText">
                      {formData.template === 'remediation-reminder' ? 'Step 3: Message Content *' : 'Reminder Message *'}
                    </Label>
                    <Textarea
                      id="reminderText"
                      placeholder="e.g., Please complete the required action by the deadline"
                      value={formData.reminderText}
                      onChange={(e) => handleChange('reminderText', e.target.value)}
                      rows={3}
                    />
                    <p className="text-xs text-gray-500">
                      This is the main message content that will be shown to users
                      {formData.template === 'remediation-reminder' && selectedRemediationAction && ' (auto-populated from selected action)'}
                    </p>
                  </div>

                  {/* Old Remediation Action Selector - Keeping for non-remediation reminders */}
                  {formData.template === 'remediation-reminder' && false && (
                    <div className="space-y-2">
                      <Label htmlFor="remediationAction">Select Remediation Action *</Label>
                      <select
                        id="remediationAction"
                        value={formData.remediationAction}
                        onChange={(e) => handleChange('remediationAction', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-transparent bg-white"
                      >
                        <option value="">Select a remediation action...</option>
                        <option value="check-disk">Perform an offline Check Disk diagnostic and fix errors</option>
                        <option value="memory-diagnostic">Run Windows Memory Diagnostic</option>
                        <option value="update-drivers">Update Device Drivers</option>
                        <option value="system-file-checker">Run System File Checker (SFC)</option>
                        <option value="disk-cleanup">Disk Cleanup and Optimization</option>
                        <option value="registry-cleanup">Registry Cleanup and Repair</option>
                        <option value="clear-dns">Clear DNS Cache</option>
                        <option value="reset-network">Reset Network Adapters</option>
                        <option value="hardware-diagnostics">Run Hardware Diagnostics</option>
                        <option value="windows-updates">Check for Windows Updates</option>
                      </select>
                      <p className="text-xs text-gray-500">
                        Choose the remediation action users will be reminded to complete
                      </p>
                    </div>
                  )}

                  {/* Live Preview - Remediation Reminder */}
                  {formData.template === 'remediation-reminder' && formData.reminderText && (
                    <div>
                      <div className="flex items-center gap-2 mb-2">
                        <Eye className="w-4 h-4 text-yellow-600" />
                        <Label className="text-sm text-yellow-700">Live Preview</Label>
                      </div>
                      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 space-y-3 max-w-sm mx-auto">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <div className="inline-block px-2.5 py-0.5 bg-yellow-100 text-yellow-700 rounded-full text-xs">
                                Remediation Reminder
                              </div>
                              {selectedRemediationAction && (
                                <div className={`inline-block px-2.5 py-0.5 rounded-full text-xs ${
                                  selectedRemediationAction.severity === 'Critical' ? 'bg-red-100 text-red-700' :
                                  selectedRemediationAction.severity === 'High' ? 'bg-orange-100 text-orange-700' :
                                  selectedRemediationAction.severity === 'Medium' ? 'bg-yellow-100 text-yellow-700' :
                                  'bg-green-100 text-green-700'
                                }`}>
                                  {selectedRemediationAction.severity}
                                </div>
                              )}
                            </div>
                            <h4 className="text-gray-900 text-sm">{formData.messageTitle || 'Remediation Reminder'}</h4>
                            <p className="text-xs text-gray-700 mt-1">
                              {formData.reminderText}
                            </p>
                          </div>
                          <button className="text-gray-400 p-1">
                            <X className="w-4 h-4" />
                          </button>
                        </div>

                        {selectedRemediationAction && (
                          <>
                            <div className="bg-blue-50 border border-blue-200 rounded p-2 space-y-1">
                              <div className="flex items-center justify-between text-xs">
                                <span className="text-blue-700">Action Type:</span>
                                <span className="text-blue-900">{selectedRemediationAction.actionType}</span>
                              </div>
                              {selectedRemediationAction.application && (
                                <div className="flex items-center justify-between text-xs">
                                  <span className="text-blue-700">Application:</span>
                                  <span className="text-blue-900">{selectedRemediationAction.application}</span>
                                </div>
                              )}
                              <div className="flex items-center justify-between text-xs">
                                <span className="text-blue-700">Est. Time:</span>
                                <span className="text-blue-900">{selectedRemediationAction.estimatedTime}</span>
                              </div>
                            </div>

                            <div className="bg-gray-50 border border-gray-200 rounded p-2 space-y-1">
                              <p className="text-xs text-gray-700">What you need to do:</p>
                              {selectedRemediationAction.requiredActions.slice(0, 2).map((action, idx) => (
                                <div key={idx} className="flex items-start gap-1 text-xs text-gray-600">
                                  <Check className="w-3 h-3 text-green-600 mt-0.5 flex-shrink-0" />
                                  <span>{action}</span>
                                </div>
                              ))}
                            </div>

                            {selectedRemediationAction.requiresReboot && (
                              <div className="bg-orange-50 border border-orange-200 rounded p-2 flex items-center gap-2">
                                <AlertCircle className="w-4 h-4 text-orange-600 flex-shrink-0" />
                                <p className="text-xs text-orange-800">Requires system reboot</p>
                              </div>
                            )}
                          </>
                        )}

                        <div className="bg-red-50 border border-red-200 rounded p-2">
                          <p className="text-xs text-red-700">⏰ Due: Today at 2:00 PM</p>
                        </div>

                        <div className="flex gap-2">
                          <button className="flex-1 px-3 py-2 bg-gray-100 text-gray-700 rounded text-xs hover:bg-gray-200 transition-colors">
                            Remind in 1 hour
                          </button>
                          <button className="flex-1 px-3 py-2 bg-purple-700 text-white rounded text-xs hover:bg-purple-800 transition-colors">
                            Remediate Now
                          </button>
                        </div>
                        <div className="text-xs text-gray-500 text-center">Powered by Riverbed</div>
                      </div>
                    </div>
                  )}

                  {/* Live Preview - VIP Reminder */}
                  {formData.template === 'vip-reminder' && formData.reminderText && (
                    <div>
                      <div className="flex items-center gap-2 mb-2">
                        <Eye className="w-4 h-4 text-yellow-600" />
                        <Label className="text-sm text-yellow-700">Live Preview</Label>
                      </div>
                      <div className="bg-gradient-to-br from-purple-50 to-blue-50 rounded-lg shadow-md border-2 border-purple-300 p-4 space-y-3 max-w-sm mx-auto">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <div className="inline-block px-2.5 py-0.5 bg-gradient-to-r from-purple-100 to-blue-100 text-purple-800 rounded-full text-xs">
                                ⭐ VIP Priority
                              </div>
                            </div>
                            <h4 className="text-gray-900">{formData.messageTitle || 'VIP Reminder'}</h4>
                            <p className="text-xs text-gray-700 mt-1">
                              {formData.reminderText}
                            </p>
                          </div>
                          <button className="text-gray-400 p-1">
                            <X className="w-4 h-4" />
                          </button>
                        </div>

                        <div className="bg-white border border-purple-200 rounded p-2">
                          <p className="text-xs text-gray-600">Priority Support Available</p>
                          <p className="text-xs text-purple-700">Contact: VIP-Support@riverbed.com</p>
                        </div>

                        <div className="flex gap-2">
                          <button className="flex-1 px-3 py-2 bg-white border border-purple-300 text-purple-700 rounded text-xs hover:bg-purple-50 transition-colors">
                            Defer (1 day)
                          </button>
                          <button className="flex-1 px-3 py-2 bg-gradient-to-r from-purple-700 to-purple-600 text-white rounded text-xs hover:from-purple-800 hover:to-purple-700 transition-colors">
                            Take Action
                          </button>
                        </div>
                        <div className="text-xs text-gray-500 text-center">Powered by Riverbed</div>
                      </div>
                    </div>
                  )}

                  {/* Live Preview - Deadline Reminder */}
                  {formData.template === 'deadline-reminder' && formData.reminderText && (
                    <div>
                      <div className="flex items-center gap-2 mb-2">
                        <Eye className="w-4 h-4 text-yellow-600" />
                        <Label className="text-sm text-yellow-700">Live Preview</Label>
                      </div>
                      <div className="bg-white rounded-lg shadow-sm border-l-4 border-orange-500 p-4 space-y-3 max-w-sm mx-auto">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="inline-block px-2.5 py-0.5 bg-orange-100 text-orange-700 rounded-full text-xs mb-2">
                              ⏰ Deadline Approaching
                            </div>
                            <h4 className="text-gray-900 text-sm">{formData.messageTitle || 'Deadline Reminder'}</h4>
                            <p className="text-xs text-gray-700 mt-1">
                              {formData.reminderText}
                            </p>
                          </div>
                          <button className="text-gray-400 p-1">
                            <X className="w-4 h-4" />
                          </button>
                        </div>

                        <div className="bg-gradient-to-r from-orange-50 to-red-50 border border-orange-200 rounded p-3 space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="text-xs text-gray-700">Time Remaining:</span>
                            <span className="text-sm text-orange-700">4 hours 23 mins</span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-1.5">
                            <div className="bg-gradient-to-r from-orange-500 to-red-500 h-1.5 rounded-full" style={{ width: '75%' }}></div>
                          </div>
                          <p className="text-xs text-orange-700">Due: Today at 5:00 PM</p>
                        </div>

                        <div className="flex gap-2">
                          <button className="flex-1 px-3 py-2 bg-gray-100 text-gray-700 rounded text-xs hover:bg-gray-200 transition-colors">
                            Snooze
                          </button>
                          <button className="flex-1 px-3 py-2 bg-orange-600 text-white rounded text-xs hover:bg-orange-700 transition-colors">
                            Complete Now
                          </button>
                        </div>
                        <div className="text-xs text-gray-500 text-center">Powered by Riverbed</div>
                      </div>
                    </div>
                  )}

                  <div className="bg-yellow-100 border border-yellow-300 rounded p-3">
                    <div className="flex items-start gap-2">
                      <AlertCircle className="w-4 h-4 text-yellow-700 mt-0.5 flex-shrink-0" />
                      <p className="text-xs text-yellow-900">
                        Reminder messages help users stay on track with pending actions. Different templates offer specialized layouts for remediations, VIP users, and deadlines. Enter your reminder message above to see a live preview.
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Step 3: Schedule */}
          {currentStep === 3 && (
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-gray-900 mb-4">
                <Zap className="w-5 h-5 text-blue-600" />
                <h3>Delivery Schedule</h3>
              </div>

              <div className="space-y-2">
                <Label htmlFor="scheduleType">Delivery Schedule</Label>
                <select
                  id="scheduleType"
                  value={formData.scheduleType}
                  onChange={(e) => handleChange('scheduleType', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="immediate">Send Immediately</option>
                  <option value="scheduled">Schedule for Later</option>
                  <option value="recurring">Recurring Schedule</option>
                </select>
              </div>

              {(formData.scheduleType === 'scheduled' || formData.scheduleType === 'recurring') && (
                <div className="space-y-2">
                  <Label htmlFor="scheduledDate">Schedule Date & Time</Label>
                  <Input
                    id="scheduledDate"
                    type="datetime-local"
                    value={formData.scheduledDate}
                    onChange={(e) => handleChange('scheduledDate', e.target.value)}
                  />
                </div>
              )}

              <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
                <div className="flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-purple-600 mt-0.5 flex-shrink-0" />
                  <div className="text-xs text-purple-900">
                    <p>TBD</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Step 4: Target Group Selection & Final Review */}
          {currentStep === 4 && (
            <div className="space-y-6">
              <div className="flex items-center gap-2 text-gray-900 mb-4">
                <Users className="w-5 h-5 text-purple-600" />
                <h3>Target Group Selection & Final Review</h3>
              </div>

              <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
                <div className="flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-purple-600 mt-0.5 flex-shrink-0" />
                  <p className="text-sm text-purple-900">
                    Select your target audience and review all message settings before creation. The preview shows exactly how recipients will see your message.
                  </p>
                </div>
              </div>

              {/* Target Group Selection */}
              <div className="border border-gray-200 rounded-lg p-4 space-y-4 bg-white">
                <div className="flex items-center gap-2">
                  <Users className="w-5 h-5 text-blue-600" />
                  <h4 className="text-gray-900">1. Select Target Audience</h4>
                </div>
                
                <div className="space-y-3">
                  <Label htmlFor="targetGroup">Target Group/Audience *</Label>
                  <select
                    id="targetGroup"
                    value={formData.targetGroup}
                    onChange={(e) => handleChange('targetGroup', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  >
                    <option value="">-- Select target group --</option>
                    <option value="All Employees">All Employees</option>
                    <option value="Engineering Dept">Engineering Department</option>
                    <option value="Sales Dept">Sales Department</option>
                    <option value="Remote Workers">Remote Workers</option>
                    <option value="VIP Users">VIP Users</option>
                    <option value="Executive Team">Executive Team</option>
                    <option value="IT Operations">IT Operations</option>
                    <option value="Custom Group">Custom Group (Advanced)</option>
                  </select>

                  {/* Target Group Info */}
                  {formData.targetGroup && (
                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                      <div className="flex items-start gap-2">
                        <Check className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                        <div className="text-xs text-blue-900">
                          <p className="font-medium mb-1">Target Group Selected: {formData.targetGroup}</p>
                          <p>
                            {formData.targetGroup === 'All Employees' && 'Message will be delivered to all employees in the organization.'}
                            {formData.targetGroup === 'Engineering Dept' && 'Message will be delivered to all members of the Engineering department.'}
                            {formData.targetGroup === 'Sales Dept' && 'Message will be delivered to all members of the Sales department.'}
                            {formData.targetGroup === 'Remote Workers' && 'Message will be delivered to all employees marked as remote workers.'}
                            {formData.targetGroup === 'VIP Users' && 'Message will be delivered to VIP users with special handling rules.'}
                            {formData.targetGroup === 'Executive Team' && 'Message will be delivered to executive team members.'}
                            {formData.targetGroup === 'IT Operations' && 'Message will be delivered to IT Operations team members.'}
                            {formData.targetGroup === 'Custom Group' && 'Message will be delivered to a custom-defined group (configure in advanced settings).'}
                          </p>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Delivery Options */}
                  <div className="grid grid-cols-2 gap-3 pt-2">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={formData.vipHandling}
                        onChange={(e) => handleChange('vipHandling', e.target.checked)}
                        className="w-4 h-4 text-purple-600 border-gray-300 rounded focus:ring-purple-500"
                      />
                      <span className="text-sm text-gray-700">VIP Priority Handling</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={formData.fatiguePrevention}
                        onChange={(e) => handleChange('fatiguePrevention', e.target.checked)}
                        className="w-4 h-4 text-purple-600 border-gray-300 rounded focus:ring-purple-500"
                      />
                      <span className="text-sm text-gray-700">Fatigue Prevention</span>
                    </label>
                  </div>
                </div>
              </div>

              {/* Configuration Summary */}
              <div className="border border-gray-200 rounded-lg p-4 space-y-3 bg-gray-50">
                <div className="flex items-center gap-2">
                  <ListChecks className="w-5 h-5 text-purple-600" />
                  <h4 className="text-gray-900">2. Configuration Summary</h4>
                </div>
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <p className="text-gray-600">Message Name:</p>
                    <p className="text-gray-900">{formData.name || 'Not set'}</p>
                  </div>
                  <div>
                    <p className="text-gray-600">Message Type:</p>
                    <p className="text-gray-900 capitalize">{formData.type}</p>
                  </div>
                  <div>
                    <p className="text-gray-600">Delivery Channel:</p>
                    <p className="text-gray-900 capitalize">{formData.channel}</p>
                  </div>
                  <div>
                    <p className="text-gray-600">Template:</p>
                    <p className="text-gray-900">{formData.template || 'Not selected'}</p>
                  </div>
                  <div>
                    <p className="text-gray-600">Target Audience:</p>
                    <p className="text-gray-900">{formData.targetGroup || 'Not set'}</p>
                  </div>
                  <div>
                    <p className="text-gray-600">Delivery Mode:</p>
                    <p className="text-gray-900 capitalize">{formData.deliveryMode.replace('-', ' ')}</p>
                  </div>
                  <div>
                    <p className="text-gray-600">Schedule:</p>
                    <p className="text-gray-900 capitalize">
                      {formData.scheduleType === 'immediate' && 'Send Immediately'}
                      {formData.scheduleType === 'scheduled' && `Scheduled: ${formData.scheduledDate || 'Not set'}`}
                      {formData.scheduleType === 'recurring' && 'Recurring Schedule'}
                    </p>
                  </div>
                  <div>
                    <p className="text-gray-600">Priority:</p>
                    <p className="text-gray-900 capitalize">{formData.priority}</p>
                  </div>
                </div>
                
                {formData.hasInteractiveFlow && (
                  <div className="pt-2 border-t border-gray-300">
                    <p className="text-blue-600 text-sm">✓ Interactive Flow Enabled</p>
                  </div>
                )}
                {formData.requiresResponse && (
                  <div className="pt-2 border-t border-gray-300">
                    <p className="text-orange-600 text-sm">✓ User Response Required</p>
                  </div>
                )}
                {formData.template === 'multi-step-survey' && formData.surveyQuestions.length > 0 && (
                  <div className="pt-2 border-t border-gray-300">
                    <p className="text-purple-600 text-sm">✓ {formData.surveyQuestions.length} Survey Question{formData.surveyQuestions.length > 1 ? 's' : ''} Configured</p>
                  </div>
                )}
                {formData.links.length > 0 && (
                  <div className="pt-2 border-t border-gray-300">
                    <p className="text-blue-600 text-sm">✓ {formData.links.length} Action Link{formData.links.length > 1 ? 's' : ''} Added</p>
                  </div>
                )}
                {formData.translations.length > 0 && (
                  <div className="pt-2 border-t border-gray-300">
                    <p className="text-green-600 text-sm">✓ {formData.translations.length} Translation{formData.translations.length > 1 ? 's' : ''} Configured</p>
                  </div>
                )}
                {formData.brandingProfile !== 'default' && (
                  <div className="pt-2 border-t border-gray-300">
                    <p className="text-purple-600 text-sm">✓ Custom Branding: {formData.brandingProfile}</p>
                  </div>
                )}
                {formData.enableAutoRouting && (
                  <div className="pt-2 border-t border-gray-300">
                    <p className="text-orange-600 text-sm">✓ Channel Auto-Routing Enabled</p>
                  </div>
                )}
                {formData.vipHandling && (
                  <div className="pt-2 border-t border-gray-300">
                    <p className="text-yellow-600 text-sm">✓ VIP Priority Handling Enabled</p>
                  </div>
                )}
                {formData.fatiguePrevention && (
                  <div className="pt-2 border-t border-gray-300">
                    <p className="text-teal-600 text-sm">✓ User Fatigue Prevention Active</p>
                  </div>
                )}
                {formData.scheduleType !== 'immediate' && (
                  <div className="pt-2 border-t border-gray-300">
                    <p className="text-indigo-600 text-sm">✓ Scheduled Delivery: {formData.scheduleType === 'scheduled' ? 'One-Time' : 'Recurring'}</p>
                  </div>
                )}
              </div>

              {/* Live Message Preview */}
              <div className="border-2 border-purple-300 rounded-lg p-6 bg-gradient-to-br from-purple-50 to-white shadow-sm">
                <div className="flex items-center gap-2 mb-4">
                  <Eye className="w-5 h-5 text-purple-600" />
                  <h4 className="text-gray-900">3. Live Message Preview</h4>
                </div>
                <p className="text-sm text-purple-700 mb-4">
                  This is exactly how your message will appear to end users in their {formData.channel} channel.
                </p>
                
                {/* Template-based Message Preview */}
                <div className="bg-gray-100 rounded-lg p-6 border border-gray-200 flex items-start justify-center">
                  <div className="max-w-md w-full bg-white rounded-lg shadow-lg border border-gray-300">
                    <div className="p-6 space-y-4">
                      {formData.showLogo && (
                        <div className={`flex mb-3 ${
                          formData.logoPosition === 'top-center' ? 'justify-center' :
                          formData.logoPosition === 'top-right' ? 'justify-end' :
                          'justify-start'
                        }`}>
                          {brandingLogo ? (
                            brandingLogo.type === 'svg' ? (
                              <div dangerouslySetInnerHTML={{ __html: brandingLogo.preview }} className="max-h-10" />
                            ) : (
                              <img src={brandingLogo.preview} alt="Branding logo" className="max-h-10" />
                            )
                          ) : (
                            <div className="w-24 h-10 bg-purple-100 border-2 border-purple-300 rounded flex items-center justify-center">
                              <span className="text-xs text-purple-700">Company Logo</span>
                            </div>
                          )}
                        </div>
                      )}
                      
                      {formData.showHeader && (
                        <h3 
                          className="text-gray-900"
                          dangerouslySetInnerHTML={{ __html: formData.messageTitle || 'Message Title' }}
                        />
                      )}
                      
                      {formData.showDescription && formData.messageDescription && (
                        <p 
                          className="text-gray-600 text-sm italic"
                          dangerouslySetInnerHTML={{ __html: formData.messageDescription }}
                        />
                      )}
                      
                      {formData.showBody && (
                        <div 
                          className="text-gray-700 text-sm"
                          dangerouslySetInnerHTML={{ __html: formData.messageContent || 'Your message content will appear here...' }}
                        />
                      )}
                      
                      {(formData.showButton1 || formData.showButton2 || formData.showButton3) && (
                        <div className="flex gap-2 pt-2 border-t border-gray-200">
                          {formData.showButton1 && (
                            <button className={`px-4 py-2 rounded-lg text-sm ${
                              formData.button1Type === 'primary' ? (
                                formData.brandingProfile === 'security' ? 'bg-red-600 text-white' :
                                formData.brandingProfile === 'it' ? 'bg-blue-600 text-white' :
                                formData.brandingProfile === 'hr' ? 'bg-green-600 text-white' :
                                'bg-purple-900 text-white'
                              ) :
                              formData.button1Type === 'secondary' ? 'border border-gray-300 text-gray-700' :
                              'text-gray-600 hover:bg-gray-50'
                            }`}>
                              {formData.buttonPrimary || 'Button 1'}
                            </button>
                          )}
                          {formData.showButton2 && (
                            <button className={`px-4 py-2 rounded-lg text-sm ${
                              formData.button2Type === 'primary' ? (
                                formData.brandingProfile === 'security' ? 'bg-red-600 text-white' :
                                formData.brandingProfile === 'it' ? 'bg-blue-600 text-white' :
                                formData.brandingProfile === 'hr' ? 'bg-green-600 text-white' :
                                'bg-purple-700 text-white'
                              ) :
                              formData.button2Type === 'secondary' ? 'border border-gray-300 text-gray-700' :
                              'text-gray-600 hover:bg-gray-50'
                            }`}>
                              {formData.buttonSecondary || 'Button 2'}
                            </button>
                          )}
                          {formData.showButton3 && (
                            <button className={`px-4 py-2 rounded-lg text-sm ${
                              formData.button3Type === 'primary' ? (
                                formData.brandingProfile === 'security' ? 'bg-red-600 text-white' :
                                formData.brandingProfile === 'it' ? 'bg-blue-600 text-white' :
                                formData.brandingProfile === 'hr' ? 'bg-green-600 text-white' :
                                'bg-purple-700 text-white'
                              ) :
                              formData.button3Type === 'secondary' ? 'border border-gray-300 text-gray-700' :
                              'text-gray-600 hover:bg-gray-50'
                            }`}>
                              {formData.buttonTertiary || 'Button 3'}
                            </button>
                          )}
                        </div>
                      )}

                      {!formData.showHeader && !formData.showDescription && !formData.showBody && 
                       !formData.showButton1 && !formData.showButton2 && !formData.showButton3 && !formData.showLogo && (
                        <div className="text-center py-8 text-gray-400">
                          <p className="text-sm">No elements selected in template</p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-transparent border border-purple-200 rounded-lg p-4">
                <div className="flex items-start gap-2">
                  <Check className="w-4 h-4 text-purple-600 mt-0.5 flex-shrink-0" />
                  <div className="text-xs text-purple-900">
                    <p className="mb-1">This message will be created in <span className="text-purple-700">draft</span> status.</p>
                    <p>You can test, preview, and activate it from the Messages Overview page.</p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        <DialogFooter className="mt-6">
          <button
            onClick={handleClose}
            className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
          >
            Cancel
          </button>
          
          {currentStep > 1 && (
            <button
              onClick={handleBack}
              className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
            >
              Back
            </button>
          )}
          
          {currentStep < totalSteps ? (
            <button
              onClick={handleNext}
              disabled={!isStepValid()}
              className="px-4 py-2 bg-purple-900 text-white rounded-lg hover:bg-purple-950 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Next Step
            </button>
          ) : (
            <button
              onClick={handleSubmit}
              disabled={!isStepValid()}
              className="px-4 py-2 bg-purple-900 text-white rounded-lg hover:bg-purple-950 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {editMessage ? 'Update Message' : 'Create Message'}
            </button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}