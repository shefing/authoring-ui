import { useState } from 'react';
import { Settings, Users, Clock, AlertTriangle, Zap } from 'lucide-react';

interface DeliveryRule {
  id: string;
  name: string;
  category: 'fatigue' | 'sequencing' | 'vip' | 'urgency';
  enabled: boolean;
  config: any;
}

export function DeliveryRules() {
  const [rules] = useState<DeliveryRule[]>([
    {
      id: '1',
      name: 'Survey Fatigue Prevention',
      category: 'fatigue',
      enabled: true,
      config: {
        maxSurveysPerWeek: 2,
        minDaysBetween: 3
      }
    },
    {
      id: '2',
      name: 'Remediation Confirmation Sequencing',
      category: 'sequencing',
      enabled: true,
      config: {
        allowParallel: false,
        maxConcurrent: 1,
        queueNonIntrusive: true
      }
    },
    {
      id: '3',
      name: 'VIP User Reminder Frequency',
      category: 'vip',
      enabled: true,
      config: {
        reminderInterval: 7,
        maxReminders: 2
      }
    },
    {
      id: '4',
      name: 'IT Staff Reminder Frequency',
      category: 'vip',
      enabled: true,
      config: {
        reminderInterval: 1,
        maxReminders: 10
      }
    },
    {
      id: '5',
      name: 'Urgent Message Override',
      category: 'urgency',
      enabled: true,
      config: {
        bypassFatigue: true,
        allowParallel: true
      }
    }
  ]);

  const getCategoryIcon = (category: DeliveryRule['category']) => {
    switch (category) {
      case 'fatigue':
        return <Clock className="w-5 h-5" />;
      case 'sequencing':
        return <Zap className="w-5 h-5" />;
      case 'vip':
        return <Users className="w-5 h-5" />;
      case 'urgency':
        return <AlertTriangle className="w-5 h-5" />;
    }
  };

  const getCategoryColor = (category: DeliveryRule['category']) => {
    switch (category) {
      case 'fatigue':
        return 'bg-blue-100 text-blue-700';
      case 'sequencing':
        return 'bg-purple-100 text-purple-700';
      case 'vip':
        return 'bg-green-100 text-green-700';
      case 'urgency':
        return 'bg-red-100 text-red-700';
    }
  };

  return (
    <div className="p-8">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-gray-50 mb-3 pb-2 pt-3 -mt-8 -mx-8 px-8 border-b border-gray-200">
        <div className="-mb-[7px] pt-5 pb-[15px]">
          <h1 className="text-gray-900">Delivery Rules & Controls</h1>
          <p className="text-gray-600 mt-1">
            Manage fatigue prevention, VIP routing, and role-based delivery controls
          </p>
        </div>
      </div>

      {/* Key Concepts */}
      <div className="mb-8 bg-purple-50 border border-purple-200 rounded-lg p-6">
        <h3 className="text-purple-900 mb-3">Intelligent Delivery Management</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-purple-700 text-sm">
          <div>
            <p className="mb-2">• <span className="text-purple-900">Fatigue Prevention:</span> Limit message frequency to avoid overwhelming users</p>
            <p className="mb-2">• <span className="text-purple-900">Sequencing:</span> Control whether actions can run in parallel or must be sequential</p>
          </div>
          <div>
            <p className="mb-2">• <span className="text-purple-900">VIP Handling:</span> Different rules for executives vs. IT staff vs. general users</p>
            <p className="mb-2">• <span className="text-purple-900">Urgency Override:</span> Critical messages bypass normal restrictions</p>
          </div>
        </div>
      </div>

      {/* Rules Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {rules.map((rule) => (
          <div key={rule.id} className="bg-white rounded-lg border border-gray-200">
            {/* Rule Header */}
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-3 flex-1">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${getCategoryColor(rule.category)}`}>
                    {getCategoryIcon(rule.category)}
                  </div>
                  <div className="flex-1">
                    <h3 className="text-gray-900">{rule.name}</h3>
                    <p className="text-gray-500 text-sm mt-1 capitalize">{rule.category} Rule</p>
                  </div>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input type="checkbox" checked={rule.enabled} readOnly className="sr-only peer" />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                </label>
              </div>
            </div>

            {/* Rule Configuration */}
            <div className="p-6">
              {rule.category === 'fatigue' && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-gray-600 text-sm mb-2">Max Surveys Per Week</label>
                    <input
                      type="number"
                      value={rule.config.maxSurveysPerWeek}
                      readOnly
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-600 text-sm mb-2">Minimum Days Between Surveys</label>
                    <input
                      type="number"
                      value={rule.config.minDaysBetween}
                      readOnly
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                    />
                  </div>
                  <p className="text-gray-500 text-xs">
                    Prevents survey fatigue by limiting how often users are asked to complete surveys
                  </p>
                </div>
              )}

              {rule.category === 'sequencing' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-gray-900 text-sm">Allow Parallel Execution</p>
                      <p className="text-gray-500 text-xs">Multiple remediations at once</p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input type="checkbox" checked={rule.config.allowParallel} readOnly className="sr-only peer" />
                      <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                    </label>
                  </div>
                  <div>
                    <label className="block text-gray-600 text-sm mb-2">Max Concurrent Actions</label>
                    <input
                      type="number"
                      value={rule.config.maxConcurrent}
                      readOnly
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-gray-900 text-sm">Queue Non-Intrusive Messages</p>
                      <p className="text-gray-500 text-xs">Snoozed action shouldn't delay background fixes</p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input type="checkbox" checked={rule.config.queueNonIntrusive} readOnly className="sr-only peer" />
                      <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                    </label>
                  </div>
                </div>
              )}

              {rule.category === 'vip' && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-gray-600 text-sm mb-2">
                      Reminder Interval (days) {rule.name.includes('VIP') ? '(Less Frequent)' : '(More Frequent)'}
                    </label>
                    <input
                      type="number"
                      value={rule.config.reminderInterval}
                      readOnly
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-600 text-sm mb-2">Maximum Reminders</label>
                    <input
                      type="number"
                      value={rule.config.maxReminders}
                      readOnly
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                    />
                  </div>
                  <p className="text-gray-500 text-xs">
                    {rule.name.includes('VIP') 
                      ? 'VIP users receive fewer, less frequent reminders to reduce interruptions'
                      : 'IT staff receive more frequent reminders as they are expected to act quickly'}
                  </p>
                </div>
              )}

              {rule.category === 'urgency' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-gray-900 text-sm">Bypass Fatigue Rules</p>
                      <p className="text-gray-500 text-xs">Critical messages ignore frequency limits</p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input type="checkbox" checked={rule.config.bypassFatigue} readOnly className="sr-only peer" />
                      <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                    </label>
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-gray-900 text-sm">Allow Parallel Urgent Messages</p>
                      <p className="text-gray-500 text-xs">Show immediately, don't wait in queue</p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input type="checkbox" checked={rule.config.allowParallel} readOnly className="sr-only peer" />
                      <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                    </label>
                  </div>
                  <p className="text-gray-500 text-xs">
                    Urgent security alerts and critical issues bypass normal delivery restrictions
                  </p>
                </div>
              )}
            </div>

            {/* Rule Actions */}
            <div className="px-6 py-4 bg-gray-50 border-t border-gray-200 flex justify-end">
              <button className="text-blue-600 hover:text-blue-800 text-sm flex items-center gap-1">
                <Settings className="w-4 h-4" />
                Advanced Settings
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Future Enhancements Note */}
      <div className="bg-gray-50 border border-gray-200 rounded-lg p-6">
        <h3 className="text-gray-900 mb-3">Runbook-Controlled Rules (Future Enhancement)</h3>
        <p className="text-gray-600 text-sm mb-4">
          Some delivery properties should eventually be controlled via Runbook for dynamic, conditional logic:
        </p>
        <ul className="text-gray-600 text-sm space-y-2">
          <li>• Runbook can determine message urgency based on device diagnostics</li>
          <li>• User role (VIP, IT staff, general) can be dynamically determined</li>
          <li>• Fatigue rules can be adjusted based on user's recent interaction history</li>
          <li>• Sequencing can be conditional based on the type of fix being applied</li>
        </ul>
        <p className="text-gray-500 text-xs mt-4">
          Note: The architecture supports this for future enhancement, but initial implementation uses static configuration
        </p>
      </div>

      {/* Use Case Examples */}
      <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
          <h3 className="text-blue-900 mb-2">Scenario: Snoozed Remediation</h3>
          <p className="text-blue-700 text-sm mb-3">
            User snoozes a network fix confirmation for later. The system should:
          </p>
          <ul className="text-blue-700 text-sm space-y-1">
            <li>• Not block background/non-intrusive fixes from running</li>
            <li>• Send reminder after configured interval (different for VIP vs. regular users)</li>
            <li>• Stop reminding after max reminder count is reached</li>
          </ul>
        </div>
        <div className="bg-red-50 border border-red-200 rounded-lg p-6">
          <h3 className="text-red-900 mb-2">Scenario: Security Alert</h3>
          <p className="text-red-700 text-sm mb-3">
            Critical security issue detected on device. The system should:
          </p>
          <ul className="text-red-700 text-sm space-y-1">
            <li>• Bypass fatigue rules and show immediately</li>
            <li>• Display in parallel with any other messages</li>
            <li>• Use urgent branding theme for visibility</li>
            <li>• Apply to all users including VIPs</li>
          </ul>
        </div>
      </div>
    </div>
  );
}