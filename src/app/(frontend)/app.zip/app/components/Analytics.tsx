import { useState } from 'react';
import { BarChart3, TrendingUp, Users, Clock, MessageSquare, CheckCircle } from 'lucide-react';

export function Analytics() {
  const [timeRange, setTimeRange] = useState<'7d' | '30d' | '90d'>('30d');

  const stats = {
    totalMessages: 2847,
    totalSent: 145789,
    totalAcknowledged: 118432,
    avgResponseTime: '4.2 min',
    avgResponseRate: 81,
    activeFlows: 12
  };

  const messageTypeData = [
    { type: 'Confirmation', sent: 45230, acknowledged: 38945, rate: 86 },
    { type: 'Survey', sent: 34567, acknowledged: 25678, rate: 74 },
    { type: 'Notification', sent: 43892, acknowledged: 37891, rate: 86 },
    { type: 'Reminder', sent: 18900, acknowledged: 13524, rate: 72 },
    { type: 'Self-Service', sent: 3200, acknowledged: 2394, rate: 75 }
  ];

  const channelData = [
    { channel: 'Riverbed', sent: 98234, acknowledged: 82345, rate: 84 },
    { channel: 'Teams', sent: 38945, acknowledged: 30123, rate: 77 },
    { channel: 'Email', sent: 8610, acknowledged: 5964, rate: 69 }
  ];

  const topMessages = [
    { name: 'Network Auto-Fix Confirmation', sent: 8934, ack: 7823, rate: 88 },
    { name: 'Win11 Migration Survey', sent: 2450, ack: 1823, rate: 74 },
    { name: 'Security Policy Update', sent: 1200, ack: 1043, rate: 87 },
    { name: 'VPN Connection Issue Fix', sent: 3456, ack: 3102, rate: 90 },
    { name: 'Device Health Self-Service', sent: 867, ack: 734, rate: 85 }
  ];

  return (
    <div className="p-8">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-gray-50 mb-3 pb-2 pt-3 -mt-8 -mx-8 px-8 border-b border-gray-200">
        <div className="flex items-center justify-between -mb-[7px] pt-5">
          <div>
            <h1 className="text-gray-900">Analytics & Insights</h1>
            <p className="text-gray-600 mt-1">
              Track message delivery, user engagement, and channel performance
            </p>
          </div>
          <select
            value={timeRange}
            onChange={(e) => setTimeRange(e.target.value as '7d' | '30d' | '90d')}
            className="px-4 py-2 border border-gray-300 rounded-lg"
          >
            <option value="7d">Last 7 Days</option>
            <option value="30d">Last 30 Days</option>
            <option value="90d">Last 90 Days</option>
          </select>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-8">
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
              <MessageSquare className="w-5 h-5 text-blue-600" />
            </div>
          </div>
          <p className="text-gray-600 text-sm">Total Messages</p>
          <p className="text-gray-900 mt-1">{stats.totalMessages.toLocaleString()}</p>
        </div>
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
              <Users className="w-5 h-5 text-purple-600" />
            </div>
          </div>
          <p className="text-gray-600 text-sm">Messages Sent</p>
          <p className="text-gray-900 mt-1">{stats.totalSent.toLocaleString()}</p>
        </div>
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
              <CheckCircle className="w-5 h-5 text-green-600" />
            </div>
          </div>
          <p className="text-gray-600 text-sm">Acknowledged</p>
          <p className="text-gray-900 mt-1">{stats.totalAcknowledged.toLocaleString()}</p>
        </div>
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-orange-600" />
            </div>
          </div>
          <p className="text-gray-600 text-sm">Avg Response Rate</p>
          <p className="text-gray-900 mt-1">{stats.avgResponseRate}%</p>
        </div>
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 bg-teal-100 rounded-lg flex items-center justify-center">
              <Clock className="w-5 h-5 text-teal-600" />
            </div>
          </div>
          <p className="text-gray-600 text-sm">Avg Response Time</p>
          <p className="text-gray-900 mt-1">{stats.avgResponseTime}</p>
        </div>
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 bg-indigo-100 rounded-lg flex items-center justify-center">
              <BarChart3 className="w-5 h-5 text-indigo-600" />
            </div>
          </div>
          <p className="text-gray-600 text-sm">Active Flows</p>
          <p className="text-gray-900 mt-1">{stats.activeFlows}</p>
        </div>
      </div>

      {/* Performance by Message Type */}
      <div className="bg-white rounded-lg border border-gray-200 mb-8 overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-200">
          <h3 className="text-gray-900">Performance by Message Type</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="text-left px-6 py-3 text-gray-600">Message Type</th>
                <th className="text-left px-6 py-3 text-gray-600">Sent</th>
                <th className="text-left px-6 py-3 text-gray-600">Acknowledged</th>
                <th className="text-left px-6 py-3 text-gray-600">Response Rate</th>
                <th className="text-left px-6 py-3 text-gray-600">Performance</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {messageTypeData.map((item) => (
                <tr key={item.type} className="hover:bg-gray-50">
                  <td className="px-6 py-4">
                    <p className="text-gray-900">{item.type}</p>
                  </td>
                  <td className="px-6 py-4">
                    <p className="text-gray-900">{item.sent.toLocaleString()}</p>
                  </td>
                  <td className="px-6 py-4">
                    <p className="text-gray-900">{item.acknowledged.toLocaleString()}</p>
                  </td>
                  <td className="px-6 py-4">
                    <p className="text-gray-900">{item.rate}%</p>
                  </td>
                  <td className="px-6 py-4">
                    <div className="w-full bg-gray-200 rounded-full h-2 max-w-[200px]">
                      <div 
                        className={`h-2 rounded-full ${
                          item.rate >= 80 ? 'bg-green-600' :
                          item.rate >= 70 ? 'bg-yellow-600' :
                          'bg-red-600'
                        }`}
                        style={{ width: `${item.rate}%` }}
                      />
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Performance by Channel */}
      <div className="bg-white rounded-lg border border-gray-200 mb-8 overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-200">
          <h3 className="text-gray-900">Performance by Channel</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="text-left px-6 py-3 text-gray-600">Channel</th>
                <th className="text-left px-6 py-3 text-gray-600">Sent</th>
                <th className="text-left px-6 py-3 text-gray-600">Acknowledged</th>
                <th className="text-left px-6 py-3 text-gray-600">Response Rate</th>
                <th className="text-left px-6 py-3 text-gray-600">Performance</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {channelData.map((item) => (
                <tr key={item.channel} className="hover:bg-gray-50">
                  <td className="px-6 py-4">
                    <p className="text-gray-900">{item.channel}</p>
                  </td>
                  <td className="px-6 py-4">
                    <p className="text-gray-900">{item.sent.toLocaleString()}</p>
                  </td>
                  <td className="px-6 py-4">
                    <p className="text-gray-900">{item.acknowledged.toLocaleString()}</p>
                  </td>
                  <td className="px-6 py-4">
                    <p className="text-gray-900">{item.rate}%</p>
                  </td>
                  <td className="px-6 py-4">
                    <div className="w-full bg-gray-200 rounded-full h-2 max-w-[200px]">
                      <div 
                        className="bg-blue-600 h-2 rounded-full"
                        style={{ width: `${item.rate}%` }}
                      />
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Top Performing Messages */}
      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-200">
          <h3 className="text-gray-900">Top Performing Messages</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="text-left px-6 py-3 text-gray-600">Message Name</th>
                <th className="text-left px-6 py-3 text-gray-600">Sent</th>
                <th className="text-left px-6 py-3 text-gray-600">Acknowledged</th>
                <th className="text-left px-6 py-3 text-gray-600">Response Rate</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {topMessages.map((item, index) => (
                <tr key={index} className="hover:bg-gray-50">
                  <td className="px-6 py-4">
                    <p className="text-gray-900">{item.name}</p>
                  </td>
                  <td className="px-6 py-4">
                    <p className="text-gray-900">{item.sent.toLocaleString()}</p>
                  </td>
                  <td className="px-6 py-4">
                    <p className="text-gray-900">{item.ack.toLocaleString()}</p>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-full bg-gray-200 rounded-full h-2 max-w-[150px]">
                        <div 
                          className="bg-green-600 h-2 rounded-full"
                          style={{ width: `${item.rate}%` }}
                        />
                      </div>
                      <span className="text-gray-900 text-sm">{item.rate}%</span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* REST API Access Note */}
      <div className="mt-8 bg-green-50 border border-green-200 rounded-lg p-6">
        <h3 className="text-green-900 mb-2">REST API Access</h3>
        <p className="text-green-700 text-sm mb-3">
          All analytics data is available via REST API for integration with external reporting tools:
        </p>
        <div className="bg-green-900 bg-opacity-10 rounded-lg p-4 font-mono text-sm text-green-900">
          <p>GET /api/v1/analytics/messages?timeRange=30d</p>
          <p className="mt-2">GET /api/v1/analytics/channels?timeRange=30d</p>
          <p className="mt-2">GET /api/v1/analytics/acknowledgements?messageId={'{id}'}</p>
        </div>
      </div>
    </div>
  );
}