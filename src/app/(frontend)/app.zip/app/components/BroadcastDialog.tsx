import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';
import { Send } from 'lucide-react';

export interface BroadcastRecord {
  id: string;
  messageId: string;
  targetAudience: string;
  expirationValue: number;
  expirationUnit: 'minutes' | 'hours' | 'days';
  createdAt: Date;
  expiresAt: Date;
}

interface BroadcastDialogProps {
  open: boolean;
  onClose: () => void;
  messageName: string;
  onBroadcast: (data: {
    targetAudience: string;
    expirationValue: number;
    expirationUnit: 'minutes' | 'hours' | 'days';
  }) => void;
}

export function BroadcastDialog({ open, onClose, messageName, onBroadcast }: BroadcastDialogProps) {
  const [targetAudience, setTargetAudience] = useState('');
  const [expirationValue, setExpirationValue] = useState(24);
  const [expirationUnit, setExpirationUnit] = useState<'minutes' | 'hours' | 'days'>('hours');

  const handleBroadcast = () => {
    if (!targetAudience.trim()) {
      alert('Please enter a target audience');
      return;
    }

    if (expirationValue <= 0) {
      alert('Please enter a valid expiration time');
      return;
    }

    onBroadcast({
      targetAudience: targetAudience.trim(),
      expirationValue,
      expirationUnit
    });

    // Reset form
    setTargetAudience('');
    setExpirationValue(24);
    setExpirationUnit('hours');
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="text-gray-900">Broadcast Message</DialogTitle>
          <DialogDescription className="text-gray-600">
            Send "{messageName}" to your target audience
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {/* Target Audience */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Target Audience *
            </label>
            <select
              value={targetAudience}
              onChange={(e) => setTargetAudience(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-900"
            >
              <option value="">Select audience...</option>
              <option value="All Users">All Users</option>
              <option value="IT Operations">IT Operations</option>
              <option value="Engineering">Engineering</option>
              <option value="Support Team">Support Team</option>
              <option value="Executive Team">Executive Team</option>
              <option value="Corporate">Corporate</option>
              <option value="VIP Users">VIP Users</option>
              <option value="Beta Testers">Beta Testers</option>
              <option value="Remote Workers">Remote Workers</option>
              <option value="On-Site Staff">On-Site Staff</option>
            </select>
          </div>

          {/* Expiration Time */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Message Expiration *
            </label>
            <div className="flex gap-2">
              <input
                type="number"
                min="1"
                value={expirationValue}
                onChange={(e) => setExpirationValue(Number(e.target.value))}
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-900"
                placeholder="Enter value"
              />
              <select
                value={expirationUnit}
                onChange={(e) => setExpirationUnit(e.target.value as 'minutes' | 'hours' | 'days')}
                className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-900"
              >
                <option value="minutes">Minutes</option>
                <option value="hours">Hours</option>
                <option value="days">Days</option>
              </select>
            </div>
            <p className="text-xs text-gray-500 mt-1">
              Message will expire after the specified time period
            </p>
          </div>
        </div>

        <div className="flex justify-end gap-3 mt-6">
          <button
            onClick={onClose}
            className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleBroadcast}
            className="px-4 py-2 bg-purple-900 text-white rounded-lg hover:bg-purple-950 transition-colors flex items-center gap-2"
          >
            <Send className="w-4 h-4" />
            Broadcast
          </button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
