import { Message } from './MessagesOverview';
import { X, Calendar, Users, Radio, Workflow, CheckCircle } from 'lucide-react';

interface MessageDetailModalProps {
  message: Message;
  onClose: () => void;
}

export function MessageDetailModal({ message, onClose }: MessageDetailModalProps) {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-auto">
        {/* Header */}
        <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
          <div>
            <h2 className="text-gray-900">{message.name}</h2>
            <p className="text-gray-600 text-sm mt-1">Message Details & Performance</p>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Overview Grid */}
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-gray-50 rounded-lg p-4">
              <div className="flex items-center gap-2 text-gray-600 mb-2">
                <Radio className="w-4 h-4" />
                <span className="text-sm">Channel</span>
              </div>
              <p className="text-gray-900 capitalize">{message.channel}</p>
            </div>
            <div className="bg-gray-50 rounded-lg p-4">
              <div className="flex items-center gap-2 text-gray-600 mb-2">
                <Workflow className="w-4 h-4" />
                <span className="text-sm">Message Type</span>
              </div>
              <p className="text-gray-900 capitalize">{message.type}</p>
            </div>
            <div className="bg-gray-50 rounded-lg p-4">
              <div className="flex items-center gap-2 text-gray-600 mb-2">
                <Users className="w-4 h-4" />
                <span className="text-sm">Target Group</span>
              </div>
              <p className="text-gray-900">{message.targetGroup}</p>
            </div>
            <div className="bg-gray-50 rounded-lg p-4">
              <div className="flex items-center gap-2 text-gray-600 mb-2">
                <Calendar className="w-4 h-4" />
                <span className="text-sm">Created</span>
              </div>
              <p className="text-gray-900">
                {new Date(message.createdAt).toLocaleDateString('en-US', {
                  month: 'long',
                  day: 'numeric',
                  year: 'numeric'
                })}
              </p>
            </div>
          </div>

          {/* Performance Stats */}
          <div>
            <h3 className="text-gray-900 mb-4">Performance Metrics</h3>
            <div className="grid grid-cols-3 gap-4">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-blue-600 text-sm">Messages Sent</p>
                <p className="text-blue-900 mt-1">{message.sent.toLocaleString()}</p>
              </div>
              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                <p className="text-green-600 text-sm">Acknowledged</p>
                <p className="text-green-900 mt-1">{message.acknowledged.toLocaleString()}</p>
              </div>
              <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
                <p className="text-purple-600 text-sm">Response Rate</p>
                <p className="text-purple-900 mt-1">
                  {message.sent > 0 ? Math.round((message.acknowledged / message.sent) * 100) : 0}%
                </p>
              </div>
            </div>
          </div>

          {/* Configuration Details */}
          <div>
            <h3 className="text-gray-900 mb-4">Configuration</h3>
            <div className="bg-gray-50 rounded-lg p-4 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-gray-600">Delivery Mode</span>
                <span className="text-gray-900 capitalize">{message.deliveryMode}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-600">Template</span>
                <span className="text-gray-900">{message.template}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-600">Interactive Flow</span>
                <span className={`flex items-center gap-1 ${message.hasInteractiveFlow ? 'text-green-600' : 'text-gray-400'}`}>
                  <CheckCircle className="w-4 h-4" />
                  {message.hasInteractiveFlow ? 'Enabled' : 'Disabled'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-600">Requires Response</span>
                <span className={`flex items-center gap-1 ${message.requiresResponse ? 'text-green-600' : 'text-gray-400'}`}>
                  <CheckCircle className="w-4 h-4" />
                  {message.requiresResponse ? 'Yes' : 'No'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-600">Created By</span>
                <span className="text-gray-900">{message.createdBy}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-600">Status</span>
                <span className="text-gray-900 capitalize">{message.status}</span>
              </div>
            </div>
          </div>

          {/* Interactive Flow Details (if applicable) */}
          {message.hasInteractiveFlow && (
            <div>
              <h3 className="text-gray-900 mb-4">Interactive Flow Configuration</h3>
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-blue-900">This message uses conditional logic based on user responses</p>
                <ul className="mt-3 space-y-2 text-blue-800 text-sm">
                  <li>• Runbook integration for dynamic data</li>
                  <li>• 2-way communication with minimal latency</li>
                  <li>• Conditional branching based on device diagnostics</li>
                  <li>• Dynamic parameter substitution</li>
                </ul>
              </div>
            </div>
          )}

          {/* Use Case Context */}
          <div>
            <h3 className="text-gray-900 mb-4">Use Case</h3>
            <div className="bg-gray-50 rounded-lg p-4">
              {message.type === 'survey' && (
                <p className="text-gray-700">
                  Multi-step survey with conditional questions. Follow-up questions adjust based on previous responses
                  to gather detailed feedback without overwhelming users.
                </p>
              )}
              {message.type === 'confirmation' && (
                <p className="text-gray-700">
                  Automated fix detection and user confirmation. Presents options: Fix Now, Snooze, Learn More, or Open Ticket.
                  Script signing validation occurs before prompting user.
                </p>
              )}
              {message.type === 'notification' && (
                <p className="text-gray-700">
                  Post-resolution notification to inform users of completed fixes and provide feedback options.
                  Shows transparency in IT operations and allows continued conversation if issues persist.
                </p>
              )}
              {message.type === 'reminder' && (
                <p className="text-gray-700">
                  Follow-up reminder for snoozed actions. Frequency controlled by user fatigue rules and VIP status.
                </p>
              )}
              {message.type === 'self-service' && (
                <p className="text-gray-700">
                  User-initiated chat interface for device health checks and suggested fixes. Provides conversational
                  support with diagnostic capabilities.
                </p>
              )}
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="sticky bottom-0 bg-gray-50 border-t border-gray-200 px-6 py-4 flex justify-end gap-3">
          <button
            onClick={onClose}
            className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-100 transition-colors"
          >
            Close
          </button>
          <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
            Edit Message
          </button>
        </div>
      </div>
    </div>
  );
}
