import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';
import { Label } from './ui/label';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { 
  AlertCircle, 
  Workflow, 
  GitBranch, 
  MessageSquare, 
  CheckCircle, 
  Plus,
  Trash2,
  MoveUp,
  MoveDown
} from 'lucide-react';

interface CreateFlowDialogProps {
  open: boolean;
  onClose: () => void;
  onSubmit?: (flowData: any) => void;
}

type NodeType = 'message' | 'condition' | 'action' | 'runbook';
type TriggerType = 'manual' | 'automatic' | 'runbook';

interface FlowNode {
  id: string;
  type: NodeType;
  label: string;
  config: {
    // Message node
    messageTemplate?: string;
    requiresResponse?: boolean;
    responseOptions?: string[];
    
    // Condition node
    conditionType?: 'user-response' | 'device-state' | 'script-result' | 'custom';
    conditionExpression?: string;
    
    // Action node
    actionType?: 'execute-script' | 'create-ticket' | 'send-notification' | 'update-status';
    actionConfig?: string;
    
    // Runbook node
    runbookId?: string;
    runbookName?: string;
  };
}

export function CreateFlowDialog({ open, onClose, onSubmit }: CreateFlowDialogProps) {
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    triggerType: 'manual' as TriggerType,
    nodes: [] as FlowNode[],
    supportsParallelExecution: false,
    minLatency: true,
    backwardCompatible: true,
  });

  const [selectedNodeIndex, setSelectedNodeIndex] = useState<number | null>(null);

  const totalSteps = 3;

  const handleChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const addNode = (type: NodeType) => {
    const newNode: FlowNode = {
      id: `node-${Date.now()}`,
      type,
      label: getDefaultNodeLabel(type),
      config: {}
    };
    setFormData(prev => ({
      ...prev,
      nodes: [...prev.nodes, newNode]
    }));
    setSelectedNodeIndex(formData.nodes.length);
  };

  const removeNode = (index: number) => {
    setFormData(prev => ({
      ...prev,
      nodes: prev.nodes.filter((_, i) => i !== index)
    }));
    setSelectedNodeIndex(null);
  };

  const moveNode = (index: number, direction: 'up' | 'down') => {
    const newNodes = [...formData.nodes];
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    
    if (targetIndex >= 0 && targetIndex < newNodes.length) {
      [newNodes[index], newNodes[targetIndex]] = [newNodes[targetIndex], newNodes[index]];
      setFormData(prev => ({ ...prev, nodes: newNodes }));
      setSelectedNodeIndex(targetIndex);
    }
  };

  const updateNode = (index: number, updates: Partial<FlowNode>) => {
    setFormData(prev => ({
      ...prev,
      nodes: prev.nodes.map((node, i) => 
        i === index ? { ...node, ...updates } : node
      )
    }));
  };

  const getDefaultNodeLabel = (type: NodeType): string => {
    switch (type) {
      case 'message': return 'Send message to user';
      case 'condition': return 'Check condition';
      case 'action': return 'Execute action';
      case 'runbook': return 'Run diagnostic';
    }
  };

  const getNodeIcon = (type: NodeType) => {
    switch (type) {
      case 'message':
        return <MessageSquare className="w-5 h-5" />;
      case 'condition':
        return <GitBranch className="w-5 h-5" />;
      case 'action':
        return <CheckCircle className="w-5 h-5" />;
      case 'runbook':
        return <Workflow className="w-5 h-5" />;
    }
  };

  const getNodeColor = (type: NodeType) => {
    switch (type) {
      case 'message':
        return 'bg-blue-100 text-blue-700 border-blue-300';
      case 'condition':
        return 'bg-purple-100 text-purple-700 border-purple-300';
      case 'action':
        return 'bg-green-100 text-green-700 border-green-300';
      case 'runbook':
        return 'bg-orange-100 text-orange-700 border-orange-300';
    }
  };

  const handleNext = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSubmit = () => {
    onSubmit?.(formData);
    handleClose();
  };

  const handleClose = () => {
    setFormData({
      name: '',
      description: '',
      triggerType: 'manual',
      nodes: [],
      supportsParallelExecution: false,
      minLatency: true,
      backwardCompatible: true,
    });
    setCurrentStep(1);
    setSelectedNodeIndex(null);
    onClose();
  };

  const isStepValid = () => {
    switch (currentStep) {
      case 1:
        return formData.name.trim() !== '' && formData.triggerType;
      case 2:
        return formData.nodes.length > 0;
      case 3:
        return true;
      default:
        return false;
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create Interactive Flow</DialogTitle>
          <DialogDescription>
            Build conditional message flows with Runbook integration for 2-way communication
          </DialogDescription>
        </DialogHeader>

        {/* Progress Steps */}
        <div className="flex items-center justify-between mb-6">
          {[1, 2, 3].map((step) => (
            <div key={step} className="flex items-center flex-1">
              <div className={`flex items-center justify-center w-8 h-8 rounded-full border-2 transition-colors ${
                step === currentStep 
                  ? 'border-purple-700 bg-purple-700 text-white' 
                  : step < currentStep 
                  ? 'border-purple-700 bg-purple-700 text-white' 
                  : 'border-gray-300 bg-white text-gray-400'
              }`}>
                <span className="text-sm">{step}</span>
              </div>
              {step < 3 && (
                <div className={`h-0.5 flex-1 mx-2 ${
                  step < currentStep ? 'bg-purple-700' : 'bg-gray-300'
                }`} />
              )}
            </div>
          ))}
        </div>

        {/* Step Content */}
        <div className="space-y-4">
          {/* Step 1: Basic Configuration */}
          {currentStep === 1 && (
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-gray-900 mb-4">
                <Workflow className="w-5 h-5 text-blue-600" />
                <h3>Flow Configuration</h3>
              </div>

              <div className="space-y-2">
                <Label htmlFor="name">Flow Name *</Label>
                <Input
                  id="name"
                  placeholder="e.g., Auto-Fix Confirmation Flow"
                  value={formData.name}
                  onChange={(e) => handleChange('name', e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description *</Label>
                <Textarea
                  id="description"
                  placeholder="Describe the purpose and behavior of this flow..."
                  value={formData.description}
                  onChange={(e) => handleChange('description', e.target.value)}
                  rows={3}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="triggerType">Trigger Type *</Label>
                <select
                  id="triggerType"
                  value={formData.triggerType}
                  onChange={(e) => handleChange('triggerType', e.target.value as TriggerType)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="manual">Manual (User-initiated)</option>
                  <option value="automatic">Automatic (Event-triggered)</option>
                  <option value="runbook">Runbook-initiated</option>
                </select>
                <p className="text-xs text-gray-500">
                  Determines how and when this flow is triggered
                </p>
              </div>

              <div className="grid grid-cols-1 gap-3">
                <div className="border border-gray-200 rounded-lg p-4 space-y-3">
                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      id="minLatency"
                      checked={formData.minLatency}
                      onChange={(e) => handleChange('minLatency', e.target.checked)}
                      className="w-4 h-4 text-blue-600 rounded border-gray-300 focus:ring-blue-500"
                    />
                    <Label htmlFor="minLatency" className="cursor-pointer">
                      Optimize for Minimal Latency (2-way communication)
                    </Label>
                  </div>
                  <p className="text-xs text-gray-500 pl-6">
                    Ensures real-time interaction with minimal delay for user responses
                  </p>
                </div>

                <div className="border border-gray-200 rounded-lg p-4 space-y-3">
                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      id="backwardCompatible"
                      checked={formData.backwardCompatible}
                      onChange={(e) => handleChange('backwardCompatible', e.target.checked)}
                      className="w-4 h-4 text-blue-600 rounded border-gray-300 focus:ring-blue-500"
                    />
                    <Label htmlFor="backwardCompatible" className="cursor-pointer">
                      Maintain Backward Compatibility with Remediation NG
                    </Label>
                  </div>
                  <p className="text-xs text-gray-500 pl-6">
                    Ensures existing remediation flows continue to work
                  </p>
                </div>

                <div className="border border-gray-200 rounded-lg p-4 space-y-3">
                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      id="supportsParallelExecution"
                      checked={formData.supportsParallelExecution}
                      onChange={(e) => handleChange('supportsParallelExecution', e.target.checked)}
                      className="w-4 h-4 text-blue-600 rounded border-gray-300 focus:ring-blue-500"
                    />
                    <Label htmlFor="supportsParallelExecution" className="cursor-pointer">
                      Support Parallel Execution (Future Enhancement)
                    </Label>
                  </div>
                  <p className="text-xs text-gray-500 pl-6">
                    Allow multiple branches to execute simultaneously
                  </p>
                </div>
              </div>

              <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
                <div className="flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-purple-600 mt-0.5 flex-shrink-0" />
                  <div className="text-xs text-purple-900">
                    <p className="mb-1">Interactive flows enable:</p>
                    <ul className="list-disc list-inside space-y-1">
                      <li>Conditional logic based on user responses or device state</li>
                      <li>Runbook integration for diagnostics and automated actions</li>
                      <li>Dynamic branching with minimal latency</li>
                      <li>Real-time 2-way communication</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Step 2: Flow Builder */}
          {currentStep === 2 && (
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-gray-900 mb-4">
                <GitBranch className="w-5 h-5 text-blue-600" />
                <h3>Build Flow Logic</h3>
              </div>

              <div className="grid grid-cols-3 gap-6">
                {/* Node Palette */}
                <div className="space-y-3">
                  <h4 className="text-gray-700">Add Nodes</h4>
                  
                  <button
                    onClick={() => addNode('message')}
                    className="w-full flex items-center gap-3 p-3 border-2 border-blue-300 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors"
                  >
                    <MessageSquare className="w-5 h-5 text-blue-700" />
                    <div className="text-left flex-1">
                      <p className="text-blue-900 text-sm">Message</p>
                      <p className="text-blue-700 text-xs">Send to user</p>
                    </div>
                    <Plus className="w-4 h-4 text-blue-700" />
                  </button>

                  <button
                    onClick={() => addNode('condition')}
                    className="w-full flex items-center gap-3 p-3 border-2 border-purple-300 bg-purple-50 rounded-lg hover:bg-purple-100 transition-colors"
                  >
                    <GitBranch className="w-5 h-5 text-purple-700" />
                    <div className="text-left flex-1">
                      <p className="text-purple-900 text-sm">Condition</p>
                      <p className="text-purple-700 text-xs">Branch logic</p>
                    </div>
                    <Plus className="w-4 h-4 text-purple-700" />
                  </button>

                  <button
                    onClick={() => addNode('action')}
                    className="w-full flex items-center gap-3 p-3 border-2 border-green-300 bg-green-50 rounded-lg hover:bg-green-100 transition-colors"
                  >
                    <CheckCircle className="w-5 h-5 text-green-700" />
                    <div className="text-left flex-1">
                      <p className="text-green-900 text-sm">Action</p>
                      <p className="text-green-700 text-xs">Execute task</p>
                    </div>
                    <Plus className="w-4 h-4 text-green-700" />
                  </button>

                  <button
                    onClick={() => addNode('runbook')}
                    className="w-full flex items-center gap-3 p-3 border-2 border-orange-300 bg-orange-50 rounded-lg hover:bg-orange-100 transition-colors"
                  >
                    <Workflow className="w-5 h-5 text-orange-700" />
                    <div className="text-left flex-1">
                      <p className="text-orange-900 text-sm">Runbook</p>
                      <p className="text-orange-700 text-xs">Diagnostics</p>
                    </div>
                    <Plus className="w-4 h-4 text-orange-700" />
                  </button>

                  <div className="bg-gray-50 border border-gray-200 rounded-lg p-3 mt-4">
                    <p className="text-xs text-gray-600">
                      Click to add nodes to your flow. Nodes execute sequentially from top to bottom.
                    </p>
                  </div>
                </div>

                {/* Flow Visualization */}
                <div className="col-span-2 space-y-3">
                  <div className="flex items-center justify-between">
                    <h4 className="text-gray-700">Flow Sequence</h4>
                    <span className="text-xs text-gray-500">{formData.nodes.length} nodes</span>
                  </div>

                  {formData.nodes.length === 0 ? (
                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                      <Workflow className="w-12 h-12 text-gray-400 mx-auto mb-2" />
                      <p className="text-gray-500">No nodes added yet</p>
                      <p className="text-gray-400 text-xs mt-1">Add nodes from the left panel to build your flow</p>
                    </div>
                  ) : (
                    <div className="space-y-2 max-h-96 overflow-y-auto pr-2">
                      {formData.nodes.map((node, index) => (
                        <div key={node.id}>
                          <div 
                            className={`flex items-center gap-3 p-3 rounded-lg border-2 cursor-pointer transition-all ${
                              selectedNodeIndex === index 
                                ? `${getNodeColor(node.type)} border-current` 
                                : 'bg-white border-gray-200 hover:border-gray-300'
                            }`}
                            onClick={() => setSelectedNodeIndex(index)}
                          >
                            <div className={`flex items-center justify-center w-8 h-8 rounded ${getNodeColor(node.type)}`}>
                              {getNodeIcon(node.type)}
                            </div>
                            <div className="flex-1">
                              <p className="text-gray-900 text-sm">{node.label}</p>
                              <p className="text-gray-500 text-xs capitalize">{node.type} node</p>
                            </div>
                            <div className="flex items-center gap-1">
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  moveNode(index, 'up');
                                }}
                                disabled={index === 0}
                                className="p-1 text-gray-400 hover:text-gray-600 disabled:opacity-30"
                              >
                                <MoveUp className="w-4 h-4" />
                              </button>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  moveNode(index, 'down');
                                }}
                                disabled={index === formData.nodes.length - 1}
                                className="p-1 text-gray-400 hover:text-gray-600 disabled:opacity-30"
                              >
                                <MoveDown className="w-4 h-4" />
                              </button>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  removeNode(index);
                                }}
                                className="p-1 text-red-400 hover:text-red-600"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </div>
                          {index < formData.nodes.length - 1 && (
                            <div className="flex justify-center py-1">
                              <div className="w-0.5 h-4 bg-gray-300"></div>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Node Configuration */}
                  {selectedNodeIndex !== null && formData.nodes[selectedNodeIndex] && (
                    <div className="border border-gray-300 rounded-lg p-4 bg-gray-50 space-y-3 mt-4">
                      <h4 className="text-gray-900">Configure Node</h4>
                      
                      <div className="space-y-2">
                        <Label htmlFor="nodeLabel">Node Label</Label>
                        <Input
                          id="nodeLabel"
                          value={formData.nodes[selectedNodeIndex].label}
                          onChange={(e) => updateNode(selectedNodeIndex, { label: e.target.value })}
                          placeholder="Describe what this node does..."
                        />
                      </div>

                      {/* Message Node Config */}
                      {formData.nodes[selectedNodeIndex].type === 'message' && (
                        <div className="space-y-2">
                          <Label htmlFor="messageTemplate">Message Template</Label>
                          <select
                            id="messageTemplate"
                            value={formData.nodes[selectedNodeIndex].config.messageTemplate || ''}
                            onChange={(e) => updateNode(selectedNodeIndex, {
                              config: { ...formData.nodes[selectedNodeIndex].config, messageTemplate: e.target.value }
                            })}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                          >
                            <option value="">Select template...</option>
                            <option value="remediation-confirmation">Remediation Confirmation</option>
                            <option value="success-notification">Success Notification</option>
                            <option value="multi-step-survey">Multi-step Survey</option>
                          </select>
                        </div>
                      )}

                      {/* Condition Node Config */}
                      {formData.nodes[selectedNodeIndex].type === 'condition' && (
                        <div className="space-y-2">
                          <Label htmlFor="conditionType">Condition Type</Label>
                          <select
                            id="conditionType"
                            value={formData.nodes[selectedNodeIndex].config.conditionType || ''}
                            onChange={(e) => updateNode(selectedNodeIndex, {
                              config: { ...formData.nodes[selectedNodeIndex].config, conditionType: e.target.value }
                            })}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                          >
                            <option value="">Select condition...</option>
                            <option value="user-response">User Response</option>
                            <option value="device-state">Device State</option>
                            <option value="script-result">Script Result</option>
                            <option value="custom">Custom Expression</option>
                          </select>
                        </div>
                      )}

                      {/* Action Node Config */}
                      {formData.nodes[selectedNodeIndex].type === 'action' && (
                        <div className="space-y-2">
                          <Label htmlFor="actionType">Action Type</Label>
                          <select
                            id="actionType"
                            value={formData.nodes[selectedNodeIndex].config.actionType || ''}
                            onChange={(e) => updateNode(selectedNodeIndex, {
                              config: { ...formData.nodes[selectedNodeIndex].config, actionType: e.target.value }
                            })}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                          >
                            <option value="">Select action...</option>
                            <option value="execute-script">Execute Script</option>
                            <option value="create-ticket">Create Support Ticket</option>
                            <option value="send-notification">Send Notification</option>
                            <option value="update-status">Update Device Status</option>
                          </select>
                        </div>
                      )}

                      {/* Runbook Node Config */}
                      {formData.nodes[selectedNodeIndex].type === 'runbook' && (
                        <div className="space-y-2">
                          <Label htmlFor="runbookName">Runbook Name</Label>
                          <select
                            id="runbookName"
                            value={formData.nodes[selectedNodeIndex].config.runbookName || ''}
                            onChange={(e) => updateNode(selectedNodeIndex, {
                              config: { ...formData.nodes[selectedNodeIndex].config, runbookName: e.target.value }
                            })}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                          >
                            <option value="">Select runbook...</option>
                            <option value="network-diagnostics">Network Diagnostics</option>
                            <option value="device-health-check">Device Health Check</option>
                            <option value="application-scan">Application Scan</option>
                          </select>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Step 3: Review */}
          {currentStep === 3 && (
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-gray-900 mb-4">
                <CheckCircle className="w-5 h-5 text-blue-600" />
                <h3>Review & Create</h3>
              </div>

              {/* Flow Summary */}
              <div className="border border-gray-200 rounded-lg p-4 space-y-3 bg-white">
                <div className="flex items-center justify-between border-b pb-3">
                  <h4 className="text-gray-900">{formData.name}</h4>
                  <span className={`px-2.5 py-1 rounded-full text-sm capitalize ${
                    formData.triggerType === 'automatic' ? 'bg-green-100 text-green-800' :
                    formData.triggerType === 'runbook' ? 'bg-orange-100 text-orange-800' :
                    'bg-blue-100 text-blue-800'
                  }`}>
                    {formData.triggerType}
                  </span>
                </div>

                <p className="text-gray-600 text-sm">{formData.description}</p>

                <div className="pt-3 border-t border-gray-200">
                  <p className="text-gray-700 text-sm mb-3">Flow Sequence ({formData.nodes.length} nodes):</p>
                  <div className="space-y-2">
                    {formData.nodes.map((node, index) => (
                      <div key={node.id}>
                        <div className={`flex items-center gap-3 p-3 rounded-lg border ${getNodeColor(node.type)}`}>
                          {getNodeIcon(node.type)}
                          <span className="text-sm flex-1">{node.label}</span>
                          <span className="text-xs capitalize opacity-75">{node.type}</span>
                        </div>
                        {index < formData.nodes.length - 1 && (
                          <div className="flex justify-center py-1">
                            <div className="w-0.5 h-4 bg-gray-300"></div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Configuration Summary */}
              <div className="border border-gray-200 rounded-lg p-4 space-y-2 bg-gray-50">
                <h4 className="text-gray-900">Technical Configuration</h4>
                <div className="space-y-1 text-sm">
                  {formData.minLatency && (
                    <p className="text-blue-600">✓ Optimized for minimal latency (2-way communication)</p>
                  )}
                  {formData.backwardCompatible && (
                    <p className="text-green-600">✓ Backward compatible with Remediation NG</p>
                  )}
                  {formData.supportsParallelExecution && (
                    <p className="text-purple-600">✓ Supports parallel execution</p>
                  )}
                  <p className="text-gray-600">
                    • {formData.nodes.filter(n => n.type === 'condition').length} decision points
                  </p>
                  <p className="text-gray-600">
                    • {formData.nodes.filter(n => n.type === 'runbook').length} Runbook integrations
                  </p>
                </div>
              </div>

              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                <div className="flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                  <div className="text-xs text-green-900">
                    <p className="mb-1">Flow will be available immediately after creation.</p>
                    <p>You can assign it to messages or test it in the Flow Builder.</p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        <DialogFooter className="mt-6">
          <button
            onClick={handleClose}
            className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
          >
            Cancel
          </button>
          
          {currentStep > 1 && (
            <button
              onClick={handleBack}
              className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
            >
              Back
            </button>
          )}
          
          {currentStep < totalSteps ? (
            <button
              onClick={handleNext}
              disabled={!isStepValid()}
              className="px-4 py-2 bg-purple-700 text-white rounded-lg hover:bg-purple-800 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Next Step
            </button>
          ) : (
            <button
              onClick={handleSubmit}
              disabled={!isStepValid()}
              className="px-4 py-2 bg-purple-700 text-white rounded-lg hover:bg-purple-800 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Create Flow
            </button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}