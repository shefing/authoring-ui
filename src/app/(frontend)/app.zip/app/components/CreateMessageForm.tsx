import { useState } from 'react';
import { BroadcastMessage } from './BroadcastDashboard';
import { Eye, Send, X, AlertCircle } from 'lucide-react';

interface CreateMessageFormProps {
  onSubmit: (message: Omit<BroadcastMessage, 'id' | 'createdAt' | 'createdBy' | 'acknowledgedCount' | 'totalTargets'>) => void;
  onCancel: () => void;
  onPreview: (message: BroadcastMessage) => void;
}

export function CreateMessageForm({ onSubmit, onCancel, onPreview }: CreateMessageFormProps) {
  const [formData, setFormData] = useState({
    title: '',
    content: '',
    targetGroup: '',
    expirationPeriod: 7,
    expirationUnit: 'days' as 'hours' | 'days' | 'weeks',
    link: '',
    branding: 'remediation' as 'default' | 'remediation',
    status: 'draft' as 'active' | 'expired' | 'draft'
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  const targetGroups = [
    'All Devices',
    'Corporate Laptops',
    'Remote Workers',
    'Engineering Department',
    'Sales Department',
    'Executive Devices',
    'Mobile Devices',
    'Windows Devices',
    'macOS Devices'
  ];

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.title.trim()) {
      newErrors.title = 'Title is required';
    }

    if (!formData.content.trim()) {
      newErrors.content = 'Message content is required';
    }

    if (!formData.targetGroup) {
      newErrors.targetGroup = 'Target group is required';
    }

    if (formData.expirationPeriod <= 0) {
      newErrors.expirationPeriod = 'Expiration period must be greater than 0';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (status: 'draft' | 'active') => {
    if (!validateForm()) return;

    onSubmit({
      ...formData,
      status
    });
  };

  const handlePreview = () => {
    const previewMessage: BroadcastMessage = {
      ...formData,
      id: 'preview',
      createdAt: new Date(),
      createdBy: 'current.user@company.com',
      acknowledgedCount: 0,
      totalTargets: 0
    };
    onPreview(previewMessage);
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        {/* Form Header */}
        <div className="border-b border-gray-200 px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-gray-900">Create Broadcast Message</h2>
              <p className="text-gray-600 mt-1">Configure and send a message to targeted device groups</p>
            </div>
            <button onClick={onCancel} className="text-gray-400 hover:text-gray-600">
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        {/* Form Content */}
        <div className="p-6 space-y-6">
          {/* Feature Flag Notice */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
            <div>
              <p className="text-blue-900">Closed Beta Feature</p>
              <p className="text-blue-700 text-sm mt-1">
                This broadcast messaging feature requires the ADA module to be installed on target devices. 
                Messages will only be delivered to devices with the required module.
              </p>
            </div>
          </div>

          {/* Message Title */}
          <div>
            <label className="block text-gray-700 mb-2">
              Message Title <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              className={`w-full px-3 py-2 border ${errors.title ? 'border-red-500' : 'border-gray-300'} rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent`}
              placeholder="Enter a clear, concise title"
            />
            {errors.title && <p className="text-red-500 text-sm mt-1">{errors.title}</p>}
          </div>

          {/* Message Content */}
          <div>
            <label className="block text-gray-700 mb-2">
              Message Content <span className="text-red-500">*</span>
            </label>
            <textarea
              value={formData.content}
              onChange={(e) => setFormData({ ...formData, content: e.target.value })}
              rows={5}
              className={`w-full px-3 py-2 border ${errors.content ? 'border-red-500' : 'border-gray-300'} rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none`}
              placeholder="Enter the message content that will be displayed to users"
            />
            {errors.content && <p className="text-red-500 text-sm mt-1">{errors.content}</p>}
            <p className="text-gray-500 text-sm mt-1">Message will be displayed as a popup with an OK button</p>
          </div>

          {/* Optional Link */}
          <div>
            <label className="block text-gray-700 mb-2">
              Link (Optional)
            </label>
            <input
              type="url"
              value={formData.link}
              onChange={(e) => setFormData({ ...formData, link: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="https://example.com/more-info"
            />
            <p className="text-gray-500 text-sm mt-1">Add a clickable link within the message</p>
          </div>

          {/* Target Group */}
          <div>
            <label className="block text-gray-700 mb-2">
              Target Entity Group <span className="text-red-500">*</span>
            </label>
            <select
              value={formData.targetGroup}
              onChange={(e) => setFormData({ ...formData, targetGroup: e.target.value })}
              className={`w-full px-3 py-2 border ${errors.targetGroup ? 'border-red-500' : 'border-gray-300'} rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent`}
            >
              <option value="">Select a target group</option>
              {targetGroups.map((group) => (
                <option key={group} value={group}>{group}</option>
              ))}
            </select>
            {errors.targetGroup && <p className="text-red-500 text-sm mt-1">{errors.targetGroup}</p>}
          </div>

          {/* Expiration Period */}
          <div>
            <label className="block text-gray-700 mb-2">
              Expiration Period <span className="text-red-500">*</span>
            </label>
            <div className="flex gap-3">
              <input
                type="number"
                min="1"
                value={formData.expirationPeriod}
                onChange={(e) => setFormData({ ...formData, expirationPeriod: parseInt(e.target.value) || 1 })}
                className={`w-32 px-3 py-2 border ${errors.expirationPeriod ? 'border-red-500' : 'border-gray-300'} rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent`}
              />
              <select
                value={formData.expirationUnit}
                onChange={(e) => setFormData({ ...formData, expirationUnit: e.target.value as 'hours' | 'days' | 'weeks' })}
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="hours">Hours</option>
                <option value="days">Days</option>
                <option value="weeks">Weeks</option>
              </select>
            </div>
            {errors.expirationPeriod && <p className="text-red-500 text-sm mt-1">{errors.expirationPeriod}</p>}
            <p className="text-gray-500 text-sm mt-1">
              How long the message should wait for non-reporting devices
            </p>
          </div>

          {/* Branding */}
          <div>
            <label className="block text-gray-700 mb-2">
              Branding / Template
            </label>
            <select
              value={formData.branding}
              onChange={(e) => setFormData({ ...formData, branding: e.target.value as 'default' | 'remediation' })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="remediation">Remediation Template (Default for MS0)</option>
              <option value="default">Default Template</option>
            </select>
            <p className="text-gray-500 text-sm mt-1">
              MS0: Using remediation branding as default. CSS branding capabilities planned for future release.
            </p>
          </div>
        </div>

        {/* Form Actions */}
        <div className="border-t border-gray-200 px-6 py-4 bg-gray-50 flex items-center justify-between">
          <button
            onClick={handlePreview}
            className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-100 transition-colors"
          >
            <Eye className="w-4 h-4" />
            Preview
          </button>
          <div className="flex items-center gap-3">
            <button
              onClick={onCancel}
              className="px-4 py-2 text-gray-700 hover:text-gray-900 transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={() => handleSubmit('draft')}
              className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-100 transition-colors"
            >
              Save as Draft
            </button>
            <button
              onClick={() => handleSubmit('active')}
              className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Send className="w-4 h-4" />
              Send Broadcast
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
