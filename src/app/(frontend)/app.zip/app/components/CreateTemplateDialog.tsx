import { useState, useRef } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';
import { Label } from './ui/label';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { AlertCircle, FileText, Palette, Globe, Code, Check, MessageSquare, MousePointerClick, Bold, Italic, Underline, List, ListOrdered, Link } from 'lucide-react';
import { BrandingLogo } from './UnifiedCommunicationPlatform';

interface CreateTemplateDialogProps {
  open: boolean;
  onClose: () => void;
  onSubmit?: (templateData: any) => void;
  brandingLogo: BrandingLogo | null;
  dialogTitle?: string;
}

type MessageType = 'survey' | 'confirmation' | 'notification' | 'reminder' | 'self-service';

// Rich Text Formatting Toolbar Component
function FormattingToolbar({ onFormat }: { onFormat: (tag: string) => void }) {
  return (
    <div className="flex items-center gap-1 p-2 bg-gray-50 border border-gray-200 rounded-t-lg">
      <button
        type="button"
        onClick={() => onFormat('bold')}
        className="p-1.5 hover:bg-gray-200 rounded transition-colors"
        title="Bold"
      >
        <Bold className="w-4 h-4 text-gray-700" />
      </button>
      <button
        type="button"
        onClick={() => onFormat('italic')}
        className="p-1.5 hover:bg-gray-200 rounded transition-colors"
        title="Italic"
      >
        <Italic className="w-4 h-4 text-gray-700" />
      </button>
      <button
        type="button"
        onClick={() => onFormat('underline')}
        className="p-1.5 hover:bg-gray-200 rounded transition-colors"
        title="Underline"
      >
        <Underline className="w-4 h-4 text-gray-700" />
      </button>
      <div className="w-px h-6 bg-gray-300 mx-1" />
      <button
        type="button"
        onClick={() => onFormat('ul')}
        className="p-1.5 hover:bg-gray-200 rounded transition-colors"
        title="Bullet List"
      >
        <List className="w-4 h-4 text-gray-700" />
      </button>
      <button
        type="button"
        onClick={() => onFormat('ol')}
        className="p-1.5 hover:bg-gray-200 rounded transition-colors"
        title="Numbered List"
      >
        <ListOrdered className="w-4 h-4 text-gray-700" />
      </button>
      <div className="w-px h-6 bg-gray-300 mx-1" />
      <button
        type="button"
        onClick={() => onFormat('link')}
        className="p-1.5 hover:bg-gray-200 rounded transition-colors"
        title="Insert Link"
      >
        <Link className="w-4 h-4 text-gray-700" />
      </button>
      <div className="ml-auto text-xs text-gray-500">
        Select text to format
      </div>
    </div>
  );
}

export function CreateTemplateDialog({ open, onClose, onSubmit, brandingLogo, dialogTitle }: CreateTemplateDialogProps) {
  const [currentStep, setCurrentStep] = useState(1);
  const [contentTab, setContentTab] = useState<'title' | 'description' | 'body'>('title');
  
  // Refs for rich text editing
  const titleInputRef = useRef<HTMLInputElement>(null);
  const descriptionInputRef = useRef<HTMLInputElement>(null);
  const bodyTextareaRef = useRef<HTMLTextAreaElement>(null);
  
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    type: 'notification' as MessageType,
    division: 'Corporate',
    channels: [] as string[],
    supportsDynamic: false,
    supportsTranslation: false,
    
    // Content
    title: '',
    body: '',
    messageDescription: '',
    buttonPrimary: '',
    buttonSecondary: '',
    buttonTertiary: '',
    
    // Element Visibility
    showHeader: true,
    showDescription: true,
    showBody: true,
    showButton1: true,
    showButton2: true,
    showButton3: true,
    
    // Button Configuration
    buttonCount: 3,
    button1Type: 'primary' as 'primary' | 'secondary' | 'tertiary',
    button2Type: 'secondary' as 'primary' | 'secondary' | 'tertiary',
    button3Type: 'tertiary' as 'primary' | 'secondary' | 'tertiary',
    
    // Logo Settings
    showLogo: false,
    logoPosition: 'top-left' as 'top-left' | 'top-center' | 'top-right',
    
    // Styling
    brandingProfile: 'default' as 'default' | 'security' | 'it' | 'hr' | 'custom',
    customCSS: '',
    
    // Translation
    languages: [] as string[],
    defaultLanguage: 'en',
    
    // Dynamic Parameters
    dynamicParams: [] as string[],
    parameterHelp: '',
  });

  const totalSteps = 8;

  const handleChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleChannelToggle = (channel: string) => {
    setFormData(prev => ({
      ...prev,
      channels: prev.channels.includes(channel)
        ? prev.channels.filter(c => c !== channel)
        : [...prev.channels, channel]
    }));
  };

  const handleParamToggle = (param: string) => {
    setFormData(prev => ({
      ...prev,
      dynamicParams: prev.dynamicParams.includes(param)
        ? prev.dynamicParams.filter(p => p !== param)
        : [...prev.dynamicParams, param]
    }));
  };

  // Helper to wrap selected text with formatting tags
  const applyFormatting = (field: string, tag: string, textareaRef?: HTMLTextAreaElement | HTMLInputElement | null) => {
    if (!textareaRef) return;
    
    const start = textareaRef.selectionStart || 0;
    const end = textareaRef.selectionEnd || 0;
    const text = formData[field as keyof typeof formData] as string || '';
    const selectedText = text.substring(start, end);
    
    let newText = '';
    let newCursorPos = start;
    
    if (tag === 'bold') {
      newText = text.substring(0, start) + '<strong>' + selectedText + '</strong>' + text.substring(end);
      newCursorPos = start + 8; // length of '<strong>'
    } else if (tag === 'italic') {
      newText = text.substring(0, start) + '<em>' + selectedText + '</em>' + text.substring(end);
      newCursorPos = start + 4; // length of '<em>'
    } else if (tag === 'underline') {
      newText = text.substring(0, start) + '<u>' + selectedText + '</u>' + text.substring(end);
      newCursorPos = start + 3; // length of '<u>'
    } else if (tag === 'link') {
      const url = prompt('Enter URL:');
      if (url) {
        newText = text.substring(0, start) + '<a href="' + url + '">' + (selectedText || 'Link') + '</a>' + text.substring(end);
        newCursorPos = start + 9 + url.length; // length of '<a href="URL">'
      } else {
        return;
      }
    } else if (tag === 'ul') {
      newText = text.substring(0, start) + '<ul>\n  <li>' + (selectedText || 'List item') + '</li>\n</ul>' + text.substring(end);
      newCursorPos = start + 10; // position after '<ul>\n  <li>'
    } else if (tag === 'ol') {
      newText = text.substring(0, start) + '<ol>\n  <li>' + (selectedText || 'List item') + '</li>\n</ol>' + text.substring(end);
      newCursorPos = start + 10; // position after '<ol>\n  <li>'
    }
    
    handleChange(field, newText);
    
    // Restore cursor position after state update
    setTimeout(() => {
      if (textareaRef) {
        textareaRef.focus();
        textareaRef.setSelectionRange(newCursorPos, newCursorPos);
      }
    }, 0);
  };

  const handleNext = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSubmit = () => {
    onSubmit?.(formData);
    handleClose();
  };

  const handleClose = () => {
    setFormData({
      name: '',
      description: '',
      type: 'notification',
      division: 'Corporate',
      channels: [],
      supportsDynamic: false,
      supportsTranslation: false,
      title: '',
      body: '',
      messageDescription: '',
      buttonPrimary: '',
      buttonSecondary: '',
      buttonTertiary: '',
      showHeader: true,
      showDescription: true,
      showBody: true,
      showButton1: true,
      showButton2: true,
      showButton3: true,
      buttonCount: 3,
      button1Type: 'primary',
      button2Type: 'secondary',
      button3Type: 'tertiary',
      showLogo: false,
      logoPosition: 'top-left',
      brandingProfile: 'default',
      customCSS: '',
      languages: [],
      defaultLanguage: 'en',
      dynamicParams: [],
      parameterHelp: '',
    });
    setCurrentStep(1);
    onClose();
  };

  const isStepValid = () => {
    switch (currentStep) {
      case 1:
        return formData.name.trim() !== '' && formData.type === 'notification';
      case 2:
        return formData.title.trim() !== '' || formData.messageDescription.trim() !== '' || formData.body.trim() !== '';
      case 3:
        return true; // Button configuration is optional
      case 4:
        return true; // Logo is optional
      case 5:
        return formData.channels.length > 0;
      case 6:
        return true; // Dynamic parameters optional
      case 7:
        return true; // Branding is optional
      case 8:
        return true; // Review step
      default:
        return false;
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-[80vw] w-[80vw] max-h-[90vh] overflow-y-auto top-[5%] -translate-y-0">
        <DialogHeader>
          <DialogTitle>{dialogTitle || 'Create New Template'}</DialogTitle>
          <DialogDescription>
            Create a reusable message template with branding, dynamic parameters, and multi-channel support
          </DialogDescription>
        </DialogHeader>

        {/* Progress Steps */}
        <div className="flex items-center justify-between mb-6">
          {[1, 2, 3, 4, 5, 6, 7, 8].map((step) => (
            <div key={step} className="flex items-center flex-1">
              <div className={`flex items-center justify-center w-8 h-8 rounded-full border-2 transition-colors ${
                step === currentStep 
                  ? 'border-purple-900 bg-purple-900 text-white' 
                  : step < currentStep 
                  ? 'border-purple-900 bg-purple-900 text-white' 
                  : 'border-gray-300 bg-white text-gray-400'
              }`}>
                <span className="text-sm">{step}</span>
              </div>
              {step < 8 && (
                <div className={`h-0.5 flex-1 mx-2 ${
                  step < currentStep ? 'bg-purple-900' : 'bg-gray-300'
                }`} />
              )}
            </div>
          ))}
        </div>

        {/* Step Content */}
        <div className="space-y-4">
          {/* Step 1: Basic Information */}
          {currentStep === 1 && (
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-gray-900 mb-4">
                <FileText className="w-5 h-5 text-purple-700" />
                <h3>Basic Information</h3>
              </div>

              <div className="space-y-2">
                <Label htmlFor="name">Template Name *</Label>
                <Input
                  id="name"
                  placeholder="e.g., Security Alert - Engineering Division"
                  value={formData.name}
                  onChange={(e) => handleChange('name', e.target.value)}
                  className="border border-gray-300"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  placeholder="Brief description of when and how this template should be used..."
                  value={formData.description}
                  onChange={(e) => handleChange('description', e.target.value)}
                  rows={3}
                  className="border border-gray-300"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="type">Message Type *</Label>
                <select
                  id="type"
                  value={formData.type}
                  onChange={(e) => handleChange('type', e.target.value as MessageType)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="survey">Survey</option>
                  <option value="confirmation">Confirmation</option>
                  <option value="notification">Notification</option>
                  <option value="reminder">Reminder</option>
                  <option value="self-service">Self-Service</option>
                </select>
                <p className="text-xs text-gray-500">
                  Determines available content fields and structure
                </p>
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div className="flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                  <div className="text-xs text-blue-900">
                    <p className="mb-1">Reusable Template</p>
                    <p>Create once and reuse across multiple messages. Ensures consistent branding and saves time.</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Step 2: Message Content */}
          {currentStep === 2 && (
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-gray-900 mb-4">
                <MessageSquare className="w-5 h-5 text-purple-700" />
                <h3>Message Content</h3>
              </div>

              <div className="border border-purple-200 rounded-lg p-4 space-y-4 bg-purple-50">
                <Label>Configure Message Content</Label>
                <p className="text-xs text-gray-500">
                  Define the content fields for your template with rich text editing support
                </p>
                
                {/* Content Tabs */}
                <div className="space-y-2">
                  <div className="flex border-b border-purple-300">
                    <button
                      type="button"
                      onClick={() => setContentTab('title')}
                      className={`px-4 py-2 text-sm transition-colors ${
                        contentTab === 'title'
                          ? 'border-b-2 border-purple-900 text-purple-900'
                          : 'text-gray-600 hover:text-gray-900'
                      }`}
                    >
                      Title
                    </button>
                    <button
                      type="button"
                      onClick={() => setContentTab('description')}
                      className={`px-4 py-2 text-sm transition-colors ${
                        contentTab === 'description'
                          ? 'border-b-2 border-purple-900 text-purple-900'
                          : 'text-gray-600 hover:text-gray-900'
                      }`}
                    >
                      Description
                    </button>
                    <button
                      type="button"
                      onClick={() => setContentTab('body')}
                      className={`px-4 py-2 text-sm transition-colors ${
                        contentTab === 'body'
                          ? 'border-b-2 border-purple-900 text-purple-900'
                          : 'text-gray-600 hover:text-gray-900'
                      }`}
                    >
                      Body
                    </button>
                  </div>

                  {/* Title Tab */}
                  {contentTab === 'title' && (
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 mb-2">
                        <input
                          type="checkbox"
                          id="enableTitle"
                          checked={formData.showHeader}
                          onChange={(e) => handleChange('showHeader', e.target.checked)}
                          className="w-4 h-4 text-purple-600 rounded border-gray-300 focus:ring-purple-500"
                        />
                        <Label htmlFor="enableTitle" className="cursor-pointer">
                          Enable Message Title
                        </Label>
                      </div>
                      {formData.showHeader && (
                        <div>
                          <FormattingToolbar onFormat={(tag) => applyFormatting('title', tag, titleInputRef.current)} />
                          <Input
                            ref={titleInputRef}
                            id="messageTitle"
                            placeholder="e.g., Security Alert, Update Complete, Action Required"
                            value={formData.title}
                            onChange={(e) => handleChange('title', e.target.value)}
                            className="rounded-t-none border-t-0 h-20"
                          />
                          <p className="text-xs text-gray-500 mt-1">
                            The title that end users will see (supports HTML formatting)
                          </p>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Description Tab */}
                  {contentTab === 'description' && (
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 mb-2">
                        <input
                          type="checkbox"
                          id="enableMessageDescription"
                          checked={formData.showDescription}
                          onChange={(e) => handleChange('showDescription', e.target.checked)}
                          className="w-4 h-4 text-purple-600 rounded border-gray-300 focus:ring-purple-500"
                        />
                        <Label htmlFor="enableMessageDescription" className="cursor-pointer">
                          Enable Message Description
                        </Label>
                      </div>
                      {formData.showDescription && (
                        <div>
                          <FormattingToolbar onFormat={(tag) => applyFormatting('messageDescription', tag, descriptionInputRef.current)} />
                          <Input
                            ref={descriptionInputRef}
                            id="messageDescription"
                            placeholder="e.g., Brief summary or subtitle for the message"
                            value={formData.messageDescription || ''}
                            onChange={(e) => handleChange('messageDescription', e.target.value)}
                            className="rounded-t-none border-t-0 h-20"
                          />
                          <p className="text-xs text-gray-500 mt-1">
                            Optional short description or subtitle (supports HTML formatting)
                          </p>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Body Tab */}
                  {contentTab === 'body' && (
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 mb-2">
                        <input
                          type="checkbox"
                          id="enableBody"
                          checked={formData.showBody}
                          onChange={(e) => handleChange('showBody', e.target.checked)}
                          className="w-4 h-4 text-purple-600 rounded border-gray-300 focus:ring-purple-500"
                        />
                        <Label htmlFor="enableBody" className="cursor-pointer">
                          Enable Message Body
                        </Label>
                      </div>
                      {formData.showBody && (
                        <div>
                          <FormattingToolbar onFormat={(tag) => applyFormatting('body', tag, bodyTextareaRef.current)} />
                          <Textarea
                            ref={bodyTextareaRef}
                            id="messageBody"
                            placeholder="e.g., Your system update has been completed successfully. No further action is required."
                            value={formData.body}
                            onChange={(e) => handleChange('body', e.target.value)}
                            rows={3}
                            className="rounded-t-none border-t-0"
                          />
                          <p className="text-xs text-gray-500 mt-1">
                            The main message content that end users will see (supports HTML formatting)
                          </p>
                        </div>
                      )}
                    </div>
                  )}
                </div>

                <p className="text-xs text-purple-700 pt-2 border-t border-purple-200">
                  Note: Content fields will be used as defaults when creating messages from this template. These values can be overridden later when creating a message based on this template.
                </p>
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div className="flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                  <div className="text-xs text-blue-900">
                    <p>Content fields will be used as defaults when creating messages from this template.</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Step 3: Actions Configuration */}
          {currentStep === 3 && (
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-gray-900 mb-4">
                <MousePointerClick className="w-5 h-5 text-purple-700" />
                <h3>Actions Configuration</h3>
              </div>

              <div className="border border-purple-200 rounded-lg p-4 space-y-4 bg-purple-50">
                <Label>Button Configuration</Label>
                <p className="text-xs text-gray-500">
                  Configure action buttons for user interactions
                </p>
                
                {/* Button Count Selector */}
                <div className="space-y-2">
                  <Label>Number of Buttons</Label>
                  <div className="flex gap-2">
                    {[0, 1, 2, 3].map((count) => (
                      <button
                        key={count}
                        type="button"
                        onClick={() => {
                          handleChange('buttonCount', count);
                          handleChange('showButton1', count >= 1);
                          handleChange('showButton2', count >= 2);
                          handleChange('showButton3', count >= 3);
                        }}
                        className={`flex-1 px-4 py-2 text-sm rounded-lg border-2 transition-all ${
                          formData.buttonCount === count
                            ? 'border-purple-600 bg-purple-100 text-purple-900'
                            : 'border-gray-300 bg-white text-gray-700 hover:border-gray-400'
                        }`}
                      >
                        {count === 0 ? 'None' : count}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Button Type Selectors */}
                {formData.buttonCount >= 1 && (
                  <div className="space-y-3 pt-3 border-t border-purple-200">
                    {/* Button 1 Type & Text */}
                    <div className="space-y-2">
                      <Label>Button 1 Type</Label>
                      <div className="flex gap-2">
                        {['primary', 'secondary', 'tertiary'].map((type) => (
                          <button
                            key={type}
                            type="button"
                            onClick={() => handleChange('button1Type', type)}
                            className={`flex-1 px-3 py-2 text-sm rounded-lg border-2 transition-all capitalize ${
                              formData.button1Type === type
                                ? 'border-purple-600 bg-white text-purple-900'
                                : 'border-gray-300 bg-white text-gray-700 hover:border-gray-400'
                            }`}
                          >
                            {type}
                          </button>
                        ))}
                      </div>
                      <Input
                        placeholder="Enter button 1 text..."
                        value={formData.buttonPrimary}
                        onChange={(e) => handleChange('buttonPrimary', e.target.value)}
                        className="mt-2 max-w-md"
                      />
                    </div>

                    {/* Button 2 Type & Text */}
                    {formData.buttonCount >= 2 && (
                      <div className="space-y-2">
                        <Label>Button 2 Type</Label>
                        <div className="flex gap-2">
                          {['primary', 'secondary', 'tertiary'].map((type) => (
                            <button
                              key={type}
                              type="button"
                              onClick={() => handleChange('button2Type', type)}
                              className={`flex-1 px-3 py-2 text-sm rounded-lg border-2 transition-all capitalize ${
                                formData.button2Type === type
                                  ? 'border-purple-600 bg-white text-purple-900'
                                  : 'border-gray-300 bg-white text-gray-700 hover:border-gray-400'
                              }`}
                            >
                              {type}
                            </button>
                          ))}
                        </div>
                        <Input
                          placeholder="Enter button 2 text..."
                          value={formData.buttonSecondary}
                          onChange={(e) => handleChange('buttonSecondary', e.target.value)}
                          className="mt-2 max-w-md"
                        />
                      </div>
                    )}

                    {/* Button 3 Type & Text */}
                    {formData.buttonCount >= 3 && (
                      <div className="space-y-2">
                        <Label>Button 3 Type</Label>
                        <div className="flex gap-2">
                          {['primary', 'secondary', 'tertiary'].map((type) => (
                            <button
                              key={type}
                              type="button"
                              onClick={() => handleChange('button3Type', type)}
                              className={`flex-1 px-3 py-2 text-sm rounded-lg border-2 transition-all capitalize ${
                                formData.button3Type === type
                                  ? 'border-purple-600 bg-white text-purple-900'
                                  : 'border-gray-300 bg-white text-gray-700 hover:border-gray-400'
                              }`}
                            >
                              {type}
                            </button>
                          ))}
                        </div>
                        <Input
                          placeholder="Enter button 3 text..."
                          value={formData.buttonTertiary}
                          onChange={(e) => handleChange('buttonTertiary', e.target.value)}
                          className="mt-2 max-w-md"
                        />
                      </div>
                    )}
                  </div>
                )}

                <p className="text-xs text-purple-700 pt-2 border-t border-purple-200">
                  Note: Button texts can be overridden later when creating a message based on this template.
                </p>
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div className="flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                  <div className="text-xs text-blue-900">
                    <p>Primary buttons are highlighted, secondary buttons have borders, and tertiary buttons are text-only.</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Step 4: Logo Settings */}
          {currentStep === 4 && (
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-gray-900 mb-4">
                <Palette className="w-5 h-5 text-purple-700" />
                <h3>Logo Settings</h3>
              </div>

              <div className="border border-gray-200 rounded-lg p-4 space-y-3">
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="showLogo"
                    checked={formData.showLogo}
                    onChange={(e) => handleChange('showLogo', e.target.checked)}
                    className="w-4 h-4 text-purple-300 rounded border-gray-300 focus:ring-purple-500"
                  />
                  <Label htmlFor="showLogo" className="cursor-pointer">
                    Show Branding Logo
                  </Label>
                </div>

                {formData.showLogo && (
                  <div className="pl-6 space-y-4">
                    <div className="space-y-2">
                      <Label>Logo Position</Label>
                      <p className="text-xs text-gray-500 mb-2">
                        Select the position of the branding logo in the message
                      </p>
                      <div className="grid grid-cols-3 gap-2">
                        {['top-left', 'top-center', 'top-right'].map((position) => (
                          <div key={position} className="flex items-center gap-2 p-2 border border-gray-200 rounded hover:bg-gray-50">
                            <input
                              type="radio"
                              id={`logo-${position}`}
                              checked={formData.logoPosition === position}
                              onChange={() => handleChange('logoPosition', position)}
                              className="w-3 h-3 text-purple-300 rounded border-gray-300"
                            />
                            <label htmlFor={`logo-${position}`} className="text-sm cursor-pointer capitalize">
                              {position.replace('-', ' ')}
                            </label>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Logo Preview */}
                    <div className="space-y-2">
                      <Label>Logo Preview</Label>
                      <div className="bg-gray-100 rounded-lg p-6 border border-gray-200">
                        <div className="max-w-md mx-auto bg-white rounded-lg shadow-sm border border-gray-300 p-6">
                          <div className={`flex ${
                            formData.logoPosition === 'top-center' ? 'justify-center' :
                            formData.logoPosition === 'top-right' ? 'justify-end' :
                            'justify-start'
                          }`}>
                            {brandingLogo ? (
                              brandingLogo.type === 'svg' ? (
                                <div dangerouslySetInnerHTML={{ __html: brandingLogo.preview }} className="max-h-12" />
                              ) : (
                                <img src={brandingLogo.preview} alt="Branding logo" className="max-h-12" />
                              )
                            ) : (
                              <div className="w-32 h-12 bg-purple-100 border-2 border-purple-300 rounded flex items-center justify-center">
                                <span className="text-xs text-purple-700">No Logo Uploaded</span>
                              </div>
                            )}
                          </div>
                          <div className="mt-4 pt-4 border-t border-gray-200">
                            <p className="text-sm text-gray-500 text-center">Message content will appear below the logo</p>
                          </div>
                        </div>
                      </div>
                      {!brandingLogo && (
                        <p className="text-xs text-orange-600">
                          No logo uploaded yet. Upload a logo on the Branding & CSS Customization page.
                        </p>
                      )}
                    </div>
                  </div>
                )}

                <div className="bg-blue-50 border border-blue-200 rounded p-3 mt-3">
                  <div className="flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                    <p className="text-xs text-blue-900">
                      Branding logos help maintain consistency and recognition across messages. Upload your logo on the Branding & CSS Customization page.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Step 5: Supported Channels */}
          {currentStep === 5 && (
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-gray-900 mb-4">
                <Globe className="w-5 h-5 text-purple-700" />
                <h3>Supported Channels</h3>
              </div>

              <div className="space-y-2 border border-gray-200 rounded-lg p-4">
                <Label>Supported Channels *</Label>
                <p className="text-xs text-gray-500">
                  Select all channels where this template can be used
                </p>
                <div className="grid grid-cols-2 gap-3 mt-4">
                  {[
                    { id: 'riverbed', label: 'Riverbed IOT', description: 'Native in-app notifications' },
                    { id: 'teams', label: 'Microsoft Teams', description: 'Team collaboration messages' },
                    { id: 'slack', label: 'Slack', description: 'Workspace notifications' },
                    { id: 'email', label: 'Email', description: 'Traditional email delivery' }
                  ].map((channel) => (
                    <div key={channel.id} className="flex items-start gap-3 p-3 hover:bg-gray-50 rounded border border-gray-200">
                      <input
                        type="checkbox"
                        id={channel.id}
                        checked={formData.channels.includes(channel.id)}
                        onChange={() => handleChannelToggle(channel.id)}
                        className="w-4 h-4 text-purple-300 rounded border-gray-300 focus:ring-purple-500 mt-1"
                      />
                      <div className="flex-1">
                        <Label htmlFor={channel.id} className="cursor-pointer">
                          {channel.label}
                        </Label>
                        <p className="text-xs text-gray-500 mt-0.5">{channel.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div className="flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                  <div className="text-xs text-blue-900">
                    <p>Templates can be used across multiple channels. Channel-specific formatting will be applied automatically.</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Step 6: Dynamic Parameters */}
          {currentStep === 6 && (
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-gray-900 mb-4">
                <Code className="w-5 h-5 text-purple-700" />
                <h3>Dynamic Parameters</h3>
              </div>

              <div className="border border-gray-200 rounded-lg p-4 space-y-3">
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="supportsDynamic"
                    checked={formData.supportsDynamic}
                    onChange={(e) => handleChange('supportsDynamic', e.target.checked)}
                    className="w-4 h-4 text-purple-300 rounded border-gray-300 focus:ring-purple-500"
                  />
                  <Label htmlFor="supportsDynamic" className="cursor-pointer">
                    Enable Dynamic Parameters
                  </Label>
                </div>

                {formData.supportsDynamic && (
                  <div className="pl-6 space-y-2">
                    <Label>Available Parameters</Label>
                    <p className="text-xs text-gray-500 mb-2">
                      Select parameters that can be dynamically inserted into messages
                    </p>
                    <div className="grid grid-cols-3 gap-2">
                      {['application', 'user', 'device', 'issue', 'timestamp', 'location'].map((param) => (
                        <div key={param} className="flex items-center gap-2 p-2 border border-gray-200 rounded hover:bg-gray-50">
                          <input
                            type="checkbox"
                            id={`param-${param}`}
                            checked={formData.dynamicParams.includes(param)}
                            onChange={() => handleParamToggle(param)}
                            className="w-3 h-3 text-purple-300 rounded border-gray-300"
                          />
                          <label htmlFor={`param-${param}`} className="text-sm cursor-pointer capitalize">
                            {param}
                          </label>
                        </div>
                      ))}
                    </div>
                    
                    <div className="mt-3 p-3 bg-gray-50 border border-gray-200 rounded">
                      <p className="text-xs text-gray-700 mb-2">Usage Example:</p>
                      <code className="text-xs text-purple-700">
                        Hello {'{user}'}, your {'{device}'} requires attention.
                      </code>
                    </div>
                  </div>
                )}

                <div className="bg-blue-50 border border-blue-200 rounded p-3 mt-3">
                  <div className="flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                    <p className="text-xs text-blue-900">
                      Dynamic parameters allow you to personalize messages with real-time data like user names, device info, and timestamps.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Step 7: Branding Profile */}
          {currentStep === 7 && (
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-gray-900 mb-4">
                <Palette className="w-5 h-5 text-purple-600" />
                <h3>Branding Profile</h3>
              </div>

              <div className="border border-purple-200 rounded-lg p-4 space-y-4 bg-purple-50">
                <div className="flex items-center gap-2">
                  <Palette className="w-5 h-5 text-purple-600" />
                  <h4 className="text-gray-900">Branding & CSS Customization</h4>
                </div>

                <div className="space-y-3">
                  <div className="space-y-2">
                    <Label>Branding Profile</Label>
                    <div className="grid grid-cols-2 gap-2">
                      {[
                        { value: 'default', label: 'Default', subtitle: 'Riverbed Purple', colors: ['#581c87', '#c084fc'] },
                        { value: 'security', label: 'Security', subtitle: 'Red/Orange Alert', colors: ['#dc2626', '#f97316'] },
                        { value: 'it', label: 'IT Department', subtitle: 'Blue', colors: ['#2563eb', '#60a5fa'] },
                        { value: 'hr', label: 'HR Department', subtitle: 'Green', colors: ['#16a34a', '#4ade80'] },
                        { value: 'custom', label: 'Custom CSS', subtitle: 'Advanced', colors: ['#6b7280', '#9ca3af'] },
                      ].map((profile) => (
                        <button
                          key={profile.value}
                          type="button"
                          onClick={() => handleChange('brandingProfile', profile.value)}
                          className={`p-3 rounded-lg border-2 transition-all text-left ${
                            formData.brandingProfile === profile.value
                              ? 'border-purple-600 bg-white shadow-sm'
                              : 'border-gray-200 bg-white hover:border-gray-300'
                          }`}
                        >
                          <div className="flex items-center gap-2 mb-2">
                            <div className="flex gap-1">
                              {profile.colors.map((color, idx) => (
                                <div
                                  key={idx}
                                  className="w-4 h-4 rounded"
                                  style={{ backgroundColor: color }}
                                />
                              ))}
                            </div>
                            {formData.brandingProfile === profile.value && (
                              <Check className="w-4 h-4 text-purple-600 ml-auto" />
                            )}
                          </div>
                          <div className="text-sm text-gray-900">{profile.label}</div>
                          <div className="text-xs text-gray-500">{profile.subtitle}</div>
                        </button>
                      ))}
                    </div>
                  </div>

                  {formData.brandingProfile === 'custom' && (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label htmlFor="customCSS">Custom CSS</Label>
                        <Code className="w-4 h-4 text-purple-600" />
                      </div>
                      <Textarea
                        id="customCSS"
                        placeholder=".message-container { background: linear-gradient(...); border-radius: 12px; }"
                        value={formData.customCSS}
                        onChange={(e) => handleChange('customCSS', e.target.value)}
                        rows={6}
                        className="font-mono text-xs"
                      />
                      <p className="text-xs text-purple-700">
                        Apply custom CSS for advanced branding. Classes: .message-container, .message-header, .message-body, .message-button
                      </p>
                    </div>
                  )}

                  <div className="bg-purple-100 border border-purple-300 rounded p-3">
                    <div className="flex items-start gap-2">
                      <AlertCircle className="w-4 h-4 text-purple-700 mt-0.5 flex-shrink-0" />
                      <p className="text-xs text-purple-900">
                        Custom branding helps build trust and recognition. Security-themed messages use distinct colors to emphasize urgency.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Step 8: Review & Create */}
          {currentStep === 8 && (
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-gray-900 mb-4">
                <FileText className="w-5 h-5 text-blue-600" />
                <h3>Review & Create</h3>
              </div>

              {/* Template Preview */}
              <div className="border border-gray-200 rounded-lg p-6 space-y-4 bg-white">
                <div className="flex items-center justify-between border-b pb-4">
                  <h4 className="text-gray-900">Template Preview</h4>
                  <span className={`px-2.5 py-1 rounded-full text-sm capitalize ${
                    formData.type === 'survey' ? 'bg-purple-100 text-purple-800' :
                    formData.type === 'confirmation' ? 'bg-orange-100 text-orange-800' :
                    formData.type === 'notification' ? 'bg-blue-100 text-blue-800' :
                    formData.type === 'reminder' ? 'bg-yellow-100 text-yellow-800' :
                    'bg-green-100 text-green-800'
                  }`}>
                    {formData.type}
                  </span>
                </div>

                <div className="bg-gray-100 rounded-lg p-6 border border-gray-200 flex items-start justify-center">
                  <div className="max-w-md w-full bg-white rounded-lg shadow-lg border border-gray-300">
                    <div className="p-6 space-y-4">
                      {formData.showLogo && (
                        <div className={`flex mb-3 ${
                          formData.logoPosition === 'top-center' ? 'justify-center' :
                          formData.logoPosition === 'top-right' ? 'justify-end' :
                          'justify-start'
                        }`}>
                          {brandingLogo ? (
                            brandingLogo.type === 'svg' ? (
                              <div dangerouslySetInnerHTML={{ __html: brandingLogo.preview }} className="max-h-10" />
                            ) : (
                              <img src={brandingLogo.preview} alt="Branding logo" className="max-h-10" />
                            )
                          ) : (
                            <div className="w-24 h-10 bg-purple-100 border-2 border-purple-300 rounded flex items-center justify-center">
                              <span className="text-xs text-purple-700">Company Logo</span>
                            </div>
                          )}
                        </div>
                      )}
                      
                      {formData.showHeader && (
                        <h3 className="text-gray-900">
                          {formData.title || 'Sample Message Title'}
                        </h3>
                      )}
                      
                      {formData.showDescription && (
                        <p className="text-gray-600 text-sm italic">
                          {formData.messageDescription || 'Brief description of the message content'}
                        </p>
                      )}
                      
                      {formData.showBody && (
                        <p className="text-gray-700 text-sm">
                          {formData.body || (
                            <>
                              This is the main message content area. {formData.supportsDynamic && (
                                <span className="text-purple-700">Dynamic parameters like {'{user}'} and {'{device}'} can be used here.</span>
                              )}
                            </>
                          )}
                        </p>
                      )}
                      
                      {(formData.showButton1 || formData.showButton2 || formData.showButton3) && (
                        <div className="flex gap-2 pt-2 border-t border-gray-200">
                          {formData.showButton1 && (
                            <button className={`px-4 py-2 rounded-lg text-sm ${
                              formData.button1Type === 'primary' ? (
                                formData.brandingProfile === 'security' ? 'bg-red-600 text-white' :
                                formData.brandingProfile === 'it' ? 'bg-blue-600 text-white' :
                                formData.brandingProfile === 'hr' ? 'bg-green-600 text-white' :
                                'bg-purple-900 text-white'
                              ) :
                              formData.button1Type === 'secondary' ? 'border border-gray-300 text-gray-700' :
                              'text-gray-600 hover:bg-gray-50'
                            }`}>
                              {formData.buttonPrimary || 'Button 1'}
                            </button>
                          )}
                          {formData.showButton2 && (
                            <button className={`px-4 py-2 rounded-lg text-sm ${
                              formData.button2Type === 'primary' ? (
                                formData.brandingProfile === 'security' ? 'bg-red-600 text-white' :
                                formData.brandingProfile === 'it' ? 'bg-blue-600 text-white' :
                                formData.brandingProfile === 'hr' ? 'bg-green-600 text-white' :
                                'bg-purple-700 text-white'
                              ) :
                              formData.button2Type === 'secondary' ? 'border border-gray-300 text-gray-700' :
                              'text-gray-600 hover:bg-gray-50'
                            }`}>
                              {formData.buttonSecondary || 'Button 2'}
                            </button>
                          )}
                          {formData.showButton3 && (
                            <button className={`px-4 py-2 rounded-lg text-sm ${
                              formData.button3Type === 'primary' ? (
                                formData.brandingProfile === 'security' ? 'bg-red-600 text-white' :
                                formData.brandingProfile === 'it' ? 'bg-blue-600 text-white' :
                                formData.brandingProfile === 'hr' ? 'bg-green-600 text-white' :
                                'bg-purple-700 text-white'
                              ) :
                              formData.button3Type === 'secondary' ? 'border border-gray-300 text-gray-700' :
                              'text-gray-600 hover:bg-gray-50'
                            }`}>
                              {formData.buttonTertiary || 'Button 3'}
                            </button>
                          )}
                        </div>
                      )}

                      {!formData.showHeader && !formData.showDescription && !formData.showBody && 
                       !formData.showButton1 && !formData.showButton2 && !formData.showButton3 && !formData.showLogo && (
                        <div className="text-center py-8 text-gray-400">
                          <p className="text-sm">No elements selected for this template</p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* Configuration Summary */}
              <div className="border border-gray-200 rounded-lg p-4 space-y-3 bg-gray-50">
                <h4 className="text-gray-900">Configuration Summary</h4>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-gray-600">Template Name:</p>
                    <p className="text-gray-900">{formData.name || 'Not set'}</p>
                  </div>
                  <div>
                    <p className="text-gray-600">Message Type:</p>
                    <p className="text-gray-900 capitalize">{formData.type}</p>
                  </div>
                  <div>
                    <p className="text-gray-600">Channels:</p>
                    <p className="text-gray-900">{formData.channels.length > 0 ? formData.channels.join(', ') : 'None selected'}</p>
                  </div>
                  <div>
                    <p className="text-gray-600">Buttons:</p>
                    <p className="text-gray-900">{formData.buttonCount} button(s)</p>
                  </div>
                  <div>
                    <p className="text-gray-600">Branding:</p>
                    <p className="text-gray-900 capitalize">{formData.brandingProfile}</p>
                  </div>
                  <div>
                    <p className="text-gray-600">Dynamic Parameters:</p>
                    <p className="text-gray-900">{formData.supportsDynamic ? `Yes (${formData.dynamicParams.length})` : 'No'}</p>
                  </div>
                </div>
              </div>

              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                <div className="flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                  <div className="text-xs text-green-900">
                    <p className="mb-1">Template will be available immediately after creation.</p>
                    <p>You can use it when creating new messages or assign it to existing messages.</p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        <DialogFooter className="mt-6">
          <button
            onClick={handleClose}
            className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
          >
            Cancel
          </button>
          
          {currentStep > 1 && (
            <button
              onClick={handleBack}
              className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
            >
              Back
            </button>
          )}
          
          {currentStep < totalSteps ? (
            <button
              onClick={handleNext}
              disabled={currentStep === 2 ? false : !isStepValid()}
              className="px-4 py-2 bg-purple-900 text-white rounded-lg hover:bg-purple-950 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Next Step
            </button>
          ) : (
            <button
              onClick={handleSubmit}
              disabled={!isStepValid()}
              className="px-4 py-2 bg-purple-900 text-white rounded-lg hover:bg-purple-950 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Create Template
            </button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}