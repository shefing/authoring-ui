import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';
import { Grid, List, X, MessageSquare, CheckCircle, Send, BarChart3, Filter, Table } from 'lucide-react';
import { MessageType, Channel, Message } from './MessagesOverview';

interface FilterPanelProps {
  messages: Message[];
  selectedFilters: {
    status?: string[];
    type?: string[];
    channel?: string[];
    deliveryMode?: string[];
  };
  onFilterChange: (filterType: string, value: string) => void;
  onClearFilters: () => void;
  viewMode?: 'chart' | 'list';
  onViewModeChange?: (mode: 'chart' | 'list') => void;
  children?: React.ReactNode;
  searchTerm?: string;
  onSearchChange?: (value: string) => void;
  tableViewMode?: 'grid' | 'table';
  onTableViewModeChange?: (mode: 'grid' | 'table') => void;
}

export function MessageFilterPanel({ messages, selectedFilters, onFilterChange, onClearFilters, viewMode = 'chart', onViewModeChange, children, searchTerm = '', onSearchChange, tableViewMode = 'grid', onTableViewModeChange }: FilterPanelProps) {
  // Use viewMode directly from props instead of local state

  // Calculate status distribution
  const statusData = [
    { name: 'Active', key: 'active', value: messages.filter(m => m.status === 'active').length, color: '#86efac' },
    { name: 'Draft', key: 'draft', value: messages.filter(m => m.status === 'draft').length, color: '#e2e8f0' },
    { name: 'Scheduled', key: 'scheduled', value: messages.filter(m => m.status === 'scheduled').length, color: '#93c5fd' },
    { name: 'Completed', key: 'completed', value: messages.filter(m => m.status === 'completed').length, color: '#c4b5fd' },
  ].filter(item => item.value > 0);

  // Calculate type distribution
  const typeData = [
    { name: 'Survey', key: 'survey', value: messages.filter(m => m.type === 'survey').length, color: '#c4b5fd' },
    { name: 'Confirmation', key: 'confirmation', value: messages.filter(m => m.type === 'confirmation').length, color: '#fcd34d' },
    { name: 'Notification', key: 'notification', value: messages.filter(m => m.type === 'notification').length, color: '#93c5fd' },
    { name: 'Reminder', key: 'reminder', value: messages.filter(m => m.type === 'reminder').length, color: '#fde68a' },
    { name: 'Self-Service', key: 'self-service', value: messages.filter(m => m.type === 'self-service').length, color: '#86efac' },
  ].filter(item => item.value > 0);

  // Calculate channel distribution
  const channelData = [
    { name: 'Riverbed', key: 'riverbed', value: messages.filter(m => m.channel === 'riverbed').length, color: '#a5b4fc' },
    { name: 'Teams', key: 'teams', value: messages.filter(m => m.channel === 'teams').length, color: '#93c5fd' },
    { name: 'Slack', key: 'slack', value: messages.filter(m => m.channel === 'slack').length, color: '#fda4af' },
    { name: 'Email', key: 'email', value: messages.filter(m => m.channel === 'email').length, color: '#86efac' },
  ].filter(item => item.value > 0);

  // Calculate delivery mode distribution
  const deliveryModeData = [
    { name: 'Intrusive', key: 'intrusive', value: messages.filter(m => m.deliveryMode === 'intrusive').length, color: '#fca5a1' },
    { name: 'Non-Intrusive', key: 'non-intrusive', value: messages.filter(m => m.deliveryMode === 'non-intrusive').length, color: '#86efac' },
  ].filter(item => item.value > 0);

  const DonutChart = ({ data, filterType }: { data: any[], filterType: string }) => {
    const total = data.reduce((sum, item) => sum + item.value, 0);
    const centerText = total.toString();

    return (
      <div className="relative w-[120px] h-[120px]">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart margin={{ top: 0, right: 0, bottom: 0, left: 0 }}>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              innerRadius={35}
              outerRadius={50}
              paddingAngle={2}
              dataKey="value"
              onClick={(entry) => onFilterChange(filterType, entry.key)}
              className="cursor-pointer"
              isAnimationActive={false}
            >
              {data.map((entry, index) => (
                <Cell 
                  key={`cell-${index}`} 
                  fill={entry.color}
                  className="hover:opacity-80 transition-opacity"
                />
              ))}
            </Pie>
          </PieChart>
        </ResponsiveContainer>
        <div className="absolute top-0 left-0 w-[120px] h-[120px] flex items-center justify-center pointer-events-none">
          <span className="text-2xl font-semibold text-gray-900">{centerText}</span>
        </div>
      </div>
    );
  };

  const FilterCard = ({ title, data, filterType }: { title: string, data: any[], filterType: string }) => {
    if (viewMode === 'chart') {
      return (
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <h3 className="text-sm font-medium text-gray-900 mb-4">{title}</h3>
          <div className="flex gap-4">
            <DonutChart data={data} filterType={filterType} />
            <div className="flex-1 space-y-1.5">
              {data.map((item, index) => {
                const isSelected = selectedFilters[filterType as keyof typeof selectedFilters]?.includes(item.key);
                return (
                  <button
                    key={index}
                    onClick={() => onFilterChange(filterType, item.key)}
                    className={`w-full flex items-center justify-between px-2 py-1 rounded text-xs hover:bg-gray-50 transition-colors ${
                      isSelected ? 'bg-purple-100' : ''
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <div
                        className="w-2 h-2 rounded-full"
                        style={{ backgroundColor: item.color }}
                      />
                      <span className="text-gray-700">{item.name}</span>
                    </div>
                    <span className="font-medium text-gray-900">{item.value}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      );
    }

    return null;
  };

  const hasActiveFilters = Object.values(selectedFilters).some(arr => arr && arr.length > 0);

  // Get all active filter pills
  const getActiveFilterPills = () => {
    const pills: Array<{ category: string; label: string; value: string; color: string }> = [];
    
    if (selectedFilters.status) {
      selectedFilters.status.forEach(status => {
        const item = statusData.find(d => d.key === status);
        if (item) {
          pills.push({ category: 'Status', label: item.name, value: status, color: item.color });
        }
      });
    }
    
    if (selectedFilters.type) {
      selectedFilters.type.forEach(type => {
        const item = typeData.find(d => d.key === type);
        if (item) {
          pills.push({ category: 'Type', label: item.name, value: type, color: item.color });
        }
      });
    }
    
    if (selectedFilters.channel) {
      selectedFilters.channel.forEach(channel => {
        const item = channelData.find(d => d.key === channel);
        if (item) {
          pills.push({ category: 'Channel', label: item.name, value: channel, color: item.color });
        }
      });
    }
    
    if (selectedFilters.deliveryMode) {
      selectedFilters.deliveryMode.forEach(mode => {
        const item = deliveryModeData.find(d => d.key === mode);
        if (item) {
          pills.push({ category: 'Delivery Mode', label: item.name, value: mode, color: item.color });
        }
      });
    }
    
    return pills;
  };

  const filterPills = getActiveFilterPills();

  return (
    <div className="mb-6 pb-6 flex flex-col flex-1 overflow-hidden">
      {/* Search Field with View Mode Toggle */}
      <div className="mb-4 flex gap-3 items-center flex-shrink-0">
        <div className="relative flex-1">
          <input
            type="text"
            placeholder="Search messages..."
            value={searchTerm}
            onChange={(e) => onSearchChange?.(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white"
          />
          <div className="absolute left-3 top-1/2 -translate-y-1/2">
            <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
          </div>
        </div>
        
        {/* Filter View Mode Toggle */}
        {onViewModeChange && (
          <div className="flex items-center gap-1 bg-white border border-gray-200 rounded-lg p-1">
            <button
              onClick={() => onViewModeChange(viewMode === 'list' ? 'chart' : 'list')}
              className={`p-1.5 rounded transition-colors ${
                viewMode === 'list' ? 'bg-purple-900 text-white' : 'text-gray-600 hover:bg-gray-100'
              }`}
              title="Toggle Filters"
            >
              <Filter className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Table/Grid View Mode Toggle */}
        {onTableViewModeChange && (
          <div className="flex gap-2 bg-white rounded-lg border border-gray-200 p-1">
            <button
              onClick={() => onTableViewModeChange('grid')}
              className={`p-1.5 rounded transition-colors ${
                tableViewMode === 'grid'
                  ? 'bg-purple-900 text-white'
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
              title="Card View"
            >
              <svg className="w-4 h-4" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                <rect x="1" y="1" width="6" height="6" rx="1" />
                <rect x="9" y="1" width="6" height="6" rx="1" />
                <rect x="1" y="9" width="6" height="6" rx="1" />
                <rect x="9" y="9" width="6" height="6" rx="1" />
              </svg>
            </button>
            <button
              onClick={() => onTableViewModeChange('table')}
              className={`p-1.5 rounded transition-colors ${
                tableViewMode === 'table'
                  ? 'bg-purple-900 text-white'
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
              title="Table View"
            >
              <Table className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>

      {viewMode === 'chart' ? (
        <>
          {/* Filter cards grid removed */}

          {/* Messages Table */}
          {children && (
            <div className="flex-1 overflow-hidden flex flex-col">
              {children}
            </div>
          )}
        </>
      ) : (
        <div className="bg-white rounded-lg border border-gray-200 p-4 flex-shrink-0">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-medium text-gray-900">Messages filtered by active criteria</h2>
            {hasActiveFilters && (
              <button
                onClick={onClearFilters}
                className="text-xs text-purple-700 hover:text-purple-800 flex items-center gap-1 px-2 py-1"
              >
                <X className="w-3 h-3" />
                Reset All
              </button>
            )}
          </div>

          {/* Available Filters */}
          <div className="flex flex-wrap gap-x-6 gap-y-3">
            {/* Status Options */}
            <div>
              <label className="text-xs font-semibold text-gray-700 mb-1.5 block">Status</label>
              <div className="flex flex-wrap gap-1.5">
                <button
                  onClick={() => {
                    const { status, ...rest } = selectedFilters;
                    onClearFilters();
                    Object.entries(rest).forEach(([key, values]) => {
                      if (values) {
                        values.forEach(value => onFilterChange(key, value));
                      }
                    });
                  }}
                  className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs border transition-colors ${
                    !selectedFilters.status || selectedFilters.status.length === 0
                      ? 'bg-purple-50 border-purple-300 text-purple-900' 
                      : 'bg-white border-gray-200 text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  <span>All</span>
                  <span className="font-medium">({messages.length})</span>
                </button>
                {statusData.map((item, index) => {
                  const isSelected = selectedFilters.status?.includes(item.key);
                  return (
                    <button
                      key={index}
                      onClick={() => onFilterChange('status', item.key)}
                      className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs border transition-colors ${
                        isSelected 
                          ? 'bg-purple-50 border-purple-300 text-purple-900' 
                          : 'bg-white border-gray-200 text-gray-700 hover:bg-gray-50'
                      }`}
                    >
                      <div className="w-2 h-2 rounded-full" style={{ backgroundColor: item.color }} />
                      <span>{item.name}</span>
                      <span className="font-medium">({item.value})</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Type Options */}
            <div>
              <label className="text-xs font-semibold text-gray-700 mb-1.5 block">Message Type</label>
              <div className="flex flex-wrap gap-1.5">
                <button
                  onClick={() => {
                    const { type, ...rest } = selectedFilters;
                    onClearFilters();
                    Object.entries(rest).forEach(([key, values]) => {
                      if (values) {
                        values.forEach(value => onFilterChange(key, value));
                      }
                    });
                  }}
                  className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs border transition-colors ${
                    !selectedFilters.type || selectedFilters.type.length === 0
                      ? 'bg-purple-50 border-purple-300 text-purple-900' 
                      : 'bg-white border-gray-200 text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  <span>All</span>
                  <span className="font-medium">({messages.length})</span>
                </button>
                {typeData.map((item, index) => {
                  const isSelected = selectedFilters.type?.includes(item.key);
                  return (
                    <button
                      key={index}
                      onClick={() => onFilterChange('type', item.key)}
                      className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs border transition-colors ${
                        isSelected 
                          ? 'bg-purple-50 border-purple-300 text-purple-900' 
                          : 'bg-white border-gray-200 text-gray-700 hover:bg-gray-50'
                      }`}
                    >
                      <div className="w-2 h-2 rounded-full" style={{ backgroundColor: item.color }} />
                      <span>{item.name}</span>
                      <span className="font-medium">({item.value})</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Channel Options */}
            <div>
              <label className="text-xs font-semibold text-gray-700 mb-1.5 block">Channel</label>
              <div className="flex flex-wrap gap-1.5">
                <button
                  onClick={() => {
                    const { channel, ...rest } = selectedFilters;
                    onClearFilters();
                    Object.entries(rest).forEach(([key, values]) => {
                      if (values) {
                        values.forEach(value => onFilterChange(key, value));
                      }
                    });
                  }}
                  className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs border transition-colors ${
                    !selectedFilters.channel || selectedFilters.channel.length === 0
                      ? 'bg-purple-50 border-purple-300 text-purple-900' 
                      : 'bg-white border-gray-200 text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  <span>All</span>
                  <span className="font-medium">({messages.length})</span>
                </button>
                {channelData.map((item, index) => {
                  const isSelected = selectedFilters.channel?.includes(item.key);
                  return (
                    <button
                      key={index}
                      onClick={() => onFilterChange('channel', item.key)}
                      className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs border transition-colors ${
                        isSelected 
                          ? 'bg-purple-50 border-purple-300 text-purple-900' 
                          : 'bg-white border-gray-200 text-gray-700 hover:bg-gray-50'
                      }`}
                    >
                      <div className="w-2 h-2 rounded-full" style={{ backgroundColor: item.color }} />
                      <span>{item.name}</span>
                      <span className="font-medium">({item.value})</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Delivery Mode Options */}
            <div>
              <label className="text-xs font-semibold text-gray-700 mb-1.5 block">Delivery Mode</label>
              <div className="flex flex-wrap gap-1.5">
                <button
                  onClick={() => {
                    const { deliveryMode, ...rest } = selectedFilters;
                    onClearFilters();
                    Object.entries(rest).forEach(([key, values]) => {
                      if (values) {
                        values.forEach(value => onFilterChange(key, value));
                      }
                    });
                  }}
                  className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs border transition-colors ${
                    !selectedFilters.deliveryMode || selectedFilters.deliveryMode.length === 0
                      ? 'bg-purple-50 border-purple-300 text-purple-900' 
                      : 'bg-white border-gray-200 text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  <span>All</span>
                  <span className="font-medium">({messages.length})</span>
                </button>
                {deliveryModeData.map((item, index) => {
                  const isSelected = selectedFilters.deliveryMode?.includes(item.key);
                  return (
                    <button
                      key={index}
                      onClick={() => onFilterChange('deliveryMode', item.key)}
                      className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs border transition-colors ${
                        isSelected 
                          ? 'bg-purple-50 border-purple-300 text-purple-900' 
                          : 'bg-white border-gray-200 text-gray-700 hover:bg-gray-50'
                      }`}
                    >
                      <div className="w-2 h-2 rounded-full" style={{ backgroundColor: item.color }} />
                      <span>{item.name}</span>
                      <span className="font-medium">({item.value})</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* Messages Table - render in both views */}
      {viewMode === 'list' && children && (
        <div className="mt-4 flex-1 overflow-hidden flex flex-col">
          {children}
        </div>
      )}
    </div>
  );
}