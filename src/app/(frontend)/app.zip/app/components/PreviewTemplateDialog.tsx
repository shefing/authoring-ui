import { X, MessageSquare, Monitor, Smartphone } from 'lucide-react';
import { BrandingLogo } from './UnifiedCommunicationPlatform';

interface PreviewTemplateDialogProps {
  open: boolean;
  onClose: () => void;
  template: {
    name: string;
    description?: string;
    type: string;
    division: string;
    channels: string[];
    supportsDynamic: boolean;
    showHeader?: boolean;
    showDescription?: boolean;
    showBody?: boolean;
    showButton1?: boolean;
    showButton2?: boolean;
    showButton3?: boolean;
    showLogo?: boolean;
    logoPosition?: 'top-left' | 'top-center' | 'top-right' | 'center-left' | 'center-right' | 'bottom-left' | 'bottom-center' | 'bottom-right';
    // Content fields
    title?: string;
    messageDescription?: string;
    body?: string;
    buttonPrimary?: string;
    buttonSecondary?: string;
    buttonTertiary?: string;
    brandingProfile?: 'default' | 'security' | 'it' | 'hr' | 'custom';
    // Button configuration
    button1Type?: 'primary' | 'secondary' | 'tertiary';
    button2Type?: 'primary' | 'secondary' | 'tertiary';
    buttonAlignment?: 'left' | 'center' | 'right';
  } | null;
  brandingLogo?: BrandingLogo | null;
}

export function PreviewTemplateDialog({ open, onClose, template, brandingLogo }: PreviewTemplateDialogProps) {
  if (!open || !template) return null;

  // Set defaults for optional fields if not provided
  const showHeader = template.showHeader !== false; // default true
  const showDescription = template.showDescription !== false; // default true
  const showBody = template.showBody !== false; // default true
  const showButton1 = template.showButton1 !== false; // default true
  const showButton2 = template.showButton2 !== false; // default true
  const showButton3 = template.showButton3 || false; // default false
  const showLogo = template.showLogo || false;
  const logoPosition = template.logoPosition || 'top-left';
  const buttonAlignment = template.buttonAlignment || 'left';
  const button1Type = template.button1Type || 'primary';
  const button2Type = template.button2Type || 'secondary';
  const brandingProfile = template.brandingProfile || 'default';

  // Sample content based on message type (fallback if no custom content)
  const sampleContent = {
    survey: {
      title: 'User Feedback Survey',
      description: 'We value your input',
      message: template.supportsDynamic 
        ? 'Hi {user}, we need your input on {application}. Please answer the following questions.'
        : 'We need your input. Please answer the following questions.',
    },
    confirmation: {
      title: 'Action Required',
      description: 'Please confirm this action',
      message: template.supportsDynamic
        ? 'Your {device} requires immediate attention. The following action will be performed: Restart {application}.'
        : 'Your device requires immediate attention. Please confirm the action to proceed.',
    },
    notification: {
      title: 'Remediation Complete',
      description: 'Operation successful',
      message: template.supportsDynamic
        ? 'Success! {application} has been updated on {device}. No further action is required.'
        : 'The operation has been completed successfully. No further action is required.',
    },
    reminder: {
      title: 'Pending Action Reminder',
      description: 'You have a pending task',
      message: template.supportsDynamic
        ? 'This is a reminder about the pending action on {device}. Please complete the required remediation for {application} within 24 hours.'
        : 'This is a reminder about your pending action. Please complete the required task within 24 hours.',
    },
    'self-service': {
      title: 'IT Support Chat',
      description: 'How can we help?',
      message: template.supportsDynamic
        ? 'Hi {user}! I\'m here to help you with {application}. What issue are you experiencing?'
        : 'Welcome to IT Support. How can we assist you today?',
    }
  };

  const defaultContent = sampleContent[template.type as keyof typeof sampleContent] || sampleContent.notification;

  // Use custom content if available, otherwise fall back to sample content
  const displayTitle = template.title || defaultContent.title;
  const displayDescription = template.messageDescription || defaultContent.description;
  const displayBody = template.body || defaultContent.message;
  const displayButton1 = template.buttonPrimary || 'Primary Action';
  const displayButton2 = template.buttonSecondary || 'Secondary Action';

  // Function to get button styles based on type and branding
  const getButtonStyles = (type: 'primary' | 'secondary' | 'tertiary') => {
    if (type === 'primary') {
      if (brandingProfile === 'security') return 'bg-red-600 text-white hover:bg-red-700';
      if (brandingProfile === 'it') return 'bg-blue-600 text-white hover:bg-blue-700';
      if (brandingProfile === 'hr') return 'bg-green-600 text-white hover:bg-green-700';
      return 'bg-purple-900 text-white hover:bg-purple-950';
    }
    if (type === 'secondary') return 'border border-gray-300 text-gray-700 hover:bg-gray-50';
    return 'text-gray-600 hover:bg-gray-50';
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-5xl max-h-[90vh] overflow-hidden flex flex-col">
        {/* Dialog Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-200 bg-gray-50">
          <div>
            <h2 className="text-gray-900">Template Preview</h2>
            <p className="text-gray-600 text-sm mt-1">{template.name}</p>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Dialog Content */}
        <div className="flex-1 overflow-y-auto">
          <div className="p-8 bg-gray-100">
            <div className="max-w-2xl mx-auto">
              <div className="flex items-center gap-2 mb-4 justify-center">
                <MessageSquare className="w-5 h-5 text-purple-600" />
                <h3 className="text-gray-900">Template Structure Preview</h3>
              </div>
              
              {/* Clean template preview matching CreateTemplateDialog */}
              <div className="bg-gray-100 rounded-lg p-6 border border-gray-200 flex items-start justify-center">
                <div className="max-w-md w-full bg-white rounded-lg shadow-lg border border-gray-300 border-t-4 border-t-purple-900">
                  <div className="p-6 space-y-4">
                    {/* Top Logo Positions */}
                    {showLogo && (logoPosition === 'top-left' || logoPosition === 'top-center' || logoPosition === 'top-right') && (
                      <div className={`flex mb-3 ${
                        logoPosition === 'top-center' ? 'justify-center' :
                        logoPosition === 'top-right' ? 'justify-end' :
                        'justify-start'
                      }`}>
                        {brandingLogo ? (
                          brandingLogo.type === 'svg' ? (
                            <div dangerouslySetInnerHTML={{ __html: brandingLogo.preview }} className="max-h-10 w-auto flex items-center" style={{ maxHeight: '40px' }} />
                          ) : (
                            <img src={brandingLogo.preview} alt="Company Logo" className="max-h-10 w-auto object-contain" style={{ maxHeight: '40px' }} />
                          )
                        ) : (
                          <div className="w-24 h-10 bg-purple-100 border-2 border-purple-300 rounded flex items-center justify-center">
                            <span className="text-xs text-purple-700">Company Logo</span>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Center Logo Positions - Side-by-side layout */}
                    {showLogo && (logoPosition === 'center-left' || logoPosition === 'center-right') ? (
                      <div className={`flex gap-4 items-start ${
                        logoPosition === 'center-left' ? '' : 'flex-row-reverse'
                      }`}>
                        {/* Logo on left or right */}
                        <div className="flex-shrink-0">
                          {brandingLogo ? (
                            brandingLogo.type === 'svg' ? (
                              <div dangerouslySetInnerHTML={{ __html: brandingLogo.preview }} className="max-h-10 w-auto flex items-center" style={{ maxHeight: '40px' }} />
                            ) : (
                              <img src={brandingLogo.preview} alt="Company Logo" className="max-h-10 w-auto object-contain" style={{ maxHeight: '40px' }} />
                            )
                          ) : (
                            <div className="w-24 h-10 bg-purple-100 border-2 border-purple-300 rounded flex items-center justify-center">
                              <span className="text-xs text-purple-700">Company Logo</span>
                            </div>
                          )}
                        </div>

                        {/* Content area */}
                        <div className="flex-1 space-y-4">
                          {showHeader && (
                            <h3 
                              className="text-purple-900 font-bold text-lg"
                              dangerouslySetInnerHTML={{ __html: displayTitle }}
                            />
                          )}
                          
                          {showDescription && displayDescription && (
                            <p 
                              className="text-gray-600 text-sm italic"
                              dangerouslySetInnerHTML={{ __html: displayDescription }}
                            />
                          )}
                          
                          {showBody && (
                            <p 
                              className="text-gray-700 text-sm"
                              dangerouslySetInnerHTML={{ __html: displayBody }}
                            />
                          )}
                        </div>
                      </div>
                    ) : (
                      /* Non-center logo positions - normal stacked layout */
                      <>
                        {showHeader && (
                          <h3 
                            className="text-purple-900 font-bold text-lg"
                            dangerouslySetInnerHTML={{ __html: displayTitle }}
                          />
                        )}
                        
                        {showDescription && displayDescription && (
                          <p 
                            className="text-gray-600 text-sm italic"
                            dangerouslySetInnerHTML={{ __html: displayDescription }}
                          />
                        )}
                        
                        {showBody && (
                          <p 
                            className="text-gray-700 text-sm"
                            dangerouslySetInnerHTML={{ __html: displayBody }}
                          />
                        )}
                      </>
                    )}

                    {/* Bottom Logo Positions */}
                    {showLogo && (logoPosition === 'bottom-left' || logoPosition === 'bottom-center' || logoPosition === 'bottom-right') && (
                      <div className={`flex mt-3 ${
                        logoPosition === 'bottom-center' ? 'justify-center' :
                        logoPosition === 'bottom-right' ? 'justify-end' :
                        'justify-start'
                      }`}>
                        {brandingLogo ? (
                          brandingLogo.type === 'svg' ? (
                            <div dangerouslySetInnerHTML={{ __html: brandingLogo.preview }} className="max-h-10 w-auto flex items-center" style={{ maxHeight: '40px' }} />
                          ) : (
                            <img src={brandingLogo.preview} alt="Company Logo" className="max-h-10 w-auto object-contain" style={{ maxHeight: '40px' }} />
                          )
                        ) : (
                          <div className="w-24 h-10 bg-purple-100 border-2 border-purple-300 rounded flex items-center justify-center">
                            <span className="text-xs text-purple-700">Company Logo</span>
                          </div>
                        )}
                      </div>
                    )}
                    
                    {(showButton1 || showButton2 || showButton3) && (
                      <div className={`flex gap-2 pt-2 border-t border-gray-200 ${
                        buttonAlignment === 'center' ? 'justify-center' :
                        buttonAlignment === 'right' ? 'justify-end' :
                        ''
                      }`}>
                        {showButton1 && (
                          <button className={`px-4 py-2 rounded-lg text-sm transition-colors ${getButtonStyles(button1Type)}`}>
                            {displayButton1}
                          </button>
                        )}
                        {showButton2 && (
                          <button className={`px-4 py-2 rounded-lg text-sm transition-colors ${getButtonStyles(button2Type)}`}>
                            {displayButton2}
                          </button>
                        )}
                        {showButton3 && (
                          <button className="px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-lg text-sm">
                            Tertiary Action
                          </button>
                        )}
                      </div>
                    )}

                    {!showHeader && !showDescription && !showBody && 
                     !showButton1 && !showButton2 && !showButton3 && !showLogo && (
                      <div className="text-center py-8 text-gray-400">
                        <p className="text-sm">No elements selected for this template</p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Template Info */}
          <div className="px-8 py-6 border-t border-gray-200 bg-white">
            <h3 className="text-gray-900 mb-4">Template Information</h3>
            <div className="grid grid-cols-3 gap-6">
              {/* Row 1: Template metadata */}
              <div>
                <p className="text-gray-600 text-sm mb-1">Template Name</p>
                <p className="text-gray-900">{template.name}</p>
              </div>
              
              <div>
                <p className="text-gray-600 text-sm mb-1">Template Description</p>
                <p className="text-gray-900">{template.description || '—'}</p>
              </div>

              <div>
                <p className="text-gray-600 text-sm mb-1">Template Type</p>
                <p className="text-gray-900 capitalize">{template.type}</p>
              </div>

              {/* Row 2: Message content */}
              <div>
                <p className="text-gray-600 text-sm mb-1">Title</p>
                {template.title ? (
                  <div 
                    className="text-gray-900"
                    dangerouslySetInnerHTML={{ __html: template.title }}
                  />
                ) : (
                  <p className="text-gray-900">—</p>
                )}
              </div>

              <div>
                <p className="text-gray-600 text-sm mb-1">Description</p>
                {template.messageDescription ? (
                  <div 
                    className="text-gray-900"
                    dangerouslySetInnerHTML={{ __html: template.messageDescription }}
                  />
                ) : (
                  <p className="text-gray-900">—</p>
                )}
              </div>

              <div>
                <p className="text-gray-600 text-sm mb-1">Body</p>
                {template.body ? (
                  <div 
                    className="text-gray-900"
                    dangerouslySetInnerHTML={{ __html: template.body }}
                  />
                ) : (
                  <p className="text-gray-900">—</p>
                )}
              </div>
            </div>

            {template.supportsDynamic && (
              <div className="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-blue-900 text-sm">
                  <strong>Dynamic Parameters:</strong> This preview shows example values. In production, 
                  placeholders like {'{user}'}, {'{application}'}, and {'{device}'} will be replaced with actual runtime values.
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Dialog Footer */}
        <div className="px-6 py-4 border-t border-gray-200 flex justify-end gap-3 bg-gray-50">
          <button
            onClick={onClose}
            className="px-6 py-2 bg-purple-900 text-white rounded-lg hover:bg-purple-950 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}