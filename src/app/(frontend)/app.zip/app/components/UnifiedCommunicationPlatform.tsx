import { useState, useEffect } from 'react';
import { MessagesOverview } from './MessagesOverview';
import { TemplateManager, Template } from './TemplateManager';
import { BrandingCustomization } from './BrandingCustomization';
import { LayoutDashboard, FileText, Palette, MessageSquare, Plus } from 'lucide-react';
import type { Message } from './MessagesOverview';

export type NavigationView = 'overview' | 'templates' | 'branding';

export interface BrandingLogo {
  preview: string;
  type: 'file' | 'svg';
  id?: string;
  name?: string;
  isDefault?: boolean;
}

// Default templates - keeping examples for future reference
// const defaultTemplates: Template[] = [
//   {
//     id: '1',
//     name: 'Multi-step Survey',
//     description: 'Interactive survey template for gathering user feedback across multiple steps',
//     type: 'survey',
//     division: 'Corporate',
//     supportsDynamic: true,
//     channels: ['riverbed', 'teams'],
//     usageCount: 12,
//     showLogo: true,
//     logoPosition: 'top-center',
//     showHeader: true,
//     showDescription: true,
//     showBody: true,
//     showButton1: true,
//     showButton2: true,
//     showButton3: false
//   },
//   {
//     id: '2',
//     name: 'Remediation Confirmation',
//     description: 'Confirmation template for IT remediation actions requiring user acknowledgment',
//     type: 'confirmation',
//     division: 'IT Operations',
//     supportsDynamic: true,
//     channels: ['riverbed'],
//     usageCount: 45,
//     showLogo: true,
//     logoPosition: 'top-left',
//     showHeader: true,
//     showDescription: false,
//     showBody: true,
//     showButton1: true,
//     showButton2: true,
//     showButton3: false
//   },
//   {
//     id: '3',
//     name: 'Success Notification',
//     description: 'Standard notification template for successful operations and status updates',
//     type: 'notification',
//     division: 'Corporate',
//     supportsDynamic: true,
//     channels: ['riverbed', 'teams', 'email'],
//     usageCount: 28,
//     showLogo: false,
//     showHeader: true,
//     showDescription: true,
//     showBody: true,
//     showButton1: false,
//     showButton2: false,
//     showButton3: false
//   },
//   {
//     id: '4',
//     name: 'Remediation Reminder',
//     description: 'Automated reminder for pending remediation tasks and actions',
//     type: 'reminder',
//     division: 'IT Operations',
//     supportsDynamic: false,
//     channels: ['riverbed'],
//     usageCount: 34,
//     showLogo: true,
//     logoPosition: 'top-right',
//     showHeader: true,
//     showDescription: true,
//     showBody: true,
//     showButton1: true,
//     showButton2: false,
//     showButton3: false
//   },
//   {
//     id: '5',
//     name: 'Chat Interface',
//     description: 'Self-service chat template with interactive conversation capabilities',
//     type: 'self-service',
//     division: 'Support',
//     supportsDynamic: true,
//     channels: ['teams', 'slack'],
//     usageCount: 8,
//     showLogo: false,
//     showHeader: true,
//     showDescription: true,
//     showBody: true,
//     showButton1: true,
//     showButton2: true,
//     showButton3: true
//   },
//   {
//     id: '6',
//     name: 'Security Alert - Engineering',
//     description: 'Critical security alerts specifically tailored for engineering teams',
//     type: 'notification',
//     division: 'Engineering',
//     supportsDynamic: true,
//     channels: ['riverbed', 'teams'],
//     usageCount: 3,
//     showLogo: true,
//     logoPosition: 'top-center',
//     showHeader: true,
//     showDescription: true,
//     showBody: true,
//     showButton1: true,
//     showButton2: false,
//     showButton3: false
//   },
// ];

const defaultTemplates: Template[] = [];

// Default Riverbed logo - exported for use across components
export const defaultBrandingLogo: BrandingLogo = {
  id: 'riverbed-default',
  name: 'Default Logo',
  preview: '<svg width="175" height="38" viewBox="0 0 175 38" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M169.633 26.6811C169.633 32.016 166.188 33.2963 163.483 33.2963C160.778 33.2963 157.332 32.016 157.332 26.6811C157.332 21.3462 160.778 20.0627 163.483 20.0627C166.188 20.0627 169.633 21.3429 169.633 26.6811ZM174.512 26.6811V0.745464C174.512 0.265775 174.247 0 173.771 0H170.377C169.9 0 169.633 0.265775 169.633 0.745464V17.9819C168.255 16.1668 165.286 15.3663 163.483 15.3663C157.281 15.3663 152.454 19.2621 152.454 26.6779C152.454 33.562 157.278 37.9895 163.483 37.9895C169.688 37.9927 174.512 34.0968 174.512 26.6811ZM136.547 20.0627C134.373 20.0627 131.723 20.9151 130.767 24.0104H142.324C141.371 20.9151 138.72 20.0627 136.547 20.0627ZM146.777 27.5854H130.397C130.822 32.1748 134.003 33.2963 136.547 33.2963C137.98 33.2963 139.622 32.9754 140.842 31.7503C141.213 31.4845 141.638 31.3224 142.063 31.5363L145.19 32.9235C145.56 33.0824 145.721 33.5102 145.454 33.8829C143.493 36.6055 140.363 37.9927 136.547 37.9927C130.345 37.9927 125.521 34.0968 125.521 26.6811C125.521 19.2621 130.345 15.3695 136.547 15.3695C142.749 15.3695 147.576 19.2654 147.576 26.6811V26.8399C147.572 27.2677 147.202 27.5854 146.777 27.5854ZM115.79 26.6811C115.79 31.8572 112.345 33.2963 109.64 33.2963C106.935 33.2963 103.49 32.016 103.49 26.6811C103.49 21.3462 106.935 20.0627 109.64 20.0627C112.345 20.0627 115.79 21.3429 115.79 26.6811ZM120.669 26.6811C120.669 19.2621 115.845 15.3695 109.643 15.3695C107.84 15.3695 104.871 16.1701 103.493 17.9851V0.745464C103.493 0.265775 103.229 0 102.752 0H99.3584C98.8818 0 98.6145 0.265775 98.6145 0.745464V26.6811C98.6145 34.0968 103.438 37.9927 109.643 37.9927C115.845 37.9927 120.669 33.2444 120.669 26.6811ZM93.1275 19.9039C93.0245 20.4127 92.9182 20.6266 92.2807 20.4905C91.3855 20.2993 90.5322 20.2247 89.6821 20.2247C87.3507 20.2247 85.2287 21.0772 85.2287 24.4933V36.6055C85.2287 37.0852 84.9647 37.3542 84.4881 37.3542H81.0942C80.6176 37.3542 80.3503 37.0884 80.3503 36.6055V24.4933C80.3503 17.8749 84.2724 15.4765 89.1508 15.4765C90.4227 15.4765 91.7494 15.632 93.0728 16.0113C93.5848 16.1571 93.7716 16.4618 93.6556 16.9706L93.1275 19.9039ZM70.1169 24.0104H58.5601C59.5133 20.9151 62.1666 20.0627 64.3401 20.0627C66.5137 20.0627 69.1638 20.9151 70.1169 24.0104ZM75.3657 26.8399V26.6811C75.3657 19.2621 70.542 15.3695 64.3369 15.3695C58.1351 15.3695 53.3082 19.2654 53.3082 26.6811C53.3082 34.0968 58.1319 37.9927 64.3369 37.9927C68.1559 37.9927 71.2826 36.6055 73.2436 33.8829C73.5077 33.5102 73.3499 33.0824 72.9796 32.9235L69.8529 31.5363C69.4278 31.3224 69.006 31.4812 68.6325 31.7503C67.4121 32.9786 65.7699 33.2963 64.3369 33.2963C61.7931 33.2963 58.6116 32.1748 58.1866 27.5854H74.5671C74.9953 27.5854 75.3657 27.2677 75.3657 26.8399ZM42.3503 36.6573C42.1925 37.137 41.819 37.3509 41.3424 37.3509H37.5267C37.0501 37.3509 36.6798 37.137 36.4673 36.6573L28.0371 16.6984C27.8793 16.3256 28.1434 16.0048 28.5137 16.0048H32.3295C32.806 16.0048 33.1763 16.2187 33.3373 16.6984L39.4329 31.4261L45.5285 16.6984C45.6863 16.2187 46.0598 16.0048 46.5364 16.0048H50.3522C50.7225 16.0048 50.935 16.3256 50.7772 16.6984L42.3503 36.6573ZM23.1136 16.7535C23.1136 16.2738 22.8496 16.008 22.373 16.008H18.9791C18.5025 16.008 18.2385 16.2738 18.2385 16.7535V36.6055C18.2385 37.0852 18.5025 37.3542 18.9791 37.3542H22.373C22.8496 37.3542 23.1136 37.0884 23.1136 36.6055V16.7535ZM20.676 4.53436C22.3183 4.53436 23.6449 5.86971 23.6449 7.5227C23.6449 9.17568 22.3183 10.511 20.676 10.511C19.0338 10.511 17.7071 9.17568 17.7071 7.5227C17.7071 5.86971 19.0306 4.53436 20.676 4.53436ZM13.3053 16.9674C13.4051 16.4618 13.2248 16.1668 12.7225 16.008C11.4087 15.5931 10.0724 15.4732 8.80044 15.4732C3.92204 15.4732 0 17.8749 0 24.4901V36.6022C0 37.0819 0.264046 37.3509 0.740616 37.3509H4.13456C4.61113 37.3509 4.87518 37.0852 4.87518 36.6022V24.4901C4.87518 21.0739 6.9972 20.2215 9.32853 20.2215C10.1754 20.2215 11.0352 20.2798 11.9271 20.4873C12.5293 20.6266 12.6903 20.3771 12.774 19.9006L13.3053 16.9674Z" fill="url(#paint0_linear_7_658)"/><mask id="mask0_7_658" style="mask-type:luminance" maskUnits="userSpaceOnUse" x="0" y="0" width="175" height="38"><path d="M169.633 26.6811C169.633 32.016 166.188 33.2963 163.483 33.2963C160.778 33.2963 157.332 32.016 157.332 26.6811C157.332 21.3462 160.778 20.0627 163.483 20.0627C166.188 20.0627 169.633 21.3429 169.633 26.6811ZM174.512 26.6811V0.745464C174.512 0.265775 174.247 0 173.771 0H170.377C169.9 0 169.633 0.265775 169.633 0.745464V17.9819C168.255 16.1668 165.286 15.3663 163.483 15.3663C157.281 15.3663 152.454 19.2621 152.454 26.6779C152.454 33.562 157.278 37.9895 163.483 37.9895C169.688 37.9927 174.512 34.0968 174.512 26.6811ZM136.547 20.0627C134.373 20.0627 131.723 20.9151 130.767 24.0104H142.324C141.371 20.9151 138.72 20.0627 136.547 20.0627ZM146.777 27.5854H130.397C130.822 32.1748 134.003 33.2963 136.547 33.2963C137.98 33.2963 139.622 32.9754 140.842 31.7503C141.213 31.4845 141.638 31.3224 142.063 31.5363L145.19 32.9235C145.56 33.0824 145.721 33.5102 145.454 33.8829C143.493 36.6055 140.363 37.9927 136.547 37.9927C130.345 37.9927 125.521 34.0968 125.521 26.6811C125.521 19.2621 130.345 15.3695 136.547 15.3695C142.749 15.3695 147.576 19.2654 147.576 26.6811V26.8399C147.572 27.2677 147.202 27.5854 146.777 27.5854ZM115.79 26.6811C115.79 31.8572 112.345 33.2963 109.64 33.2963C106.935 33.2963 103.49 32.016 103.49 26.6811C103.49 21.3462 106.935 20.0627 109.64 20.0627C112.345 20.0627 115.79 21.3429 115.79 26.6811ZM120.669 26.6811C120.669 19.2621 115.845 15.3695 109.643 15.3695C107.84 15.3695 104.871 16.1701 103.493 17.9851V0.745464C103.493 0.265775 103.229 0 102.752 0H99.3584C98.8818 0 98.6145 0.265775 98.6145 0.745464V26.6811C98.6145 34.0968 103.438 37.9927 109.643 37.9927C115.845 37.9927 120.669 33.2444 120.669 26.6811ZM93.1275 19.9039C93.0245 20.4127 92.9182 20.6266 92.2807 20.4905C91.3855 20.2993 90.5322 20.2247 89.6821 20.2247C87.3507 20.2247 85.2287 21.0772 85.2287 24.4933V36.6055C85.2287 37.0852 84.9647 37.3542 84.4881 37.3542H81.0942C80.6176 37.3542 80.3503 37.0884 80.3503 36.6055V24.4933C80.3503 17.8749 84.2724 15.4765 89.1508 15.4765C90.4227 15.4765 91.7494 15.632 93.0728 16.0113C93.5848 16.1571 93.7716 16.4618 93.6556 16.9706L93.1275 19.9039ZM70.1169 24.0104H58.5601C59.5133 20.9151 62.1666 20.0627 64.3401 20.0627C66.5137 20.0627 69.1638 20.9151 70.1169 24.0104ZM75.3657 26.8399V26.6811C75.3657 19.2621 70.542 15.3695 64.3369 15.3695C58.1351 15.3695 53.3082 19.2654 53.3082 26.6811C53.3082 34.0968 58.1319 37.9927 64.3369 37.9927C68.1559 37.9927 71.2826 36.6055 73.2436 33.8829C73.5077 33.5102 73.3499 33.0824 72.9796 32.9235L69.8529 31.5363C69.4278 31.3224 69.006 31.4812 68.6325 31.7503C67.4121 32.9786 65.7699 33.2963 64.3369 33.2963C61.7931 33.2963 58.6116 32.1748 58.1866 27.5854H74.5671C74.9953 27.5854 75.3657 27.2677 75.3657 26.8399ZM42.3503 36.6573C42.1925 37.137 41.819 37.3509 41.3424 37.3509H37.5267C37.0501 37.3509 36.6798 37.137 36.4673 36.6573L28.0371 16.6984C27.8793 16.3256 28.1434 16.0048 28.5137 16.0048H32.3295C32.806 16.0048 33.1763 16.2187 33.3373 16.6984L39.4329 31.4261L45.5285 16.6984C45.6863 16.2187 46.0598 16.0048 46.5364 16.0048H50.3522C50.7225 16.0048 50.935 16.3256 50.7772 16.6984L42.3503 36.6573ZM23.1136 16.7535C23.1136 16.2738 22.8496 16.008 22.373 16.008H18.9791C18.5025 16.008 18.2385 16.2738 18.2385 16.7535V36.6055C18.2385 37.0852 18.5025 37.3542 18.9791 37.3542H22.373C22.8496 37.3542 23.1136 37.0884 23.1136 36.6055V16.7535ZM20.676 4.53436C22.3183 4.53436 23.6449 5.86971 23.6449 7.5227C23.6449 9.17568 22.3183 10.511 20.676 10.511C19.0338 10.511 17.7071 9.17568 17.7071 7.5227C17.7071 5.86971 19.0306 4.53436 20.676 4.53436ZM13.3053 16.9674C13.4051 16.4618 13.2248 16.1668 12.7225 16.008C11.4087 15.5931 10.0724 15.4732 8.80044 15.4732C3.92204 15.4732 0 17.8749 0 24.4901V36.6022C0 37.0819 0.264046 37.3509 0.740616 37.3509H4.13456C4.61113 37.3509 4.87518 37.0852 4.87518 36.6022V24.4901C4.87518 21.0739 6.9972 20.2215 9.32853 20.2215C10.1754 20.2215 11.0352 20.2798 11.9271 20.4873C12.5293 20.6266 12.6903 20.3771 12.774 19.9006L13.3053 16.9674Z" fill="white"/></mask><g mask="url(#mask0_7_658)"><path d="M284.49 56.5837L99.878 179.911L-59.6547 -62.3002L124.957 -185.627L284.49 56.5837Z" fill="url(#paint1_linear_7_658)"/></g><defs><linearGradient id="paint0_linear_7_658" x1="40.2247" y1="75.0006" x2="143.293" y2="-31.0361" gradientUnits="userSpaceOnUse"><stop offset="0.025" stop-color="#4C4EAC"/><stop offset="0.0741" stop-color="#544DB0"/><stop offset="0.1482" stop-color="#684ABC"/><stop offset="0.2202" stop-color="#8346CA"/><stop offset="0.2535" stop-color="#9041CD"/><stop offset="0.3149" stop-color="#B233D6"/><stop offset="0.3403" stop-color="#C22DDA"/><stop offset="0.4131" stop-color="#E813A9"/><stop offset="0.4561" stop-color="#F4248F"/><stop offset="0.4883" stop-color="#FF3378"/><stop offset="0.5469" stop-color="#FF685B"/><stop offset="0.6003" stop-color="#FF7856"/><stop offset="0.6558" stop-color="#FE8750"/><stop offset="0.8884" stop-color="#FCC13A"/><stop offset="1" stop-color="#FBD831"/></linearGradient><linearGradient id="paint1_linear_7_658" x1="20.0949" y1="61.1745" x2="207.515" y2="-67.0135" gradientUnits="userSpaceOnUse"><stop offset="0.025" stop-color="#4C4EAC"/><stop offset="0.0741" stop-color="#544DB0"/><stop offset="0.1482" stop-color="#684ABC"/><stop offset="0.2202" stop-color="#8346CA"/><stop offset="0.2535" stop-color="#9041CD"/><stop offset="0.3149" stop-color="#B233D6"/><stop offset="0.3403" stop-color="#C22DDA"/><stop offset="0.4131" stop-color="#E813A9"/><stop offset="0.4561" stop-color="#F4248F"/><stop offset="0.4883" stop-color="#FF3378"/><stop offset="0.5469" stop-color="#FF685B"/><stop offset="0.6003" stop-color="#FF7856"/><stop offset="0.6558" stop-color="#FE8750"/><stop offset="0.8884" stop-color="#FCC13A"/><stop offset="1" stop-color="#FBD831"/></linearGradient></defs></svg>',
  type: 'svg',
  isDefault: true
};

export function UnifiedCommunicationPlatform() {
  const [currentView, setCurrentView] = useState<NavigationView>('overview');
  const [brandingLogo, setBrandingLogo] = useState<BrandingLogo | null>(defaultBrandingLogo);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showCreateTemplateDialog, setShowCreateTemplateDialog] = useState(false);
  const [templates, setTemplates] = useState<Template[]>(defaultTemplates);
  const [messages, setMessages] = useState<Message[]>([]); // Messages state - persists during tab navigation, resets on page reload

  // Load data from localStorage on mount
  useEffect(() => {
    try {
      const savedTemplates = localStorage.getItem('riverbed-templates');
      const savedLogo = localStorage.getItem('riverbed-branding-logo');
      
      // Load saved templates if they exist, otherwise start fresh
      if (savedTemplates) {
        const parsed = JSON.parse(savedTemplates);
        if (Array.isArray(parsed) && parsed.length > 0) {
          setTemplates(parsed);
        } else {
          setTemplates([]);
        }
      } else {
        setTemplates([]);
      }
      
      if (savedLogo) {
        const parsed = JSON.parse(savedLogo);
        setBrandingLogo(parsed);
      }
    } catch (error) {
      console.error('Error loading from localStorage:', error);
    }
  }, []);

  // Save templates to localStorage whenever they change
  useEffect(() => {
    try {
      localStorage.setItem('riverbed-templates', JSON.stringify(templates));
    } catch (error) {
      console.error('Error saving templates to localStorage:', error);
    }
  }, [templates]);

  // Save branding logo to localStorage whenever it changes
  useEffect(() => {
    try {
      if (brandingLogo) {
        localStorage.setItem('riverbed-branding-logo', JSON.stringify(brandingLogo));
      }
    } catch (error) {
      console.error('Error saving branding logo to localStorage:', error);
    }
  }, [brandingLogo]);

  const renderView = () => {
    switch (currentView) {
      case 'overview':
        return <MessagesOverview 
          templates={templates} 
          brandingLogo={brandingLogo}
          messages={messages}
          onMessagesChange={setMessages}
          showCreateDialog={showCreateDialog}
          setShowCreateDialog={setShowCreateDialog}
        />;
      case 'templates':
        return <TemplateManager 
          brandingLogo={brandingLogo} 
          templates={templates} 
          onTemplatesChange={setTemplates}
          showCreateDialogPro={showCreateTemplateDialog}
          setShowCreateDialogPro={setShowCreateTemplateDialog}
        />;
      case 'branding':
        return <BrandingCustomization onLogoChange={setBrandingLogo} />;
      default:
        return <MessagesOverview templates={templates} brandingLogo={brandingLogo} messages={messages} onMessagesChange={setMessages} />;
    }
  };

  const tabs = [
    { id: 'overview' as NavigationView, label: 'Messages', icon: LayoutDashboard },
    { id: 'templates' as NavigationView, label: 'Templates', icon: FileText },
    { id: 'branding' as NavigationView, label: 'Branding', icon: Palette },
  ];

  return (
    <div className="flex flex-col h-screen bg-gray-50">
      {/* Header with branding */}
      <div className="bg-white border-b border-gray-200">
        <div className="px-6 pt-4">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-purple-900 rounded-lg flex items-center justify-center">
              <MessageSquare className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-gray-900">End-user Communication</h1>
              <p className="text-purple-700 text-sm">Create and manage branded message & templates for end-user communications</p>
            </div>
          </div>
          
          {/* Tabs */}
          <div className="flex items-center justify-between gap-1 border-b border-gray-200">
            <div className="flex gap-1">
              {tabs.map((tab) => {
                const Icon = tab.icon;
                const isActive = currentView === tab.id;
                
                return (
                  <button
                    key={tab.id}
                    onClick={() => setCurrentView(tab.id)}
                    className={`flex items-center gap-2 px-4 py-2.5 border-b-2 transition-colors ${
                      isActive
                        ? 'border-purple-900 text-purple-900 bg-purple-50'
                        : 'border-transparent text-gray-600 hover:text-gray-900 hover:bg-gray-50'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    <span>{tab.label}</span>
                    {tab.id === 'messages' && (
                      <span className="bg-purple-900 text-white text-xs px-2 py-0.5 rounded">
                        M.S - 1
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
            
            {currentView === 'overview' && (
              <button 
                onClick={() => setShowCreateDialog(true)}
                className="flex items-center gap-2 bg-purple-900 text-white px-4 py-2 rounded-lg hover:bg-purple-950 transition-colors mb-2"
              >
                <Plus className="w-5 h-5" />
                Create Message
              </button>
            )}
            
            {currentView === 'templates' && (
              <button 
                onClick={() => setShowCreateTemplateDialog(true)}
                className="flex items-center gap-2 bg-purple-900 text-white px-4 py-2 rounded-lg hover:bg-purple-950 transition-colors mb-2"
              >
                <Plus className="w-5 h-5" />
                New Template
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Main content */}
      <main className="flex-1 overflow-auto">
        {renderView()}
      </main>
    </div>
  );
}