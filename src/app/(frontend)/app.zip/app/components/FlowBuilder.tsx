import { useState } from 'react';
import { Plus, Workflow, GitBranch, MessageSquare, CheckCircle, AlertCircle } from 'lucide-react';
import { CreateFlowDialog } from './CreateFlowDialog';

interface FlowNode {
  id: string;
  type: 'message' | 'condition' | 'action' | 'runbook';
  label: string;
  config?: any;
}

interface InteractiveFlow {
  id: string;
  name: string;
  description: string;
  triggerType: 'manual' | 'automatic' | 'runbook';
  nodes: FlowNode[];
  usedIn: number;
}

export function FlowBuilder() {
  const [flows] = useState<InteractiveFlow[]>([
    {
      id: '1',
      name: 'Win11 Migration Survey Flow',
      description: 'Conditional survey that adjusts questions based on satisfaction level',
      triggerType: 'manual',
      nodes: [
        { id: '1', type: 'message', label: 'Initial satisfaction question' },
        { id: '2', type: 'condition', label: 'Check if dissatisfied' },
        { id: '3', type: 'message', label: 'Follow-up questions on pain points' },
        { id: '4', type: 'action', label: 'Create support ticket' }
      ],
      usedIn: 1
    },
    {
      id: '2',
      name: 'Auto-Fix Confirmation Flow',
      description: 'Detects issue, validates script, requests confirmation, executes fix',
      triggerType: 'automatic',
      nodes: [
        { id: '1', type: 'runbook', label: 'Diagnose device issue' },
        { id: '2', type: 'condition', label: 'Check script signing' },
        { id: '3', type: 'message', label: 'Request user confirmation' },
        { id: '4', type: 'condition', label: 'User response (Fix/Snooze/Ticket)' },
        { id: '5', type: 'action', label: 'Execute remediation' },
        { id: '6', type: 'message', label: 'Notify completion' }
      ],
      usedIn: 3
    },
    {
      id: '3',
      name: 'Self-Service Device Health',
      description: 'Interactive chat that shows device health and suggests fixes',
      triggerType: 'runbook',
      nodes: [
        { id: '1', type: 'message', label: 'Welcome message' },
        { id: '2', type: 'runbook', label: 'Run diagnostics' },
        { id: '3', type: 'condition', label: 'Evaluate health status' },
        { id: '4', type: 'message', label: 'Present findings + fix options' },
        { id: '5', type: 'action', label: 'Apply selected fix' }
      ],
      usedIn: 1
    }
  ]);

  const [selectedFlow, setSelectedFlow] = useState<InteractiveFlow | null>(null);
  const [showCreateDialog, setShowCreateDialog] = useState(false);

  const getNodeIcon = (type: FlowNode['type']) => {
    switch (type) {
      case 'message':
        return <MessageSquare className="w-5 h-5" />;
      case 'condition':
        return <GitBranch className="w-5 h-5" />;
      case 'action':
        return <CheckCircle className="w-5 h-5" />;
      case 'runbook':
        return <Workflow className="w-5 h-5" />;
    }
  };

  const getNodeColor = (type: FlowNode['type']) => {
    switch (type) {
      case 'message':
        return 'bg-blue-100 text-blue-700 border-blue-300';
      case 'condition':
        return 'bg-purple-100 text-purple-700 border-purple-300';
      case 'action':
        return 'bg-green-100 text-green-700 border-green-300';
      case 'runbook':
        return 'bg-orange-100 text-orange-700 border-orange-300';
    }
  };

  return (
    <div className="p-8">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-gray-50 mb-3 pb-2 pt-3 -mt-8 -mx-8 px-8 border-b border-gray-200">
        <div className="flex items-center justify-between -mb-[7px] pt-5">
          <div>
            <h1 className="text-gray-900">Interactive Flow Builder</h1>
            <p className="text-gray-600 mt-1">
              Create logic-based, conditional message flows integrated with Runbook diagnostics
            </p>
          </div>
          <button 
            onClick={() => setShowCreateDialog(true)}
            className="flex items-center gap-2 bg-purple-900 text-white px-4 py-2 rounded-lg hover:bg-purple-950 transition-colors"
          >
            <Plus className="w-5 h-5" />
            New Flow
          </button>
        </div>

        {/* Key Features */}
        <div className="bg-purple-50 border border-purple-200 rounded-lg p-6">
          <h3 className="text-purple-900 mb-2">Interactive Flow Capabilities</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-purple-700 text-sm">
            <div>
              <p className="mb-2">• <span className="text-purple-900">Runbook Integration:</span> Trigger diagnostics and use results in flow logic</p>
              <p className="mb-2">• <span className="text-purple-900">Conditional Logic:</span> Branch based on user responses or device state</p>
            </div>
            <div>
              <p className="mb-2">• <span className="text-purple-900">2-Way Communication:</span> Minimal latency for real-time interaction</p>
              <p className="mb-2">• <span className="text-purple-900">Dynamic Parameters:</span> Use {'{user}'}, {'{device}'}, {'{application}'} tokens</p>
            </div>
          </div>
        </div>
      </div>

      {/* Flows List */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {flows.map((flow) => (
          <div 
            key={flow.id} 
            className={`bg-white rounded-lg border-2 transition-all cursor-pointer ${
              selectedFlow?.id === flow.id 
                ? 'border-blue-500 shadow-lg' 
                : 'border-gray-200 hover:border-gray-300'
            }`}
            onClick={() => setSelectedFlow(flow)}
          >
            {/* Flow Header */}
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <h3 className="text-gray-900">{flow.name}</h3>
                  <p className="text-gray-500 text-sm mt-1">{flow.description}</p>
                </div>
                <span className={`px-2.5 py-1 rounded-full text-sm capitalize ${
                  flow.triggerType === 'automatic' ? 'bg-green-100 text-green-800' :
                  flow.triggerType === 'runbook' ? 'bg-orange-100 text-orange-800' :
                  'bg-blue-100 text-blue-800'
                }`}>
                  {flow.triggerType}
                </span>
              </div>
            </div>

            {/* Flow Visualization */}
            <div className="p-6">
              <div className="space-y-2">
                {flow.nodes.map((node, index) => (
                  <div key={node.id}>
                    <div className={`flex items-center gap-3 p-3 rounded-lg border ${getNodeColor(node.type)}`}>
                      {getNodeIcon(node.type)}
                      <span className="text-sm flex-1">{node.label}</span>
                    </div>
                    {index < flow.nodes.length - 1 && (
                      <div className="flex justify-center py-1">
                        <div className="w-0.5 h-4 bg-gray-300"></div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Flow Stats */}
            <div className="px-6 py-4 bg-gray-50 border-t border-gray-200">
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-600">
                  {flow.nodes.length} nodes • {flow.nodes.filter(n => n.type === 'condition').length} decision points
                </span>
                <span className="text-gray-600">
                  Used in {flow.usedIn} {flow.usedIn === 1 ? 'message' : 'messages'}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Flow Details (when selected) */}
      {selectedFlow && (
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h3 className="text-gray-900 mb-4">{selectedFlow.name} - Configuration</h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Use Case Example */}
            <div>
              <h4 className="text-gray-700 mb-3">Use Case Scenario</h4>
              {selectedFlow.id === '1' && (
                <div className="bg-purple-50 border border-purple-200 rounded-lg p-4 text-sm text-purple-900 space-y-2">
                  <p><span className="text-purple-700">1.</span> Ask: "How satisfied are you with Win11 migration?"</p>
                  <p><span className="text-purple-700">2.</span> If rating {'<'} 3: Show follow-up questions about pain points</p>
                  <p><span className="text-purple-700">3.</span> If very dissatisfied: Automatically create support ticket</p>
                  <p><span className="text-purple-700">4.</span> Collect detailed feedback for analysis</p>
                </div>
              )}
              {selectedFlow.id === '2' && (
                <div className="bg-orange-50 border border-orange-200 rounded-lg p-4 text-sm text-orange-900 space-y-2">
                  <p><span className="text-orange-700">1.</span> Runbook detects network issue automatically</p>
                  <p><span className="text-orange-700">2.</span> Validate remediation script signing (backward compat)</p>
                  <p><span className="text-orange-700">3.</span> Show popup: "Can we fix it now? [Yes/Snooze/More Info/Ticket]"</p>
                  <p><span className="text-orange-700">4.</span> If user approves: Execute fix and notify completion</p>
                  <p><span className="text-orange-700">5.</span> If snoozed: Schedule reminder based on fatigue rules</p>
                </div>
              )}
              {selectedFlow.id === '3' && (
                <div className="bg-green-50 border border-green-200 rounded-lg p-4 text-sm text-green-900 space-y-2">
                  <p><span className="text-green-700">1.</span> User opens Teams self-service chat</p>
                  <p><span className="text-green-700">2.</span> Runbook runs full device diagnostics</p>
                  <p><span className="text-green-700">3.</span> Present findings: "Your device is healthy" or "2 issues found"</p>
                  <p><span className="text-green-700">4.</span> Offer suggested fixes with explanations</p>
                  <p><span className="text-green-700">5.</span> User selects fix, system applies it within chat</p>
                </div>
              )}
            </div>

            {/* Technical Requirements */}
            <div>
              <h4 className="text-gray-700 mb-3">Technical Requirements</h4>
              <div className="bg-gray-50 border border-gray-200 rounded-lg p-4 space-y-3 text-sm">
                <div className="flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-gray-900">2-Way Communication</p>
                    <p className="text-gray-600 text-xs mt-1">IOT protocol ensures minimal latency for interactive responses</p>
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-gray-900">Runbook Integration</p>
                    <p className="text-gray-600 text-xs mt-1">Diagnostics and device state can drive conditional logic</p>
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-gray-900">Dynamic Context</p>
                    <p className="text-gray-600 text-xs mt-1">Messages use runtime parameters: user name, device info, application names</p>
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-gray-900">Platform Support</p>
                    <p className="text-gray-600 text-xs mt-1">Works on Windows and macOS with ADA module</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-6 pt-6 border-t border-gray-200 flex justify-end gap-3">
            <button className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors">
              Duplicate Flow
            </button>
            <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
              Edit Flow
            </button>
          </div>
        </div>
      )}

      {/* Node Types Legend */}
      <div className="mt-8 bg-gray-50 border border-gray-200 rounded-lg p-6">
        <h3 className="text-gray-900 mb-4">Flow Node Types</h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-100 border border-blue-300 rounded-lg flex items-center justify-center">
              <MessageSquare className="w-5 h-5 text-blue-700" />
            </div>
            <div>
              <p className="text-gray-900 text-sm">Message</p>
              <p className="text-gray-500 text-xs">Send message to user</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-purple-100 border border-purple-300 rounded-lg flex items-center justify-center">
              <GitBranch className="w-5 h-5 text-purple-700" />
            </div>
            <div>
              <p className="text-gray-900 text-sm">Condition</p>
              <p className="text-gray-500 text-xs">Branch based on logic</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-green-100 border border-green-300 rounded-lg flex items-center justify-center">
              <CheckCircle className="w-5 h-5 text-green-700" />
            </div>
            <div>
              <p className="text-gray-900 text-sm">Action</p>
              <p className="text-gray-500 text-xs">Execute operation</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-orange-100 border border-orange-300 rounded-lg flex items-center justify-center">
              <Workflow className="w-5 h-5 text-orange-700" />
            </div>
            <div>
              <p className="text-gray-900 text-sm">Runbook</p>
              <p className="text-gray-500 text-xs">Run diagnostics</p>
            </div>
          </div>
        </div>
      </div>

      {/* Create Flow Dialog */}
      <CreateFlowDialog
        open={showCreateDialog}
        onClose={() => setShowCreateDialog(false)}
        onSubmit={(data) => {
          console.log('New flow:', data);
          // Handle flow creation
        }}
      />
    </div>
  );
}