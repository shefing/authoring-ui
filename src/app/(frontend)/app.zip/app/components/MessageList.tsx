import { BroadcastMessage } from './BroadcastDashboard';
import { Eye, Clock, CheckCircle, XCircle, Users, Calendar } from 'lucide-react';

interface MessageListProps {
  messages: BroadcastMessage[];
  onPreview: (message: BroadcastMessage) => void;
  onEdit: (message: BroadcastMessage) => void;
}

export function MessageList({ messages, onPreview, onEdit }: MessageListProps) {
  const getStatusColor = (status: BroadcastMessage['status']) => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-800';
      case 'expired':
        return 'bg-gray-100 text-gray-800';
      case 'draft':
        return 'bg-yellow-100 text-yellow-800';
    }
  };

  const getStatusIcon = (status: BroadcastMessage['status']) => {
    switch (status) {
      case 'active':
        return <CheckCircle className="w-4 h-4" />;
      case 'expired':
        return <XCircle className="w-4 h-4" />;
      case 'draft':
        return <Clock className="w-4 h-4" />;
    }
  };

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  const getAcknowledgementRate = (message: BroadcastMessage) => {
    if (message.totalTargets === 0) return 0;
    return Math.round((message.acknowledgedCount / message.totalTargets) * 100);
  };

  return (
    <div className="space-y-6">
      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <CheckCircle className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <p className="text-gray-600">Active Messages</p>
              <p className="text-gray-900 mt-1">{messages.filter(m => m.status === 'active').length}</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <Users className="w-6 h-6 text-green-600" />
            </div>
            <div>
              <p className="text-gray-600">Total Acknowledgements</p>
              <p className="text-gray-900 mt-1">
                {messages.reduce((sum, m) => sum + m.acknowledgedCount, 0).toLocaleString()}
              </p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
              <Calendar className="w-6 h-6 text-purple-600" />
            </div>
            <div>
              <p className="text-gray-600">Expired Messages</p>
              <p className="text-gray-900 mt-1">{messages.filter(m => m.status === 'expired').length}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Messages Table */}
      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="text-left px-6 py-3 text-gray-600">Message</th>
                <th className="text-left px-6 py-3 text-gray-600">Target Group</th>
                <th className="text-left px-6 py-3 text-gray-600">Status</th>
                <th className="text-left px-6 py-3 text-gray-600">Acknowledgement Rate</th>
                <th className="text-left px-6 py-3 text-gray-600">Created</th>
                <th className="text-left px-6 py-3 text-gray-600">Expires</th>
                <th className="text-left px-6 py-3 text-gray-600">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {messages.map((message) => {
                const rate = getAcknowledgementRate(message);
                const expirationDate = new Date(message.createdAt);
                expirationDate.setDate(
                  expirationDate.getDate() + 
                  (message.expirationUnit === 'hours' ? message.expirationPeriod / 24 :
                   message.expirationUnit === 'weeks' ? message.expirationPeriod * 7 :
                   message.expirationPeriod)
                );

                return (
                  <tr key={message.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4">
                      <div>
                        <p className="text-gray-900">{message.title}</p>
                        <p className="text-gray-500 text-sm mt-1 line-clamp-1">{message.content}</p>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <Users className="w-4 h-4 text-gray-400" />
                        <span className="text-gray-900">{message.targetGroup}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-sm ${getStatusColor(message.status)}`}>
                        {getStatusIcon(message.status)}
                        {message.status.charAt(0).toUpperCase() + message.status.slice(1)}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div>
                        <div className="flex items-center gap-2">
                          <div className="flex-1 bg-gray-200 rounded-full h-2 max-w-[100px]">
                            <div 
                              className="bg-blue-600 h-2 rounded-full transition-all"
                              style={{ width: `${rate}%` }}
                            />
                          </div>
                          <span className="text-gray-900 text-sm">{rate}%</span>
                        </div>
                        <p className="text-gray-500 text-sm mt-1">
                          {message.acknowledgedCount.toLocaleString()} / {message.totalTargets.toLocaleString()}
                        </p>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <p className="text-gray-900">{formatDate(message.createdAt)}</p>
                      <p className="text-gray-500 text-sm">{message.createdBy}</p>
                    </td>
                    <td className="px-6 py-4">
                      <p className="text-gray-900">{formatDate(expirationDate)}</p>
                      <p className="text-gray-500 text-sm">
                        {message.expirationPeriod} {message.expirationUnit}
                      </p>
                    </td>
                    <td className="px-6 py-4">
                      <button
                        onClick={() => onPreview(message)}
                        className="text-blue-600 hover:text-blue-800 flex items-center gap-1"
                      >
                        <Eye className="w-4 h-4" />
                        Preview
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
