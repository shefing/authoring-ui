import React, { useState, useEffect } from 'react';
import { Plus, Filter, Search, Eye, Edit, Copy, Send, MessageSquare, CheckCircle, TrendingUp, BarChart3, List } from 'lucide-react';
import { MessageDetailModal } from './MessageDetailModal';
import { CreateMessageDialog } from './CreateMessageDialog';
import { CreateMessageDialogNew } from './CreateMessageDialogNew';
import { CreateTemplateDialogPro } from './CreateTemplateDialogPro';
import { PreviewMessageDialog } from './PreviewMessageDialog';
import { MessageDesignPreview } from './MessageDesignPreview';
import { MessageFilterPanel } from './MessageFilterPanel';
import { Template } from './TemplateManager';
import { BrandingLogo } from './UnifiedCommunicationPlatform';
import { BroadcastDialog, BroadcastRecord } from './BroadcastDialog';

export type MessageType = 'survey' | 'confirmation' | 'notification' | 'reminder' | 'self-service';
export type Channel = 'riverbed' | 'teams' | 'slack' | 'email';
export type DeliveryMode = 'intrusive' | 'non-intrusive';

export interface Message {
  id: string;
  name: string;
  type: MessageType;
  channel: Channel;
  deliveryMode: DeliveryMode;
  template: string;
  templateId?: string;
  targetGroup: string;
  status: 'active' | 'draft' | 'scheduled' | 'completed';
  sent: number;
  acknowledged: number;
  createdAt: Date;
  createdBy: string;
  hasInteractiveFlow: boolean;
  requiresResponse: boolean;
  // Message content fields
  messageTitle?: string;
  messageDescription?: string;
  messageContent?: string;
  buttonPrimary?: string;
  buttonSecondary?: string;
  buttonTertiary?: string;
  // Template display configuration
  showLogo?: boolean;
  logoPosition?: 'top-left' | 'top-center' | 'top-right';
  showHeader?: boolean;
  showDescription?: boolean;
  showBody?: boolean;
  showButton1?: boolean;
  showButton2?: boolean;
  showButton3?: boolean;
  button1Type?: 'primary' | 'secondary' | 'tertiary';
  button2Type?: 'primary' | 'secondary' | 'tertiary';
  button3Type?: 'primary' | 'secondary' | 'tertiary';
  customCSS?: string;
  brandingProfile?: 'default' | 'security' | 'it' | 'hr' | 'custom';
  // Broadcast history
  broadcastHistory?: BroadcastRecord[];
}

interface MessagesOverviewProps {
  templates: Template[];
  brandingLogo: BrandingLogo | null;
  messages: Message[];
  onMessagesChange: (messages: Message[]) => void;
  showCreateDialog?: boolean;
  setShowCreateDialog?: (show: boolean) => void;
}

export function MessagesOverview({ templates, brandingLogo, messages, onMessagesChange, showCreateDialog: externalShowCreate, setShowCreateDialog: externalSetShowCreate }: MessagesOverviewProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedFilters, setSelectedFilters] = useState<{
    status?: string[];
    type?: string[];
    channel?: string[];
    deliveryMode?: string[];
  }>({});
  const [selectedMessage, setSelectedMessage] = useState<Message | null>(null);
  const [previewMessage, setPreviewMessage] = useState<Message | null>(null);
  const [editMessage, setEditMessage] = useState<Message | null>(null);
  const [broadcastMessage, setBroadcastMessage] = useState<Message | null>(null);
  const [internalShowCreateDialog, setInternalShowCreateDialog] = useState(false);
  const [showDesignPreview, setShowDesignPreview] = useState(false);
  const [viewMode, setViewMode] = useState<'chart' | 'list'>('chart');
  const [tableViewMode, setTableViewMode] = useState<'grid' | 'table'>('table');

  // Use external state if provided, otherwise use internal state
  const showCreateDialog = externalShowCreate !== undefined ? externalShowCreate : internalShowCreateDialog;
  const setShowCreateDialog = externalSetShowCreate || setInternalShowCreateDialog;

  // Messages are now managed by the parent component (UnifiedCommunicationPlatform)
  // They persist during tab navigation but reset on page reload

  const filteredMessages = messages.filter(msg => {
    const matchesSearch = msg.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         msg.targetGroup.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = !selectedFilters.status || selectedFilters.status.length === 0 || selectedFilters.status.includes(msg.status);
    const matchesType = !selectedFilters.type || selectedFilters.type.length === 0 || selectedFilters.type.includes(msg.type);
    const matchesChannel = !selectedFilters.channel || selectedFilters.channel.length === 0 || selectedFilters.channel.includes(msg.channel);
    const matchesDeliveryMode = !selectedFilters.deliveryMode || selectedFilters.deliveryMode.length === 0 || selectedFilters.deliveryMode.includes(msg.deliveryMode);
    
    return matchesSearch && matchesStatus && matchesType && matchesChannel && matchesDeliveryMode;
  });

  const handleFilterChange = (filterType: string, value: string) => {
    setSelectedFilters(prev => {
      const currentFilters = prev[filterType as keyof typeof prev] || [];
      const newFilters = currentFilters.includes(value)
        ? currentFilters.filter(v => v !== value)
        : [...currentFilters, value];
      
      return {
        ...prev,
        [filterType]: newFilters
      };
    });
  };

  const handleClearFilters = () => {
    setSelectedFilters({});
  };

  const getTypeColor = (type: MessageType) => {
    const colors = {
      survey: 'bg-purple-100 text-purple-800',
      confirmation: 'bg-orange-100 text-orange-800',
      notification: 'bg-blue-100 text-blue-800',
      reminder: 'bg-yellow-100 text-yellow-800',
      'self-service': 'bg-green-100 text-green-800'
    };
    return colors[type];
  };

  const getChannelColor = (channel: Channel) => {
    const colors = {
      riverbed: 'bg-gray-100 text-gray-800',
      teams: 'bg-indigo-100 text-indigo-800',
      slack: 'bg-pink-100 text-pink-800',
      email: 'bg-teal-100 text-teal-800'
    };
    return colors[channel];
  };

  const getStatusColor = (status: Message['status']) => {
    const colors = {
      active: 'bg-green-100 text-green-800',
      draft: 'bg-gray-100 text-gray-800',
      scheduled: 'bg-blue-100 text-blue-800',
      completed: 'bg-purple-100 text-purple-800'
    };
    return colors[status];
  };

  const handleBroadcast = (data: { targetAudience: string; expirationValue: number; expirationUnit: 'minutes' | 'hours' | 'days' }) => {
    if (!broadcastMessage) return;

    // Calculate expiration date
    const now = new Date();
    const expiresAt = new Date(now);
    if (data.expirationUnit === 'minutes') {
      expiresAt.setMinutes(expiresAt.getMinutes() + data.expirationValue);
    } else if (data.expirationUnit === 'hours') {
      expiresAt.setHours(expiresAt.getHours() + data.expirationValue);
    } else {
      expiresAt.setDate(expiresAt.getDate() + data.expirationValue);
    }

    // Create broadcast record
    const broadcastRecord: BroadcastRecord = {
      id: String(Date.now()),
      messageId: broadcastMessage.id,
      targetAudience: data.targetAudience,
      expirationValue: data.expirationValue,
      expirationUnit: data.expirationUnit,
      createdAt: now,
      expiresAt: expiresAt
    };

    // Update message with broadcast history
    onMessagesChange(messages.map(msg =>
      msg.id === broadcastMessage.id
        ? {
            ...msg,
            broadcastHistory: [...(msg.broadcastHistory || []), broadcastRecord]
          }
        : msg
    ));

    setBroadcastMessage(null);
  };

  return (
    <div className="px-8 pb-8 pt-6 h-screen flex flex-col">
      {/* Header removed */}

      {/* Filter Panel with Messages Table */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <MessageFilterPanel
          messages={messages}
          selectedFilters={selectedFilters}
          onFilterChange={handleFilterChange}
          onClearFilters={handleClearFilters}
          viewMode={viewMode}
          onViewModeChange={setViewMode}
          searchTerm={searchTerm}
          onSearchChange={setSearchTerm}
          tableViewMode={tableViewMode}
          onTableViewModeChange={setTableViewMode}
        >
          {tableViewMode === 'table' ? (
            /* Messages Table */
            <div className="bg-white rounded-lg border border-gray-200 overflow-hidden flex flex-col flex-1">
              <div className="flex-shrink-0">
                <table className="w-full table-fixed">
                  <colgroup>
                    <col style={{ width: '256px' }} />
                    <col style={{ width: '128px' }} />
                    <col style={{ width: '128px' }} />
                    <col style={{ width: '128px' }} />
                    <col style={{ width: '192px' }} />
                    <col style={{ width: '128px' }} />
                    <col style={{ width: '144px' }} />
                  </colgroup>
                  <thead className="bg-gray-50 border-b border-gray-200">
                    <tr>
                      <th className="text-left px-6 py-3 text-gray-600">Name</th>
                      <th className="text-left px-6 py-3 text-gray-600">Type</th>
                      <th className="text-left px-6 py-3 text-gray-600">Channel</th>
                      <th className="text-left px-6 py-3 text-gray-600">Mode</th>
                      <th className="text-left px-6 py-3 text-gray-600">Template</th>
                      <th className="text-left px-6 py-3 text-gray-600">Broadcast</th>
                      <th className="text-left px-6 py-3 text-gray-600">Actions</th>
                    </tr>
                  </thead>
                </table>
              </div>
              <div className="overflow-y-auto flex-1">
                <table className="w-full table-fixed">
                  <colgroup>
                    <col style={{ width: '256px' }} />
                    <col style={{ width: '128px' }} />
                    <col style={{ width: '128px' }} />
                    <col style={{ width: '128px' }} />
                    <col style={{ width: '192px' }} />
                    <col style={{ width: '128px' }} />
                    <col style={{ width: '144px' }} />
                  </colgroup>
                  <tbody className="divide-y divide-gray-200">
                    {filteredMessages.map((message) => {
                      const responseRate = message.sent > 0 
                        ? Math.round((message.acknowledged / message.sent) * 100) 
                        : 0;

                      // Calculate active broadcasts
                      const now = new Date();
                      const activeBroadcasts = (message.broadcastHistory || []).filter(
                        broadcast => new Date(broadcast.expiresAt) > now
                      );
                      const activeBroadcastCount = activeBroadcasts.length;
                      const hasActiveBroadcast = activeBroadcastCount > 0;

                      return (
                        <tr key={message.id} className="hover:bg-gray-50">
                          <td className="px-6 py-4">
                            <div>
                              <p className="text-gray-900">{message.name}</p>
                            </div>
                          </td>
                          <td className="px-6 py-4">
                            <span className={`inline-flex items-center px-2.5 py-1 rounded text-sm capitalize ${getTypeColor(message.type)}`}>
                              {message.type}
                            </span>
                          </td>
                          <td className="px-6 py-4">
                            <span className={`inline-flex items-center px-2.5 py-1 rounded text-sm capitalize ${getChannelColor(message.channel)}`}>
                              {message.channel}
                            </span>
                          </td>
                          <td className="px-6 py-4">
                            <span className="text-gray-900 text-sm capitalize">{message.deliveryMode}</span>
                          </td>
                          <td className="px-6 py-4">
                            <p className="text-gray-900 text-sm">{message.template}</p>
                            {message.hasInteractiveFlow && (
                              <p className="text-purple-900 text-xs mt-1">Interactive Flow</p>
                            )}
                          </td>
                          <td className="px-6 py-4">
                            {hasActiveBroadcast ? (
                              <span className="inline-flex items-center px-2.5 py-1 rounded text-sm bg-green-100 text-green-800">
                                Active ({activeBroadcastCount})
                              </span>
                            ) : (
                              <span className="inline-flex items-center px-2.5 py-1 rounded text-sm bg-gray-100 text-gray-600">
                                Inactive
                              </span>
                            )}
                          </td>
                          <td className="px-6 py-4">
                            <div className="flex items-center gap-2">
                              <button 
                                onClick={() => setPreviewMessage(message)}
                                className="text-purple-900 hover:text-purple-950"
                                title="Preview message"
                              >
                                <Eye className="w-4 h-4" />
                              </button>
                              <button 
                                onClick={() => setEditMessage(message)}
                                className="text-purple-900 hover:text-purple-950"
                                title="Edit message"
                              >
                                <Edit className="w-4 h-4" />
                              </button>
                              <button 
                                onClick={() => {
                                  const duplicatedMessage: Message = {
                                    ...message,
                                    id: String(Date.now()),
                                    name: `${message.name} (Copy)`,
                                    createdAt: new Date(),
                                    status: 'draft',
                                    sent: 0,
                                    acknowledged: 0,
                                    broadcastHistory: []
                                  };
                                  onMessagesChange([duplicatedMessage, ...messages]);
                                }}
                                className="text-purple-900 hover:text-purple-950" 
                                title="Copy message"
                              >
                                <Copy className="w-4 h-4" />
                              </button>
                              <button 
                                onClick={() => setBroadcastMessage(message)}
                                className="text-purple-900 hover:text-purple-950" 
                                title="Send message"
                              >
                                <Send className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          ) : (
            /* Messages Grid */
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-4 overflow-y-auto auto-rows-max flex-1">
              {filteredMessages.map((message) => {
                const responseRate = message.sent > 0 
                  ? Math.round((message.acknowledged / message.sent) * 100) 
                  : 0;

                return (
                  <div key={message.id} className="bg-white rounded-lg border border-gray-200 overflow-hidden hover:shadow-lg transition-shadow flex flex-col h-auto min-h-fit">
                    {/* Message Header */}
                    <div className="p-6 border-b border-gray-200">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex-1">
                          <h3 className="text-gray-900">{message.name}</h3>
                          <p className="text-gray-500 text-sm mt-1">{message.targetGroup}</p>
                        </div>
                        <span className={`px-2.5 py-1 rounded-full text-sm capitalize ${getTypeColor(message.type)}`}>
                          {message.type}
                        </span>
                      </div>
                    </div>

                    {/* Message Details */}
                    <div className="p-6 space-y-4 flex-1">
                      {/* Status */}
                      <div>
                        <p className="text-gray-600 text-sm mb-2">Status</p>
                        <span className={`inline-flex items-center px-2.5 py-1 rounded text-sm capitalize ${getStatusColor(message.status)}`}>
                          {message.status}
                        </span>
                      </div>

                      {/* Channel & Mode */}
                      <div>
                        <p className="text-gray-600 text-sm mb-2">Channel & Mode</p>
                        <div className="flex flex-wrap gap-2">
                          <span className={`inline-flex items-center px-2.5 py-1 rounded text-sm capitalize ${getChannelColor(message.channel)}`}>
                            {message.channel}
                          </span>
                          <span className="bg-gray-100 text-gray-700 px-2.5 py-1 rounded text-sm capitalize">
                            {message.deliveryMode}
                          </span>
                        </div>
                      </div>

                      {/* Template */}
                      <div>
                        <p className="text-gray-600 text-sm mb-2">Template</p>
                        <p className="text-gray-900 text-sm">{message.template}</p>
                        {message.hasInteractiveFlow && (
                          <p className="text-purple-900 text-xs mt-1">Interactive Flow</p>
                        )}
                      </div>

                      {/* Stats */}
                      {message.sent > 0 && (
                        <div className="pt-3 border-t border-gray-200">
                          <div className="flex justify-between text-sm">
                            <span className="text-gray-600">Sent: {message.sent}</span>
                            <span className="text-gray-600">Acknowledged: {message.acknowledged}</span>
                          </div>
                          <div className="mt-2">
                            <div className="w-full bg-gray-200 rounded-full h-2">
                              <div 
                                className="bg-purple-900 h-2 rounded-full" 
                                style={{ width: `${responseRate}%` }}
                              />
                            </div>
                            <p className="text-xs text-gray-500 mt-1">{responseRate}% response rate</p>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Actions */}
                    <div className="px-6 py-4 bg-gray-50 border-t border-gray-200 flex items-center justify-between mt-auto">
                      <button 
                        className="text-purple-900 hover:text-purple-950 flex items-center gap-1 text-sm"
                        onClick={() => setPreviewMessage(message)}
                      >
                        <Eye className="w-4 h-4" />
                        Preview
                      </button>
                      <div className="flex items-center gap-2">
                        <button 
                          onClick={() => setEditMessage(message)}
                          className="text-gray-600 hover:text-gray-800"
                          title="Edit message"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button 
                          onClick={() => {
                            const duplicatedMessage: Message = {
                              ...message,
                              id: String(Date.now()),
                              name: `${message.name} (Copy)`,
                              createdAt: new Date(),
                              status: 'draft',
                              sent: 0,
                              acknowledged: 0,
                              broadcastHistory: []
                            };
                            onMessagesChange([duplicatedMessage, ...messages]);
                          }}
                          className="text-gray-600 hover:text-gray-800" 
                          title="Copy message"
                        >
                          <Copy className="w-4 h-4" />
                        </button>
                        <button 
                          onClick={() => setBroadcastMessage(message)}
                          className="text-purple-900 hover:text-purple-950" 
                          title="Send message"
                        >
                          <Send className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </MessageFilterPanel>
      </div>

      {/* Message Detail Modal */}
      {selectedMessage && (
        <MessageDetailModal 
          message={selectedMessage}
          onClose={() => setSelectedMessage(null)}
        />
      )}

      {/* Preview Message Dialog */}
      {previewMessage && (
        <PreviewMessageDialog 
          message={previewMessage}
          open={!!previewMessage}
          onClose={() => setPreviewMessage(null)}
          templates={templates}
          brandingLogo={brandingLogo}
        />
      )}

      {/* Create Message Dialog */}
      <CreateMessageDialogNew
        open={showCreateDialog}
        onClose={() => setShowCreateDialog(false)}
        templates={templates}
        brandingLogo={brandingLogo}
        onSubmit={(data) => {
          // Create new message with generated ID
          const newMessage: Message = {
            id: String(messages.length + 1),
            name: data.name,
            type: data.type as MessageType,
            channel: data.channel as Channel,
            deliveryMode: data.deliveryMode as DeliveryMode,
            template: data.template,
            templateId: data.templateId,
            targetGroup: data.targetGroup,
            status: 'active',
            sent: 0,
            acknowledged: 0,
            createdAt: new Date(),
            createdBy: 'current-user@company.com',
            hasInteractiveFlow: data.hasInteractiveFlow || false,
            requiresResponse: data.requiresResponse || false,
            // Message content
            messageTitle: data.messageTitle,
            messageDescription: data.messageDescription,
            messageContent: data.messageContent,
            buttonPrimary: data.buttonPrimary,
            buttonSecondary: data.buttonSecondary,
            buttonTertiary: data.buttonTertiary,
            // Template display configuration
            showLogo: data.showLogo,
            logoPosition: data.logoPosition,
            showHeader: data.showHeader,
            showDescription: data.showDescription,
            showBody: data.showBody,
            showButton1: data.showButton1,
            showButton2: data.showButton2,
            showButton3: data.showButton3,
            button1Type: data.button1Type,
            button2Type: data.button2Type,
            button3Type: data.button3Type,
            customCSS: data.customCSS,
            brandingProfile: data.brandingProfile,
          };
          
          // Add to messages list
          onMessagesChange([newMessage, ...messages]);
          setShowCreateDialog(false);
        }}
      />

      {/* Edit Message Dialog */}
      {editMessage && (
        <CreateMessageDialogNew
          open={!!editMessage}
          onClose={() => setEditMessage(null)}
          editMessage={editMessage}
          templates={templates}
          brandingLogo={brandingLogo}
          onSubmit={(data) => {
            // Update existing message while preserving important fields
            onMessagesChange(messages.map(msg => 
              msg.id === editMessage.id
                ? {
                    ...msg,
                    name: data.name,
                    type: data.type as MessageType,
                    channel: data.channel as Channel,
                    deliveryMode: data.deliveryMode as DeliveryMode,
                    template: data.template,
                    templateId: data.templateId,
                    targetGroup: data.targetGroup,
                    hasInteractiveFlow: data.hasInteractiveFlow || false,
                    requiresResponse: data.requiresResponse || false,
                    // Message content
                    messageTitle: data.messageTitle,
                    messageDescription: data.messageDescription,
                    messageContent: data.messageContent,
                    buttonPrimary: data.buttonPrimary,
                    buttonSecondary: data.buttonSecondary,
                    buttonTertiary: data.buttonTertiary,
                    // Template display configuration
                    showLogo: data.showLogo,
                    logoPosition: data.logoPosition,
                    showHeader: data.showHeader,
                    showDescription: data.showDescription,
                    showBody: data.showBody,
                    showButton1: data.showButton1,
                    showButton2: data.showButton2,
                    showButton3: data.showButton3,
                    button1Type: data.button1Type,
                    button2Type: data.button2Type,
                    button3Type: data.button3Type,
                    customCSS: data.customCSS,
                    brandingProfile: data.brandingProfile,
                  }
                : msg
            ));
            setEditMessage(null);
          }}
        />
      )}

      {/* Design Preview Dialog */}
      <MessageDesignPreview 
        open={showDesignPreview}
        onClose={() => setShowDesignPreview(false)}
      />

      {/* Broadcast Dialog */}
      {broadcastMessage && (
        <BroadcastDialog
          open={!!broadcastMessage}
          onClose={() => setBroadcastMessage(null)}
          messageName={broadcastMessage.name}
          onBroadcast={handleBroadcast}
        />
      )}
    </div>
  );
}