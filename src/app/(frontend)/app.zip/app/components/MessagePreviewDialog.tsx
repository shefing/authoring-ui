import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from './ui/dialog';
import riverbedLogo from "figma:asset/4b161716604143be2e292f585da4d73d4ab36bb3.png";

interface MessagePreviewDialogProps {
  open: boolean;
  onClose: () => void;
}

export function MessagePreviewDialog({ open, onClose }: MessagePreviewDialogProps) {
  const [selectedReminder, setSelectedReminder] = useState<string | null>(null);

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl p-8">
        <DialogHeader className="sr-only">
          <DialogTitle>Message Preview</DialogTitle>
          <DialogDescription>
            Preview how your message will appear to end users
          </DialogDescription>
        </DialogHeader>

        {/* Message Preview Card */}
        <div className="border border-gray-300 rounded-lg overflow-hidden shadow-lg bg-white max-w-2xl mx-auto">
          {/* Header */}
          <div className="bg-white px-4 py-3 flex items-center justify-between border-b border-gray-200">
            <div className="text-gray-900">Company IT</div>
            <img src={riverbedLogo} alt="Riverbed" className="h-8" />
          </div>

          {/* Purple Banner Section */}
          <div className="bg-gradient-to-r from-purple-400 to-purple-300 px-8 py-12 text-white">
            <h2 className="text-white text-2xl mb-2">
              We identified some issue
            </h2>
            <p className="text-white text-base opacity-90">
              Can we go ahead and fix it?
            </p>
          </div>

          {/* Action Section */}
          <div className="bg-white px-6 py-5 border-t border-gray-200">
            <div className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-2 text-gray-900 flex-1">
                <span>Remind me in:</span>
                <button
                  onClick={() => setSelectedReminder('1hour')}
                  className={`px-3 py-1.5 text-sm rounded transition-colors ${
                    selectedReminder === '1hour'
                      ? 'bg-blue-100 text-blue-700 border border-blue-300'
                      : 'text-blue-600 hover:bg-blue-50'
                  }`}
                >
                  1 Hour
                </button>
                <button
                  onClick={() => setSelectedReminder('2hours')}
                  className={`px-3 py-1.5 text-sm rounded transition-colors ${
                    selectedReminder === '2hours'
                      ? 'bg-blue-100 text-blue-700 border border-blue-300'
                      : 'text-blue-600 hover:bg-blue-50'
                  }`}
                >
                  2 Hours
                </button>
                <button
                  onClick={() => setSelectedReminder('4hours')}
                  className={`px-3 py-1.5 text-sm rounded transition-colors ${
                    selectedReminder === '4hours'
                      ? 'bg-blue-100 text-blue-700 border border-blue-300'
                      : 'text-blue-600 hover:bg-blue-50'
                  }`}
                >
                  4 Hours
                </button>
                <button
                  onClick={() => setSelectedReminder('8hours')}
                  className={`px-3 py-1.5 text-sm rounded transition-colors ${
                    selectedReminder === '8hours'
                      ? 'bg-blue-100 text-blue-700 border border-blue-300'
                      : 'text-blue-600 hover:bg-blue-50'
                  }`}
                >
                  8 Hours
                </button>
              </div>
              <button className="px-8 py-2.5 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors">
                Yes
              </button>
            </div>
          </div>
        </div>

        {/* Additional Info */}
        <div className="mt-6 p-4 bg-gray-50 rounded-lg border border-gray-200">
          <p className="text-xs text-gray-600">
            This preview shows how the message will appear on user devices. The actual content can be customized when creating the message.
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}