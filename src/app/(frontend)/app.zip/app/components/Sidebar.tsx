import { NavigationView } from './UnifiedCommunicationPlatform';
import { 
  LayoutDashboard, 
  FileText, 
  Radio, 
  Workflow, 
  Palette, 
  Settings, 
  BarChart3,
  MessageSquare,
  CheckCircle
} from 'lucide-react';

interface SidebarProps {
  currentView: NavigationView;
  onNavigate: (view: NavigationView) => void;
}

export function Sidebar({ currentView, onNavigate }: SidebarProps) {
  const navigation = [
    { id: 'overview' as NavigationView, label: 'Messages', icon: LayoutDashboard },
    { id: 'templates' as NavigationView, label: 'Templates', icon: FileText },
    { id: 'channels' as NavigationView, label: 'Channels', icon: Radio },
    { id: 'flows' as NavigationView, label: 'Interactive Flows', icon: Workflow },
    { id: 'branding' as NavigationView, label: 'Branding', icon: Palette },
    { id: 'rules' as NavigationView, label: 'Delivery Rules', icon: Settings },
    { id: 'analytics' as NavigationView, label: 'Analytics', icon: BarChart3 }
  ];

  return (
    <div className="w-64 bg-gray-950 text-white flex flex-col" style={{ backgroundColor: '#1a0f2e' }}>
      {/* Header */}
      <div className="p-6 border-b border-purple-950/50">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-purple-900 rounded-lg flex items-center justify-center">
            <MessageSquare className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-white">End-user Communication</h1>
            <p className="text-purple-300/70 text-sm">Unified Platform</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4">
        <ul className="space-y-1">
          {navigation.map((item) => {
            const Icon = item.icon;
            const isActive = currentView === item.id;
            
            return (
              <li key={item.id}>
                <button
                  onClick={() => onNavigate(item.id)}
                  disabled={item.id === 'flows' || item.id === 'analytics'}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors select-none ${
                    item.id === 'flows' || item.id === 'analytics'
                      ? 'text-purple-200/30 cursor-not-allowed'
                      : isActive 
                        ? 'bg-purple-900 text-white shadow-lg shadow-purple-900/50' 
                        : 'text-purple-200/80 hover:bg-purple-900/30 hover:text-white'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span>{item.label}</span>
                </button>
              </li>
            );
          })}
        </ul>
      </nav>

      {/* Footer */}
      <div className="p-4 border-t border-purple-950/50">
      </div>
    </div>
  );
}