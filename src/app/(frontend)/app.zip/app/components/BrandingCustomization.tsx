import { useState } from 'react';
import { Palette, Eye, Code, Upload, Plus, Edit, Trash2, X, Check } from 'lucide-react';
import { BrandingLogo, defaultBrandingLogo } from './UnifiedCommunicationPlatform';
import { CustomLogoUploadSection } from './CustomLogoUploadSection';

interface BrandingTheme {
  id: string;
  name: string;
  appliesTo: 'division' | 'message-type' | 'urgency' | 'global';
  scope: string;
  customCSS: string;
  colors: {
    primary: string;
    secondary: string;
    background: string;
    text: string;
  };
  logos?: Array<{
    id: string;
    name: string;
    preview: string;
    type: 'file' | 'svg';
  }>;
}

interface BrandingCustomizationProps {
  onLogoChange: (logo: BrandingLogo | null) => void;
}

export function BrandingCustomization({ onLogoChange }: BrandingCustomizationProps) {
  const [themes, setThemes] = useState<BrandingTheme[]>([
    {
      id: '1',
      name: 'Corporate Default',
      appliesTo: 'global',
      scope: 'All Messages',
      customCSS: '',
      colors: {
        primary: '#581c87',
        secondary: '#c084fc',
        background: '#FFFFFF',
        text: '#1E293B'
      }
    },
    {
      id: '2',
      name: 'Security Alert Theme',
      appliesTo: 'urgency',
      scope: 'Urgent Messages',
      customCSS: '.alert-banner { border-left: 4px solid #DC2626; }',
      colors: {
        primary: '#DC2626',
        secondary: '#F59E0B',
        background: '#FEF2F2',
        text: '#991B1B'
      }
    },
    {
      id: '3',
      name: 'Engineering Division',
      appliesTo: 'division',
      scope: 'Engineering Dept',
      customCSS: '',
      colors: {
        primary: '#7C3AED',
        secondary: '#A78BFA',
        background: '#FFFFFF',
        text: '#1E293B'
      }
    },
    {
      id: '4',
      name: 'Remediation Confirmation',
      appliesTo: 'message-type',
      scope: 'Confirmation Messages',
      customCSS: '.confirmation-header { background: linear-gradient(135deg, #F97316, #FB923C); }',
      colors: {
        primary: '#F97316',
        secondary: '#FB923C',
        background: '#FFFFFF',
        text: '#1E293B'
      }
    },
    {
      id: '5',
      name: 'Executive VIP Theme',
      appliesTo: 'division',
      scope: 'Executive Users',
      customCSS: '.vip-badge { display: flex; align-items: center; gap: 4px; }',
      colors: {
        primary: '#0F172A',
        secondary: '#94A3B8',
        background: '#FFFFFF',
        text: '#0F172A'
      }
    }
  ]);

  const [selectedTheme, setSelectedTheme] = useState<BrandingTheme | null>(themes[0]);
  const [originalTheme, setOriginalTheme] = useState<BrandingTheme | null>(themes[0]);
  const [showCSSEditor, setShowCSSEditor] = useState(false);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [editingTheme, setEditingTheme] = useState<BrandingTheme | null>(null);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [deletingThemeId, setDeletingThemeId] = useState<string | null>(null);
  const [logoPreview, setLogoPreview] = useState<string | null>(null);
  const [logoType, setLogoType] = useState<'file' | 'svg'>('file');
  const [svgCode, setSvgCode] = useState('');
  const [savedSuccessfully, setSavedSuccessfully] = useState(false);
  const [viewMode, setViewMode] = useState<'single' | 'tabs'>('tabs');
  const [activeTab, setActiveTab] = useState<'theme' | 'logo' | 'fonts'>('theme');
  const [logoConfigLogos, setLogoConfigLogos] = useState<Array<{
    id: string;
    name: string;
    preview: string;
    type: 'file' | 'svg';
  }>>([]);
  const [logoSvgDialogOpen, setLogoSvgDialogOpen] = useState(false);
  const [logoSvgDialogIndex, setLogoSvgDialogIndex] = useState<number | null>(null);
  const [logoSvgDialogInput, setLogoSvgDialogInput] = useState('');

  // Check if there are any changes
  const hasChanges = selectedTheme && originalTheme && (
    selectedTheme.colors.primary !== originalTheme.colors.primary ||
    selectedTheme.colors.secondary !== originalTheme.colors.secondary ||
    selectedTheme.colors.background !== originalTheme.colors.background ||
    selectedTheme.colors.text !== originalTheme.colors.text ||
    JSON.stringify(selectedTheme.logos) !== JSON.stringify(originalTheme.logos)
  );

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const preview = reader.result as string;
        setLogoPreview(preview);
        onLogoChange({ preview, type: 'file' });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSvgCodeSubmit = () => {
    setLogoPreview(svgCode);
    onLogoChange({ preview: svgCode, type: 'svg' });
  };

  const handleCreateTheme = (theme: Omit<BrandingTheme, 'id'>) => {
    const newTheme: BrandingTheme = {
      ...theme,
      id: String(Date.now())
    };
    setThemes([...themes, newTheme]);
    setSelectedTheme(newTheme);
    setShowCreateDialog(false);
  };

  const handleUpdateTheme = (updatedTheme: BrandingTheme) => {
    setThemes(themes.map(t => t.id === updatedTheme.id ? updatedTheme : t));
    setSelectedTheme(updatedTheme);
    setShowEditDialog(false);
    setEditingTheme(null);
  };

  const handleDeleteTheme = () => {
    if (deletingThemeId) {
      setThemes(themes.filter(t => t.id !== deletingThemeId));
      if (selectedTheme?.id === deletingThemeId) {
        setSelectedTheme(themes.find(t => t.id !== deletingThemeId) || null);
      }
      setShowDeleteDialog(false);
      setDeletingThemeId(null);
    }
  };

  const handleEditClick = (theme: BrandingTheme) => {
    setEditingTheme(theme);
    setShowEditDialog(true);
  };

  const handleDeleteClick = (themeId: string) => {
    setDeletingThemeId(themeId);
    setShowDeleteDialog(true);
  };

  const handleSaveChanges = () => {
    if (selectedTheme) {
      // Save to themes array
      setThemes(themes.map(t => t.id === selectedTheme.id ? selectedTheme : t));
      
      // Save to localStorage
      localStorage.setItem('brandingTheme', JSON.stringify(selectedTheme));
      
      // Update original theme to match current
      setOriginalTheme(JSON.parse(JSON.stringify(selectedTheme)));
      
      // If the theme logo is marked as default, update the global branding logo
      const themeLogo = selectedTheme.logos?.[0];
      if (themeLogo) {
        onLogoChange(themeLogo);
      }
      
      setSavedSuccessfully(true);
      setTimeout(() => setSavedSuccessfully(false), 3000);
    }
  };

  const handleRevertToDefaults = () => {
    if (originalTheme) {
      setSelectedTheme(JSON.parse(JSON.stringify(originalTheme)));
    }
  };

  return (
    <div className="p-8">
      {/* View Mode Content */}
      {viewMode === 'single' ? (
        /* Single View - All Sections on One Page */
        <div className="space-y-4">
          {/* Theme Designer Section - First Row */}
          <div className="bg-white rounded-lg border border-gray-200 p-4">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-gray-900">Theme Designer</h2>
            </div>

            {selectedTheme && (
              <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
                {/* Theme List - Left Side with Vertical Scroll */}
                <div className="lg:col-span-1">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-gray-900 text-sm">Themes</h3>
                    <button className="text-purple-900 hover:text-purple-950 text-xs" onClick={() => setShowCreateDialog(true)}>
                      + New
                    </button>
                  </div>

                  <div className="space-y-2 max-h-[500px] overflow-y-auto pr-2">
                    {themes.map((theme) => (
                      <div
                        key={theme.id}
                        className={`bg-gray-50 rounded-lg border-2 p-3 transition-all cursor-pointer ${
                          selectedTheme?.id === theme.id
                            ? 'border-purple-900 shadow-md'
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                      >
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex-1" onClick={() => {
                            setSelectedTheme(theme);
                            setOriginalTheme(JSON.parse(JSON.stringify(theme)));
                          }}>
                            <h4 className="text-gray-900 text-sm">{theme.name}</h4>
                            <p className="text-gray-500 text-xs mt-0.5">{theme.scope}</p>
                          </div>
                        <div className="flex items-center gap-1">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleEditClick(theme);
                            }}
                            className="p-1 text-gray-600 hover:text-purple-900 transition-colors"
                            title="Edit theme"
                          >
                            <Edit className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleDeleteClick(theme.id);
                            }}
                            className="p-1 text-gray-600 hover:text-red-600 transition-colors"
                            title="Delete theme"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                      <div className="mb-2">
                        <span className={`px-2 py-0.5 rounded text-xs capitalize ${
                          theme.appliesTo === 'global' ? 'bg-purple-100 text-purple-900' :
                          theme.appliesTo === 'urgency' ? 'bg-red-100 text-red-700' :
                          theme.appliesTo === 'division' ? 'bg-purple-100 text-purple-700' :
                          'bg-green-100 text-green-700'
                        }`}>
                          {theme.appliesTo}
                        </span>
                      </div>

                      {/* Color Preview */}
                      <div className="flex gap-1.5" onClick={() => {
                        setSelectedTheme(theme);
                        setOriginalTheme(JSON.parse(JSON.stringify(theme)));
                      }}>
                        <div
                          className="w-6 h-6 rounded border border-gray-200"
                          style={{ backgroundColor: theme.colors.primary }}
                          title="Primary"
                        />
                        <div
                          className="w-6 h-6 rounded border border-gray-200"
                          style={{ backgroundColor: theme.colors.secondary }}
                          title="Secondary"
                        />
                        <div
                          className="w-6 h-6 rounded border border-gray-200"
                          style={{ backgroundColor: theme.colors.background }}
                          title="Background"
                        />
                        <div
                          className="w-6 h-6 rounded border border-gray-200"
                          style={{ backgroundColor: theme.colors.text }}
                          title="Text"
                        />
                      </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Theme Designer Content - Right Side */}
                <div className="lg:col-span-3">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-gray-900 text-sm">{selectedTheme.name}</h3>
                    <div className="flex items-center gap-2">
                      {hasChanges && (
                        <button 
                          className="px-3 py-1.5 rounded-lg text-sm transition-colors border border-gray-300 text-gray-700 hover:bg-gray-50"
                          onClick={handleRevertToDefaults}
                        >
                          Revert to Defaults
                        </button>
                      )}
                      <button 
                        className={`px-3 py-1.5 rounded-lg text-sm transition-colors ${
                          hasChanges 
                            ? 'bg-purple-900 text-white hover:bg-purple-950' 
                            : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                        }`}
                        onClick={handleSaveChanges}
                        disabled={!hasChanges}
                      >
                        Save Changes
                      </button>
                    </div>
                  </div>

                  {/* Scope */}
                  <div className="mb-4">
                    <label className="block text-gray-700 mb-1.5 text-sm">Scope</label>
                    <input
                      type="text"
                      value={selectedTheme.scope}
                      onChange={(e) => setSelectedTheme({ ...selectedTheme, scope: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-white text-sm"
                      placeholder="e.g., Engineering Dept, Urgent Messages"
                    />
                  </div>

                  {/* Color Configuration */}
                  <div className="mb-4">
                    <label className="block text-gray-700 mb-2 text-sm">Color Palette</label>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-gray-600 mb-1 text-xs">Primary Color</label>
                        <div className="flex gap-2">
                          <input
                            type="color"
                            value={selectedTheme.colors.primary}
                            onChange={(e) => {
                              setSelectedTheme({ 
                                ...selectedTheme, 
                                colors: { ...selectedTheme.colors, primary: e.target.value }
                              });
                            }}
                            className="w-10 h-9 rounded border border-gray-300 cursor-pointer"
                          />
                          <input
                            type="text"
                            value={selectedTheme.colors.primary}
                            onChange={(e) => {
                              setSelectedTheme({ 
                                ...selectedTheme, 
                                colors: { ...selectedTheme.colors, primary: e.target.value }
                              });
                            }}
                            className="flex-1 px-2 py-1.5 border border-gray-300 rounded text-xs"
                          />
                        </div>
                      </div>
                      <div>
                        <label className="block text-gray-600 mb-1 text-xs">Secondary Color</label>
                        <div className="flex gap-2">
                          <input
                            type="color"
                            value={selectedTheme.colors.secondary}
                            onChange={(e) => {
                              setSelectedTheme({ 
                                ...selectedTheme, 
                                colors: { ...selectedTheme.colors, secondary: e.target.value }
                              });
                            }}
                            className="w-10 h-9 rounded border border-gray-300 cursor-pointer"
                          />
                          <input
                            type="text"
                            value={selectedTheme.colors.secondary}
                            onChange={(e) => {
                              setSelectedTheme({ 
                                ...selectedTheme, 
                                colors: { ...selectedTheme.colors, secondary: e.target.value }
                              });
                            }}
                            className="flex-1 px-2 py-1.5 border border-gray-300 rounded text-xs"
                          />
                        </div>
                      </div>
                      <div>
                        <label className="block text-gray-600 mb-1 text-xs">Background Color</label>
                        <div className="flex gap-2">
                          <input
                            type="color"
                            value={selectedTheme.colors.background}
                            onChange={(e) => {
                              setSelectedTheme({ 
                                ...selectedTheme, 
                                colors: { ...selectedTheme.colors, background: e.target.value }
                              });
                            }}
                            className="w-10 h-9 rounded border border-gray-300 cursor-pointer"
                          />
                          <input
                            type="text"
                            value={selectedTheme.colors.background}
                            onChange={(e) => {
                              setSelectedTheme({ 
                                ...selectedTheme, 
                                colors: { ...selectedTheme.colors, background: e.target.value }
                              });
                            }}
                            className="flex-1 px-2 py-1.5 border border-gray-300 rounded text-xs"
                          />
                        </div>
                      </div>
                      <div>
                        <label className="block text-gray-600 mb-1 text-xs">Text Color</label>
                        <div className="flex gap-2">
                          <input
                            type="color"
                            value={selectedTheme.colors.text}
                            onChange={(e) => {
                              setSelectedTheme({ 
                                ...selectedTheme, 
                                colors: { ...selectedTheme.colors, text: e.target.value }
                              });
                            }}
                            className="w-10 h-9 rounded border border-gray-300 cursor-pointer"
                          />
                          <input
                            type="text"
                            value={selectedTheme.colors.text}
                            onChange={(e) => {
                              setSelectedTheme({ 
                                ...selectedTheme, 
                                colors: { ...selectedTheme.colors, text: e.target.value }
                              });
                            }}
                            className="flex-1 px-2 py-1.5 border border-gray-300 rounded text-xs"
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Live Preview - Inline */}
                  <div className="mb-4">
                    <label className="block text-gray-700 mb-2 text-sm">Live Preview</label>
                    <div className="bg-gray-100 rounded-lg p-4 flex items-center justify-center">
                      <div
                        className="max-w-sm w-full bg-white rounded-lg shadow-xl border-t-4"
                        style={{ borderColor: selectedTheme.colors.primary }}
                      >
                        <div className="p-4">
                          <h3 className="text-lg" style={{ color: selectedTheme.colors.primary }}>
                            Sample Message Title
                          </h3>
                          <p style={{ color: selectedTheme.colors.text }} className="mt-2 text-xs">
                            This is how your message will appear to end users with the selected branding theme.
                            Custom colors and CSS will be applied.
                          </p>
                        </div>
                        <div
                          className="border-t px-4 py-3"
                          style={{ backgroundColor: selectedTheme.colors.background }}
                        >
                          <button
                            className="w-full py-1.5 rounded-lg text-white transition-colors text-sm"
                            style={{ backgroundColor: selectedTheme.colors.primary }}
                          >
                            OK
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Custom CSS */}
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <label className="block text-gray-700 text-sm">Custom CSS (Advanced)</label>
                      <button
                        onClick={() => setShowCSSEditor(!showCSSEditor)}
                        className="flex items-center gap-1 text-purple-900 hover:text-purple-950 text-sm"
                      >
                        <Code className="w-4 h-4" />
                        {showCSSEditor ? 'Hide' : 'Edit'} CSS
                      </button>
                    </div>
                    {showCSSEditor && (
                      <textarea
                        value={selectedTheme.customCSS}
                        onChange={(e) => setSelectedTheme({ ...selectedTheme, customCSS: e.target.value })}
                        rows={6}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg font-mono text-xs resize-none"
                        placeholder="Enter custom CSS rules..."
                      />
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Second Row - Logo and Fonts Side by Side */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Logo Section */}
            <div className="bg-white rounded-lg border border-gray-200 p-4">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-gray-900">Logo Configuration</h2>
              </div>

              {/* Logo Type Toggle */}
              <div className="flex gap-2 mb-3">
                <button
                  onClick={() => setLogoType('file')}
                  className={`px-3 py-1.5 rounded-lg text-xs transition-colors ${
                    logoType === 'file'
                      ? 'bg-purple-900 text-white'
                      : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                  }`}
                >
                  Upload File
                </button>
                <button
                  onClick={() => setLogoType('svg')}
                  className={`px-3 py-1.5 rounded-lg text-xs transition-colors ${
                    logoType === 'svg'
                      ? 'bg-purple-900 text-white'
                      : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                  }`}
                >
                  Paste SVG Code
                </button>
              </div>

              {logoType === 'file' ? (
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                  <Upload className="w-6 h-6 text-gray-400 mx-auto mb-2" />
                  <p className="text-gray-600 text-xs mb-2">Upload division or department logo</p>
                <input
                  type="file"
                  id="logo-upload"
                  accept="image/png,image/jpeg,image/jpg,image/svg+xml"
                  onChange={handleFileUpload}
                  className="hidden"
                />
                  <button 
                    className="text-purple-900 hover:text-purple-950 text-xs"
                    onClick={() => document.getElementById('logo-upload')?.click()}
                  >
                    Choose File
                  </button>
                  <p className="text-gray-500 text-xs mt-1">PNG, JPG, SVG up to 2MB. Recommended: 200x50px</p>
                </div>
              ) : (
                <div>
                  <label className="block text-gray-700 mb-1.5 text-sm">SVG Code</label>
                  <textarea
                    value={svgCode}
                    onChange={(e) => setSvgCode(e.target.value)}
                    rows={6}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg font-mono text-xs resize-none mb-2"
                    placeholder="Paste your SVG code here... e.g., <svg>...</svg>"
                  />
                  <button
                    onClick={handleSvgCodeSubmit}
                    className="px-3 py-1.5 bg-purple-900 text-white rounded-lg text-xs hover:bg-purple-950"
                  >
                    Apply SVG
                  </button>
                </div>
              )}

              {/* Logo Preview */}
              {logoPreview && (
                <div className="mt-4">
                  <div className="flex items-center justify-between mb-2">
                    <h5 className="text-gray-700 text-sm">Preview</h5>
                    <button
                      onClick={() => {
                        setLogoPreview(null);
                        setSvgCode('');
                        onLogoChange(null);
                      }}
                      className="text-red-600 hover:text-red-800 text-xs"
                    >
                      Remove
                    </button>
                  </div>
                  <div className="border border-gray-300 rounded-lg p-3 bg-gray-50 flex items-center justify-center">
                    {logoType === 'svg' ? (
                      <div dangerouslySetInnerHTML={{ __html: logoPreview }} />
                    ) : (
                      <img src={logoPreview} alt="Logo preview" className="max-h-16" />
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Fonts & Style Section */}
            <div className="bg-white rounded-lg border border-gray-200 p-4">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-gray-900">Fonts & Typography</h2>
              </div>

              <div className="space-y-3">
                <div>
                  <label className="block text-gray-700 mb-1.5 text-sm">Primary Font Family</label>
                  <select className="w-full px-3 py-1.5 border border-gray-300 rounded-lg bg-white text-sm">
                    <option value="system">System Default</option>
                    <option value="inter">Inter</option>
                    <option value="roboto">Roboto</option>
                    <option value="open-sans">Open Sans</option>
                    <option value="lato">Lato</option>
                    <option value="montserrat">Montserrat</option>
                    <option value="poppins">Poppins</option>
                    <option value="arial">Arial</option>
                    <option value="helvetica">Helvetica</option>
                    <option value="georgia">Georgia</option>
                    <option value="times">Times New Roman</option>
                  </select>
                </div>

                <div>
                  <label className="block text-gray-700 mb-1.5 text-sm">Heading Font</label>
                  <select className="w-full px-3 py-1.5 border border-gray-300 rounded-lg bg-white text-sm">
                    <option value="same">Same as Primary</option>
                    <option value="inter">Inter</option>
                    <option value="roboto">Roboto</option>
                    <option value="open-sans">Open Sans</option>
                    <option value="lato">Lato</option>
                    <option value="montserrat">Montserrat</option>
                    <option value="poppins">Poppins</option>
                    <option value="arial">Arial</option>
                    <option value="helvetica">Helvetica</option>
                    <option value="georgia">Georgia</option>
                    <option value="times">Times New Roman</option>
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-gray-700 mb-1.5 text-sm">Base Font Size</label>
                    <select className="w-full px-3 py-1.5 border border-gray-300 rounded-lg bg-white text-sm" defaultValue="14">
                      <option value="12">12px</option>
                      <option value="13">13px</option>
                      <option value="14">14px</option>
                      <option value="15">15px</option>
                      <option value="16">16px</option>
                      <option value="18">18px</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-gray-700 mb-1.5 text-sm">Line Height</label>
                    <select className="w-full px-3 py-1.5 border border-gray-300 rounded-lg bg-white text-sm" defaultValue="1.5">
                      <option value="1.2">1.2 (Tight)</option>
                      <option value="1.4">1.4 (Snug)</option>
                      <option value="1.5">1.5 (Normal)</option>
                      <option value="1.6">1.6 (Relaxed)</option>
                      <option value="1.8">1.8 (Loose)</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-gray-700 mb-2 text-sm">Font Weight</label>
                  <div className="grid grid-cols-3 gap-1.5">
                    <button className="px-2 py-1.5 border border-gray-300 rounded-lg bg-white hover:bg-purple-50 hover:border-purple-300 transition-colors text-xs">
                      Light (300)
                    </button>
                    <button className="px-2 py-1.5 border-2 border-purple-900 rounded-lg bg-purple-50 text-purple-900 text-xs">
                      Regular (400)
                    </button>
                    <button className="px-2 py-1.5 border border-gray-300 rounded-lg bg-white hover:bg-purple-50 hover:border-purple-300 transition-colors text-xs">
                      Medium (500)
                    </button>
                    <button className="px-2 py-1.5 border border-gray-300 rounded-lg bg-white hover:bg-purple-50 hover:border-purple-300 transition-colors text-xs">
                      Semi-Bold (600)
                    </button>
                    <button className="px-2 py-1.5 border border-gray-300 rounded-lg bg-white hover:bg-purple-50 hover:border-purple-300 transition-colors text-xs">
                      Bold (700)
                    </button>
                    <button className="px-2 py-1.5 border border-gray-300 rounded-lg bg-white hover:bg-purple-50 hover:border-purple-300 transition-colors text-xs">
                      Extra Bold (800)
                    </button>
                  </div>
                </div>

                {/* Apply Button */}
                <div className="flex justify-end pt-3 border-t border-gray-200">
                  <button className="px-3 py-1.5 bg-purple-900 text-white rounded-lg hover:bg-purple-950 transition-colors text-sm">
                    Apply Font Settings
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* Branding View - Simplified */
        <div>
          {/* Branding Content - No Sub-tabs */}
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            {selectedTheme && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Left Column - Controls */}
                <div className="space-y-4">
                      {/* Selected Theme Indicator */}
                      <div className="bg-purple-50 border border-purple-200 rounded-lg p-3">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-xs text-gray-600 mb-0.5">Selected Theme</p>
                            <p className="text-sm font-medium text-purple-900">{selectedTheme.name}</p>
                          </div>
                          <div className="flex items-center gap-2">
                            <div className="w-6 h-6 rounded border border-gray-300" style={{ backgroundColor: selectedTheme.colors.primary }} title="Primary Color"></div>
                            <div className="w-6 h-6 rounded border border-gray-300" style={{ backgroundColor: selectedTheme.colors.secondary }} title="Secondary Color"></div>
                          </div>
                        </div>
                      </div>

                      {/* Scope */}
                      <div>
                        <label className="block text-gray-700 mb-1.5 text-sm">Scope</label>
                        <input
                          type="text"
                          value={selectedTheme.scope}
                          disabled
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-100 text-sm cursor-not-allowed"
                          placeholder="e.g., Engineering Dept, Urgent Messages"
                        />
                      </div>

                      {/* Color Configuration */}
                      <div>
                        <label className="block text-gray-700 mb-2 text-sm">Color Palette</label>
                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <label className="block text-gray-600 mb-1 text-xs">Primary Color</label>
                            <div className="flex gap-2">
                              <input
                                type="color"
                                value={selectedTheme.colors.primary}
                                onChange={(e) => {
                                  setSelectedTheme({ 
                                    ...selectedTheme, 
                                    colors: { ...selectedTheme.colors, primary: e.target.value }
                                  });
                                }}
                                className="w-10 h-9 rounded border border-gray-300 cursor-pointer"
                              />
                              <input
                                type="text"
                                value={selectedTheme.colors.primary}
                                onChange={(e) => {
                                  setSelectedTheme({ 
                                    ...selectedTheme, 
                                    colors: { ...selectedTheme.colors, primary: e.target.value }
                                  });
                                }}
                                className="flex-1 px-2 py-1.5 border border-gray-300 rounded text-xs"
                              />
                            </div>
                          </div>
                          <div>
                            <label className="block text-gray-600 mb-1 text-xs">Secondary Color</label>
                            <div className="flex gap-2">
                              <input
                                type="color"
                                value={selectedTheme.colors.secondary}
                                onChange={(e) => {
                                  setSelectedTheme({ 
                                    ...selectedTheme, 
                                    colors: { ...selectedTheme.colors, secondary: e.target.value }
                                  });
                                }}
                                className="w-10 h-9 rounded border border-gray-300 cursor-pointer"
                              />
                              <input
                                type="text"
                                value={selectedTheme.colors.secondary}
                                onChange={(e) => {
                                  setSelectedTheme({ 
                                    ...selectedTheme, 
                                    colors: { ...selectedTheme.colors, secondary: e.target.value }
                                  });
                                }}
                                className="flex-1 px-2 py-1.5 border border-gray-300 rounded text-xs"
                              />
                            </div>
                          </div>
                          <div>
                            <label className="block text-gray-600 mb-1 text-xs">Background Color</label>
                            <div className="flex gap-2">
                              <input
                                type="color"
                                value={selectedTheme.colors.background}
                                onChange={(e) => {
                                  setSelectedTheme({ 
                                    ...selectedTheme, 
                                    colors: { ...selectedTheme.colors, background: e.target.value }
                                  });
                                }}
                                className="w-10 h-9 rounded border border-gray-300 cursor-pointer"
                              />
                              <input
                                type="text"
                                value={selectedTheme.colors.background}
                                onChange={(e) => {
                                  setSelectedTheme({ 
                                    ...selectedTheme, 
                                    colors: { ...selectedTheme.colors, background: e.target.value }
                                  });
                                }}
                                className="flex-1 px-2 py-1.5 border border-gray-300 rounded text-xs"
                              />
                            </div>
                          </div>
                          <div>
                            <label className="block text-gray-600 mb-1 text-xs">Text Color</label>
                            <div className="flex gap-2">
                              <input
                                type="color"
                                value={selectedTheme.colors.text}
                                onChange={(e) => {
                                  setSelectedTheme({ 
                                    ...selectedTheme, 
                                    colors: { ...selectedTheme.colors, text: e.target.value }
                                  });
                                }}
                                className="w-10 h-9 rounded border border-gray-300 cursor-pointer"
                              />
                              <input
                                type="text"
                                value={selectedTheme.colors.text}
                                onChange={(e) => {
                                  setSelectedTheme({ 
                                    ...selectedTheme, 
                                    colors: { ...selectedTheme.colors, text: e.target.value }
                                  });
                                }}
                                className="flex-1 px-2 py-1.5 border border-gray-300 rounded text-xs"
                              />
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Logo Management */}
                      <CustomLogoUploadSection
                        customLogo={selectedTheme.logos?.[0] || defaultBrandingLogo}
                        onLogoChange={(logo) => {
                          if (logo) {
                            setSelectedTheme({
                              ...selectedTheme,
                              logos: [logo]
                            });
                          } else {
                            setSelectedTheme({
                              ...selectedTheme,
                              logos: []
                            });
                          }
                        }}
                        label="Theme Logo"
                        description="Upload a logo for this branding theme. This will be available for messages using this theme."
                      />

                      {/* Save Changes */}
                      <div className="flex items-center justify-between pt-2">
                        <div className="flex items-center gap-2">
                          {hasChanges && (
                            <button 
                              className="px-3 py-1.5 rounded-lg text-sm transition-colors border border-gray-300 text-gray-700 hover:bg-gray-50"
                              onClick={handleRevertToDefaults}
                            >
                              Revert to Defaults
                            </button>
                          )}
                          <button 
                            className={`px-3 py-1.5 rounded-lg text-sm transition-colors ${
                              hasChanges 
                                ? 'bg-purple-900 text-white hover:bg-purple-950' 
                                : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                            }`}
                            onClick={handleSaveChanges}
                            disabled={!hasChanges}
                          >
                            Save Changes
                          </button>
                        </div>
                        {savedSuccessfully && (
                          <span className="text-green-600 text-sm flex items-center gap-1">
                            <Check className="w-4 h-4" />
                            Saved successfully
                          </span>
                        )}
                      </div>
                </div>

                {/* Right Column - Live Preview (Sticky) */}
                <div className="lg:sticky lg:top-8 self-start">
                  <label className="block text-gray-700 mb-3 text-sm font-medium">Live Preview</label>
                  <div className="bg-gray-100 rounded-lg p-6 flex items-center justify-center min-h-[400px]">
                    <div
                      className="max-w-sm w-full bg-white rounded-lg shadow-xl border-t-4"
                      style={{ borderColor: selectedTheme.colors.primary }}
                    >
                      {/* Logo Preview - Always show default or custom logo */}
                      {(() => {
                        const logoToDisplay = selectedTheme.logos?.[0] || defaultBrandingLogo;
                        return logoToDisplay?.preview ? (
                          <div className="p-4 border-b border-gray-100 flex items-center justify-center">
                            {logoToDisplay.type === 'svg' ? (
                              <div 
                                dangerouslySetInnerHTML={{ __html: logoToDisplay.preview }} 
                                className="max-h-12"
                                style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}
                              />
                            ) : (
                              <img 
                                src={logoToDisplay.preview} 
                                alt="Theme logo" 
                                className="max-h-12 object-contain"
                              />
                            )}
                          </div>
                        ) : null;
                      })()}
                      
                      <div className="p-4">
                        <h3 className="text-lg font-medium" style={{ color: selectedTheme.colors.primary }}>
                          Sample Message Title
                        </h3>
                        <p style={{ color: selectedTheme.colors.text }} className="mt-2 text-sm">
                          This is how your message will appear to end users with the selected branding theme.
                          Custom colors and styling will be applied automatically.
                        </p>
                      </div>
                      <div
                        className="border-t px-4 py-3"
                        style={{ backgroundColor: selectedTheme.colors.background }}
                      >
                        <button
                          className="w-full py-2 rounded-lg text-white transition-colors text-sm font-medium hover:opacity-90"
                          style={{ backgroundColor: selectedTheme.colors.primary }}
                        >
                          Action Button
                        </button>
                      </div>
                    </div>
                  </div>
                  
                  {/* Preview Info */}
                  <div className="mt-3 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                    <p className="text-xs text-blue-800">
                      <strong>Tip:</strong> The preview updates in real-time as you adjust colors and logos. This is how messages will appear to your end users.
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Create Theme Dialog */}
      {showCreateDialog && (
        <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-8 w-96">
            <h3 className="text-gray-900 text-lg mb-4">Create New Theme</h3>
            <form onSubmit={(e) => e.preventDefault()}>
              <div className="mb-4">
                <label className="block text-gray-700 text-sm mb-2">Name</label>
                <input
                  type="text"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                  placeholder="e.g., Security Alert Theme"
                />
              </div>
              <div className="mb-4">
                <label className="block text-gray-700 text-sm mb-2">Applies To</label>
                <select
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                >
                  <option value="global">Global</option>
                  <option value="urgency">Urgency</option>
                  <option value="division">Division</option>
                  <option value="message-type">Message Type</option>
                </select>
              </div>
              <div className="mb-4">
                <label className="block text-gray-700 text-sm mb-2">Scope</label>
                <input
                  type="text"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                  placeholder="e.g., Engineering Dept, Urgent Messages"
                />
              </div>
              <div className="mb-4">
                <label className="block text-gray-700 text-sm mb-2">Custom CSS</label>
                <textarea
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg font-mono text-sm resize-none"
                  placeholder="Enter custom CSS rules..."
                />
              </div>
              <div className="mb-4">
                <label className="block text-gray-700 text-sm mb-2">Color Palette</label>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-gray-600 mb-1 text-xs">Primary Color</label>
                    <div className="flex gap-2">
                      <input
                        type="color"
                        className="w-12 h-10 rounded border border-gray-300 cursor-pointer"
                      />
                      <input
                        type="text"
                        className="flex-1 px-3 py-2 border border-gray-300 rounded text-sm"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-gray-600 mb-1 text-xs">Secondary Color</label>
                    <div className="flex gap-2">
                      <input
                        type="color"
                        className="w-12 h-10 rounded border border-gray-300 cursor-pointer"
                      />
                      <input
                        type="text"
                        className="flex-1 px-3 py-2 border border-gray-300 rounded text-sm"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-gray-600 mb-1 text-xs">Background Color</label>
                    <div className="flex gap-2">
                      <input
                        type="color"
                        className="w-12 h-10 rounded border border-gray-300 cursor-pointer"
                      />
                      <input
                        type="text"
                        className="flex-1 px-3 py-2 border border-gray-300 rounded text-sm"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-gray-600 mb-1 text-xs">Text Color</label>
                    <div className="flex gap-2">
                      <input
                        type="color"
                        className="w-12 h-10 rounded border border-gray-300 cursor-pointer"
                      />
                      <input
                        type="text"
                        className="flex-1 px-3 py-2 border border-gray-300 rounded text-sm"
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex justify-end">
                <button
                  className="px-3 py-1.5 bg-gray-500 text-white rounded-lg text-sm hover:bg-gray-600 mr-2"
                  onClick={() => setShowCreateDialog(false)}
                >
                  Cancel
                </button>
                <button
                  className="px-3 py-1.5 bg-purple-900 text-white rounded-lg text-sm hover:bg-purple-950"
                  onClick={() => handleCreateTheme({
                    name: 'New Theme',
                    appliesTo: 'global',
                    scope: 'All Messages',
                    customCSS: '',
                    colors: {
                      primary: '#2563EB',
                      secondary: '#64748B',
                      background: '#FFFFFF',
                      text: '#1E293B'
                    }
                  })}
                >
                  Create
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Theme Dialog */}
      {showEditDialog && editingTheme && (
        <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-8 w-96">
            <h3 className="text-gray-900 text-lg mb-4">Edit Theme</h3>
            <form onSubmit={(e) => e.preventDefault()}>
              <div className="mb-4">
                <label className="block text-gray-700 text-sm mb-2">Name</label>
                <input
                  type="text"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                  placeholder="e.g., Security Alert Theme"
                  value={editingTheme.name}
                  onChange={(e) => setEditingTheme({ ...editingTheme, name: e.target.value })}
                />
              </div>
              <div className="mb-4">
                <label className="block text-gray-700 text-sm mb-2">Applies To</label>
                <select
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                  value={editingTheme.appliesTo}
                  onChange={(e) => setEditingTheme({ ...editingTheme, appliesTo: e.target.value as BrandingTheme['appliesTo'] })}
                >
                  <option value="global">Global</option>
                  <option value="urgency">Urgency</option>
                  <option value="division">Division</option>
                  <option value="message-type">Message Type</option>
                </select>
              </div>
              <div className="mb-4">
                <label className="block text-gray-700 text-sm mb-2">Scope</label>
                <input
                  type="text"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                  placeholder="e.g., Engineering Dept, Urgent Messages"
                  value={editingTheme.scope}
                  onChange={(e) => setEditingTheme({ ...editingTheme, scope: e.target.value })}
                />
              </div>
              <div className="mb-4">
                <label className="block text-gray-700 text-sm mb-2">Custom CSS</label>
                <textarea
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg font-mono text-sm resize-none"
                  placeholder="Enter custom CSS rules..."
                  value={editingTheme.customCSS}
                  onChange={(e) => setEditingTheme({ ...editingTheme, customCSS: e.target.value })}
                />
              </div>
              <div className="mb-4">
                <label className="block text-gray-700 text-sm mb-2">Color Palette</label>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-gray-600 mb-1 text-xs">Primary Color</label>
                    <div className="flex gap-2">
                      <input
                        type="color"
                        value={editingTheme.colors.primary}
                        className="w-12 h-10 rounded border border-gray-300 cursor-pointer"
                        onChange={(e) => setEditingTheme({ ...editingTheme, colors: { ...editingTheme.colors, primary: e.target.value } })}
                      />
                      <input
                        type="text"
                        value={editingTheme.colors.primary}
                        className="flex-1 px-3 py-2 border border-gray-300 rounded text-sm"
                        onChange={(e) => setEditingTheme({ ...editingTheme, colors: { ...editingTheme.colors, primary: e.target.value } })}
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-gray-600 mb-1 text-xs">Secondary Color</label>
                    <div className="flex gap-2">
                      <input
                        type="color"
                        value={editingTheme.colors.secondary}
                        className="w-12 h-10 rounded border border-gray-300 cursor-pointer"
                        onChange={(e) => setEditingTheme({ ...editingTheme, colors: { ...editingTheme.colors, secondary: e.target.value } })}
                      />
                      <input
                        type="text"
                        value={editingTheme.colors.secondary}
                        className="flex-1 px-3 py-2 border border-gray-300 rounded text-sm"
                        onChange={(e) => setEditingTheme({ ...editingTheme, colors: { ...editingTheme.colors, secondary: e.target.value } })}
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-gray-600 mb-1 text-xs">Background Color</label>
                    <div className="flex gap-2">
                      <input
                        type="color"
                        value={editingTheme.colors.background}
                        className="w-12 h-10 rounded border border-gray-300 cursor-pointer"
                        onChange={(e) => setEditingTheme({ ...editingTheme, colors: { ...editingTheme.colors, background: e.target.value } })}
                      />
                      <input
                        type="text"
                        value={editingTheme.colors.background}
                        className="flex-1 px-3 py-2 border border-gray-300 rounded text-sm"
                        onChange={(e) => setEditingTheme({ ...editingTheme, colors: { ...editingTheme.colors, background: e.target.value } })}
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-gray-600 mb-1 text-xs">Text Color</label>
                    <div className="flex gap-2">
                      <input
                        type="color"
                        value={editingTheme.colors.text}
                        className="w-12 h-10 rounded border border-gray-300 cursor-pointer"
                        onChange={(e) => setEditingTheme({ ...editingTheme, colors: { ...editingTheme.colors, text: e.target.value } })}
                      />
                      <input
                        type="text"
                        value={editingTheme.colors.text}
                        className="flex-1 px-3 py-2 border border-gray-300 rounded text-sm"
                        onChange={(e) => setEditingTheme({ ...editingTheme, colors: { ...editingTheme.colors, text: e.target.value } })}
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex justify-end">
                <button
                  className="px-3 py-1.5 bg-gray-500 text-white rounded-lg text-sm hover:bg-gray-600 mr-2"
                  onClick={() => setShowEditDialog(false)}
                >
                  Cancel
                </button>
                <button
                  className="px-3 py-1.5 bg-purple-900 text-white rounded-lg text-sm hover:bg-purple-950"
                  onClick={() => handleUpdateTheme(editingTheme)}
                >
                  Update
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Theme Dialog */}
      {showDeleteDialog && deletingThemeId && (
        <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-8 w-96">
            <h3 className="text-gray-900 text-lg mb-4">Delete Theme</h3>
            <p className="text-gray-600 mb-4">Are you sure you want to delete this theme?</p>
            <div className="flex justify-end">
              <button
                className="px-3 py-1.5 bg-gray-500 text-white rounded-lg text-sm hover:bg-gray-600 mr-2"
                onClick={() => setShowDeleteDialog(false)}
              >
                Cancel
              </button>
              <button
                className="px-3 py-1.5 bg-red-600 text-white rounded-lg text-sm hover:bg-red-700"
                onClick={handleDeleteTheme}
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Save Success Notification */}
      {savedSuccessfully && (
        <div className="fixed bottom-4 right-4 bg-green-500 text-white px-4 py-3 rounded-lg shadow-lg flex items-center gap-2 z-50">
          <Check className="w-5 h-5" />
          <span>Theme saved successfully!</span>
        </div>
      )}

      {/* Logo Configuration SVG Dialog */}
      {logoSvgDialogOpen && logoSvgDialogIndex !== null && (
        <div className="fixed inset-0 bg-white bg-opacity-30 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl mx-4">
            <div className="flex items-center justify-between p-4 border-b border-gray-200">
              <div className="flex items-center gap-2">
                <Code className="w-5 h-5 text-purple-900" />
                <h3 className="text-lg text-gray-900">Paste SVG Code</h3>
              </div>
              <button
                onClick={() => {
                  setLogoSvgDialogOpen(false);
                  setLogoSvgDialogIndex(null);
                  setLogoSvgDialogInput('');
                }}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="p-4 space-y-3">
              <textarea
                value={logoSvgDialogInput}
                onChange={(e) => setLogoSvgDialogInput(e.target.value)}
                rows={12}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg font-mono text-xs resize-none"
                placeholder="Paste your SVG code here... e.g., <svg>...</svg>"
                autoFocus
              />
              
              <div className="flex justify-end gap-2">
                <button
                  onClick={() => {
                    setLogoSvgDialogOpen(false);
                    setLogoSvgDialogIndex(null);
                    setLogoSvgDialogInput('');
                  }}
                  className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg text-sm"
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    if (logoSvgDialogInput) {
                      const updatedLogos = [...logoConfigLogos];
                      updatedLogos[logoSvgDialogIndex] = {
                        ...updatedLogos[logoSvgDialogIndex],
                        preview: logoSvgDialogInput,
                        type: 'svg'
                      };
                      setLogoConfigLogos(updatedLogos);
                      if (updatedLogos[0]) {
                        onLogoChange({ preview: updatedLogos[0].preview, type: updatedLogos[0].type });
                      }
                      setHasLogoChanges(true);
                    }
                    setLogoSvgDialogOpen(false);
                    setLogoSvgDialogIndex(null);
                    setLogoSvgDialogInput('');
                  }}
                  className="px-4 py-2 bg-purple-900 text-white rounded-lg text-sm hover:bg-purple-950"
                >
                  Apply SVG
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}