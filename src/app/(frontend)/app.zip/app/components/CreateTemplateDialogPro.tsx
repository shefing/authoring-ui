import { useState, useRef, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';
import { Label } from './ui/label';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { AlertCircle, FileText, Palette, Globe, Code, Check, MessageSquare, MousePointerClick, Bold, Italic, Underline, List, ListOrdered, Link, Sparkles, X, Eye, Upload, Plus, Trash2, Users } from 'lucide-react';
import { BrandingLogo, defaultBrandingLogo } from './UnifiedCommunicationPlatform';
import { CustomLogoUploadSection } from './CustomLogoUploadSection';

interface CreateTemplateDialogProProps {
  open: boolean;
  onClose: () => void;
  onSubmit?: (templateData: any) => void;
  brandingLogos?: BrandingLogo[];
  brandingLogo?: BrandingLogo | null;
  themes?: Array<{
    id: string;
    name: string;
    profile: 'default' | 'security' | 'it' | 'hr';
    logos?: BrandingLogo[];
  }>;
  dialogTitle?: string;
  editingTemplate?: any; // Template to edit
}

type MessageType = 'survey' | 'confirmation' | 'notification' | 'reminder' | 'self-service';

// Rich Text Formatting Toolbar Component
function FormattingToolbar({ onFormat }: { onFormat: (tag: string, value?: string) => void }) {
  const [showColorPicker, setShowColorPicker] = useState(false);
  
  const brandingColors = [
    { name: 'Primary', value: '#7C3AED', key: 'primary' },
    { name: 'Secondary', value: '#6366F1', key: 'secondary' },
    { name: 'Background', value: '#F3F4F6', key: 'background' },
    { name: 'Text', value: '#1F2937', key: 'text' },
  ];

  const fontSizes = [
    { name: 'Small', value: '12px', key: 'small' },
    { name: 'Normal', value: '14px', key: 'normal' },
    { name: 'Medium', value: '16px', key: 'medium' },
    { name: 'Large', value: '18px', key: 'large' },
    { name: 'X-Large', value: '24px', key: 'xlarge' },
  ];

  const handleColorSelect = (color: string) => {
    onFormat('color', color);
    setShowColorPicker(false);
  };

  return (
    <div className="flex items-center gap-1 p-2 bg-gray-50 border border-gray-200 rounded-t-lg flex-wrap">
      <button
        type="button"
        onClick={() => onFormat('bold')}
        className="p-1.5 hover:bg-gray-200 rounded transition-colors"
        title="Bold"
      >
        <Bold className="w-4 h-4 text-gray-700" />
      </button>
      <button
        type="button"
        onClick={() => onFormat('italic')}
        className="p-1.5 hover:bg-gray-200 rounded transition-colors"
        title="Italic"
      >
        <Italic className="w-4 h-4 text-gray-700" />
      </button>
      <button
        type="button"
        onClick={() => onFormat('underline')}
        className="p-1.5 hover:bg-gray-200 rounded transition-colors"
        title="Underline"
      >
        <Underline className="w-4 h-4 text-gray-700" />
      </button>
      <div className="w-px h-6 bg-gray-300 mx-1" />
      
      {/* Font Size Selector */}
      <select
        onChange={(e) => onFormat('fontSize', e.target.value)}
        className="text-xs px-2 py-1 border border-gray-300 rounded bg-white hover:bg-gray-50 transition-colors cursor-pointer"
        defaultValue=""
      >
        <option value="" disabled>Size</option>
        {fontSizes.map((size) => (
          <option key={size.key} value={size.value}>
            {size.name}
          </option>
        ))}
      </select>

      {/* Color Picker */}
      <div className="relative">
        <button
          type="button"
          onClick={() => setShowColorPicker(!showColorPicker)}
          className="text-xs px-2 py-1 border border-gray-300 rounded bg-white hover:bg-gray-50 transition-colors cursor-pointer flex items-center gap-1"
        >
          <Palette className="w-3 h-3" />
          Color
        </button>
        
        {showColorPicker && (
          <div className="absolute top-full left-0 mt-1 bg-white border border-gray-300 rounded shadow-lg z-50 min-w-[140px]">
            {brandingColors.map((color) => (
              <button
                key={color.key}
                type="button"
                onClick={() => handleColorSelect(color.value)}
                className="w-full px-3 py-2 hover:bg-gray-100 transition-colors flex items-center gap-2 text-xs"
              >
                <div 
                  className="w-4 h-4 rounded border border-gray-300"
                  style={{ backgroundColor: color.value }}
                />
                <span>{color.name}</span>
              </button>
            ))}
          </div>
        )}
      </div>

      <div className="w-px h-6 bg-gray-300 mx-1" />
      <button
        type="button"
        onClick={() => onFormat('ul')}
        className="p-1.5 hover:bg-gray-200 rounded transition-colors"
        title="Bullet List"
      >
        <List className="w-4 h-4 text-gray-700" />
      </button>
      <button
        type="button"
        onClick={() => onFormat('ol')}
        className="p-1.5 hover:bg-gray-200 rounded transition-colors"
        title="Numbered List"
      >
        <ListOrdered className="w-4 h-4 text-gray-700" />
      </button>
      <div className="w-px h-6 bg-gray-300 mx-1" />
      <button
        type="button"
        onClick={() => onFormat('link')}
        className="p-1.5 hover:bg-gray-200 rounded transition-colors"
        title="Insert Link"
      >
        <Link className="w-4 h-4 text-gray-700" />
      </button>
      <div className="ml-auto text-xs text-gray-500">
        Select text to format
      </div>
    </div>
  );
}

export function CreateTemplateDialogPro({ open, onClose, onSubmit, brandingLogos, brandingLogo, themes, dialogTitle, editingTemplate }: CreateTemplateDialogProProps) {
  const [currentStep, setCurrentStep] = useState(1);
  const [contentTab, setContentTab] = useState<'title' | 'description' | 'body'>('title');
  
  // Custom Logo Upload State - Initialize with default logo if available
  const [customLogo, setCustomLogo] = useState<BrandingLogo | null>(
    brandingLogo?.isDefault ? brandingLogo : null
  );
  
  // Load saved branding theme from localStorage on mount
  useEffect(() => {
    const savedThemeStr = localStorage.getItem('brandingTheme');
    if (savedThemeStr) {
      try {
        const savedTheme = JSON.parse(savedThemeStr);
        if (savedTheme.logos && savedTheme.logos.length > 0) {
          setCustomLogo(savedTheme.logos[0]);
        }
      } catch (error) {
        console.error('Error loading saved branding theme:', error);
      }
    }
  }, []);
  
  // Refs for rich text editing
  const titleInputRef = useRef<HTMLInputElement>(null);
  const descriptionInputRef = useRef<HTMLInputElement>(null);
  const bodyTextareaRef = useRef<HTMLTextAreaElement>(null);
  
  // Auto-select first logo when component mounts or brandingLogos changes
  const defaultLogoId = brandingLogos && brandingLogos.length > 0 ? (brandingLogos[0].id || brandingLogos[0].preview) : '';
  
  const [formData, setFormData] = useState({
    name: editingTemplate?.name || '',
    description: editingTemplate?.description || '',
    category: editingTemplate?.category || 'General',
    type: (editingTemplate?.type as MessageType) || 'notification' as MessageType,
    priority: editingTemplate?.priority || 'Medium',
    channels: editingTemplate?.channels || [] as string[],
    supportsDynamic: editingTemplate?.supportsDynamic || false,
    selectedTemplate: '', // Add template selection field
    
    // Content
    title: editingTemplate?.title || '',
    body: editingTemplate?.body || '',
    messageDescription: editingTemplate?.messageDescription || '',
    buttonPrimary: editingTemplate?.buttonPrimary || '',
    buttonSecondary: editingTemplate?.buttonSecondary || '',
    
    // Element Visibility
    showHeader: editingTemplate?.showHeader !== undefined ? editingTemplate.showHeader : true,
    showDescription: editingTemplate?.showDescription !== undefined ? editingTemplate.showDescription : true,
    showBody: editingTemplate?.showBody !== undefined ? editingTemplate.showBody : true,
    showButton1: editingTemplate?.showButton1 !== undefined ? editingTemplate.showButton1 : true,
    showButton2: editingTemplate?.showButton2 !== undefined ? editingTemplate.showButton2 : false,
    
    // Button Configuration
    buttonCount: editingTemplate?.showButton2 ? 2 : 1,
    button1Type: (editingTemplate?.button1Type as 'primary' | 'secondary' | 'tertiary') || 'primary' as 'primary' | 'secondary' | 'tertiary',
    button2Type: (editingTemplate?.button2Type as 'primary' | 'secondary' | 'tertiary') || 'secondary' as 'primary' | 'secondary' | 'tertiary',
    buttonAlignment: (editingTemplate?.buttonAlignment as 'left' | 'center' | 'right') || 'left' as 'left' | 'center' | 'right',
    
    // Logo Settings
    showLogo: editingTemplate?.showLogo || false,
    logoPosition: (editingTemplate?.logoPosition as 'top-left' | 'top-center' | 'top-right' | 'center-left' | 'center-right' | 'bottom-left' | 'bottom-center' | 'bottom-right') || 'top-left' as 'top-left' | 'top-center' | 'top-right' | 'center-left' | 'center-right' | 'bottom-left' | 'bottom-center' | 'bottom-right',
    selectedLogoId: defaultLogoId, // Track which logo is selected
    
    // Styling
    brandingProfile: (editingTemplate?.brandingProfile as 'default' | 'security' | 'it' | 'hr' | 'custom') || 'default' as 'default' | 'security' | 'it' | 'hr' | 'custom',
    customCSS: editingTemplate?.customCSS || '',
    
    // Dynamic Parameters
    dynamicParams: [] as string[],
    
    // Target Audience - Step 4
    targetGroups: [] as string[],
    vipHandling: false,
    fatiguePrevention: true,
  });

  const totalSteps = 3;

  const handleChange = (field: string, value: any) => {
    setFormData(prev => {
      const updated = { ...prev, [field]: value };
      
      // When brandingProfile changes, reset selectedLogoId to first logo of new theme
      if (field === 'brandingProfile') {
        const newThemeLogos = getLogosForTheme(value);
        if (newThemeLogos && newThemeLogos.length > 0) {
          updated.selectedLogoId = newThemeLogos[0].id || newThemeLogos[0].preview;
        } else {
          // Fallback to default branding logos
          const fallbackLogos = brandingLogos || [];
          updated.selectedLogoId = fallbackLogos.length > 0 ? (fallbackLogos[0].id || fallbackLogos[0].preview) : '';
        }
      }
      
      return updated;
    });
  };

  // Get logos for the current branding profile theme
  const getLogosForTheme = (profile: string): BrandingLogo[] => {
    if (!themes || themes.length === 0) {
      return brandingLogos || [];
    }
    
    const theme = themes.find(t => t.profile === profile);
    if (theme && theme.logos && theme.logos.length > 0) {
      return theme.logos;
    }
    
    // Fallback to default branding logos
    return brandingLogos || [];
  };

  // Get current theme's logos for display
  const currentThemeLogos = getLogosForTheme(formData.brandingProfile);

  const handleChannelToggle = (channel: string) => {
    setFormData(prev => ({
      ...prev,
      channels: prev.channels.includes(channel)
        ? prev.channels.filter(c => c !== channel)
        : [...prev.channels, channel]
    }));
  };

  // Helper to wrap selected text with formatting tags
  const applyFormatting = (field: string, tag: string, textareaRef?: HTMLTextAreaElement | HTMLInputElement | null, value?: string) => {
    if (!textareaRef) return;
    
    const start = textareaRef.selectionStart || 0;
    const end = textareaRef.selectionEnd || 0;
    const text = formData[field as keyof typeof formData] as string || '';
    const selectedText = text.substring(start, end);
    
    let newText = '';
    let newCursorPos = start;
    
    if (tag === 'bold') {
      newText = text.substring(0, start) + '<strong>' + selectedText + '</strong>' + text.substring(end);
      newCursorPos = start + 8;
    } else if (tag === 'italic') {
      newText = text.substring(0, start) + '<em>' + selectedText + '</em>' + text.substring(end);
      newCursorPos = start + 4;
    } else if (tag === 'underline') {
      newText = text.substring(0, start) + '<u>' + selectedText + '</u>' + text.substring(end);
      newCursorPos = start + 3;
    } else if (tag === 'color' && value) {
      if (selectedText) {
        newText = text.substring(0, start) + '<span style="color: ' + value + '">' + selectedText + '</span>' + text.substring(end);
        newCursorPos = start + 22 + value.length;
      } else {
        return;
      }
    } else if (tag === 'fontSize' && value) {
      if (selectedText) {
        newText = text.substring(0, start) + '<span style="font-size: ' + value + '">' + selectedText + '</span>' + text.substring(end);
        newCursorPos = start + 27 + value.length;
      } else {
        return;
      }
    } else if (tag === 'link') {
      const url = prompt('Enter URL:');
      if (url) {
        newText = text.substring(0, start) + '<a href="' + url + '">' + (selectedText || 'Link') + '</a>' + text.substring(end);
        newCursorPos = start + 9 + url.length;
      } else {
        return;
      }
    } else if (tag === 'ul') {
      newText = text.substring(0, start) + '<ul>\n  <li>' + (selectedText || 'List item') + '</li>\n</ul>' + text.substring(end);
      newCursorPos = start + 10;
    } else if (tag === 'ol') {
      newText = text.substring(0, start) + '<ol>\n  <li>' + (selectedText || 'List item') + '</li>\n</ol>' + text.substring(end);
      newCursorPos = start + 10;
    }
    
    handleChange(field, newText);
    
    setTimeout(() => {
      if (textareaRef) {
        textareaRef.focus();
        textareaRef.setSelectionRange(newCursorPos, newCursorPos);
      }
    }, 0);
  };

  const handleNext = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSubmit = () => {
    onSubmit?.(formData);
    handleClose();
  };

  const handleClose = () => {
    setFormData({
      name: '',
      description: '',
      category: 'General',
      type: 'notification',
      priority: 'Medium',
      channels: [],
      supportsDynamic: false,
      selectedTemplate: '', // Reset template selection field
      title: '',
      body: '',
      messageDescription: '',
      buttonPrimary: '',
      buttonSecondary: '',
      showHeader: true,
      showDescription: true,
      showBody: true,
      showButton1: true,
      showButton2: false,
      buttonCount: 1,
      button1Type: 'primary',
      button2Type: 'secondary',
      buttonAlignment: 'left',
      showLogo: false,
      logoPosition: 'top-left',
      brandingProfile: 'default',
      customCSS: '',
      dynamicParams: [],
      targetGroups: [],
      vipHandling: false,
      fatiguePrevention: true,
    });
    setCurrentStep(1);
    onClose();
  };

  const isStepValid = () => {
    switch (currentStep) {
      case 1:
        return formData.name.trim() !== '';
      case 2:
        return formData.title.trim() !== '' || formData.body.trim() !== '';
      case 3:
        return formData.channels.length > 0;
      default:
        return false;
    }
  };

  // Live Preview Component
  const LivePreview = () => {
    const getButtonStyles = (type: 'primary' | 'secondary' | 'tertiary') => {
      if (type === 'primary') {
        if (formData.brandingProfile === 'security') return 'bg-red-600 text-white hover:bg-red-700';
        if (formData.brandingProfile === 'it') return 'bg-blue-600 text-white hover:bg-blue-700';
        if (formData.brandingProfile === 'hr') return 'bg-green-600 text-white hover:bg-green-700';
        return 'bg-purple-900 text-white hover:bg-purple-950';
      }
      if (type === 'secondary') return 'border border-gray-300 text-gray-700 hover:bg-gray-50';
      return 'text-gray-600 hover:bg-gray-50';
    };

    // Get the selected logo or the first logo
    const getSelectedLogo = () => {
      // Prioritize custom logo if available
      if (customLogo && customLogo.preview) {
        return customLogo;
      }
      
      // If no custom logo, use default Riverbed logo
      if (!customLogo) {
        return defaultBrandingLogo;
      }
      
      if (!currentThemeLogos || currentThemeLogos.length === 0) return defaultBrandingLogo;
      if (formData.selectedLogoId) {
        return currentThemeLogos.find(l => (l.id || l.preview) === formData.selectedLogoId) || currentThemeLogos[0];
      }
      return currentThemeLogos[0];
    };

    const selectedLogo = getSelectedLogo();

    const renderLogo = () => {
      if (selectedLogo) {
        return selectedLogo.type === 'svg' ? (
          <div dangerouslySetInnerHTML={{ __html: selectedLogo.preview }} className="max-h-10 w-auto" style={{ maxHeight: '40px', display: 'flex', alignItems: 'center', justifyContent: 'center' }} />
        ) : (
          <img src={selectedLogo.preview} alt="Branding logo" className="max-h-10 w-auto object-contain" style={{ maxHeight: '40px' }} />
        );
      }
      return (
        <div className="w-24 h-10 bg-purple-100 border-2 border-purple-300 rounded flex items-center justify-center">
          <span className="text-xs text-purple-700">Logo</span>
        </div>
      );
    };

    return (
      <div className="bg-gray-100 rounded-lg p-6 flex items-center justify-center">
        <div className="max-w-md w-full bg-white rounded-lg shadow-lg border border-gray-300 border-t-4 border-t-purple-900">
          <div className="p-6 space-y-4">
            {/* Top Logo Positions */}
            {formData.showLogo && (formData.logoPosition === 'top-left' || formData.logoPosition === 'top-center' || formData.logoPosition === 'top-right') && (
              <div className={`flex mb-3 ${
                formData.logoPosition === 'top-center' ? 'justify-center' :
                formData.logoPosition === 'top-right' ? 'justify-end' :
                'justify-start'
              }`}>
                {renderLogo()}
              </div>
            )}

            {/* Center Logo Positions - Side-by-side layout */}
            {formData.showLogo && (formData.logoPosition === 'center-left' || formData.logoPosition === 'center-right') ? (
              <div className={`flex gap-4 items-start ${
                formData.logoPosition === 'center-left' ? '' : 'flex-row-reverse'
              }`}>
                {/* Logo on left or right */}
                <div className="flex-shrink-0">
                  {renderLogo()}
                </div>

                {/* Content area */}
                <div className="flex-1 space-y-4">
                  {formData.showHeader && (
                    <h3 
                      className="text-gray-900"
                      dangerouslySetInnerHTML={{ __html: formData.title || 'Sample Message Title' }}
                    />
                  )}
                  
                  {formData.showDescription && formData.messageDescription && (
                    <p 
                      className="text-gray-600 text-sm italic"
                      dangerouslySetInnerHTML={{ __html: formData.messageDescription }}
                    />
                  )}
                  
                  {formData.showBody && (
                    <p 
                      className="text-gray-700 text-sm"
                      dangerouslySetInnerHTML={{ 
                        __html: formData.body || 'This is the main message content area. Start typing to see your changes in real-time.' 
                      }}
                    />
                  )}
                </div>
              </div>
            ) : (
              /* Non-center logo positions - normal stacked layout */
              <>
                {formData.showHeader && (
                  <h3 
                    className="text-gray-900"
                    dangerouslySetInnerHTML={{ __html: formData.title || 'Sample Message Title' }}
                  />
                )}
                
                {formData.showDescription && formData.messageDescription && (
                  <p 
                    className="text-gray-600 text-sm italic"
                    dangerouslySetInnerHTML={{ __html: formData.messageDescription }}
                  />
                )}
                
                {formData.showBody && (
                  <p 
                    className="text-gray-700 text-sm"
                    dangerouslySetInnerHTML={{ 
                      __html: formData.body || 'This is the main message content area. Start typing to see your changes in real-time.' 
                    }}
                  />
                )}
              </>
            )}

            {/* Bottom Logo Positions */}
            {formData.showLogo && (formData.logoPosition === 'bottom-left' || formData.logoPosition === 'bottom-center' || formData.logoPosition === 'bottom-right') && (
              <div className={`flex mt-3 ${
                formData.logoPosition === 'bottom-center' ? 'justify-center' :
                formData.logoPosition === 'bottom-right' ? 'justify-end' :
                'justify-start'
              }`}>
                {renderLogo()}
              </div>
            )}
            
            {(formData.showButton1 || formData.showButton2) && (
              <div className={`flex gap-2 pt-2 border-t border-gray-200 ${
                formData.buttonAlignment === 'center' ? 'justify-center' :
                formData.buttonAlignment === 'right' ? 'justify-end' :
                ''
              }`}>
                {formData.showButton1 && (
                  <button className={`px-4 py-2 rounded-lg text-sm transition-colors ${getButtonStyles(formData.button1Type)}`}>
                    {formData.buttonPrimary || 'Primary Action'}
                  </button>
                )}
                {formData.showButton2 && (
                  <button className={`px-4 py-2 rounded-lg text-sm transition-colors ${getButtonStyles(formData.button2Type)}`}>
                    {formData.buttonSecondary || 'Secondary Action'}
                  </button>
                )}
              </div>
            )}

            {!formData.showHeader && !formData.showDescription && !formData.showBody && 
             !formData.showButton1 && !formData.showButton2 && !formData.showLogo && (
              <div className="text-center py-8 text-gray-400">
                <p className="text-sm">Configure your template to see preview</p>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-[80vw] w-[80vw] max-h-[90vh] overflow-hidden p-8 top-[5%] -translate-y-0">
        <DialogHeader>
          <div className="flex items-center gap-2">
            <DialogTitle>{dialogTitle || 'Create New Template'}</DialogTitle>
            <span className="inline-flex items-center px-2 py-0.5 bg-gradient-to-r from-purple-600 to-purple-700 text-white rounded-full text-xs">
              M.S - 2
            </span>
          </div>
          <DialogDescription>
            Streamlined Message creation with live preview
          </DialogDescription>
        </DialogHeader>

        {/* Progress Steps */}
        <div className="flex items-center justify-between mb-6">
          {[1, 2, 3].map((step) => (
            <div key={step} className="flex items-center flex-1">
              <div className="flex flex-col items-center">
                <div className={`flex items-center justify-center w-8 h-8 rounded-full border-2 transition-colors ${
                  step === currentStep 
                    ? 'border-purple-900 bg-purple-900 text-white' 
                    : step < currentStep 
                    ? 'border-purple-900 bg-purple-900 text-white' 
                    : 'border-gray-300 bg-white text-gray-400'
                }`}>
                  {step < currentStep ? (
                    <Check className="w-4 h-4" />
                  ) : (
                    <span className="text-sm">{step}</span>
                  )}
                </div>
                <span className={`text-xs mt-1 whitespace-nowrap ${
                  step === currentStep 
                    ? 'text-purple-900 font-medium' 
                    : step < currentStep 
                    ? 'text-purple-900' 
                    : 'text-gray-400'
                }`}>
                  {step === 1 ? 'Admin Data' : step === 2 ? 'Message Content' : 'Branding'}
                </span>
              </div>
              {step < 3 && (
                <div className={`h-0.5 flex-1 mx-2 ${
                  step < currentStep ? 'bg-purple-900' : 'bg-gray-300'
                }`} />
              )}
            </div>
          ))}
        </div>

        {/* Two Column Layout */}
        <div className="flex gap-6 h-[calc(95vh-280px)] min-h-[600px] border-t border-gray-300 pt-6">
          {/* Left Column - Form */}
          <div className="flex-1 overflow-y-auto pr-4">
            {/* Step 1: Basic Information */}
            {currentStep === 1 && (
              <div className="space-y-4 pl-1">
                <div className="flex items-center gap-2 text-gray-900 mb-4">
                  <FileText className="w-5 h-5 text-purple-700" />
                  <h3>Basic Information</h3>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="name">Template Name *</Label>
                  <Input
                    id="name"
                    placeholder="e.g., Security Alert - Engineering Division"
                    value={formData.name}
                    onChange={(e) => handleChange('name', e.target.value)}
                    className="border border-gray-300"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Description *</Label>
                  <Textarea
                    id="description"
                    placeholder="Brief description of when and how this template should be used..."
                    value={formData.description}
                    onChange={(e) => handleChange('description', e.target.value)}
                    rows={3}
                    className="border border-gray-300"
                    required
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="category">Category</Label>
                    <select
                      id="category"
                      value={formData.category}
                      onChange={(e) => handleChange('category', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent bg-white"
                    >
                      <option value="General">General</option>
                      <option value="Security">Security</option>
                      <option value="IT Operations">IT Operations</option>
                      <option value="HR">HR</option>
                      <option value="Marketing">Marketing</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="priority">Priority</Label>
                    <select
                      id="priority"
                      value={formData.priority}
                      onChange={(e) => handleChange('priority', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent bg-white"
                    >
                      <option value="Low">Low</option>
                      <option value="Medium">Medium</option>
                      <option value="High">High</option>
                      <option value="Urgent">Urgent</option>
                    </select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="type">Message Type *</Label>
                  <select
                    id="type"
                    value={formData.type}
                    onChange={(e) => handleChange('type', e.target.value as MessageType)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent bg-gray-100 cursor-not-allowed"
                    disabled
                  >
                    <option value="notification">Notification</option>
                  </select>
                  <p className="text-xs text-gray-500">Only Notification templates are supported in this version</p>
                </div>
              </div>
            )}

            {/* Step 2: Content & Actions */}
            {currentStep === 2 && (
              <div className="space-y-4">
                <div className="flex items-center gap-2 text-gray-900 mb-4">
                  <MessageSquare className="w-5 h-5 text-purple-700" />
                  <h3>Content & Actions</h3>
                </div>

                {/* Message Content with Tabs */}
                <div className="border border-purple-200 rounded-lg p-4 space-y-4 bg-purple-50">
                  <Label>Message Content</Label>
                  
                  <div className="space-y-2">
                    <div className="flex border-b border-purple-300">
                      <button
                        type="button"
                        onClick={() => setContentTab('title')}
                        className={`px-4 py-2 text-sm transition-colors ${
                          contentTab === 'title'
                            ? 'border-b-2 border-purple-900 text-purple-900'
                            : 'text-gray-600 hover:text-gray-900'
                        }`}
                      >
                        Title
                      </button>
                      <button
                        type="button"
                        onClick={() => setContentTab('description')}
                        className={`px-4 py-2 text-sm transition-colors ${
                          contentTab === 'description'
                            ? 'border-b-2 border-purple-900 text-purple-900'
                            : 'text-gray-600 hover:text-gray-900'
                        }`}
                      >
                        Description
                      </button>
                      <button
                        type="button"
                        onClick={() => setContentTab('body')}
                        className={`px-4 py-2 text-sm transition-colors ${
                          contentTab === 'body'
                            ? 'border-b-2 border-purple-900 text-purple-900'
                            : 'text-gray-600 hover:text-gray-900'
                        }`}
                      >
                        Body
                      </button>
                    </div>

                    {/* Title Tab */}
                    {contentTab === 'title' && (
                      <div className="space-y-2">
                        <div className="flex items-center gap-2 mb-2">
                          <input
                            type="checkbox"
                            id="enableTitle"
                            checked={formData.showHeader}
                            onChange={(e) => handleChange('showHeader', e.target.checked)}
                            className="w-4 h-4 text-purple-600 rounded border-gray-300 focus:ring-purple-500"
                          />
                          <Label htmlFor="enableTitle" className="cursor-pointer">
                            Enable Title
                          </Label>
                        </div>
                        {formData.showHeader && (
                          <div>
                            <FormattingToolbar onFormat={(tag, value) => applyFormatting('title', tag, titleInputRef.current, value)} />
                            <Input
                              ref={titleInputRef}
                              placeholder="e.g., Security Alert, Update Complete"
                              value={formData.title}
                              onChange={(e) => handleChange('title', e.target.value)}
                              className="rounded-t-none border-t-0 h-16"
                            />
                          </div>
                        )}
                      </div>
                    )}

                    {/* Description Tab */}
                    {contentTab === 'description' && (
                      <div className="space-y-2">
                        <div className="flex items-center gap-2 mb-2">
                          <input
                            type="checkbox"
                            id="enableDescription"
                            checked={formData.showDescription}
                            onChange={(e) => handleChange('showDescription', e.target.checked)}
                            className="w-4 h-4 text-purple-600 rounded border-gray-300 focus:ring-purple-500"
                          />
                          <Label htmlFor="enableDescription" className="cursor-pointer">
                            Enable Description
                          </Label>
                        </div>
                        {formData.showDescription && (
                          <div>
                            <FormattingToolbar onFormat={(tag, value) => applyFormatting('messageDescription', tag, descriptionInputRef.current, value)} />
                            <Input
                              ref={descriptionInputRef}
                              placeholder="e.g., Brief summary or subtitle"
                              value={formData.messageDescription || ''}
                              onChange={(e) => handleChange('messageDescription', e.target.value)}
                              className="rounded-t-none border-t-0 h-16"
                            />
                          </div>
                        )}
                      </div>
                    )}

                    {/* Body Tab */}
                    {contentTab === 'body' && (
                      <div className="space-y-2">
                        <div className="flex items-center gap-2 mb-2">
                          <input
                            type="checkbox"
                            id="enableBody"
                            checked={formData.showBody}
                            onChange={(e) => handleChange('showBody', e.target.checked)}
                            className="w-4 h-4 text-purple-600 rounded border-gray-300 focus:ring-purple-500"
                          />
                          <Label htmlFor="enableBody" className="cursor-pointer">
                            Enable Body
                          </Label>
                        </div>
                        {formData.showBody && (
                          <div>
                            <FormattingToolbar onFormat={(tag, value) => applyFormatting('body', tag, bodyTextareaRef.current, value)} />
                            <Textarea
                              ref={bodyTextareaRef}
                              placeholder="e.g., Your system update has been completed successfully..."
                              value={formData.body}
                              onChange={(e) => handleChange('body', e.target.value)}
                              rows={3}
                              className="rounded-t-none border-t-0"
                            />
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>

                {/* Button Configuration */}
                <div className="border border-purple-200 rounded-lg p-4 space-y-3 bg-purple-50">
                  <Label>Action Buttons</Label>
                  
                  <div className="flex gap-2">
                    {[0, 1, 2].map((count) => (
                      <button
                        key={count}
                        type="button"
                        onClick={() => {
                          handleChange('buttonCount', count);
                          handleChange('showButton1', count >= 1);
                          handleChange('showButton2', count >= 2);
                        }}
                        className={`flex-1 px-3 py-2 text-sm rounded border-2 transition-all ${
                          formData.buttonCount === count
                            ? 'border-purple-600 bg-purple-100 text-purple-900'
                            : 'border-gray-300 bg-white text-gray-700 hover:border-gray-400'
                        }`}
                      >
                        {count === 0 ? 'None' : count}
                      </button>
                    ))}
                  </div>

                  {formData.buttonCount >= 1 && (
                    <>
                      {/* Button Alignment */}
                      <div className="pt-2 border-t border-purple-200">
                        <Label className="text-xs mb-2">Button Alignment</Label>
                        <div className="flex gap-1 mt-1">
                          <button
                            type="button"
                            onClick={() => handleChange('buttonAlignment', 'left')}
                            className={`flex-1 px-2 py-1 text-xs rounded transition-all ${
                              formData.buttonAlignment === 'left'
                                ? 'bg-purple-900 text-white'
                                : 'bg-white border border-gray-300 text-gray-700 hover:border-gray-400'
                            }`}
                          >
                            Left
                          </button>
                          <button
                            type="button"
                            onClick={() => handleChange('buttonAlignment', 'center')}
                            className={`flex-1 px-2 py-1 text-xs rounded transition-all ${
                              formData.buttonAlignment === 'center'
                                ? 'bg-purple-900 text-white'
                                : 'bg-white border border-gray-300 text-gray-700 hover:border-gray-400'
                            }`}
                          >
                            Center
                          </button>
                          <button
                            type="button"
                            onClick={() => handleChange('buttonAlignment', 'right')}
                            className={`flex-1 px-2 py-1 text-xs rounded transition-all ${
                              formData.buttonAlignment === 'right'
                                ? 'bg-purple-900 text-white'
                                : 'bg-white border border-gray-300 text-gray-700 hover:border-gray-400'
                            }`}
                          >
                            Right
                          </button>
                        </div>
                      </div>

                      <div className="space-y-2 pt-2 border-t border-purple-200">
                        <Label className="text-xs">Button 1</Label>
                        <Input
                          placeholder="Button 1 text..."
                          value={formData.buttonPrimary}
                          onChange={(e) => handleChange('buttonPrimary', e.target.value)}
                        />
                        <div className="flex gap-1">
                          <button
                            type="button"
                            onClick={() => handleChange('button1Type', 'primary')}
                            className={`flex-1 px-2 py-1 text-xs rounded transition-all ${
                              formData.button1Type === 'primary'
                                ? 'bg-purple-900 text-white'
                                : 'bg-white border border-gray-300 text-gray-700 hover:border-gray-400'
                            }`}
                          >
                            Primary
                          </button>
                          <button
                            type="button"
                            onClick={() => handleChange('button1Type', 'secondary')}
                            className={`flex-1 px-2 py-1 text-xs rounded transition-all ${
                              formData.button1Type === 'secondary'
                                ? 'border-2 border-purple-900 text-purple-900 bg-white'
                                : 'bg-white border border-gray-300 text-gray-700 hover:border-gray-400'
                            }`}
                          >
                            Secondary
                          </button>
                          <button
                            type="button"
                            onClick={() => handleChange('button1Type', 'tertiary')}
                            className={`flex-1 px-2 py-1 text-xs rounded transition-all ${
                              formData.button1Type === 'tertiary'
                                ? 'text-purple-900 underline bg-purple-100'
                                : 'bg-white border border-gray-300 text-gray-700 hover:border-gray-400'
                            }`}
                          >
                            Plain
                          </button>
                        </div>
                      </div>
                    </>
                  )}

                  {formData.buttonCount >= 2 && (
                    <div className="space-y-2">
                      <Label className="text-xs">Button 2</Label>
                      <Input
                        placeholder="Button 2 text..."
                        value={formData.buttonSecondary}
                        onChange={(e) => handleChange('buttonSecondary', e.target.value)}
                      />
                      <div className="flex gap-1">
                        <button
                          type="button"
                          onClick={() => handleChange('button2Type', 'primary')}
                          className={`flex-1 px-2 py-1 text-xs rounded transition-all ${
                            formData.button2Type === 'primary'
                              ? 'bg-purple-900 text-white'
                              : 'bg-white border border-gray-300 text-gray-700 hover:border-gray-400'
                          }`}
                        >
                          Primary
                        </button>
                        <button
                          type="button"
                          onClick={() => handleChange('button2Type', 'secondary')}
                          className={`flex-1 px-2 py-1 text-xs rounded transition-all ${
                            formData.button2Type === 'secondary'
                              ? 'border-2 border-purple-900 text-purple-900 bg-white'
                              : 'bg-white border border-gray-300 text-gray-700 hover:border-gray-400'
                          }`}
                        >
                          Secondary
                        </button>
                        <button
                          type="button"
                          onClick={() => handleChange('button2Type', 'tertiary')}
                          className={`flex-1 px-2 py-1 text-xs rounded transition-all ${
                            formData.button2Type === 'tertiary'
                              ? 'text-purple-900 underline bg-purple-100'
                              : 'bg-white border border-gray-300 text-gray-700 hover:border-gray-400'
                          }`}
                        >
                          Plain
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Step 3: Branding */}
            {currentStep === 3 && (
              <div className="space-y-4">
                <div className="flex items-center gap-2 text-gray-900 mb-4">
                  <Palette className="w-5 h-5 text-purple-700" />
                  <h3>Branding</h3>
                </div>


                {/* Branding Profile */}
                <div className="border border-purple-200 rounded-lg p-4 space-y-3 bg-purple-50">
                  <Label>Branding Profile</Label>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { value: 'default', label: 'Default Purple' },
                      { value: 'security', label: 'Security Red' },
                      { value: 'it', label: 'IT Blue' },
                      { value: 'hr', label: 'HR Green' },
                    ].map((profile) => (
                      <button
                        key={profile.value}
                        type="button"
                        onClick={() => handleChange('brandingProfile', profile.value)}
                        className={`p-2 rounded border-2 transition-all text-left text-sm ${
                          formData.brandingProfile === profile.value
                            ? 'border-purple-600 bg-white'
                            : 'border-gray-200 bg-white hover:border-gray-300'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <div className="grid grid-cols-2 gap-0.5 w-5 h-5 flex-shrink-0">
                            {profile.value === 'default' && (
                              <>
                                <div className="bg-purple-900 rounded-sm"></div>
                                <div className="bg-purple-700 rounded-sm"></div>
                                <div className="bg-purple-500 rounded-sm"></div>
                                <div className="bg-purple-300 rounded-sm"></div>
                              </>
                            )}
                            {profile.value === 'security' && (
                              <>
                                <div className="bg-red-700 rounded-sm"></div>
                                <div className="bg-red-500 rounded-sm"></div>
                                <div className="bg-red-400 rounded-sm"></div>
                                <div className="bg-red-300 rounded-sm"></div>
                              </>
                            )}
                            {profile.value === 'it' && (
                              <>
                                <div className="bg-blue-700 rounded-sm"></div>
                                <div className="bg-blue-500 rounded-sm"></div>
                                <div className="bg-blue-400 rounded-sm"></div>
                                <div className="bg-blue-300 rounded-sm"></div>
                              </>
                            )}
                            {profile.value === 'hr' && (
                              <>
                                <div className="bg-green-700 rounded-sm"></div>
                                <div className="bg-green-500 rounded-sm"></div>
                                <div className="bg-green-400 rounded-sm"></div>
                                <div className="bg-green-300 rounded-sm"></div>
                              </>
                            )}
                          </div>
                          <span className="flex-1">{profile.label}</span>
                          {formData.brandingProfile === profile.value && (
                            <Check className="w-3 h-3 text-purple-600 flex-shrink-0" />
                          )}
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Logo Settings */}
                <div className="border border-purple-200 rounded-lg p-4 space-y-3 bg-purple-50">
                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      id="showLogo"
                      checked={formData.showLogo}
                      onChange={(e) => handleChange('showLogo', e.target.checked)}
                      className="w-4 h-4 text-purple-600 rounded border-gray-300"
                    />
                    <Label htmlFor="showLogo" className="cursor-pointer">
                      Show Branding Logo
                    </Label>
                  </div>

                  {formData.showLogo && (
                    <div className="pl-6 space-y-3">
                      {/* Logo Selection Thumbnails */}
                      {(() => {
                        // Create logo list with default Riverbed logo + user-uploaded logos
                        const defaultRiverbedLogo: BrandingLogo = {
                          id: 'riverbed-default',
                          name: 'Default Logo',
                          preview: '<svg width="175" height="38" viewBox="0 0 175 38" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M169.633 26.6811C169.633 32.016 166.188 33.2963 163.483 33.2963C160.778 33.2963 157.332 32.016 157.332 26.6811C157.332 21.3462 160.778 20.0627 163.483 20.0627C166.188 20.0627 169.633 21.3429 169.633 26.6811ZM174.512 26.6811V0.745464C174.512 0.265775 174.247 0 173.771 0H170.377C169.9 0 169.633 0.265775 169.633 0.745464V17.9819C168.255 16.1668 165.286 15.3663 163.483 15.3663C157.281 15.3663 152.454 19.2621 152.454 26.6779C152.454 33.562 157.278 37.9895 163.483 37.9895C169.688 37.9927 174.512 34.0968 174.512 26.6811ZM136.547 20.0627C134.373 20.0627 131.723 20.9151 130.767 24.0104H142.324C141.371 20.9151 138.72 20.0627 136.547 20.0627ZM146.777 27.5854H130.397C130.822 32.1748 134.003 33.2963 136.547 33.2963C137.98 33.2963 139.622 32.9754 140.842 31.7503C141.213 31.4845 141.638 31.3224 142.063 31.5363L145.19 32.9235C145.56 33.0824 145.721 33.5102 145.454 33.8829C143.493 36.6055 140.363 37.9927 136.547 37.9927C130.345 37.9927 125.521 34.0968 125.521 26.6811C125.521 19.2621 130.345 15.3695 136.547 15.3695C142.749 15.3695 147.576 19.2654 147.576 26.6811V26.8399C147.572 27.2677 147.202 27.5854 146.777 27.5854ZM115.79 26.6811C115.79 31.8572 112.345 33.2963 109.64 33.2963C106.935 33.2963 103.49 32.016 103.49 26.6811C103.49 21.3462 106.935 20.0627 109.64 20.0627C112.345 20.0627 115.79 21.3429 115.79 26.6811ZM120.669 26.6811C120.669 19.2621 115.845 15.3695 109.643 15.3695C107.84 15.3695 104.871 16.1701 103.493 17.9851V0.745464C103.493 0.265775 103.229 0 102.752 0H99.3584C98.8818 0 98.6145 0.265775 98.6145 0.745464V26.6811C98.6145 34.0968 103.438 37.9927 109.643 37.9927C115.845 37.9927 120.669 33.2444 120.669 26.6811ZM93.1275 19.9039C93.0245 20.4127 92.9182 20.6266 92.2807 20.4905C91.3855 20.2993 90.5322 20.2247 89.6821 20.2247C87.3507 20.2247 85.2287 21.0772 85.2287 24.4933V36.6055C85.2287 37.0852 84.9647 37.3542 84.4881 37.3542H81.0942C80.6176 37.3542 80.3503 37.0884 80.3503 36.6055V24.4933C80.3503 17.8749 84.2724 15.4765 89.1508 15.4765C90.4227 15.4765 91.7494 15.632 93.0728 16.0113C93.5848 16.1571 93.7716 16.4618 93.6556 16.9706L93.1275 19.9039ZM70.1169 24.0104H58.5601C59.5133 20.9151 62.1666 20.0627 64.3401 20.0627C66.5137 20.0627 69.1638 20.9151 70.1169 24.0104ZM75.3657 26.8399V26.6811C75.3657 19.2621 70.542 15.3695 64.3369 15.3695C58.1351 15.3695 53.3082 19.2654 53.3082 26.6811C53.3082 34.0968 58.1319 37.9927 64.3369 37.9927C68.1559 37.9927 71.2826 36.6055 73.2436 33.8829C73.5077 33.5102 73.3499 33.0824 72.9796 32.9235L69.8529 31.5363C69.4278 31.3224 69.006 31.4812 68.6325 31.7503C67.4121 32.9786 65.7699 33.2963 64.3369 33.2963C61.7931 33.2963 58.6116 32.1748 58.1866 27.5854H74.5671C74.9953 27.5854 75.3657 27.2677 75.3657 26.8399ZM42.3503 36.6573C42.1925 37.137 41.819 37.3509 41.3424 37.3509H37.5267C37.0501 37.3509 36.6798 37.137 36.4673 36.6573L28.0371 16.6984C27.8793 16.3256 28.1434 16.0048 28.5137 16.0048H32.3295C32.806 16.0048 33.1763 16.2187 33.3373 16.6984L39.4329 31.4261L45.5285 16.6984C45.6863 16.2187 46.0598 16.0048 46.5364 16.0048H50.3522C50.7225 16.0048 50.935 16.3256 50.7772 16.6984L42.3503 36.6573ZM23.1136 16.7535C23.1136 16.2738 22.8496 16.008 22.373 16.008H18.9791C18.5025 16.008 18.2385 16.2738 18.2385 16.7535V36.6055C18.2385 37.0852 18.5025 37.3542 18.9791 37.3542H22.373C22.8496 37.3542 23.1136 37.0884 23.1136 36.6055V16.7535ZM20.676 4.53436C22.3183 4.53436 23.6449 5.86971 23.6449 7.5227C23.6449 9.17568 22.3183 10.511 20.676 10.511C19.0338 10.511 17.7071 9.17568 17.7071 7.5227C17.7071 5.86971 19.0306 4.53436 20.676 4.53436ZM13.3053 16.9674C13.4051 16.4618 13.2248 16.1668 12.7225 16.008C11.4087 15.5931 10.0724 15.4732 8.80044 15.4732C3.92204 15.4732 0 17.8749 0 24.4901V36.6022C0 37.0819 0.264046 37.3509 0.740616 37.3509H4.13456C4.61113 37.3509 4.87518 37.0852 4.87518 36.6022V24.4901C4.87518 21.0739 6.9972 20.2215 9.32853 20.2215C10.1754 20.2215 11.0352 20.2798 11.9271 20.4873C12.5293 20.6266 12.6903 20.3771 12.774 19.9006L13.3053 16.9674Z" fill="url(#paint0_linear_7_658)"/><mask id="mask0_7_658" style="mask-type:luminance" maskUnits="userSpaceOnUse" x="0" y="0" width="175" height="38"><path d="M169.633 26.6811C169.633 32.016 166.188 33.2963 163.483 33.2963C160.778 33.2963 157.332 32.016 157.332 26.6811C157.332 21.3462 160.778 20.0627 163.483 20.0627C166.188 20.0627 169.633 21.3429 169.633 26.6811ZM174.512 26.6811V0.745464C174.512 0.265775 174.247 0 173.771 0H170.377C169.9 0 169.633 0.265775 169.633 0.745464V17.9819C168.255 16.1668 165.286 15.3663 163.483 15.3663C157.281 15.3663 152.454 19.2621 152.454 26.6779C152.454 33.562 157.278 37.9895 163.483 37.9895C169.688 37.9927 174.512 34.0968 174.512 26.6811ZM136.547 20.0627C134.373 20.0627 131.723 20.9151 130.767 24.0104H142.324C141.371 20.9151 138.72 20.0627 136.547 20.0627ZM146.777 27.5854H130.397C130.822 32.1748 134.003 33.2963 136.547 33.2963C137.98 33.2963 139.622 32.9754 140.842 31.7503C141.213 31.4845 141.638 31.3224 142.063 31.5363L145.19 32.9235C145.56 33.0824 145.721 33.5102 145.454 33.8829C143.493 36.6055 140.363 37.9927 136.547 37.9927C130.345 37.9927 125.521 34.0968 125.521 26.6811C125.521 19.2621 130.345 15.3695 136.547 15.3695C142.749 15.3695 147.576 19.2654 147.576 26.6811V26.8399C147.572 27.2677 147.202 27.5854 146.777 27.5854ZM115.79 26.6811C115.79 31.8572 112.345 33.2963 109.64 33.2963C106.935 33.2963 103.49 32.016 103.49 26.6811C103.49 21.3462 106.935 20.0627 109.64 20.0627C112.345 20.0627 115.79 21.3429 115.79 26.6811ZM120.669 26.6811C120.669 19.2621 115.845 15.3695 109.643 15.3695C107.84 15.3695 104.871 16.1701 103.493 17.9851V0.745464C103.493 0.265775 103.229 0 102.752 0H99.3584C98.8818 0 98.6145 0.265775 98.6145 0.745464V26.6811C98.6145 34.0968 103.438 37.9927 109.643 37.9927C115.845 37.9927 120.669 33.2444 120.669 26.6811ZM93.1275 19.9039C93.0245 20.4127 92.9182 20.6266 92.2807 20.4905C91.3855 20.2993 90.5322 20.2247 89.6821 20.2247C87.3507 20.2247 85.2287 21.0772 85.2287 24.4933V36.6055C85.2287 37.0852 84.9647 37.3542 84.4881 37.3542H81.0942C80.6176 37.3542 80.3503 37.0884 80.3503 36.6055V24.4933C80.3503 17.8749 84.2724 15.4765 89.1508 15.4765C90.4227 15.4765 91.7494 15.632 93.0728 16.0113C93.5848 16.1571 93.7716 16.4618 93.6556 16.9706L93.1275 19.9039ZM70.1169 24.0104H58.5601C59.5133 20.9151 62.1666 20.0627 64.3401 20.0627C66.5137 20.0627 69.1638 20.9151 70.1169 24.0104ZM75.3657 26.8399V26.6811C75.3657 19.2621 70.542 15.3695 64.3369 15.3695C58.1351 15.3695 53.3082 19.2654 53.3082 26.6811C53.3082 34.0968 58.1319 37.9927 64.3369 37.9927C68.1559 37.9927 71.2826 36.6055 73.2436 33.8829C73.5077 33.5102 73.3499 33.0824 72.9796 32.9235L69.8529 31.5363C69.4278 31.3224 69.006 31.4812 68.6325 31.7503C67.4121 32.9786 65.7699 33.2963 64.3369 33.2963C61.7931 33.2963 58.6116 32.1748 58.1866 27.5854H74.5671C74.9953 27.5854 75.3657 27.2677 75.3657 26.8399ZM42.3503 36.6573C42.1925 37.137 41.819 37.3509 41.3424 37.3509H37.5267C37.0501 37.3509 36.6798 37.137 36.4673 36.6573L28.0371 16.6984C27.8793 16.3256 28.1434 16.0048 28.5137 16.0048H32.3295C32.806 16.0048 33.1763 16.2187 33.3373 16.6984L39.4329 31.4261L45.5285 16.6984C45.6863 16.2187 46.0598 16.0048 46.5364 16.0048H50.3522C50.7225 16.0048 50.935 16.3256 50.7772 16.6984L42.3503 36.6573ZM23.1136 16.7535C23.1136 16.2738 22.8496 16.008 22.373 16.008H18.9791C18.5025 16.008 18.2385 16.2738 18.2385 16.7535V36.6055C18.2385 37.0852 18.5025 37.3542 18.9791 37.3542H22.373C22.8496 37.3542 23.1136 37.0884 23.1136 36.6055V16.7535ZM20.676 4.53436C22.3183 4.53436 23.6449 5.86971 23.6449 7.5227C23.6449 9.17568 22.3183 10.511 20.676 10.511C19.0338 10.511 17.7071 9.17568 17.7071 7.5227C17.7071 5.86971 19.0306 4.53436 20.676 4.53436ZM13.3053 16.9674C13.4051 16.4618 13.2248 16.1668 12.7225 16.008C11.4087 15.5931 10.0724 15.4732 8.80044 15.4732C3.92204 15.4732 0 17.8749 0 24.4901V36.6022C0 37.0819 0.264046 37.3509 0.740616 37.3509H4.13456C4.61113 37.3509 4.87518 37.0852 4.87518 36.6022V24.4901C4.87518 21.0739 6.9972 20.2215 9.32853 20.2215C10.1754 20.2215 11.0352 20.2798 11.9271 20.4873C12.5293 20.6266 12.6903 20.3771 12.774 19.9006L13.3053 16.9674Z" fill="white"/></mask><g mask="url(#mask0_7_658)"><path d="M284.49 56.5837L99.878 179.911L-59.6547 -62.3002L124.957 -185.627L284.49 56.5837Z" fill="url(#paint1_linear_7_658)"/></g><defs><linearGradient id="paint0_linear_7_658" x1="40.2247" y1="75.0006" x2="143.293" y2="-31.0361" gradientUnits="userSpaceOnUse"><stop offset="0.025" stop-color="#4C4EAC"/><stop offset="0.0741" stop-color="#544DB0"/><stop offset="0.1482" stop-color="#684ABC"/><stop offset="0.2202" stop-color="#8346CA"/><stop offset="0.2535" stop-color="#9041CD"/><stop offset="0.3149" stop-color="#B233D6"/><stop offset="0.3403" stop-color="#C22DDA"/><stop offset="0.4131" stop-color="#E813A9"/><stop offset="0.4561" stop-color="#F4248F"/><stop offset="0.4883" stop-color="#FF3378"/><stop offset="0.5469" stop-color="#FF685B"/><stop offset="0.6003" stop-color="#FF7856"/><stop offset="0.6558" stop-color="#FE8750"/><stop offset="0.8884" stop-color="#FCC13A"/><stop offset="1" stop-color="#FBD831"/></linearGradient><linearGradient id="paint1_linear_7_658" x1="20.0949" y1="61.1745" x2="207.515" y2="-67.0135" gradientUnits="userSpaceOnUse"><stop offset="0.025" stop-color="#4C4EAC"/><stop offset="0.0741" stop-color="#544DB0"/><stop offset="0.1482" stop-color="#684ABC"/><stop offset="0.2202" stop-color="#8346CA"/><stop offset="0.2535" stop-color="#9041CD"/><stop offset="0.3149" stop-color="#B233D6"/><stop offset="0.3403" stop-color="#C22DDA"/><stop offset="0.4131" stop-color="#E813A9"/><stop offset="0.4561" stop-color="#F4248F"/><stop offset="0.4883" stop-color="#FF3378"/><stop offset="0.5469" stop-color="#FF685B"/><stop offset="0.6003" stop-color="#FF7856"/><stop offset="0.6558" stop-color="#FE8750"/><stop offset="0.8884" stop-color="#FCC13A"/><stop offset="1" stop-color="#FBD831"/></linearGradient></defs></svg>',
                          type: 'svg' as const,
                          isDefault: true
                        };

                        // Combine default logo with user-uploaded logo (if it exists and is not the default)
                        const userLogos: BrandingLogo[] = [];
                        if (brandingLogo && brandingLogo.id !== 'riverbed-default') {
                          userLogos.push(brandingLogo);
                        }

                        const availableLogos = [defaultRiverbedLogo, ...userLogos];

                        return availableLogos.length > 0 ? (
                          <div className="space-y-2">
                            <Label className="text-xs">Select Logo</Label>
                            <div className="grid grid-cols-3 gap-2">
                              {availableLogos.map((logo) => (
                                <button
                                  key={logo.id || logo.preview}
                                  type="button"
                                  onClick={() => handleChange('selectedLogoId', logo.id || logo.preview)}
                                  className={`p-2 rounded border-2 transition-all h-20 flex items-center justify-center ${
                                    formData.selectedLogoId === (logo.id || logo.preview)
                                      ? 'border-purple-600 bg-white'
                                      : 'border-gray-300 bg-white hover:border-gray-400'
                                  }`}
                                  title={logo.name || 'Logo'}
                                >
                                  {logo.type === 'svg' ? (
                                    <div dangerouslySetInnerHTML={{ __html: logo.preview }} className="max-h-16 w-auto flex items-center justify-center" style={{ maxHeight: '64px' }} />
                                  ) : (
                                    <img src={logo.preview} alt={logo.name || 'Logo'} className="max-h-16 w-auto object-contain" style={{ maxHeight: '64px' }} />
                                  )}
                                </button>
                              ))}
                            </div>
                            {formData.selectedLogoId && availableLogos.find(l => (l.id || l.preview) === formData.selectedLogoId)?.name && (
                              <p className="text-xs text-gray-600 italic">
                                Selected: {availableLogos.find(l => (l.id || l.preview) === formData.selectedLogoId)?.name}
                              </p>
                            )}
                          </div>
                        ) : null;
                      })()}
                      
                      {/* Custom Logo Upload */}
                      <CustomLogoUploadSection
                        customLogo={customLogo}
                        setCustomLogo={setCustomLogo}
                      />
                      
                      <Label className="text-xs">Logo Position</Label>
                      <div className="grid grid-cols-3 gap-2">
                        {['top-left', 'top-center', 'top-right', 'center-left', 'placeholder', 'center-right', 'bottom-left', 'bottom-center', 'bottom-right'].map((position) => (
                          position === 'placeholder' ? (
                            <div key={position} className="h-16"></div>
                          ) : (
                            <button
                              key={position}
                              type="button"
                              onClick={() => handleChange('logoPosition', position)}
                              className={`p-2 rounded border transition-all h-16 ${
                                formData.logoPosition === position
                                  ? 'border-purple-600 bg-white text-purple-900'
                                  : 'border-gray-300 bg-white text-gray-700 hover:border-gray-400'
                              }`}
                            >
                              <div className="w-full h-full border border-gray-200 rounded-sm p-1 flex flex-col gap-0.5">
                                {position.includes('top') && (
                                  <>
                                    <div className={`flex gap-1 items-start ${
                                      position === 'top-left' ? 'justify-start' :
                                      position === 'top-center' ? 'justify-center' :
                                      'justify-end'
                                    }`}>
                                      <div className="w-2 h-2 bg-purple-400 rounded-sm flex-shrink-0"></div>
                                    </div>
                                    <div className="w-full h-0.5 bg-gray-300 rounded"></div>
                                    <div className="w-3/4 h-0.5 bg-gray-300 rounded"></div>
                                  </>
                                )}
                                {position === 'center-left' && (
                                  <div className="flex gap-1 h-full items-center">
                                    <div className="w-1.5 h-4 bg-purple-400 rounded-sm flex-shrink-0"></div>
                                    <div className="flex-1 flex flex-col gap-0.5 justify-center">
                                      <div className="w-full h-0.5 bg-gray-300 rounded"></div>
                                      <div className="w-full h-0.5 bg-gray-300 rounded"></div>
                                      <div className="w-2/3 h-0.5 bg-gray-300 rounded"></div>
                                    </div>
                                  </div>
                                )}
                                {position === 'center-right' && (
                                  <div className="flex gap-1 h-full items-center">
                                    <div className="flex-1 flex flex-col gap-0.5 justify-center">
                                      <div className="w-full h-0.5 bg-gray-300 rounded"></div>
                                      <div className="w-full h-0.5 bg-gray-300 rounded"></div>
                                      <div className="w-2/3 h-0.5 bg-gray-300 rounded"></div>
                                    </div>
                                    <div className="w-1.5 h-4 bg-purple-400 rounded-sm flex-shrink-0"></div>
                                  </div>
                                )}
                                {position.includes('bottom') && (
                                  <>
                                    <div className="w-full h-0.5 bg-gray-300 rounded"></div>
                                    <div className="w-3/4 h-0.5 bg-gray-300 rounded"></div>
                                    <div className={`flex gap-1 items-end ${
                                      position === 'bottom-left' ? 'justify-start' :
                                      position === 'bottom-center' ? 'justify-center' :
                                      'justify-end'
                                    }`}>
                                      <div className="w-2 h-2 bg-purple-400 rounded-sm flex-shrink-0"></div>
                                    </div>
                                  </>
                                )}
                              </div>
                            </button>
                          )
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}


          </div>

          {/* Right Column - Live Preview */}
          <div className="flex-1 border-l border-gray-200 pl-8 flex flex-col">
            <div className="flex items-center gap-2 text-gray-900 mb-4">
              <Eye className="w-5 h-5 text-purple-700" />
              <h3>Live Preview</h3>
              <span className="ml-auto text-xs text-gray-500">Updates in real-time</span>
            </div>
            
            {/* PRO Feature Info Box */}
            <div className="bg-purple-50 border border-purple-200 rounded-lg p-4 mb-4">
              <div className="flex items-start gap-2">
                <Sparkles className="w-4 h-4 text-purple-600 mt-0.5 flex-shrink-0" />
                <div className="text-xs text-purple-900">
                  <p className="mb-1">PRO Feature: Live Preview</p>
                  <p>See your template update in real-time as you configure it. Changes appear instantly in the preview panel.</p>
                </div>
              </div>
            </div>
            
            <div className="flex-1 overflow-y-auto">
              <LivePreview />
              
              {/* Summary Section - Only on Step 3 */}
              {currentStep === 3 && (
                <div className="mt-6 pt-6 border-t border-gray-200">
                  <div className="flex items-center gap-2 text-gray-900 mb-4">
                    <FileText className="w-5 h-5 text-purple-700" />
                    <h4>Summary</h4>
                  </div>
                  
                  <div className="space-y-4">
                    {/* Basic Information */}
                    <div className="bg-gray-50 rounded-lg p-4 space-y-2">
                      <p className="text-xs text-gray-600 uppercase tracking-wide">Basic Information</p>
                      <div className="grid grid-cols-2 gap-3 text-sm">
                        <div>
                          <span className="text-gray-600">Name:</span>
                          <p className="text-gray-900">{formData.name || 'Not set'}</p>
                        </div>
                        <div>
                          <span className="text-gray-600">Type:</span>
                          <p className="text-gray-900 capitalize">{formData.type}</p>
                        </div>
                        <div>
                          <span className="text-gray-600">Category:</span>
                          <p className="text-gray-900">{formData.category}</p>
                        </div>
                        <div>
                          <span className="text-gray-600">Priority:</span>
                          <p className="text-gray-900">{formData.priority}</p>
                        </div>
                        <div>
                          <span className="text-gray-600">Template:</span>
                          <p className="text-gray-900">{formData.selectedTemplate || 'Custom'}</p>
                        </div>
                      </div>
                    </div>

                    {/* Content */}
                    <div className="bg-gray-50 rounded-lg p-4 space-y-2">
                      <p className="text-xs text-gray-600 uppercase tracking-wide">Content</p>
                      <div className="space-y-2 text-sm">
                        <div>
                          <span className="text-gray-600">Title:</span>
                          <p className="text-gray-900">{formData.title || 'Not set'}</p>
                        </div>
                        {formData.messageDescription && (
                          <div>
                            <span className="text-gray-600">Description:</span>
                            <p className="text-gray-900 line-clamp-2">{formData.messageDescription}</p>
                          </div>
                        )}
                        <div>
                          <span className="text-gray-600">Buttons:</span>
                          <p className="text-gray-900">
                            {formData.buttonPrimary && formData.buttonSecondary 
                              ? `${formData.buttonPrimary}, ${formData.buttonSecondary}`
                              : formData.buttonPrimary || formData.buttonSecondary || 'None'}
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Channels & Branding */}
                    <div className="bg-gray-50 rounded-lg p-4 space-y-2">
                      <p className="text-xs text-gray-600 uppercase tracking-wide">Channels & Branding</p>
                      <div className="space-y-2 text-sm">
                        <div>
                          <span className="text-gray-600">Channels:</span>
                          <p className="text-gray-900 capitalize">
                            {formData.channels.length > 0 ? formData.channels.join(', ') : 'None selected'}
                          </p>
                        </div>
                        <div>
                          <span className="text-gray-600">Logo:</span>
                          <p className="text-gray-900">{formData.showLogo ? `Yes (${formData.logoPosition})` : 'No'}</p>
                        </div>
                        <div>
                          <span className="text-gray-600">Branding Profile:</span>
                          <p className="text-gray-900 capitalize">{formData.brandingProfile}</p>
                        </div>
                      </div>
                    </div>


                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        <DialogFooter className="mt-6">
          <button
            onClick={handleClose}
            className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
          >
            Cancel
          </button>
          
          {currentStep > 1 && (
            <button
              onClick={handleBack}
              className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
            >
              Back
            </button>
          )}
          
          {currentStep < totalSteps ? (
            <button
              onClick={handleNext}
              disabled={currentStep === 1 && (!formData.name.trim() || !formData.description.trim())}
              className="px-4 py-2 bg-purple-900 text-white rounded-lg hover:bg-purple-950 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed disabled:hover:bg-gray-300"
            >
              Next Step
            </button>
          ) : (
            <button
              onClick={handleSubmit}
              className="px-4 py-2 bg-purple-900 text-white rounded-lg hover:bg-purple-950 transition-colors"
            >
              Create Template
            </button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}