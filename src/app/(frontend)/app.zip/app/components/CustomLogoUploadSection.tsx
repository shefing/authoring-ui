import { defaultBrandingLogo, BrandingLogo } from './UnifiedCommunicationPlatform';
import { Label } from './ui/label';
import { Upload, Plus, Code, Trash2, Check, Star } from 'lucide-react';
import { useState } from 'react';

interface CustomLogoUploadSectionProps {
  customLogo: BrandingLogo | null;
  setCustomLogo?: (logo: BrandingLogo | null) => void;
  onLogoChange?: (logo: BrandingLogo | null) => void;
  label?: string;
  description?: string;
}

export function CustomLogoUploadSection({
  customLogo,
  setCustomLogo,
  onLogoChange,
  label = 'Custom Logo for This Message',
  description = 'Upload a custom logo for this message. This will override the selected branding logo.'
}: CustomLogoUploadSectionProps) {
  const handleLogoChange = (logo: BrandingLogo | null) => {
    if (setCustomLogo) {
      setCustomLogo(logo);
    }
    if (onLogoChange) {
      onLogoChange(logo);
    }
  };
  const [showSvgInput, setShowSvgInput] = useState(false);
  const [svgCode, setSvgCode] = useState('');

  const handleApplySvg = () => {
    if (svgCode.trim()) {
      handleLogoChange({
        name: 'Custom SVG Logo',
        preview: svgCode.trim(),
        type: 'svg',
        isDefault: false
      });
      setShowSvgInput(false);
      setSvgCode('');
    }
  };

  // Always use a logo - either custom or default
  const displayLogo = customLogo || defaultBrandingLogo;

  return (
    <div className="space-y-2 pt-3 border-t border-purple-200">
      <Label className="text-xs">{label}</Label>
      <div className="bg-white border border-gray-200 rounded-lg p-2">
        {/* Default Badge */}
        {displayLogo.isDefault && (
          <div className="mb-2 flex items-center gap-1 text-amber-600 bg-amber-50 px-2 py-1 rounded text-[10px] border border-amber-200">
            <Star className="w-3 h-3 fill-amber-600" />
            <span className="font-medium">Default Logo</span>
          </div>
        )}
        
        <div className="flex gap-2">
          {/* Logo Preview */}
          <div className="w-20 min-h-[80px] max-h-[120px] border border-gray-300 rounded bg-gray-50 flex items-center justify-center flex-shrink-0">
            {displayLogo.preview ? (
              displayLogo.type === 'svg' ? (
                <div dangerouslySetInnerHTML={{ __html: displayLogo.preview }} className="w-full h-full p-1" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }} />
              ) : (
                <img src={displayLogo.preview} alt={displayLogo.name} className="w-full h-full object-contain p-1" />
              )
            ) : (
              <Upload className="w-6 h-6 text-gray-400" />
            )}
          </div>
          
          {/* Logo Controls */}
          <div className="flex-1 space-y-1">
            <label className="block cursor-pointer">
              <div className="flex items-center justify-center gap-1 px-1.5 py-1 bg-purple-100 text-purple-900 rounded text-[10px] hover:bg-purple-200 transition-colors">
                <Upload className="w-3 h-3" />
                Upload File
              </div>
              <input
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) {
                    const reader = new FileReader();
                    reader.onloadend = () => {
                      handleLogoChange({ 
                        name: file.name || 'Custom Logo',
                        preview: reader.result as string,
                        type: 'file',
                        isDefault: false
                      });
                    };
                    reader.readAsDataURL(file);
                  }
                }}
              />
            </label>
            
            <button
              onClick={() => {
                setShowSvgInput(!showSvgInput);
                if (showSvgInput) {
                  setSvgCode('');
                } else {
                  setSvgCode(displayLogo.type === 'svg' ? displayLogo.preview : '');
                }
              }}
              className={`w-full flex items-center justify-center gap-1 px-1.5 py-1 rounded text-[10px] transition-colors ${
                showSvgInput 
                  ? 'bg-purple-100 text-purple-900 hover:bg-purple-200' 
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              <Code className="w-3 h-3" />
              {showSvgInput ? 'Hide SVG Input' : 'Paste SVG'}
            </button>
            
            {!displayLogo.isDefault && (
              <button
                onClick={() => handleLogoChange(defaultBrandingLogo)}
                className="w-full px-1.5 py-1 text-amber-700 hover:bg-amber-50 rounded text-[10px] transition-colors flex items-center justify-center gap-1"
                title="Reset to default logo"
              >
                <Star className="w-3 h-3" />
                Reset to Default
              </button>
            )}
          </div>
        </div>

        {/* Inline SVG Input */}
        {showSvgInput && (
          <div className="mt-2 pt-2 border-t border-gray-200 space-y-1">
            <textarea
              value={svgCode}
              onChange={(e) => setSvgCode(e.target.value)}
              placeholder="Paste your SVG code here..."
              rows={4}
              className="w-full px-2 py-1.5 border border-gray-300 rounded text-[10px] font-mono resize-none"
            />
            <button
              onClick={handleApplySvg}
              disabled={!svgCode.trim()}
              className="w-full flex items-center justify-center gap-1 px-1.5 py-1 bg-purple-900 text-white rounded text-[10px] hover:bg-purple-950 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Check className="w-3 h-3" />
              Apply SVG Code
            </button>
          </div>
        )}
      </div>
      <p className="text-xs text-gray-500">{description}</p>
    </div>
  );
}