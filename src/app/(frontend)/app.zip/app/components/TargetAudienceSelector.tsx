import { Users, X, Check } from 'lucide-react';
import { Label } from './ui/label';

interface TargetAudienceSelectorProps {
  targetGroups: string[];
  vipHandling: boolean;
  fatiguePrevention: boolean;
  onTargetGroupsChange: (groups: string[]) => void;
  onVipHandlingChange: (enabled: boolean) => void;
  onFatiguePreventionChange: (enabled: boolean) => void;
}

/**
 * Target Audience Selector Component
 * 
 * This component allows users to select target audiences for message delivery.
 * It will be used in the message send flow when clicking the "Send Message" button
 * from the messages table actions column.
 * 
 * Features:
 * - Multi-group selection from predefined options
 * - Add/remove functionality for selected groups
 * - VIP priority handling option
 * - Fatigue prevention option
 * - Visual feedback for selected groups
 */
export function TargetAudienceSelector({
  targetGroups,
  vipHandling,
  fatiguePrevention,
  onTargetGroupsChange,
  onVipHandlingChange,
  onFatiguePreventionChange,
}: TargetAudienceSelectorProps) {
  
  const handleAddGroup = (selectedGroup: string) => {
    if (selectedGroup && !targetGroups.includes(selectedGroup)) {
      onTargetGroupsChange([...targetGroups, selectedGroup]);
    }
  };

  const handleRemoveGroup = (index: number) => {
    onTargetGroupsChange(targetGroups.filter((_, i) => i !== index));
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 text-gray-900 mb-4">
        <Users className="w-5 h-5 text-purple-700" />
        <h3>Target Audience</h3>
      </div>

      <div className="border border-gray-200 rounded-lg p-4 space-y-4 bg-white">
        <div className="flex items-center gap-2">
          <Users className="w-5 h-5 text-blue-600" />
          <h4 className="text-gray-900">Select Target Audience</h4>
        </div>
        
        <div className="space-y-3">
          <Label htmlFor="targetGroup">Target Groups/Audiences *</Label>
          
          {/* Add Group Section */}
          <div className="flex gap-2">
            <select
              id="targetGroup"
              className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              onChange={(e) => {
                handleAddGroup(e.target.value);
                e.target.value = ''; // Reset dropdown
              }}
            >
              <option value="">-- Add target group --</option>
              <option value="All Employees">All Employees</option>
              <option value="Engineering Dept">Engineering Department</option>
              <option value="Sales Dept">Sales Department</option>
              <option value="Remote Workers">Remote Workers</option>
              <option value="VIP Users">VIP Users</option>
              <option value="Executive Team">Executive Team</option>
              <option value="IT Operations">IT Operations</option>
              <option value="Custom Group">Custom Group (Advanced)</option>
            </select>
          </div>

          {/* Selected Groups Display */}
          {targetGroups.length > 0 && (
            <div className="space-y-2">
              <Label className="text-xs text-gray-600">Selected Groups ({targetGroups.length})</Label>
              <div className="flex flex-wrap gap-2">
                {targetGroups.map((group, index) => (
                  <div
                    key={index}
                    className="inline-flex items-center gap-2 px-3 py-1.5 bg-purple-100 border border-purple-300 rounded-lg text-sm text-purple-900"
                  >
                    <Users className="w-3.5 h-3.5" />
                    <span>{group}</span>
                    <button
                      type="button"
                      onClick={() => handleRemoveGroup(index)}
                      className="ml-1 hover:bg-purple-200 rounded-full p-0.5 transition-colors"
                      title="Remove group"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Target Groups Info */}
          {targetGroups.length > 0 && (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
              <div className="flex items-start gap-2">
                <Check className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                <div className="text-xs text-blue-900">
                  <p className="font-medium mb-2">
                    {targetGroups.length} Target {targetGroups.length === 1 ? 'Group' : 'Groups'} Selected
                  </p>
                  <div className="space-y-1">
                    {targetGroups.map((group, index) => (
                      <p key={index} className="pl-2">
                        <span className="font-medium">• {group}:</span>{' '}
                        {group === 'All Employees' && 'All employees in the organization.'}
                        {group === 'Engineering Dept' && 'All members of the Engineering department.'}
                        {group === 'Sales Dept' && 'All members of the Sales department.'}
                        {group === 'Remote Workers' && 'All employees marked as remote workers.'}
                        {group === 'VIP Users' && 'VIP users with special handling rules.'}
                        {group === 'Executive Team' && 'Executive team members.'}
                        {group === 'IT Operations' && 'IT Operations team members.'}
                        {group === 'Custom Group' && 'Custom-defined group (configure in advanced settings).'}
                      </p>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Delivery Options */}
          <div className="grid grid-cols-2 gap-3 pt-2">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={vipHandling}
                onChange={(e) => onVipHandlingChange(e.target.checked)}
                className="w-4 h-4 text-purple-600 border-gray-300 rounded focus:ring-purple-500"
              />
              <span className="text-sm text-gray-700">VIP Priority Handling</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={fatiguePrevention}
                onChange={(e) => onFatiguePreventionChange(e.target.checked)}
                className="w-4 h-4 text-purple-600 border-gray-300 rounded focus:ring-purple-500"
              />
              <span className="text-sm text-gray-700">Fatigue Prevention</span>
            </label>
          </div>
        </div>
      </div>
    </div>
  );
}
