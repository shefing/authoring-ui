import { useState } from 'react';
import { Plus, Edit, Copy, Trash2, Eye, MessageSquare, Grid, List, X, Sparkles, BarChart3, Rows3, Filter, Table, SquareStack, Grid2x2 } from 'lucide-react';
import { CreateTemplateDialog } from './CreateTemplateDialog';
import { CreateTemplateDialogPro } from './CreateTemplateDialogPro';
import { PreviewTemplateDialog } from './PreviewTemplateDialog';
import { BrandingLogo } from './UnifiedCommunicationPlatform';
import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';

export interface Template {
  id: string;
  name: string;
  description?: string;
  type: 'survey' | 'confirmation' | 'notification' | 'reminder' | 'self-service';
  division: string;
  supportsDynamic: boolean;
  channels: string[];
  usageCount: number;
  source?: 'pre-defined' | 'custom';
  showHeader?: boolean;
  showDescription?: boolean;
  showBody?: boolean;
  showButton1?: boolean;
  showButton2?: boolean;
  showButton3?: boolean;
  showLogo?: boolean;
  logoPosition?: 'top-left' | 'top-center' | 'top-right' | 'center-left' | 'center-right' | 'bottom-left' | 'bottom-center' | 'bottom-right';
  // Content fields
  title?: string;
  messageDescription?: string;
  body?: string;
  buttonPrimary?: string;
  buttonSecondary?: string;
  buttonTertiary?: string;
  brandingProfile?: 'default' | 'security' | 'it' | 'hr' | 'custom';
  customCSS?: string;
  // Button configuration
  button1Type?: 'primary' | 'secondary' | 'tertiary';
  button2Type?: 'primary' | 'secondary' | 'tertiary';
  buttonAlignment?: 'left' | 'center' | 'right';
}

interface TemplateManagerProps {
  brandingLogo: BrandingLogo | null;
  templates: Template[];
  onTemplatesChange: (templates: Template[]) => void;
  showCreateDialogPro?: boolean;
  setShowCreateDialogPro?: (show: boolean) => void;
}

export function TemplateManager({ brandingLogo, templates, onTemplatesChange, showCreateDialogPro: externalShowCreateDialogPro, setShowCreateDialogPro: externalSetShowCreateDialogPro }: TemplateManagerProps) {
  const setTemplates = onTemplatesChange;
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [internalShowCreateDialogPro, setInternalShowCreateDialogPro] = useState(false);
  
  // Use external state if provided, otherwise use internal state
  const showCreateDialogPro = externalShowCreateDialogPro !== undefined ? externalShowCreateDialogPro : internalShowCreateDialogPro;
  const setShowCreateDialogPro = externalSetShowCreateDialogPro || setInternalShowCreateDialogPro;

  const [previewTemplate, setPreviewTemplate] = useState<Template | null>(null);
  const [editingTemplate, setEditingTemplate] = useState<Template | null>(null);
  const [viewMode, setViewMode] = useState<'grid' | 'table'>('table');
  const [filterViewMode, setFilterViewMode] = useState<'chart' | 'list'>('chart');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedFilters, setSelectedFilters] = useState<{
    type?: string[];
    division?: string[];
    channel?: string[];
    supportsDynamic?: string[];
  }>({});

  // Filter templates based on selected filters and search term
  const filteredTemplates = templates.filter(template => {
    // Search filter
    if (searchTerm) {
      const searchLower = searchTerm.toLowerCase();
      const matchesSearch = 
        template.name.toLowerCase().includes(searchLower) ||
        template.division.toLowerCase().includes(searchLower) ||
        template.type.toLowerCase().includes(searchLower) ||
        template.channels.some(ch => ch.toLowerCase().includes(searchLower));
      if (!matchesSearch) return false;
    }
    
    // Category filters
    if (selectedFilters.type && selectedFilters.type.length > 0) {
      if (!selectedFilters.type.includes(template.type)) return false;
    }
    if (selectedFilters.division && selectedFilters.division.length > 0) {
      if (!selectedFilters.division.includes(template.division)) return false;
    }
    if (selectedFilters.channel && selectedFilters.channel.length > 0) {
      if (!template.channels.some(ch => selectedFilters.channel?.includes(ch))) return false;
    }
    if (selectedFilters.supportsDynamic && selectedFilters.supportsDynamic.length > 0) {
      const dynamicKey = template.supportsDynamic ? 'yes' : 'no';
      if (!selectedFilters.supportsDynamic.includes(dynamicKey)) return false;
    }
    return true;
  });

  const handleFilterChange = (filterType: string, value: string) => {
    setSelectedFilters(prev => {
      const currentFilters = prev[filterType as keyof typeof prev] || [];
      const newFilters = currentFilters.includes(value)
        ? currentFilters.filter(v => v !== value)
        : [...currentFilters, value];
      
      return {
        ...prev,
        [filterType]: newFilters.length > 0 ? newFilters : undefined
      };
    });
  };

  const clearFilters = () => {
    setSelectedFilters({});
  };

  const hasActiveFilters = Object.values(selectedFilters).some(arr => arr && arr.length > 0);

  // Delete template handler
  const handleDeleteTemplate = (templateId: string) => {
    if (confirm('Are you sure you want to delete this template? This action cannot be undone.')) {
      const updatedTemplates = templates.filter(t => t.id !== templateId);
      setTemplates(updatedTemplates);
    }
  };

  // Duplicate template handler
  const handleDuplicateTemplate = (templateId: string) => {
    const templateToDuplicate = templates.find(t => t.id === templateId);
    if (templateToDuplicate) {
      const duplicatedTemplate: Template = {
        ...templateToDuplicate,
        id: Date.now().toString(),
        name: `${templateToDuplicate.name} (Copy)`,
        usageCount: 0,
      };
      setTemplates([...templates, duplicatedTemplate]);
    }
  };

  // Edit template handler
  const handleEditTemplate = (templateId: string) => {
    const templateToEdit = templates.find(t => t.id === templateId);
    if (templateToEdit) {
      setEditingTemplate(templateToEdit);
      setShowCreateDialogPro(true);
    }
  };

  // Calculate filter data
  const typeData = [
    { name: 'Survey', key: 'survey', value: templates.filter(t => t.type === 'survey').length, color: '#c4b5fd' },
    { name: 'Confirmation', key: 'confirmation', value: templates.filter(t => t.type === 'confirmation').length, color: '#fcd34d' },
    { name: 'Notification', key: 'notification', value: templates.filter(t => t.type === 'notification').length, color: '#93c5fd' },
    { name: 'Reminder', key: 'reminder', value: templates.filter(t => t.type === 'reminder').length, color: '#fde68a' },
    { name: 'Self-Service', key: 'self-service', value: templates.filter(t => t.type === 'self-service').length, color: '#86efac' },
  ].filter(item => item.value > 0);

  const divisionData = [
    { name: 'Corporate', key: 'Corporate', value: templates.filter(t => t.division === 'Corporate').length, color: '#a5b4fc' },
    { name: 'IT Operations', key: 'IT Operations', value: templates.filter(t => t.division === 'IT Operations').length, color: '#c4b5fd' },
    { name: 'Engineering', key: 'Engineering', value: templates.filter(t => t.division === 'Engineering').length, color: '#93c5fd' },
    { name: 'Support', key: 'Support', value: templates.filter(t => t.division === 'Support').length, color: '#86efac' },
    { name: 'Executive', key: 'Executive', value: templates.filter(t => t.division === 'Executive').length, color: '#fcd34d' },
  ].filter(item => item.value > 0);

  const channelData = [
    { name: 'Riverbed', key: 'riverbed', value: templates.filter(t => t.channels.includes('riverbed')).length, color: '#a5b4fc' },
    { name: 'Teams', key: 'teams', value: templates.filter(t => t.channels.includes('teams')).length, color: '#93c5fd' },
    { name: 'Slack', key: 'slack', value: templates.filter(t => t.channels.includes('slack')).length, color: '#fda4af' },
    { name: 'Email', key: 'email', value: templates.filter(t => t.channels.includes('email')).length, color: '#86efac' },
  ].filter(item => item.value > 0);

  const dynamicData = [
    { name: 'Yes', key: 'yes', value: templates.filter(t => t.supportsDynamic).length, color: '#86efac' },
    { name: 'No', key: 'no', value: templates.filter(t => !t.supportsDynamic).length, color: '#e2e8f0' },
  ].filter(item => item.value > 0);

  const DonutChart = ({ data, filterType }: { data: any[], filterType: string }) => {
    const total = data.reduce((sum, item) => sum + item.value, 0);
    const centerText = total.toString();

    return (
      <div className="relative w-[120px] h-[120px]">
        <ResponsiveContainer width={120} height={120}>
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              innerRadius={35}
              outerRadius={50}
              paddingAngle={2}
              dataKey="value"
              onClick={(entry) => handleFilterChange(filterType, entry.key)}
              className="cursor-pointer"
              isAnimationActive={false}
            >
              {data.map((entry, index) => (
                <Cell 
                  key={`cell-${index}`} 
                  fill={entry.color}
                  className="hover:opacity-80 transition-opacity"
                />
              ))}
            </Pie>
          </PieChart>
        </ResponsiveContainer>
        <div className="absolute top-0 left-0 w-[120px] h-[120px] flex items-center justify-center pointer-events-none">
          <span className="text-2xl font-semibold text-gray-900">{centerText}</span>
        </div>
      </div>
    );
  };

  const FilterCard = ({ title, data, filterType }: { title: string, data: any[], filterType: string }) => {
    return (
      <div className="bg-white rounded-lg border border-gray-200 p-4">
        <h3 className="text-sm font-medium text-gray-900 mb-4">{title}</h3>
        <div className="flex gap-4">
          <DonutChart data={data} filterType={filterType} />
          <div className="flex-1 space-y-1.5">
            {data.map((item, index) => {
              const isSelected = selectedFilters[filterType as keyof typeof selectedFilters]?.includes(item.key);
              return (
                <button
                  key={index}
                  onClick={() => handleFilterChange(filterType, item.key)}
                  className={`w-full flex items-center justify-between px-2 py-1 rounded text-xs hover:bg-gray-50 transition-colors ${
                    isSelected ? 'bg-purple-100' : ''
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <div
                      className="w-2 h-2 rounded-full"
                      style={{ backgroundColor: item.color }}
                    />
                    <span className="text-gray-700">{item.name}</span>
                  </div>
                  <span className="font-medium text-gray-900">{item.value}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    );
  };

  const getTypeColor = (type: Template['type']) => {
    const colors = {
      survey: 'bg-purple-100 text-purple-800',
      confirmation: 'bg-orange-100 text-orange-800',
      notification: 'bg-blue-100 text-blue-800',
      reminder: 'bg-yellow-100 text-yellow-800',
      'self-service': 'bg-green-100 text-green-800'
    };
    return colors[type];
  };

  return (
    <div className="p-8">
      {/* Search and View Mode Toggle */}
      <div className="mb-4 flex gap-3 items-center">
        <div className="relative flex-1">
          <input
            type="text"
            placeholder="Search templates..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent bg-white"
          />
          <div className="absolute left-3 top-1/2 -translate-y-1/2">
            <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
          </div>
        </div>
        
        {/* Filter View Mode Toggle */}
        <div className="flex items-center gap-1 bg-white border border-gray-200 rounded-lg p-1">
          <button
            onClick={() => setFilterViewMode(filterViewMode === 'list' ? 'chart' : 'list')}
            className={`p-1.5 rounded transition-colors ${
              filterViewMode === 'list' ? 'bg-purple-900 text-white' : 'text-gray-600 hover:bg-gray-100'
            }`}
            title="Toggle Filters"
          >
            <Filter className="w-4 h-4" />
          </button>
        </div>

        {/* View Mode Toggle */}
        <div className="flex gap-2 bg-white rounded-lg border border-gray-200 p-1">
          <button
            onClick={() => setViewMode('grid')}
            className={`p-1.5 rounded transition-colors ${
              viewMode === 'grid'
                ? 'bg-purple-900 text-white'
                : 'text-gray-600 hover:bg-gray-100'
            }`}
            title="Single View"
          >
            <svg className="w-4 h-4" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
              <rect x="1" y="1" width="6" height="6" rx="1" />
              <rect x="9" y="1" width="6" height="6" rx="1" />
              <rect x="1" y="9" width="6" height="6" rx="1" />
              <rect x="9" y="9" width="6" height="6" rx="1" />
            </svg>
          </button>
          <button
            onClick={() => setViewMode('table')}
            className={`p-1.5 rounded transition-colors ${
              viewMode === 'table'
                ? 'bg-purple-900 text-white'
                : 'text-gray-600 hover:bg-gray-100'
            }`}
            title="Tabs View"
          >
            <Table className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Template Type Filter */}
      {filterViewMode === 'chart' ? (
        null
      ) : (
        <div className="bg-white rounded-lg border border-gray-200 p-4 mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-medium text-gray-900">Templates filtered by active criteria</h2>
            {hasActiveFilters && (
              <button
                onClick={clearFilters}
                className="text-xs text-purple-700 hover:text-purple-800 flex items-center gap-1 px-2 py-1"
              >
                <X className="w-3 h-3" />
                Reset All
              </button>
            )}
          </div>

          {/* Available Filters */}
          <div className="flex flex-wrap gap-4">
            {/* Type Options */}
            <div>
              <label className="text-xs font-semibold text-gray-700 mb-1.5 block">Type</label>
              <div className="flex flex-wrap gap-1.5">
                <button
                  onClick={() => setSelectedFilters(prev => ({ ...prev, type: undefined }))}
                  className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs border transition-colors ${
                    !selectedFilters.type || selectedFilters.type.length === 0
                      ? 'bg-purple-50 border-purple-300 text-purple-900' 
                      : 'bg-white border-gray-200 text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  <span>All</span>
                  <span className="font-medium">({templates.length})</span>
                </button>
                {typeData.map((item, index) => {
                  const isSelected = selectedFilters.type?.includes(item.key);
                  return (
                    <button
                      key={index}
                      onClick={() => handleFilterChange('type', item.key)}
                      className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs border transition-colors ${
                        isSelected 
                          ? 'bg-purple-50 border-purple-300 text-purple-900' 
                          : 'bg-white border-gray-200 text-gray-700 hover:bg-gray-50'
                      }`}
                    >
                      <div className="w-2 h-2 rounded-full" style={{ backgroundColor: item.color }} />
                      <span>{item.name}</span>
                      <span className="font-medium">({item.value})</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Division Options */}
            <div>
              <label className="text-xs font-semibold text-gray-700 mb-1.5 block">Division</label>
              <div className="flex flex-wrap gap-1.5">
                <button
                  onClick={() => setSelectedFilters(prev => ({ ...prev, division: undefined }))}
                  className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs border transition-colors ${
                    !selectedFilters.division || selectedFilters.division.length === 0
                      ? 'bg-purple-50 border-purple-300 text-purple-900' 
                      : 'bg-white border-gray-200 text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  <span>All</span>
                  <span className="font-medium">({templates.length})</span>
                </button>
                {divisionData.map((item, index) => {
                  const isSelected = selectedFilters.division?.includes(item.key);
                  return (
                    <button
                      key={index}
                      onClick={() => handleFilterChange('division', item.key)}
                      className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs border transition-colors ${
                        isSelected 
                          ? 'bg-purple-50 border-purple-300 text-purple-900' 
                          : 'bg-white border-gray-200 text-gray-700 hover:bg-gray-50'
                      }`}
                    >
                      <div className="w-2 h-2 rounded-full" style={{ backgroundColor: item.color }} />
                      <span>{item.name}</span>
                      <span className="font-medium">({item.value})</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Channel Options */}
            <div>
              <label className="text-xs font-semibold text-gray-700 mb-1.5 block">Channel</label>
              <div className="flex flex-wrap gap-1.5">
                <button
                  onClick={() => setSelectedFilters(prev => ({ ...prev, channel: undefined }))}
                  className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs border transition-colors ${
                    !selectedFilters.channel || selectedFilters.channel.length === 0
                      ? 'bg-purple-50 border-purple-300 text-purple-900' 
                      : 'bg-white border-gray-200 text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  <span>All</span>
                  <span className="font-medium">({templates.length})</span>
                </button>
                {channelData.map((item, index) => {
                  const isSelected = selectedFilters.channel?.includes(item.key);
                  return (
                    <button
                      key={index}
                      onClick={() => handleFilterChange('channel', item.key)}
                      className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs border transition-colors ${
                        isSelected 
                          ? 'bg-purple-50 border-purple-300 text-purple-900' 
                          : 'bg-white border-gray-200 text-gray-700 hover:bg-gray-50'
                      }`}
                    >
                      <div className="w-2 h-2 rounded-full" style={{ backgroundColor: item.color }} />
                      <span>{item.name}</span>
                      <span className="font-medium">({item.value})</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Dynamic Options */}
            <div>
              <label className="text-xs font-semibold text-gray-700 mb-1.5 block">Dynamic Parameters</label>
              <div className="flex flex-wrap gap-1.5">
                <button
                  onClick={() => setSelectedFilters(prev => ({ ...prev, supportsDynamic: undefined }))}
                  className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs border transition-colors ${
                    !selectedFilters.supportsDynamic || selectedFilters.supportsDynamic.length === 0
                      ? 'bg-purple-50 border-purple-300 text-purple-900' 
                      : 'bg-white border-gray-200 text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  <span>All</span>
                  <span className="font-medium">({templates.length})</span>
                </button>
                {dynamicData.map((item, index) => {
                  const isSelected = selectedFilters.supportsDynamic?.includes(item.key);
                  return (
                    <button
                      key={index}
                      onClick={() => handleFilterChange('supportsDynamic', item.key)}
                      className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs border transition-colors ${
                        isSelected 
                          ? 'bg-purple-50 border-purple-300 text-purple-900' 
                          : 'bg-white border-gray-200 text-gray-700 hover:bg-gray-50'
                      }`}
                    >
                      <div className="w-2 h-2 rounded-full" style={{ backgroundColor: item.color }} />
                      <span>{item.name}</span>
                      <span className="font-medium">({item.value})</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Clear Filters Button - Only show for chart view */}
      {filterViewMode === 'chart' && hasActiveFilters && (
        <button
          onClick={clearFilters}
          className="bg-gray-100 text-gray-600 px-4 py-2 rounded-lg hover:bg-gray-200 transition-colors mb-8"
        >
          Clear Filters
        </button>
      )}

      {/* Templates Grid/List */}
      {viewMode === 'grid' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTemplates.map((template) => (
            <div key={template.id} className="bg-white rounded-lg border border-gray-200 overflow-hidden hover:shadow-lg transition-shadow flex flex-col">
              {/* Template Header */}
              <div className="p-6 border-b border-gray-200">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <h3 className="text-gray-900">{template.name}</h3>
                    <p className="text-gray-500 text-sm mt-1">{template.division}</p>
                  </div>
                  <span className={`px-2.5 py-1 rounded-full text-sm capitalize ${getTypeColor(template.type)}`}>
                    {template.type}
                  </span>
                </div>
              </div>

              {/* Template Details */}
              <div className="p-6 space-y-4 flex-1">
                {/* Capabilities */}
                <div>
                  <p className="text-gray-600 text-sm mb-2">Capabilities</p>
                  <div className="flex flex-wrap gap-2">
                    {template.supportsDynamic && (
                      <span className="bg-blue-50 text-blue-700 px-2 py-1 rounded text-xs">
                        Dynamic Parameters
                      </span>
                    )}
                  </div>
                </div>

                {/* Channels */}
                <div>
                  <p className="text-gray-600 text-sm mb-2">Supported Channels</p>
                  <div className="flex flex-wrap gap-2">
                    {template.channels.map((channel) => (
                      <span key={channel} className="bg-gray-100 text-gray-700 px-2 py-1 rounded text-xs capitalize">
                        {channel}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Usage */}
                <div className="pt-3 border-t border-gray-200">
                  <p className="text-gray-600 text-sm">
                    Used in <span className="text-gray-900">{template.usageCount}</span> active messages
                  </p>
                </div>
              </div>

              {/* Actions */}
              <div className="px-6 py-4 bg-gray-50 border-t border-gray-200 flex items-center justify-between mt-auto">
                <button 
                  className="text-blue-600 hover:text-blue-800 flex items-center gap-1 text-sm"
                  onClick={() => setPreviewTemplate(template)}
                >
                  <Eye className="w-4 h-4" />
                  Preview
                </button>
                <div className="flex items-center gap-2">
                  <button className="text-gray-600 hover:text-gray-800" onClick={() => handleEditTemplate(template.id)}>
                    <Edit className="w-4 h-4" />
                  </button>
                  <button className="text-gray-600 hover:text-gray-800" onClick={() => handleDuplicateTemplate(template.id)}>
                    <Copy className="w-4 h-4" />
                  </button>
                  <button className="text-gray-600 hover:text-gray-800" onClick={() => handleDeleteTemplate(template.id)}>
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="text-left px-6 py-3 text-gray-600">Name</th>
                <th className="text-left px-6 py-3 text-gray-600">Description</th>
                <th className="text-left px-6 py-3 text-gray-600">Usage</th>
                <th className="text-left px-6 py-3 text-gray-600">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {filteredTemplates.map((template) => (
                <tr key={template.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4">
                    <p className="text-gray-900">{template.name}</p>
                  </td>
                  <td className="px-6 py-4">
                    <p className="text-gray-600 text-sm">{template.description}</p>
                  </td>
                  <td className="px-6 py-4">
                    <p className="text-gray-900">{template.usageCount}</p>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <button 
                        className="text-purple-900 hover:text-purple-950"
                        onClick={() => setPreviewTemplate(template)}
                        title="Preview"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                      <button className="text-purple-900 hover:text-purple-950" title="Edit" onClick={() => handleEditTemplate(template.id)}>
                        <Edit className="w-4 h-4" />
                      </button>
                      <button className="text-purple-900 hover:text-purple-950" title="Duplicate" onClick={() => handleDuplicateTemplate(template.id)}>
                        <Copy className="w-4 h-4" />
                      </button>
                      <button className="text-purple-900 hover:text-purple-950" title="Delete" onClick={() => handleDeleteTemplate(template.id)}>
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Create Template Dialog */}
      <CreateTemplateDialog
        open={showCreateDialog}
        onClose={() => setShowCreateDialog(false)}
        brandingLogo={brandingLogo}
        onSubmit={(data) => {
          // Create new template with generated ID
          const newTemplate: Template = {
            id: String(templates.length + 1),
            name: data.name,
            type: data.type as Template['type'],
            division: data.division,
            supportsDynamic: data.supportsDynamic,
            channels: data.channels,
            usageCount: 0,
            showHeader: data.showHeader,
            showDescription: data.showDescription,
            showBody: data.showBody,
            showButton1: data.showButton1,
            showButton2: data.showButton2,
            showLogo: data.showLogo,
            logoPosition: data.logoPosition
          };
          
          // Add to templates list
          setTemplates([...templates, newTemplate]);
          setShowCreateDialog(false);
        }}
      />

      {/* Create Template Dialog PRO */}
      <CreateTemplateDialogPro
        key={editingTemplate ? `edit-${editingTemplate.id}` : 'template-creation-dialog'}
        open={showCreateDialogPro}
        onClose={() => {
          setShowCreateDialogPro(false);
          setEditingTemplate(null);
        }}
        editingTemplate={editingTemplate}
        brandingLogos={brandingLogo ? [brandingLogo] : [
          {
            id: 'default-1',
            name: 'Riverbed Logo Purple',
            preview: '<svg width="120" height="40" xmlns="http://www.w3.org/2000/svg"><rect width="120" height="40" fill="#7C3AED"/><text x="60" y="25" font-family="Arial" font-size="14" fill="white" text-anchor="middle">Riverbed</text></svg>',
            type: 'svg' as const
          },
          {
            id: 'default-2',
            name: 'Riverbed Logo Dark',
            preview: '<svg width="120" height="40" xmlns="http://www.w3.org/2000/svg"><rect width="120" height="40" fill="#1F2937"/><text x="60" y="25" font-family="Arial" font-size="14" fill="white" text-anchor="middle">Riverbed</text></svg>',
            type: 'svg' as const
          },
          {
            id: 'default-3',
            name: 'Riverbed Logo White',
            preview: '<svg width="120" height="40" xmlns="http://www.w3.org/2000/svg"><rect width="120" height="40" fill="white" stroke="#E5E7EB" stroke-width="2"/><text x="60" y="25" font-family="Arial" font-size="14" fill="#1F2937" text-anchor="middle">Riverbed</text></svg>',
            type: 'svg' as const
          }
        ]}
        themes={[
          {
            id: 'theme-1',
            name: 'Default Purple',
            profile: 'default',
            logos: [
              {
                id: 'default-logo-1',
                name: 'Purple Primary',
                preview: '<svg width="120" height="40" xmlns="http://www.w3.org/2000/svg"><rect width="120" height="40" fill="#7C3AED"/><text x="60" y="25" font-family="Arial" font-size="14" fill="white" text-anchor="middle">Riverbed</text></svg>',
                type: 'svg' as const
              },
              {
                id: 'default-logo-2',
                name: 'Purple Dark',
                preview: '<svg width="120" height="40" xmlns="http://www.w3.org/2000/svg"><rect width="120" height="40" fill="#581c87"/><text x="60" y="25" font-family="Arial" font-size="14" fill="white" text-anchor="middle">Riverbed</text></svg>',
                type: 'svg' as const
              },
              {
                id: 'default-logo-3',
                name: 'Purple Light',
                preview: '<svg width="120" height="40" xmlns="http://www.w3.org/2000/svg"><rect width="120" height="40" fill="#a78bfa"/><text x="60" y="25" font-family="Arial" font-size="14" fill="white" text-anchor="middle">Riverbed</text></svg>',
                type: 'svg' as const
              }
            ]
          },
          {
            id: 'theme-2',
            name: 'Security Red',
            profile: 'security',
            logos: [
              {
                id: 'security-logo-1',
                name: 'Security Red Primary',
                preview: '<svg width="120" height="40" xmlns="http://www.w3.org/2000/svg"><rect width="120" height="40" fill="#DC2626"/><text x="60" y="25" font-family="Arial" font-size="14" fill="white" text-anchor="middle">Security</text></svg>',
                type: 'svg' as const
              },
              {
                id: 'security-logo-2',
                name: 'Security Orange',
                preview: '<svg width="120" height="40" xmlns="http://www.w3.org/2000/svg"><rect width="120" height="40" fill="#F59E0B"/><text x="60" y="25" font-family="Arial" font-size="14" fill="white" text-anchor="middle">Security</text></svg>',
                type: 'svg' as const
              }
            ]
          },
          {
            id: 'theme-3',
            name: 'IT Blue',
            profile: 'it',
            logos: [
              {
                id: 'it-logo-1',
                name: 'IT Blue Primary',
                preview: '<svg width="120" height="40" xmlns="http://www.w3.org/2000/svg"><rect width="120" height="40" fill="#2563EB"/><text x="60" y="25" font-family="Arial" font-size="14" fill="white" text-anchor="middle">IT Services</text></svg>',
                type: 'svg' as const
              },
              {
                id: 'it-logo-2',
                name: 'IT Cyan',
                preview: '<svg width="120" height="40" xmlns="http://www.w3.org/2000/svg"><rect width="120" height="40" fill="#06B6D4"/><text x="60" y="25" font-family="Arial" font-size="14" fill="white" text-anchor="middle">IT Services</text></svg>',
                type: 'svg' as const
              },
              {
                id: 'it-logo-3',
                name: 'IT Navy',
                preview: '<svg width="120" height="40" xmlns="http://www.w3.org/2000/svg"><rect width="120" height="40" fill="#1E3A8A"/><text x="60" y="25" font-family="Arial" font-size="14" fill="white" text-anchor="middle">IT Services</text></svg>',
                type: 'svg' as const
              }
            ]
          },
          {
            id: 'theme-4',
            name: 'HR Green',
            profile: 'hr',
            logos: [
              {
                id: 'hr-logo-1',
                name: 'HR Green Primary',
                preview: '<svg width="120" height="40" xmlns="http://www.w3.org/2000/svg"><rect width="120" height="40" fill="#16A34A"/><text x="60" y="25" font-family="Arial" font-size="14" fill="white" text-anchor="middle">HR</text></svg>',
                type: 'svg' as const
              },
              {
                id: 'hr-logo-2',
                name: 'HR Teal',
                preview: '<svg width="120" height="40" xmlns="http://www.w3.org/2000/svg"><rect width="120" height="40" fill="#14B8A6"/><text x="60" y="25" font-family="Arial" font-size="14" fill="white" text-anchor="middle">HR</text></svg>',
                type: 'svg' as const
              }
            ]
          }
        ]}
        onSubmit={(data) => {
          if (editingTemplate) {
            // Update existing template
            const updatedTemplates = templates.map(t =>
              t.id === editingTemplate.id
                ? {
                    ...t,
                    name: data.name,
                    description: data.description,
                    type: data.type as Template['type'],
                    supportsDynamic: data.supportsDynamic,
                    channels: data.channels,
                    showHeader: data.showHeader,
                    showDescription: data.showDescription,
                    showBody: data.showBody,
                    showButton1: data.showButton1,
                    showButton2: data.showButton2,
                    showLogo: data.showLogo,
                    logoPosition: data.logoPosition,
                    title: data.title,
                    messageDescription: data.messageDescription,
                    body: data.body,
                    buttonPrimary: data.buttonPrimary,
                    buttonSecondary: data.buttonSecondary,
                    brandingProfile: data.brandingProfile,
                    button1Type: data.button1Type,
                    button2Type: data.button2Type,
                    buttonAlignment: data.buttonAlignment
                  }
                : t
            );
            setTemplates(updatedTemplates);
            setEditingTemplate(null);
          } else {
            // Create new template with generated ID
            const newTemplate: Template = {
              id: String(templates.length + 1),
              name: data.name,
              description: data.description,
              type: data.type as Template['type'],
              division: 'Corporate',
              supportsDynamic: data.supportsDynamic,
              channels: data.channels,
              usageCount: 0,
              source: 'custom',
              showHeader: data.showHeader,
              showDescription: data.showDescription,
              showBody: data.showBody,
              showButton1: data.showButton1,
              showButton2: data.showButton2,
              showLogo: data.showLogo,
              logoPosition: data.logoPosition,
              title: data.title,
              messageDescription: data.messageDescription,
              body: data.body,
              buttonPrimary: data.buttonPrimary,
              buttonSecondary: data.buttonSecondary,
              brandingProfile: data.brandingProfile,
              button1Type: data.button1Type,
              button2Type: data.button2Type,
              buttonAlignment: data.buttonAlignment
            };
            
            // Add to templates list
            setTemplates([...templates, newTemplate]);
          }
          setShowCreateDialogPro(false);
        }}
      />

      {/* Preview Template Dialog */}
      <PreviewTemplateDialog
        open={previewTemplate !== null}
        onClose={() => setPreviewTemplate(null)}
        template={previewTemplate}
        brandingLogo={brandingLogo}
      />
    </div>
  );
}