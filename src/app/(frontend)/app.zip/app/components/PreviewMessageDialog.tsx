import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';
import { X, Clock, Users } from 'lucide-react';
import { Message } from './MessagesOverview';
import { Template } from './TemplateManager';
import { BrandingLogo } from './UnifiedCommunicationPlatform';

interface PreviewMessageDialogProps {
  open: boolean;
  onClose: () => void;
  message: Message | null;
  templates?: Template[];
  brandingLogo?: BrandingLogo | null;
}

export function PreviewMessageDialog({ open, onClose, message, templates = [], brandingLogo = null }: PreviewMessageDialogProps) {
  const [activeTab, setActiveTab] = useState<'preview' | 'history'>('preview');
  
  if (!message) return null;

  // Find the template for this message
  const template = templates.find(t => t.id === message.templateId || t.name === message.template);

  // Format date helper
  const formatDate = (date: Date | string) => {
    const d = typeof date === 'string' ? new Date(date) : date;
    return d.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // Render template-based message preview
  const renderTemplateBasedMessage = () => {
    if (!template) {
      // Fallback if template not found
      return (
        <div className="bg-white rounded-lg shadow-lg max-w-md mx-auto p-6 space-y-4">
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <h3 className="text-gray-900 mb-2">{message.messageTitle || message.name}</h3>
              <p className="text-sm text-gray-700">
                {message.messageContent || message.messageDescription || 'No content available'}
              </p>
            </div>
            <button className="text-gray-400 hover:text-gray-600 p-1" onClick={onClose}>
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>
      );
    }

    // Get the logo to use - template's custom logo or global branding logo
    const logoToUse = template.customLogo || brandingLogo;

    // Use message's own display settings if available, otherwise fall back to template
    const displaySettings = {
      showLogo: message.showLogo !== undefined ? message.showLogo : template.showLogo,
      logoPosition: message.logoPosition || template.logoPosition,
      showHeader: message.showHeader !== undefined ? message.showHeader : template.showHeader,
      showDescription: message.showDescription !== undefined ? message.showDescription : template.showDescription,
      showBody: message.showBody !== undefined ? message.showBody : template.showBody,
      showButton1: message.showButton1 !== undefined ? message.showButton1 : template.showButton1,
      showButton2: message.showButton2 !== undefined ? message.showButton2 : template.showButton2,
      showButton3: message.showButton3 !== undefined ? message.showButton3 : template.showButton3,
      button1Type: message.button1Type || template.button1Type,
      button2Type: message.button2Type || template.button2Type,
      button3Type: message.button3Type || template.button3Type,
      buttonAlignment: template.buttonAlignment,
    };

    return (
      <div className="bg-white rounded-lg shadow-lg max-w-md mx-auto p-6 space-y-4 border border-gray-300 border-t-4 border-t-purple-900">
        {/* Logo - Top Position */}
        {displaySettings.showLogo && (displaySettings.logoPosition === 'top-left' || displaySettings.logoPosition === 'top-center' || displaySettings.logoPosition === 'top-right') && logoToUse && (
          <div className={`flex mb-3 ${
            displaySettings.logoPosition === 'top-center' ? 'justify-center' :
            displaySettings.logoPosition === 'top-right' ? 'justify-end' :
            'justify-start'
          }`}>
            {logoToUse.type === 'svg' ? (
              <div dangerouslySetInnerHTML={{ __html: logoToUse.preview }} className="max-h-10" />
            ) : (
              <img src={logoToUse.preview} alt="Logo" className="max-h-10" />
            )}
          </div>
        )}

        {/* Center Logo Positions - Side-by-side layout */}
        {displaySettings.showLogo && (displaySettings.logoPosition === 'center-left' || displaySettings.logoPosition === 'center-right') && logoToUse ? (
          <div className={`flex gap-4 items-start ${
            displaySettings.logoPosition === 'center-right' ? 'flex-row-reverse' : ''
          }`}>
            <div className="flex-shrink-0">
              {logoToUse.type === 'svg' ? (
                <div dangerouslySetInnerHTML={{ __html: logoToUse.preview }} className="max-h-10" />
              ) : (
                <img src={logoToUse.preview} alt="Logo" className="max-h-10" />
              )}
            </div>
            <div className="flex-1 space-y-3">
              {/* Title */}
              {displaySettings.showHeader && (
                <h3 className="text-purple-900 font-bold text-lg">
                  {message.messageTitle || template.title || 'Message Title'}
                </h3>
              )}

              {/* Description */}
              {displaySettings.showDescription && message.messageDescription && (
                <p className="text-gray-600 text-sm italic">
                  {message.messageDescription}
                </p>
              )}

              {/* Body */}
              {displaySettings.showBody && (
                <p className="text-gray-700 text-sm">
                  {message.messageContent || template.body || 'Message content'}
                </p>
              )}

              {/* Buttons */}
              {(displaySettings.showButton1 || displaySettings.showButton2 || displaySettings.showButton3) && (
                <div className={`flex gap-2 pt-2 border-t border-gray-200 ${
                  displaySettings.buttonAlignment === 'center' ? 'justify-center' :
                  displaySettings.buttonAlignment === 'right' ? 'justify-end' :
                  ''
                }`}>
                  {displaySettings.showButton1 && (
                    <button className={`px-4 py-2 rounded-lg text-sm ${
                      displaySettings.button1Type === 'primary' ? 'bg-purple-900 text-white hover:bg-purple-950' :
                      displaySettings.button1Type === 'secondary' ? 'border border-gray-300 text-gray-700 hover:bg-gray-50' :
                      'text-gray-600 hover:bg-gray-50'
                    }`}>
                      {message.buttonPrimary || template.buttonPrimary || 'Button 1'}
                    </button>
                  )}
                  {displaySettings.showButton2 && (
                    <button className={`px-4 py-2 rounded-lg text-sm ${
                      displaySettings.button2Type === 'primary' ? 'bg-purple-900 text-white hover:bg-purple-950' :
                      displaySettings.button2Type === 'secondary' ? 'border border-gray-300 text-gray-700 hover:bg-gray-50' :
                      'text-gray-600 hover:bg-gray-50'
                    }`}>
                      {message.buttonSecondary || template.buttonSecondary || 'Button 2'}
                    </button>
                  )}
                  {displaySettings.showButton3 && (
                    <button className={`px-4 py-2 rounded-lg text-sm ${
                      displaySettings.button3Type === 'primary' ? 'bg-purple-900 text-white hover:bg-purple-950' :
                      displaySettings.button3Type === 'secondary' ? 'border border-gray-300 text-gray-700 hover:bg-gray-50' :
                      'text-gray-600 hover:bg-gray-50'
                    }`}>
                      {message.buttonTertiary || template.buttonTertiary || 'Button 3'}
                    </button>
                  )}
                </div>
              )}
            </div>
          </div>
        ) : (
          <>
            {/* Title */}
            {displaySettings.showHeader && (
              <h3 className="text-purple-900 font-bold text-lg pr-8">
                {message.messageTitle || template.title || 'Message Title'}
              </h3>
            )}

            {/* Description */}
            {displaySettings.showDescription && message.messageDescription && (
              <p className="text-gray-600 text-sm italic">
                {message.messageDescription}
              </p>
            )}

            {/* Body */}
            {displaySettings.showBody && (
              <p className="text-gray-700 text-sm">
                {message.messageContent || template.body || 'Message content'}
              </p>
            )}

            {/* Buttons */}
            {(displaySettings.showButton1 || displaySettings.showButton2 || displaySettings.showButton3) && (
              <div className={`flex gap-2 pt-2 border-t border-gray-200 ${
                displaySettings.buttonAlignment === 'center' ? 'justify-center' :
                displaySettings.buttonAlignment === 'right' ? 'justify-end' :
                ''
              }`}>
                {displaySettings.showButton1 && (
                  <button className={`px-4 py-2 rounded-lg text-sm ${
                    displaySettings.button1Type === 'primary' ? 'bg-purple-900 text-white hover:bg-purple-950' :
                    displaySettings.button1Type === 'secondary' ? 'border border-gray-300 text-gray-700 hover:bg-gray-50' :
                    'text-gray-600 hover:bg-gray-50'
                  }`}>
                    {message.buttonPrimary || template.buttonPrimary || 'Button 1'}
                  </button>
                )}
                {displaySettings.showButton2 && (
                  <button className={`px-4 py-2 rounded-lg text-sm ${
                    displaySettings.button2Type === 'primary' ? 'bg-purple-900 text-white hover:bg-purple-950' :
                    displaySettings.button2Type === 'secondary' ? 'border border-gray-300 text-gray-700 hover:bg-gray-50' :
                    'text-gray-600 hover:bg-gray-50'
                  }`}>
                    {message.buttonSecondary || template.buttonSecondary || 'Button 2'}
                  </button>
                )}
                {displaySettings.showButton3 && (
                  <button className={`px-4 py-2 rounded-lg text-sm ${
                    displaySettings.button3Type === 'primary' ? 'bg-purple-900 text-white hover:bg-purple-950' :
                    displaySettings.button3Type === 'secondary' ? 'border border-gray-300 text-gray-700 hover:bg-gray-50' :
                    'text-gray-600 hover:bg-gray-50'
                  }`}>
                    {message.buttonTertiary || template.buttonTertiary || 'Button 3'}
                  </button>
                )}
              </div>
            )}
          </>
        )}

        {/* Logo - Bottom Position */}
        {displaySettings.showLogo && displaySettings.logoPosition?.startsWith('bottom-') && logoToUse && (
          <div className={`flex mt-3 ${
            displaySettings.logoPosition === 'bottom-center' ? 'justify-center' :
            displaySettings.logoPosition === 'bottom-right' ? 'justify-end' :
            'justify-start'
          }`}>
            {logoToUse.type === 'svg' ? (
              <div dangerouslySetInnerHTML={{ __html: logoToUse.preview }} className="max-h-10" />
            ) : (
              <img src={logoToUse.preview} alt="Logo" className="max-h-10" />
            )}
          </div>
        )}
      </div>
    );
  };

  // Render broadcast history tab
  const renderBroadcastHistory = () => {
    const history = message.broadcastHistory || [];

    if (history.length === 0) {
      return (
        <div className="flex flex-col items-center justify-center py-12 text-gray-500">
          <Clock className="w-12 h-12 mb-3 text-gray-400" />
          <p className="text-sm">No broadcast history yet</p>
          <p className="text-xs mt-1">Click the Send button to broadcast this message</p>
        </div>
      );
    }

    return (
      <div className="space-y-3">
        {history.map((record) => {
          const createdDate = typeof record.createdAt === 'string' ? new Date(record.createdAt) : record.createdAt;
          const expiresDate = typeof record.expiresAt === 'string' ? new Date(record.expiresAt) : record.expiresAt;
          const isExpired = expiresDate < new Date();

          return (
            <div 
              key={record.id} 
              className="bg-white border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow"
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4 text-purple-900" />
                  <span className="font-medium text-gray-900">{record.targetAudience}</span>
                </div>
                <span className={`px-2 py-1 rounded text-xs ${
                  isExpired ? 'bg-gray-100 text-gray-600' : 'bg-green-100 text-green-700'
                }`}>
                  {isExpired ? 'Expired' : 'Active'}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <p className="text-gray-500 text-xs mb-1">Sent On</p>
                  <p className="text-gray-900">{formatDate(createdDate)}</p>
                </div>
                <div>
                  <p className="text-gray-500 text-xs mb-1">Expires On</p>
                  <p className="text-gray-900">{formatDate(expiresDate)}</p>
                </div>
              </div>

              <div className="mt-3 pt-3 border-t border-gray-200">
                <p className="text-xs text-gray-500">
                  Duration: {record.expirationValue} {record.expirationUnit}
                </p>
              </div>
            </div>
          );
        })}
      </div>
    );
  };

  return (
    <Dialog open={open} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="text-gray-900">Message Details</DialogTitle>
          <DialogDescription className="text-gray-600">
            {message.name}
          </DialogDescription>
        </DialogHeader>

        {/* Tabs */}
        <div className="flex border-b border-gray-200 mb-4">
          <button
            onClick={() => setActiveTab('preview')}
            className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${
              activeTab === 'preview'
                ? 'border-purple-900 text-purple-900'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            Preview
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${
              activeTab === 'history'
                ? 'border-purple-900 text-purple-900'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            Broadcast History
            {message.broadcastHistory && message.broadcastHistory.length > 0 && (
              <span className="ml-2 px-2 py-0.5 bg-purple-100 text-purple-900 rounded-full text-xs">
                {message.broadcastHistory.length}
              </span>
            )}
          </button>
        </div>

        {/* Tab Content */}
        <div className="min-h-[300px]">
          {activeTab === 'preview' ? (
            <div className="bg-gray-100 p-8 rounded-lg">
              {renderTemplateBasedMessage()}
            </div>
          ) : (
            <div className="max-h-[400px] overflow-y-auto">
              {renderBroadcastHistory()}
            </div>
          )}
        </div>

        <div className="flex justify-end mt-4">
          <button 
            onClick={onClose}
            className="px-4 py-2 bg-purple-900 text-white rounded-lg hover:bg-purple-950 transition-colors"
          >
            Close
          </button>
        </div>
      </DialogContent>
    </Dialog>
  );
}