import { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from './ui/dialog';
import { Label } from './ui/label';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { MessageType, Channel, DeliveryMode, Message } from './MessagesOverview';
import { MessageSquare, Settings, Eye } from 'lucide-react';
import { Template } from './TemplateManager';
import { BrandingLogo } from './UnifiedCommunicationPlatform';

interface CreateMessageDialogNewProps {
  open: boolean;
  onClose: () => void;
  onSubmit?: (messageData: any) => void;
  templates?: Template[];
  brandingLogo?: BrandingLogo | null;
  editMessage?: Message | null;
}

export function CreateMessageDialogNew({ 
  open, 
  onClose, 
  onSubmit,
  templates = [], 
  brandingLogo = null,
  editMessage = null
}: CreateMessageDialogNewProps) {
  const [currentStep, setCurrentStep] = useState(1);
  const [selectedTemplate, setSelectedTemplate] = useState<Template | null>(null);
  
  // Form data
  const [formData, setFormData] = useState({
    name: '',
    type: 'notification' as MessageType,
    templateId: '',
    // Message content
    title: '',
    description: '',
    body: '',
    // Buttons
    buttonPrimary: '',
    buttonSecondary: '',
    buttonTertiary: '',
    // Defaults
    channel: 'riverbed' as Channel,
    deliveryMode: 'non-intrusive' as DeliveryMode,
    targetGroup: 'All Users',
  });

  const totalSteps = 2;

  // Pre-fill form when editing
  useEffect(() => {
    if (editMessage && open) {
      setFormData({
        name: editMessage.name,
        type: editMessage.type,
        templateId: editMessage.templateId || '',
        title: editMessage.messageTitle || '',
        description: editMessage.messageDescription || '',
        body: editMessage.messageContent || '',
        buttonPrimary: editMessage.buttonPrimary || '',
        buttonSecondary: editMessage.buttonSecondary || '',
        buttonTertiary: editMessage.buttonTertiary || '',
        channel: editMessage.channel,
        deliveryMode: editMessage.deliveryMode,
        targetGroup: editMessage.targetGroup,
      });

      // Set the selected template
      if (editMessage.templateId) {
        const template = templates.find(t => t.id === editMessage.templateId);
        if (template) {
          setSelectedTemplate(template);
        }
      }
    } else if (!open) {
      // Reset when dialog closes
      setFormData({
        name: '',
        type: 'notification',
        templateId: '',
        title: '',
        description: '',
        body: '',
        buttonPrimary: '',
        buttonSecondary: '',
        buttonTertiary: '',
        channel: 'riverbed',
        deliveryMode: 'non-intrusive',
        targetGroup: 'All Users',
      });
      setSelectedTemplate(null);
      setCurrentStep(1);
    }
  }, [editMessage, open, templates]);

  const handleChange = (field: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));

    // When message type changes, reset template selection
    if (field === 'type') {
      setFormData(prev => ({
        ...prev,
        templateId: '',
      }));
      setSelectedTemplate(null);
    }

    // When template is selected, populate button defaults
    if (field === 'templateId' && value) {
      const template = templates.find(t => t.id === value);
      if (template) {
        setSelectedTemplate(template);
        setFormData(prev => ({
          ...prev,
          buttonPrimary: template.buttonPrimary || '',
          buttonSecondary: template.buttonSecondary || '',
          buttonTertiary: template.buttonTertiary || '',
        }));
      }
    }
  };

  const handleSubmit = () => {
    const messageData = {
      id: Date.now().toString(),
      name: formData.name,
      type: formData.type,
      channel: formData.channel,
      deliveryMode: formData.deliveryMode,
      template: selectedTemplate?.name || '',
      templateId: selectedTemplate?.id || '',
      targetGroup: formData.targetGroup,
      status: 'active' as const,
      sent: 0,
      acknowledged: 0,
      createdAt: new Date(),
      createdBy: 'Current User',
      hasInteractiveFlow: false,
      requiresResponse: false,
      // Content
      messageTitle: formData.title,
      messageContent: formData.body,
      messageDescription: formData.description,
      // Buttons
      buttonPrimary: formData.buttonPrimary,
      buttonSecondary: formData.buttonSecondary,
      buttonTertiary: formData.buttonTertiary,
      // Template display configuration from selected template
      showLogo: selectedTemplate?.showLogo,
      logoPosition: selectedTemplate?.logoPosition,
      showHeader: selectedTemplate?.showHeader,
      showDescription: selectedTemplate?.showDescription,
      showBody: selectedTemplate?.showBody,
      showButton1: selectedTemplate?.showButton1,
      showButton2: selectedTemplate?.showButton2,
      showButton3: selectedTemplate?.showButton3,
      button1Type: selectedTemplate?.button1Type,
      button2Type: selectedTemplate?.button2Type,
      button3Type: selectedTemplate?.button3Type,
      customCSS: selectedTemplate?.customCSS,
      brandingProfile: selectedTemplate?.brandingProfile,
    };

    if (onSubmit) {
      onSubmit(messageData);
    }
    
    // Reset form
    setFormData({
      name: '',
      type: 'notification',
      templateId: '',
      title: '',
      description: '',
      body: '',
      buttonPrimary: '',
      buttonSecondary: '',
      buttonTertiary: '',
      channel: 'riverbed',
      deliveryMode: 'non-intrusive',
      targetGroup: 'All Users',
    });
    setSelectedTemplate(null);
    setCurrentStep(1);
    onClose();
  };

  const isStepValid = () => {
    if (currentStep === 1) {
      return formData.name.trim() !== '' && formData.type !== '' && formData.templateId !== '';
    }
    if (currentStep === 2) {
      // Check if at least the required template fields are filled
      if (selectedTemplate?.showHeader && !formData.title.trim()) return false;
      if (selectedTemplate?.showBody && !formData.body.trim()) return false;
      return true;
    }
    return false;
  };

  const filteredTemplates = templates.filter(t => t.type === formData.type);

  if (!open) return null;

  return (
    <Dialog open={open} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-gray-900 flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-purple-900" />
            {editMessage ? 'Edit Message' : 'Create Message'}
          </DialogTitle>
          <DialogDescription className="text-gray-600">
            {editMessage 
              ? 'Update your message content and settings' 
              : 'Create a new message using a template with predefined branding and layout'}
          </DialogDescription>
        </DialogHeader>

        {/* Progress Indicator */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            {[1, 2].map((step) => (
              <div key={step} className="flex items-center flex-1">
                <div className={`flex items-center justify-center w-8 h-8 rounded-full ${
                  currentStep >= step ? 'bg-purple-900 text-white' : 'bg-gray-200 text-gray-600'
                }`}>
                  {step}
                </div>
                <div className="flex-1 ml-2">
                  <div className="text-xs font-medium text-gray-900">
                    {step === 1 && 'Basic Info & Template'}
                    {step === 2 && 'Message Content'}
                  </div>
                </div>
                {step < totalSteps && (
                  <div className={`flex-1 h-0.5 mx-2 ${
                    currentStep > step ? 'bg-purple-900' : 'bg-gray-200'
                  }`} />
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Step Content */}
        <div className="space-y-4">
          {/* Step 1: Basic Configuration & Template Selection */}
          {currentStep === 1 && (
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-gray-900 mb-4">
                <MessageSquare className="w-5 h-5 text-purple-900" />
                <h3>Basic Configuration</h3>
              </div>

              <div className="space-y-2">
                <Label htmlFor="name">Name *</Label>
                <Input
                  id="name"
                  placeholder="e.g., Network Issue Notification"
                  value={formData.name}
                  onChange={(e) => handleChange('name', e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="type">Message Type *</Label>
                <select
                  id="type"
                  value={formData.type}
                  onChange={(e) => handleChange('type', e.target.value as MessageType)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                >
                  <option value="survey">Survey</option>
                  <option value="confirmation">Confirmation</option>
                  <option value="notification">Notification</option>
                  <option value="reminder">Reminder</option>
                  <option value="self-service">Self-Service</option>
                </select>
              </div>

              {/* Template Selector */}
              <div className="space-y-2">
                <Label htmlFor="template">Select Template *</Label>
                <select
                  id="template"
                  value={formData.templateId}
                  onChange={(e) => handleChange('templateId', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  disabled={filteredTemplates.length === 0}
                >
                  <option value="">-- Select a template --</option>
                  {filteredTemplates.map(template => (
                    <option key={template.id} value={template.id}>
                      {template.name} {template.description ? `- ${template.description}` : ''}
                    </option>
                  ))}
                </select>
                {filteredTemplates.length === 0 && (
                  <p className="text-xs text-red-600">
                    No templates available for {formData.type} messages. Please create a template first.
                  </p>
                )}
                {selectedTemplate && (
                  <div className="mt-3 p-3 bg-purple-50 border border-purple-200 rounded-lg">
                    <p className="text-sm text-purple-900">
                      <strong>Template:</strong> {selectedTemplate.name}
                    </p>
                    {selectedTemplate.description && (
                      <p className="text-xs text-purple-700 mt-1">
                        {selectedTemplate.description}
                      </p>
                    )}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Step 2: Message Content */}
          {currentStep === 2 && selectedTemplate && (
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-gray-900 mb-4">
                <Settings className="w-5 h-5 text-purple-900" />
                <h3>Message Content</h3>
              </div>

              <div className="grid grid-cols-2 gap-6">
                {/* Content Form */}
                <div className="space-y-4">
                  {/* Title */}
                  {selectedTemplate.showHeader && (
                    <div className="space-y-2">
                      <Label htmlFor="title">Title *</Label>
                      <Input
                        id="title"
                        placeholder={selectedTemplate.title || "Enter message title"}
                        value={formData.title}
                        onChange={(e) => handleChange('title', e.target.value)}
                      />
                    </div>
                  )}

                  {/* Description */}
                  {selectedTemplate.showDescription && (
                    <div className="space-y-2">
                      <Label htmlFor="description">Description</Label>
                      <Textarea
                        id="description"
                        placeholder={selectedTemplate.messageDescription || "Enter message description"}
                        value={formData.description}
                        onChange={(e) => handleChange('description', e.target.value)}
                        rows={3}
                      />
                    </div>
                  )}

                  {/* Body */}
                  {selectedTemplate.showBody && (
                    <div className="space-y-2">
                      <Label htmlFor="body">Body *</Label>
                      <Textarea
                        id="body"
                        placeholder={selectedTemplate.body || "Enter message body"}
                        value={formData.body}
                        onChange={(e) => handleChange('body', e.target.value)}
                        rows={5}
                      />
                    </div>
                  )}

                  {/* Action Buttons */}
                  {(selectedTemplate.showButton1 || selectedTemplate.showButton2 || selectedTemplate.showButton3) && (
                    <div className="space-y-3 pt-4 border-t border-gray-200">
                      <Label className="text-gray-900">Action Buttons</Label>
                      
                      {selectedTemplate.showButton1 && (
                        <div className="space-y-1">
                          <Label htmlFor="button1" className="text-sm text-gray-600">Primary Button</Label>
                          <Input
                            id="button1"
                            placeholder={selectedTemplate.buttonPrimary || "Button 1 text"}
                            value={formData.buttonPrimary}
                            onChange={(e) => handleChange('buttonPrimary', e.target.value)}
                          />
                        </div>
                      )}

                      {selectedTemplate.showButton2 && (
                        <div className="space-y-1">
                          <Label htmlFor="button2" className="text-sm text-gray-600">Secondary Button</Label>
                          <Input
                            id="button2"
                            placeholder={selectedTemplate.buttonSecondary || "Button 2 text"}
                            value={formData.buttonSecondary}
                            onChange={(e) => handleChange('buttonSecondary', e.target.value)}
                          />
                        </div>
                      )}

                      {selectedTemplate.showButton3 && (
                        <div className="space-y-1">
                          <Label htmlFor="button3" className="text-sm text-gray-600">Tertiary Button</Label>
                          <Input
                            id="button3"
                            placeholder={selectedTemplate.buttonTertiary || "Button 3 text"}
                            value={formData.buttonTertiary}
                            onChange={(e) => handleChange('buttonTertiary', e.target.value)}
                          />
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* Live Preview */}
                <div className="space-y-2">
                  <div className="flex items-center gap-2 mb-2">
                    <Eye className="w-4 h-4 text-purple-900" />
                    <Label className="text-gray-900">Live Preview</Label>
                  </div>
                  
                  <div className="border-2 border-purple-200 rounded-lg p-4 bg-purple-50/50">
                    <div className="bg-white rounded-lg shadow-lg border border-gray-300 border-t-4 border-t-purple-900 p-6 space-y-4">
                      {/* Logo - Top Position */}
                      {selectedTemplate.showLogo && (selectedTemplate.logoPosition === 'top-left' || selectedTemplate.logoPosition === 'top-center' || selectedTemplate.logoPosition === 'top-right') && (
                        <div className={`flex mb-3 ${
                          selectedTemplate.logoPosition === 'top-center' ? 'justify-center' :
                          selectedTemplate.logoPosition === 'top-right' ? 'justify-end' :
                          'justify-start'
                        }`}>
                          {brandingLogo ? (
                            brandingLogo.type === 'svg' ? (
                              <div dangerouslySetInnerHTML={{ __html: brandingLogo.preview }} className="max-h-10" />
                            ) : (
                              <img src={brandingLogo.preview} alt="Logo" className="max-h-10" />
                            )
                          ) : (
                            <div className="w-24 h-10 bg-purple-100 border-2 border-purple-300 rounded flex items-center justify-center">
                              <span className="text-xs text-purple-700">Logo</span>
                            </div>
                          )}
                        </div>
                      )}

                      {/* Center Logo Positions - Side-by-side layout */}
                      {selectedTemplate.showLogo && (selectedTemplate.logoPosition === 'center-left' || selectedTemplate.logoPosition === 'center-right') ? (
                        <div className={`flex gap-4 items-start ${
                          selectedTemplate.logoPosition === 'center-right' ? 'flex-row-reverse' : ''
                        }`}>
                          <div className="flex-shrink-0">
                            {brandingLogo ? (
                              brandingLogo.type === 'svg' ? (
                                <div dangerouslySetInnerHTML={{ __html: brandingLogo.preview }} className="max-h-10" />
                              ) : (
                                <img src={brandingLogo.preview} alt="Logo" className="max-h-10" />
                              )
                            ) : (
                              <div className="w-24 h-10 bg-purple-100 border-2 border-purple-300 rounded flex items-center justify-center">
                                <span className="text-xs text-purple-700">Logo</span>
                              </div>
                            )}
                          </div>
                          <div className="flex-1 space-y-3">
                            {/* Title */}
                            {selectedTemplate.showHeader && (
                              <h3 className="text-purple-900 font-bold text-lg">
                                {formData.title || selectedTemplate.title || 'Message Title'}
                              </h3>
                            )}

                            {/* Description */}
                            {selectedTemplate.showDescription && (
                              <p className="text-gray-600 text-sm italic">
                                {formData.description || selectedTemplate.messageDescription || 'Message description...'}
                              </p>
                            )}

                            {/* Body */}
                            {selectedTemplate.showBody && (
                              <p className="text-gray-700 text-sm">
                                {formData.body || selectedTemplate.body || 'Message body content...'}
                              </p>
                            )}

                            {/* Buttons */}
                            {(selectedTemplate.showButton1 || selectedTemplate.showButton2 || selectedTemplate.showButton3) && (
                              <div className={`flex gap-2 pt-2 border-t border-gray-200 ${
                                selectedTemplate.buttonAlignment === 'center' ? 'justify-center' :
                                selectedTemplate.buttonAlignment === 'right' ? 'justify-end' :
                                ''
                              }`}>
                                {selectedTemplate.showButton1 && (
                                  <button className={`px-4 py-2 rounded-lg text-sm ${
                                    selectedTemplate.button1Type === 'primary' ? 'bg-purple-900 text-white' :
                                    selectedTemplate.button1Type === 'secondary' ? 'border border-gray-300 text-gray-700' :
                                    'text-gray-600 hover:bg-gray-50'
                                  }`}>
                                    {formData.buttonPrimary || selectedTemplate.buttonPrimary || 'Button 1'}
                                  </button>
                                )}
                                {selectedTemplate.showButton2 && (
                                  <button className={`px-4 py-2 rounded-lg text-sm ${
                                    selectedTemplate.button2Type === 'primary' ? 'bg-purple-900 text-white' :
                                    selectedTemplate.button2Type === 'secondary' ? 'border border-gray-300 text-gray-700' :
                                    'text-gray-600 hover:bg-gray-50'
                                  }`}>
                                    {formData.buttonSecondary || selectedTemplate.buttonSecondary || 'Button 2'}
                                  </button>
                                )}
                                {selectedTemplate.showButton3 && (
                                  <button className={`px-4 py-2 rounded-lg text-sm ${
                                    selectedTemplate.button3Type === 'primary' ? 'bg-purple-900 text-white' :
                                    selectedTemplate.button3Type === 'secondary' ? 'border border-gray-300 text-gray-700' :
                                    'text-gray-600 hover:bg-gray-50'
                                  }`}>
                                    {formData.buttonTertiary || selectedTemplate.buttonTertiary || 'Button 3'}
                                  </button>
                                )}
                              </div>
                            )}
                          </div>
                        </div>
                      ) : (
                        <>
                          {/* Title */}
                          {selectedTemplate.showHeader && (
                            <h3 className="text-purple-900 font-bold text-lg">
                              {formData.title || selectedTemplate.title || 'Message Title'}
                            </h3>
                          )}

                          {/* Description */}
                          {selectedTemplate.showDescription && (
                            <p className="text-gray-600 text-sm italic">
                              {formData.description || selectedTemplate.messageDescription || 'Message description...'}
                            </p>
                          )}

                          {/* Body */}
                          {selectedTemplate.showBody && (
                            <p className="text-gray-700 text-sm">
                              {formData.body || selectedTemplate.body || 'Message body content...'}
                            </p>
                          )}

                          {/* Buttons */}
                          {(selectedTemplate.showButton1 || selectedTemplate.showButton2 || selectedTemplate.showButton3) && (
                            <div className={`flex gap-2 pt-2 border-t border-gray-200 ${
                              selectedTemplate.buttonAlignment === 'center' ? 'justify-center' :
                              selectedTemplate.buttonAlignment === 'right' ? 'justify-end' :
                              ''
                            }`}>
                              {selectedTemplate.showButton1 && (
                                <button className={`px-4 py-2 rounded-lg text-sm ${
                                  selectedTemplate.button1Type === 'primary' ? 'bg-purple-900 text-white' :
                                  selectedTemplate.button1Type === 'secondary' ? 'border border-gray-300 text-gray-700' :
                                  'text-gray-600 hover:bg-gray-50'
                                }`}>
                                  {formData.buttonPrimary || selectedTemplate.buttonPrimary || 'Button 1'}
                                </button>
                              )}
                              {selectedTemplate.showButton2 && (
                                <button className={`px-4 py-2 rounded-lg text-sm ${
                                  selectedTemplate.button2Type === 'primary' ? 'bg-purple-900 text-white' :
                                  selectedTemplate.button2Type === 'secondary' ? 'border border-gray-300 text-gray-700' :
                                  'text-gray-600 hover:bg-gray-50'
                                }`}>
                                  {formData.buttonSecondary || selectedTemplate.buttonSecondary || 'Button 2'}
                                </button>
                              )}
                              {selectedTemplate.showButton3 && (
                                <button className={`px-4 py-2 rounded-lg text-sm ${
                                  selectedTemplate.button3Type === 'primary' ? 'bg-purple-900 text-white' :
                                  selectedTemplate.button3Type === 'secondary' ? 'border border-gray-300 text-gray-700' :
                                  'text-gray-600 hover:bg-gray-50'
                                }`}>
                                  {formData.buttonTertiary || selectedTemplate.buttonTertiary || 'Button 3'}
                                </button>
                              )}
                            </div>
                          )}
                        </>
                      )}

                      {/* Logo - Bottom Position */}
                      {selectedTemplate.showLogo && selectedTemplate.logoPosition?.startsWith('bottom-') && (
                        <div className={`flex mt-3 ${
                          selectedTemplate.logoPosition === 'bottom-center' ? 'justify-center' :
                          selectedTemplate.logoPosition === 'bottom-right' ? 'justify-end' :
                          'justify-start'
                        }`}>
                          {brandingLogo ? (
                            brandingLogo.type === 'svg' ? (
                              <div dangerouslySetInnerHTML={{ __html: brandingLogo.preview }} className="max-h-10" />
                            ) : (
                              <img src={brandingLogo.preview} alt="Logo" className="max-h-10" />
                            )
                          ) : (
                            <div className="w-24 h-10 bg-purple-100 border-2 border-purple-300 rounded flex items-center justify-center">
                              <span className="text-xs text-purple-700">Logo</span>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Dialog Footer */}
        <DialogFooter className="flex justify-between items-center">
          <button
            onClick={onClose}
            className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
          >
            Cancel
          </button>
          
          <div className="flex gap-3">
            {currentStep > 1 && (
              <button
                onClick={() => setCurrentStep(prev => prev - 1)}
                className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Back
              </button>
            )}
            
            {currentStep < totalSteps ? (
              <button
                onClick={() => setCurrentStep(prev => prev + 1)}
                disabled={!isStepValid()}
                className="px-4 py-2 bg-purple-900 text-white rounded-lg hover:bg-purple-950 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Next
              </button>
            ) : (
              <button
                onClick={handleSubmit}
                disabled={!isStepValid()}
                className="px-4 py-2 bg-purple-900 text-white rounded-lg hover:bg-purple-950 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {editMessage ? 'Save Changes' : 'Create Message'}
              </button>
            )}
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}