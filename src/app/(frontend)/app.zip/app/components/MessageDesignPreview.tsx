import { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from './ui/dialog';
import { X } from 'lucide-react';
import riverbedLogo from "figma:asset/4b161716604143be2e292f585da4d73d4ab36bb3.png";
import Group2 from '../imports/Group';

interface MessageDesignPreviewProps {
  open: boolean;
  onClose: () => void;
}

export function MessageDesignPreview({ open, onClose }: MessageDesignPreviewProps) {
  const [selectedReminder, setSelectedReminder] = useState<string | null>(null);

  // Reset selection when dialog opens
  useEffect(() => {
    if (open) {
      setSelectedReminder(null);
    }
  }, [open]);

  const handleConfirm = () => {
    // Action confirmed
    onClose();
  };

  const handleReminder = (duration: string) => {
    // Reminder set for the specified duration
    setSelectedReminder(duration);
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl p-0 gap-0 [&>button]:text-white [&>button]:hover:bg-white/20 [&>button]:top-2 [&>button]:right-2 [&>button]:z-10">
        <DialogHeader className="sr-only">
          <DialogTitle>Message Design Preview</DialogTitle>
          <DialogDescription>
            Preview of the message design that will be sent to users
          </DialogDescription>
        </DialogHeader>

        {/* Message Card */}
        <div className="bg-white rounded-lg overflow-hidden">
          {/* Header Bar */}
          <div className="bg-gradient-to-r from-purple-900 to-purple-950 px-6 py-4 flex items-center justify-between pr-16">
            <div className="flex items-center gap-3">
              <div className="text-white text-[20px] font-bold">Company IT</div>
            </div>
            <div className="w-24">
              <Group2 />
            </div>
          </div>

          {/* Message Body */}
          <div className="px-8 py-10">
            <h2 className="text-gray-900 text-2xl mb-4">
              We identified some issues on your device
            </h2>
            <p className="text-gray-600 mb-6">
              Our system has detected configuration issues that may affect your device performance. 
              We can automatically fix these issues for you. Would you like us to proceed?
            </p>

            {/* Reminder Selector */}
            <div className="bg-gray-50 border border-gray-200 rounded-lg p-5 mb-6">
              <label className="block text-gray-700 mb-3">
                Remind me in:
              </label>
              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => handleReminder('1hour')}
                  className={`px-4 py-2 rounded-md transition-all ${
                    selectedReminder === '1hour'
                      ? 'bg-indigo-600 text-white shadow-md'
                      : 'bg-white text-gray-700 border border-gray-300 hover:border-indigo-400'
                  }`}
                >
                  1 Hour
                </button>
                <button
                  onClick={() => handleReminder('2hours')}
                  className={`px-4 py-2 rounded-md transition-all ${
                    selectedReminder === '2hours'
                      ? 'bg-indigo-600 text-white shadow-md'
                      : 'bg-white text-gray-700 border border-gray-300 hover:border-indigo-400'
                  }`}
                >
                  2 Hours
                </button>
                <button
                  onClick={() => handleReminder('4hours')}
                  className={`px-4 py-2 rounded-md transition-all ${
                    selectedReminder === '4hours'
                      ? 'bg-indigo-600 text-white shadow-md'
                      : 'bg-white text-gray-700 border border-gray-300 hover:border-indigo-400'
                  }`}
                >
                  4 Hours
                </button>
                <button
                  onClick={() => handleReminder('8hours')}
                  className={`px-4 py-2 rounded-md transition-all ${
                    selectedReminder === '8hours'
                      ? 'bg-indigo-600 text-white shadow-md'
                      : 'bg-white text-gray-700 border border-gray-300 hover:border-indigo-400'
                  }`}
                >
                  8 Hours
                </button>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-3">
              <button 
                onClick={handleConfirm}
                className="flex-1 bg-purple-900 text-white px-6 py-3 rounded-lg hover:bg-purple-950 transition-colors shadow-sm"
              >
                Yes, Fix It Now
              </button>
              <button 
                onClick={onClose}
                className="flex-1 bg-white text-gray-700 px-6 py-3 rounded-lg border border-gray-300 hover:bg-gray-50 transition-colors"
              >
                No, Thanks
              </button>
            </div>
          </div>

          {/* Footer Info */}
          <div className="bg-gray-50 px-8 py-4 border-t border-gray-200">
            <p className="text-xs text-gray-500">
              This is a preview of how your message will appear to end users. 
              Actual content can be customized in the message editor.
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}