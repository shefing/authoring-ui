import { BroadcastMessage } from './BroadcastDashboard';
import { X, ExternalLink } from 'lucide-react';

interface MessagePreviewProps {
  message: BroadcastMessage;
  onClose: () => void;
}

export function MessagePreview({ message, onClose }: MessagePreviewProps) {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-2xl w-full overflow-hidden shadow-xl">
        {/* Preview Header */}
        <div className="border-b border-gray-200 px-6 py-4 bg-gray-50">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-gray-900">Message Preview</h3>
              <p className="text-gray-600 text-sm mt-1">This is how the message will appear to end users</p>
            </div>
            <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        {/* Device Preview Container */}
        <div className="p-8 bg-gray-100">
          <div className="bg-gray-800 rounded-lg p-1 max-w-md mx-auto shadow-2xl">
            {/* Device Header */}
            <div className="bg-gray-900 rounded-t-lg px-4 py-2 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-red-500"></div>
                <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                <div className="w-3 h-3 rounded-full bg-green-500"></div>
              </div>
              <p className="text-gray-400 text-xs">End-User Device</p>
            </div>

            {/* Device Screen */}
            <div className="bg-gray-700 p-8 rounded-b-lg min-h-[400px] flex items-center justify-center">
              {/* Popup Message */}
              <div 
                className={`bg-white rounded-lg shadow-2xl max-w-sm w-full ${
                  message.branding === 'remediation' ? 'border-t-4 border-orange-500' : 'border-t-4 border-blue-500'
                }`}
              >
                {/* Message Header */}
                <div className="px-6 pt-6 pb-4">
                  <h4 className="text-gray-900">{message.title}</h4>
                </div>

                {/* Message Content */}
                <div className="px-6 pb-6">
                  <p className="text-gray-700 leading-relaxed">{message.content}</p>
                  
                  {/* Optional Link */}
                  {message.link && (
                    <a
                      href={message.link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className={`inline-flex items-center gap-1 mt-4 ${
                        message.branding === 'remediation' ? 'text-orange-600 hover:text-orange-700' : 'text-blue-600 hover:text-blue-700'
                      }`}
                    >
                      <span className="text-sm">Learn more</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  )}
                </div>

                {/* Message Footer with OK Button */}
                <div className="border-t border-gray-200 px-6 py-4 bg-gray-50 rounded-b-lg">
                  <button
                    className={`w-full py-2 rounded-lg text-white transition-colors ${
                      message.branding === 'remediation' 
                        ? 'bg-orange-600 hover:bg-orange-700' 
                        : 'bg-blue-600 hover:bg-blue-700'
                    }`}
                  >
                    OK
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Preview Footer - Message Details */}
        <div className="border-t border-gray-200 px-6 py-4 bg-gray-50">
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <p className="text-gray-600">Target Group</p>
              <p className="text-gray-900 mt-1">{message.targetGroup}</p>
            </div>
            <div>
              <p className="text-gray-600">Expiration Period</p>
              <p className="text-gray-900 mt-1">{message.expirationPeriod} {message.expirationUnit}</p>
            </div>
            <div>
              <p className="text-gray-600">Branding</p>
              <p className="text-gray-900 mt-1 capitalize">{message.branding}</p>
            </div>
            <div>
              <p className="text-gray-600">Status</p>
              <p className="text-gray-900 mt-1 capitalize">{message.status}</p>
            </div>
          </div>
        </div>

        {/* Close Button */}
        <div className="border-t border-gray-200 px-6 py-4 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
          >
            Close Preview
          </button>
        </div>
      </div>
    </div>
  );
}
